/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    $('#tbTablas').dataTable({
        lengthChange: false
    });

    $('select#base').select2({
        placeholder: 'Seleccione una opcion',
        theme: "bootstrap",
        minimumInputLength: 2,
        ajax: {
            url: "../vistas/procesaElegirBase.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('.datos').click(function () {
        $("#mdtBase").val($(this).parents("tr").find('td:eq(0)').text());
        $("#mdtNombre").val($(this).parents("tr").find('td:eq(1)').text());
        $("#mdtCreacion").val($(this).parents("tr").find('td:eq(2)').text());
        $("#mdtEdicion").val($(this).parents("tr").find('td:eq(3)').text());
        $("#mdtProceso").val($(this).parents("tr").find('td:eq(4)').text());
        $("#mdtDescripcion").val($(this).parents("tr").find('td:eq(5)').text());
        $("#ModalDatosTabla").modal({});
    });

    $('.editar').click(function () {
        var idTabla = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formModificarTabla.php",
            data: "idTabla=" + idTabla,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#seccionInferior").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    $('.detalle').click(function () {
        var idTabla = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formDetalleTabla.php",
            data: "idTabla=" + idTabla,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#seccionInferior").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });


});