<?php
require_once './header.php';
if (isset($_SESSION['usuario'])) {
    $usuario = $_SESSION['usuario'];
    $legajo = $usuario->getId();
    $nombre = $usuario->getNombre();
    $nombrePerfil = $usuario->getPerfil()->getNombre();
    $descripcionPerfil = $usuario->getPerfil()->getDescripcion();
    $cardUsuario = '
        <div class="card border-azul-clasico">
            <div class="card-header bg-azul-clasico text-white"> Información de usuario</div>
            <div class="card-body">
                <div class="container">
                    <div class="form-row">
                        <label class="col-3 col-form-label text-left">Número de legajo:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" value="' . $legajo . '" readonly>
                        </div>
                    </div>
                    <div class="form-row">
                        <label class="col-3 col-form-label text-left">Nombre de usuario:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" value="' . $nombre . '" readonly>
                        </div>
                    </div>
                    <div class="form-row">
                        <label class="col-3 col-form-label text-left">Perfil asignado:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" value="' . $nombrePerfil . '" readonly>
                        </div>
                    </div>
                    <div class="form-row">
                        <label class="col-3 col-form-label text-left">Detalle del perfil:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" value="' . $descripcionPerfil . '" readonly>
                        </div>
                    </div>
                </div>
            </div>
        </div>';
}
?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3">
            <div class="col text-left">
                <h4><i class="fas fa-home"></i> WEB CONTROL DE APLICACIONES E INVENTARIO DE ACTIVOS</h4>
            </div>
        </div>
        <div class="mt-3 mb-4">
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active"><?= $cardUsuario; ?></div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="..." alt="Second slide">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        $('.carousel').carousel();
    });
</script>