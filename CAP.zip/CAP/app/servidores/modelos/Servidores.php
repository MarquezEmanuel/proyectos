<?php

/**
 * Description of Servidores
 *
 * @author Emanuel
 */
class Servidores {

    private static $mensaje;

    public static function getMensaje() {
        return self::$mensaje;
    }

    public static function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM ser_servidor WHERE nombre LIKE ? AND ambiente = ? AND estado = ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array('%' . $nombre . '%', &$estado));
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public static function listarUltimosCreados() {
        $consulta = "SELECT TOP(10) * FROM ser_servidor WHERE estado = 'Activo' ORDER BY id";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public static function seleccionar($nombre, $ambiente, $tipo) {
        $consulta = "SELECT * FROM ser_servidor WHERE nombre LIKE ? AND ambiente = ? AND tipo = ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$nombre, &$ambiente, &$tipo));
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
