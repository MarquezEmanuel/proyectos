<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorAuxiliar();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $gerencia = $_POST['gerencia'];
    $empleado = $_POST['empleado'];
    $sitio = $_POST['sitio'];
    $datos = ($nombre) ? "'{$nombre}', " : "TODOS, ";
    $datos .= ($gerencia) ? "'{$gerencia}', " : "TODAS, ";
    $datos .= ($empleado) ? "'{$empleado}', " : "TODOS, ";
    $datos .= ($sitio) ? "'{$sitio}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $auxiliares = $controlador->consultar($nombre, $gerencia, $empleado, $sitio);
    $_SESSION['CAUXILIARES'] = array($nombre, $gerencia, $empleado, $sitio, $datos);
} else {
    if (isset($_SESSION['CAUXILIARES'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['CAUXILIARES'];
        $nombre = $parametros[0];
        $gerencia = $parametros[1];
        $empleado = $parametros[2];
        $sitio = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[4];
        $auxiliares = $controlador->consultar($nombre, $gerencia, $empleado, $sitio);
        $_SESSION['CAUXILIARES'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $auxiliares = $controlador->listarUltimosCreados();
        $filtro = "Resumen inicial";
        $_SESSION['CAUXILIARES'] = NULL;
    }
}

if (gettype($auxiliares) == "resource") {
    $filas = "";
    while ($auxiliar = sqlsrv_fetch_array($auxiliares, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr class='fila' title='Haga doble click para acceder a los detalles del elemento'>
                <td style='display: none;'>" . utf8_encode($auxiliar['asigla']) . "</td>
                <td>" . utf8_encode($auxiliar['anombre']) . "</td>
                <td>" . utf8_encode($auxiliar['gnombre']) . "</td>
                <td style='display: none;'>" . utf8_encode($auxiliar['eid']) . "</td>
                <td>" . utf8_encode($auxiliar['enombre']) . "</td> 
                <td style='display: none;'>" . utf8_encode($auxiliar['sid']) . "</td> 
                <td>" . utf8_encode($auxiliar['snombre']) . "</td> 
                <td style='display: none;'>" . utf8_encode($auxiliar['acantidad']) . "</td>
                <td style='display: none;'>" . utf8_encode($auxiliar['adescripcion']) . "</td>
                <td style='display: none;'>" . utf8_encode($auxiliar['arti']) . "</td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbAuxiliares" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th style="display: none;">Nombre corto</th>
                        <th>Nombre largo</th>
                        <th>Gerencia</th>
                        <th style="display: none;">Legajo delegado</th>
                        <th>Nombre delegado</th>
                        <th style="display: none;">Código sitio</th>
                        <th>Nombre sitio</th>
                        <th style="display: none;">Cantidad</th>
                        <th style="display: none;">Descripción</th>
                        <th style="display: none;">RTI</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($auxiliares == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($auxiliares, $mensaje);
}

echo ControladorHTML::getCardBusqueda($filtro, $cuerpo);
