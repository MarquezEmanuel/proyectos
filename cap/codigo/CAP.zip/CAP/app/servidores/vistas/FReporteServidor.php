<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
require_once '../../principal/vistas/header.php';

AutoCargador::cargarModulos();

$controlador = new ControladorServidor();
$resultado = 2;
if ($resultado == 2) {
    $total = $tproduccion = $ttest = $tdesarrollo = 0;
    $filas = "";

    $cuerpo = '
        <div class="row">
            <div class="col">
                <div class="card border-azul-clasico" title="Total de servidores">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>TOTAL</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $total . '</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card border-azul-clasico" title="Total de servidores en producción">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>PRODUCCIÓN</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $tproduccion . '</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card border-azul-clasico" title="Total de servidores en test">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>TEST</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $ttest . '</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card border-azul-clasico" title="Total de servidores en desarrollo">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>DESARROLLO</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $tdesarrollo . '</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col">
                <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white"><i class="fas fa-table"></i> Información resumida</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>IP</th>
                                        <th>Nombre</th>
                                        <th>Bases de datos</th>
                                        <th>Aplicaciones</th>
                                        <th>Jobs</th>
                                    </tr>
                                </thead>
                                <tbody>' . $filas . '</tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>';
} else {
    $filtro = "Información resumida";
    $mensaje = $controlador->getMensaje();
    $alerta = ControladorHTML::getAlertaOperacion($resultado, $mensaje);
    $cuerpo = ControladorHTML::getCardBusqueda($filtro, $alerta);
}
?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="fas fa-server"></i> REPORTE DE SERVIDORES</h4>
                </div>
            </div>
            <div class="mt-3 mb-4"><?= $cuerpo; ?></div>
        </div>
    </div>
</div>
