<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
require_once '../../principal/vistas/header.php';

AutoCargador::cargarModulos();

$controlador = new ControladorServidor();
$servidores = $controlador->listarReporte();
if (gettype($servidores) == "resource") {
    $total = $tproduccion = $ttest = $tdesarrollo = 0;
    $filas = "";
    while ($servidor = sqlsrv_fetch_array($servidores, SQLSRV_FETCH_ASSOC)) {
        $total = $total + 1;
        $tproduccion = ($servidor['ambiente'] === "Produccion") ? $tproduccion + 1 : $tproduccion;
        $ttest = ($servidor['ambiente'] === "Test") ? $ttest + 1 : $ttest;
        $tdesarrollo = ($servidor['ambiente'] === "Desarrollo") ? $tdesarrollo + 1 : $tdesarrollo;
        $filas .= "
            <tr>
                <td>" . utf8_encode($servidor['id']) . "</td>
                <td>" . utf8_encode($servidor['nombre']) . "</td>
                <td class='text-center'>{$servidor['aplicaciones']}</td>
                <td class='text-center'>{$servidor['bases']}</td>
                <td class='text-center'>{$servidor['jobs']}</td>
            </tr>";
    }
    $cuerpo = '
        <div class="row">
            <div class="col">
                <div class="card border-azul-clasico" title="Total de servidores">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>TOTAL</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $total . '</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card border-azul-clasico" title="Total de servidores en producción">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>PRODUCCIÓN</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $tproduccion . '</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card border-azul-clasico" title="Total de servidores en test">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>TEST</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $ttest . '</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card border-azul-clasico" title="Total de servidores en desarrollo">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>DESARROLLO</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $tdesarrollo . '</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-row mt-4">
            <div class="col-5">
                <div class="input-group">
                    <select class="custom-select" id="minimo" name="minimo" title="Cantidad minima de elementos">
                        <option value="1">1 elemento</option>
                        <option value="2">2 elementos</option>
                        <option value="3">3 elementos</option>
                        <option value="4">4 elementos</option>
                        <option value="5">5 elementos</option>
                        <option value="6">6 elementos</option>
                        <option value="7">7 elementos</option>
                        <option value="8">8 elementos</option>
                        <option value="9">9 elementos</option>
                        <option value="10">10 elementos</option>
                    </select>
                    <select class="custom-select" id="elemento" name="elemento">
                        <option value="2">Aplicaciones</option>
                        <option value="3">Bases de datos</option>
                        <option value="4">Jobs</option>
                    </select>
                    <div class="input-group-append">
                      <button class="btn btn-outline-success" id="btnGraficar" name="btnGraficar"
                              title="Graficar" type="button"><i class="fas fa-chart-pie"></i></button>
                    </div>
                </div>
            </div>
            <div class="col"></div>
        </div>
        <div class="row mt-4">
            <div class="col">
                <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white"><i class="fas fa-table"></i> Información resumida</div>
                    <div class="card-body">
                        <div class="table-responsive mt-4 mb-4">
                            <table id="tbReporteServidores" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>IP</th>
                                        <th>Nombre</th>
                                        <th>Aplicaciones</th>
                                        <th>Bases de datos</th>
                                        <th>Jobs</th>
                                    </tr>
                                </thead>
                                <tbody>' . $filas . '</tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4" id="seccionImagen" style="display: none;">
            <div class="col">
                <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white"><i class="fas fa-chart-pie"></i> Gráfico</div>
                    <div class="card-body">
                        <div class="text-center" id="imagen"></div>
                    </div>
                </div>
            </div>
        </div>';
} else {
    $filtro = "Información resumida";
    $mensaje = $controlador->getMensaje();
    $alerta = ControladorHTML::getAlertaOperacion($servidores, $mensaje);
    $cuerpo = ControladorHTML::getCardBusqueda($filtro, $alerta);
}
?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="fas fa-server"></i> REPORTE DE SERVIDORES</h4>
                </div>
            </div>
            <div class="mt-3 mb-4"><?= $cuerpo; ?></div>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/ReporteServidor.js"></script>
