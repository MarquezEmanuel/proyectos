<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['idServidor'])) {

    $controlador = new ControladorServidor();
    $id = $_POST['idServidor'];
    $nombre = utf8_decode($_POST['nombre']);
    $ip = $_POST['ip'];
    $ambiente = $_POST['ambiente'];
    $tipo = $_POST['tipo'];
    $descripcion = utf8_decode($_POST['descripcion']);

    $modificacion = $controlador->modificar($id, $nombre, $ip, $ambiente, $tipo, $descripcion);
    $mensaje = $controlador->getMensaje();
    switch ($modificacion) {
        case 2:
            $exito = true;
            $icono = "<i class='far fa-check-circle'></i>";
            $clase = 'class="alert alert-success text-center"';
            break;
        case 1:
            $icono = "<i class='fas fa-exclamation-circle'></i>";
            $clase = 'class="alert alert-warning text-center"';
            break;
        case 0:
            $icono = "<i class='fas fa-exclamation-triangle'></i>";
            $clase = 'class="alert alert-danger text-center"';
            break;
    }
    $resultado = "<div {$clase} role='alert'>{$icono} <strong>{$mensaje}</strong></div>";
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = "<div class='alert alert-danger text-center' role='alert'><i class='fas fa-exclamation-circle'></i> <strong>{$mensaje}</strong></div>";
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
