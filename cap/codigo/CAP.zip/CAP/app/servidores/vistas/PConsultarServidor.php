<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorServidor();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $tipo = $_POST['tipo'];
    $ambiente = $_POST['ambiente'];
    $servidores = $controlador->consultar($nombre, $tipo, $ambiente);
    $datos = ($nombre) ? "'{$nombre}', " : "TODOS, ";
    $datos .= ($tipo) ? "'{$tipo}', " : "TODOS, ";
    $datos .= ($ambiente) ? "'{$ambiente}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $_SESSION['CSERVIDORES'] = array($nombre, $tipo, $ambiente, $datos);
} else {
    if (isset($_SESSION['CSERVIDORES'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['CSERVIDORES'];
        $nombre = $parametros[0];
        $tipo = $parametros[1];
        $ambiente = $parametros[2];
        $servidores = $controlador->consultar($nombre, $tipo, $ambiente);
        $filtro = "Ultima búsqueda realizada: " . $parametros[3];
        $_SESSION['CSERVIDORES'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $servidores = $controlador->listarUltimosCreados();
        $filtro = "Resumen inicial";
        $_SESSION['CSERVIDORES'] = NULL;
    }
}

if (gettype($servidores) == "resource") {
    $filas = "";
    while ($servidor = sqlsrv_fetch_array($servidores, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr>
                <td>" . utf8_encode($servidor['id']) . "</td>
                <td>" . utf8_encode($servidor['nombre']) . "</td>
                <td>" . utf8_encode($servidor['ambiente']) . "</td>
                <td>" . utf8_encode($servidor['tipo']) . "</td>
                <td style='display: none;'>" . utf8_encode($servidor['descripcion']) . "</td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbServidores" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>IP</th>
                        <th>Nombre</th>
                        <th>Ambiente</th>
                        <th>Tipo</th>
                        <th style="display: none;">Descripción</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($servidores == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($servidores, $mensaje);
}
$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
