<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorJob();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $servidor = $_POST['servidor'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $jobs = $controlador->consultar($servidor, $nombre, $descripcion);
    $datos = ($servidor) ? "'{$servidor}', " : "TODOS, ";
    $datos .= ($nombre) ? "'{$nombre}', " : "TODOS, ";
    $datos .= ($descripcion) ? "'{$descripcion}'" : "TODAS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $_SESSION['CJOBS'] = array($servidor, $nombre, $descripcion, $datos);
} else {
    if (isset($_SESSION['CJOBS'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['CJOBS'];
        $servidor = $parametros[0];
        $nombre = $parametros[1];
        $descripcion = $parametros[2];
        $jobs = $controlador->consultar($servidor, $nombre, $descripcion);
        $filtro = "Ultima búsqueda realizada: " . $parametros[3];
        $_SESSION['CJOBS'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $jobs = $controlador->listarUltimosProcesados();
        $filtro = "Resumen inicial";
        $_SESSION['CJOBS'] = NULL;
    }
}


if (gettype($jobs) == "resource") {
    $filas = "";
    while ($job = sqlsrv_fetch_array($jobs, SQLSRV_FETCH_ASSOC)) {
        $fechaCreacion = isset($job['fechaCreacion']) ? date_format($job['fechaCreacion'], 'd/m/Y') : "";
        $fechaEdicion = isset($job['fechaEdicion']) ? date_format($job['fechaEdicion'], 'd/m/Y') : "";
        $fechaProceso = isset($job['fechaProceso']) ? date_format($job['fechaProceso'], 'd/m/Y') : "";
        $filas .= "
            <tr>
                <td>" . utf8_encode($job['servidor']) . "</td>
                <td>" . utf8_encode($job['nombre']) . "</td>
                <td>" . utf8_encode($job['categoria']) . "</td>
                <td>" . utf8_encode($job['version']) . "</td>
                <td>" . utf8_encode($job['pasos']) . "</td>
                <td style='display: none;'>{$fechaCreacion}</td>
                <td style='display: none;'>{$fechaEdicion}</td>
                <td style='display: none;'>" . utf8_encode($job['descripcion']) . "</td>
                <td style='display: none;'>{$fechaProceso}</td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbJobs" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Servidor</th>
                        <th>Nombre</th>
                        <th>Categoria</th>
                        <th>Versión</th>
                        <th>Pasos</th>
                        <th style="display: none;">Fecha creación</th>
                        <th style="display: none;">Fecha edición</th>
                        <th style="display: none;">Descripción</th>
                        <th style="display: none;">Fecha proceso</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($jobs == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($jobs, $mensaje);
}
$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
