<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Jobs {

    private static $mensaje;

    public static function getMensaje() {
        return self::$mensaje;
    }

    public static function consultar($servidor, $nombre, $descripcion) {
        $consulta = "SELECT * FROM ser_job WHERE servidor LIKE ? AND nombre LIKE ? AND descripcion LIKE ?";
        Log::escribirLineaError($consulta."   -- ".$servidor." | ".$nombre." | ".$descripcion);
        $datos = array('%' . $servidor . '%', '%' . $nombre . '%', '%' . $descripcion . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public static function listarUltimosProcesados() {
        $consulta = "SELECT TOP(10) * FROM ser_job ORDER BY fechaProceso DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
