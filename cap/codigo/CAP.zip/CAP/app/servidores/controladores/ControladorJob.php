<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ControladorJob {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function consultar($servidor, $nombre, $descripcion) {
        $resultado = Jobs::consultar($servidor, $nombre, $descripcion);
        $this->mensaje = Jobs::getMensaje();
        return $resultado;
    }

    public function listarUltimosProcesados() {
        $resultado = Jobs::listarUltimosProcesados();
        $this->mensaje = Jobs::getMensaje();
        return $resultado;
    }

}
