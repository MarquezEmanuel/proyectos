/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    /* CARGA LA FECHA DEL DIA ACTUAL PARA USAR EN LOS NOMBRES DE ARCHIVOS */

    var hoy = new Date();
    var fecha = hoy.getDate() + "_" + (hoy.getMonth() + 1) + "_" + hoy.getFullYear();

    $('#tbReporteSitios').dataTable({
        dom: 'Bfrtip',
        lengthChange: false,
        paging: false,
        buttons: [{
                extend: 'excelHtml5',
                title: fecha + '_REPORTE_SITIOS'
            }
        ],
        language: {url: "../../../lib/JQuery/Spanish.json"}
    });

    $("#btnGraficar").click(function () {
        $("#seccionImagen").show();
        google.charts.load('current', {'packages': ['corechart']});
        google.charts.setOnLoadCallback(drawChart);
        function drawChart() {
            var tipo = $("#elemento :selected").text();
            var columna = $("#elemento :selected").val();
            var minimo = $("#minimo :selected").val();
            var registros = [];
            registros.push(["Sitio", "Total", {role: "style"}]);

            $("#tbReporteSitios tbody tr").each(function () {
                var sitio = $(this).find('td:eq(1)').text();
                var dato = $(this).find('td:eq(' + columna + ')').text();
                if (parseInt(dato, 10) >= minimo) {
                    registros.push([sitio, parseInt(dato, 10), "color: #1B4F72"]);
                }
            });
            if (registros.length > 1) {
                var data = google.visualization.arrayToDataTable(registros);
                var view = new google.visualization.DataView(data);
                var options = {
                    title: "Total de " + tipo + " por sitio",
                    width: "100%",
                    height: 1000,
                    bar: {groupWidth: "20%"},
                    legend: {position: "none"},
                    hAxis: {slantedText: true, slantedTextAngle: 90}
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("imagen"));
                chart.draw(view, options);
            } else {
                var men = '<b>El criterio no supera el valor minimo de elementos para graficar</b>';
                var div = '<div class="alert alert-warning text-center" role="alert">' + men + '</div>';
                $("#imagen").html(div);
            }
            $('html,body').animate({scrollTop: $("#seccionImagen").offset().top}, '1250');
        }
    });

});

