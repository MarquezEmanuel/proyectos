<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
require_once '../../principal/vistas/header.php';

AutoCargador::cargarModulos();

$controlador = new ControladorSitio();
$resultado = 2;
if ($resultado == 2) {
    $total = $tsucursal = $tcpd = $tsar = 0;
    $filas = "";
    $cuerpo = '
        <div class="row">
            <div class="col">
                <div class="card border-azul-clasico" title="Total de sitios">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>TOTAL</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $total . '</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card border-azul-clasico" title="Total de sucursales">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>SUCURSAL</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $tsucursal . '</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card border-azul-clasico" title="Total de centros de procesamientos de datos">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>CPD</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $tcpd . '</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card border-azul-clasico" title="Total de sitios de almacenamiento de resguardos">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>SAR</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $tsar . '</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col">
                <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white"><i class="fas fa-table"></i> Información resumida</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Nombre</th>
                                        <th>Comunicación</th>
                                        <th>Firewall</th>
                                        <th>Hardware</th>
                                        <th>Instalación</th>
                                        <th>Switch</th>
                                    </tr>
                                </thead>
                                <tbody>' . $filas . '</tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>';
} else {
    $filtro = "Información resumida";
    $mensaje = $controlador->getMensaje();
    $alerta = ControladorHTML::getAlertaOperacion($resultado, $mensaje);
    $cuerpo = ControladorHTML::getCardBusqueda($filtro, $alerta);
}
?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="far fa-building"></i> REPORTE DE SITIOS</h4>
                </div>
            </div>
            <div class="mt-3 mb-4"><?= $cuerpo; ?></div>
        </div>
    </div>
</div>