<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorInstalacion();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $gerencia = $_POST['gerencia'];
    $empleado = $_POST['empleado'];
    $sitio = $_POST['sitio'];
    $datos = ($nombre) ? "'{$nombre}', " : "TODAS, ";
    $datos .= ($gerencia) ? "'{$gerencia}', " : "TODAS, ";
    $datos .= ($empleado) ? "'{$empleado}', " : "TODOS, ";
    $datos .= ($sitio) ? "'{$sitio}', " : "TODOS, ";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $instalaciones = $controlador->consultar($nombre, $gerencia, $empleado, $sitio);
    $_SESSION['CINSTALACIONES'] = array($nombre, $gerencia, $empleado, $sitio, $datos);
} else {
    if (isset($_SESSION['CINSTALACIONES'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['CINSTALACIONES'];
        $nombre = $parametros[0];
        $gerencia = $parametros[1];
        $empleado = $parametros[2];
        $sitio = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[4];
        $instalaciones = $controlador->buscar($nombre, $estado);
        $_SESSION['CINSTALACIONES'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $instalaciones = $controlador->listarUltimasCreadas();
        $filtro = "Resumen inicial";
        $_SESSION['CINSTALACIONES'] = NULL;
    }
}

if (gettype($instalaciones) == "resource") {
    $filas = "";
    while ($instalacion = sqlsrv_fetch_array($instalaciones, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr class='fila' title='Haga doble click para acceder a los detalles del elemento'>
                <td>" . utf8_encode($instalacion['isigla']) . "</td>
                <td>" . utf8_encode($instalacion['inombre']) . "</td>
                <td>" . utf8_encode($instalacion['gnombre']) . "</td>
                <td style='display: none;'>" . utf8_encode($instalacion['eid']) . "</td> 
                <td>" . utf8_encode($instalacion['enombre']) . "</td> 
                <td style='display: none;'>" . utf8_encode($instalacion['sid']) . "</td> 
                <td>" . utf8_encode($instalacion['snombre']) . "</td>
                <td style='display: none;'>" . utf8_encode($instalacion['pnombre']) . "</td> 
                <td style='display: none;'>{$instalacion['irti']}</td> 
                <td style='display: none;'>" . utf8_encode($instalacion['idescripcion']) . "</td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbInstalaciones" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre corto</th>
                        <th>Nombre largo</th>
                        <th>Gerencia</th>
                        <th style="display: none;">Legajo responsable</th>
                        <th>Nombre reesponsable</th>
                        <th style="display: none;">Código sitio</th>
                        <th>Nombre sitio</th>
                        <th style="display: none;">Plataforma</th>
                        <th style="display: none;">RTI</th>
                        <th style="display: none;">Descripción</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($instalaciones == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($instalaciones, $mensaje);
}

echo ControladorHTML::getCardBusqueda($filtro, $cuerpo);

