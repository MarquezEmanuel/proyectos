<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorFirewall();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $marca = $_POST['marca'];
    $ip = $_POST['ip'];
    $sitio = $_POST['sitio'];
    $datos = ($nombre) ? "'{$nombre}', " : "TODOS, ";
    $datos .= ($marca) ? "'{$marca}', " : "TODAS, ";
    $datos .= ($ip) ? "'{$ip}', " : "TODAS, ";
    $datos .= ($sitio) ? "'{$sitio}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $firewalls = $controlador->consultar($nombre, $marca, $ip, $sitio);
    $_SESSION['CFIREWALLS'] = array($nombre, $marca, $ip, $sitio, $datos);
} else {
    if (isset($_SESSION['CFIREWALLS'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['CFIREWALLS'];
        $nombre = $parametros[0];
        $marca = $parametros[1];
        $ip = $parametros[2];
        $sitio = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[4];
        $firewalls = $controlador->consultar($nombre, $marca, $ip, $sitio);
        $_SESSION['CFIREWALLS'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $firewalls = $controlador->listarUltimosCreados();
        $filtro = "Resumen inicial";
        $_SESSION['CFIREWALLS'] = NULL;
    }
}

if (gettype($firewalls) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($firewall = sqlsrv_fetch_array($firewalls, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr class='fila' title='Haga doble click para acceder a los detalles del elemento'>
                <td>" . utf8_encode($firewall['fnombre']) . "</td>
                <td>" . utf8_encode($firewall['fmarca']) . "</td>
                <td>" . utf8_encode($firewall['fmodelo']) . "</td> 
                <td>" . utf8_encode($firewall['fnumeroSerie']) . "</td>
                <td style='display: none;'>" . utf8_encode($firewall['fversion']) . "</td>
                <td>{$firewall['fip']}</td>
                <td style='display: none;'>{$firewall['sid']}</td>
                <td>" . utf8_encode($firewall['snombre']) . "</td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbFirewalls" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Nro serie</th>
                        <th style="display: none;">Versión</th>
                        <th>IP</th>
                        <th style="display: none;">Código sitio</th>
                        <th>Nombre sitio</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($firewalls == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($firewalls, $mensaje);
}

echo ControladorHTML::getCardBusqueda($filtro, $cuerpo);
