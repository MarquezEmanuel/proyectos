<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="fas fa-code-branch"></i> BUSCAR INSTALACIÓN</h4>
                </div>
                <div class="col text-right">
                    <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
                </div>
            </div>
            <div class="mt-3 mb-4">
                <form method="POST" id="formBuscarInstalacion" name="formBuscarInstalacion">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="nombre" class="col-2 col-form-label text-left">Nombre:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombre" id="nombre" 
                                           maxlength="9" pattern="[A-Za-z0-9]{1,9}"
                                           title="Nombre de la instalacion: campo no obligatorio"
                                           placeholder="Nombre de la instalación">
                                </div>
                                <label for="estado" class="col-2 col-form-label text-left">* Estado:</label>
                                <div class="col">
                                    <select id="estado" name="estado" class="form-control mb-2" required>
                                        <option value="Activa">Activa</option>
                                        <option value="Inactiva">Inactiva</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success" name="btnBuscarInstalacion"><i class="fas fa-search"></i>  BUSCAR</button>
                            <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                        </div>
                    </div>
                </form>
            </div>
            <br>
            <div id="seccionInferior" class="mt-4 mb-2">
                <?php require_once './procesaBuscarInstalacion.php'; ?>
            </div>
        </div>
        <div class="modal fade" id="ModalCambioEstadoInstalacion" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg border-azul-clasico">
                <div class="modal-content">
                    <div class="modal-header bg-azul-clasico text-white">
                        <h4 class="modal-title text-center" id="tituloModal"></h4>
                    </div>
                    <div class="modal-body" id="cuerpoModal">
                        <form id="formCambioEstadoInstalacion" name="formCambioEstadoInstalacion" method="POST">
                            <input type="hidden" name="modalAccion" id="modalAccion">
                            <input type="hidden" name="modalIdInstalacion" id="modalIdInstalacion">
                            <div class="form-row">
                                <label for="nombre" class="col-sm-2 col-form-label text-left">Nombre:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="modalNombre" id="modalNombre" readonly>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success"
                                name="btnCambiarEstadoInstalacion" id="btnCambiarEstadoInstalacion">
                            <i class="far fa-save"></i> GUARDAR</button>
                        <input type='submit' class='btn btn-outline-secondary' 
                               style="display: none;"
                               name="btnRefrescarPantalla" id="btnRefrescarPantalla" value='Aceptar'>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="ModalDatosInstalacion" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg border-azul-clasico">
                <div class="modal-content">
                    <div class="modal-header bg-azul-clasico text-white">
                        <h4 class="modal-title text-center"><i class="fas fa-microchip"></i> DATOS BÁSICOS</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-row">
                            <label for="mdiInventario" class="col-sm-2 col-form-label">Inventario:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       name="mdiInventario" id="mdiInventario" readonly>
                            </div>
                            <label for="mdISigla" class="col-sm-2 col-form-label">Nombre corto:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       name="mdiSigla" id="mdiSigla" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <label for="mdiNombre" class="col-sm-2 col-form-label">Nombre largo:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       name="mdiNombre" id="mdiNombre" readonly>
                            </div>
                            <label for="mdiGerencia" class="col-sm-2 col-form-label">Gerencia:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       name="mdiGerencia" id="mdiGerencia" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <label for="mdiLegajo" class="col-sm-2 col-form-label">Legajo:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       name="mdiLegajo" id="mdiLegajo" readonly>
                            </div>
                            <label for="mdiResponsable" class="col-sm-2 col-form-label">Responsable:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       name="mdiResponsable" id="mdiResponsable" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <label for="mdiSitio" class="col-sm-2 col-form-label">Ubicación:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       name="mdiSitio" id="mdiSitio" readonly>
                            </div>
                            <label for="mdiPlataforma" class="col-sm-2 col-form-label">Plataforma:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       name="mdiPlataforma" id="mdiPlataforma" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <label for="mdiRTI" class="col-sm-2 col-form-label">RTI:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       name="mdiRTI" id="mdiRTI" readonly>
                            </div>
                            <label class="col-sm-2 col-form-label"></label>
                            <div class="col"></div>
                        </div>
                        <div class="form-row">
                            <label for="mdiDescripcion" class="col-sm-2 col-form-label">Descripción:</label>
                            <div class="col">
                                <textarea type="text" class="form-control mb-2" 
                                          name="mdiDescripcion" id="mdiDescripcion" readonly></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type='submit' class='btn btn-outline-secondary' data-dismiss="modal" value='Aceptar'>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/BuscarInstalacion.js"></script>