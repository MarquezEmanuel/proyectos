<?php

/**
 * Description of ServicioInterno
 *
 * @author Emanuel
 */
class ServicioInterno {

    private $id;
    private $sigla;
    private $nombre;
    private $departamento;
    private $disponibilidad;
    private $integridad;
    private $confidencialidad;
    private $autenticidad;
    private $rti;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $sigla = NULL, $nombre = NULL, $departamento = NULL, $disponibilidad = NULL, $integridad = NULL, $confidencialidad = NULL, $autenticidad = NULL, $rti = NULL, $estado = NULL) {
        $this->id = $id;
        $this->sigla = utf8_decode(strtoupper($sigla));
        $this->nombre = utf8_decode($nombre);
        $this->departamento = $departamento;
        $this->disponibilidad = $disponibilidad;
        $this->integridad = $integridad;
        $this->confidencialidad = $confidencialidad;
        $this->autenticidad = $autenticidad;
        $this->rti = utf8_decode($rti);
        $this->estado = $estado;
    }

    public function getId() {
        return $this->id;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getDepartamento() {
        return $this->departamento;
    }

    public function getDisponibilidad() {
        return $this->disponibilidad;
    }

    public function getIntegridad() {
        return $this->integridad;
    }

    public function getConfidencialidad() {
        return $this->confidencialidad;
    }

    public function getAutenticidad() {
        return $this->autenticidad;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setSigla($sigla) {
        $this->sigla = utf8_encode($sigla);
    }

    public function setNombre($nombre) {
        $this->nombre = utf8_decode(strtoupper($nombre));
    }

    public function setDepartamento($departamento) {
        $this->departamento = $departamento;
    }

    public function setDisponibilidad($disponibilidad) {
        $this->disponibilidad = $disponibilidad;
    }

    public function setIntegridad($integridad) {
        $this->integridad = $integridad;
    }

    public function setConfidencialidad($confidencialidad) {
        $this->confidencialidad = $confidencialidad;
    }

    public function setAutenticidad($autenticidad) {
        $this->autenticidad = $autenticidad;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = '{$this->estado}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("ser_servicio_interno", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 'Activo') ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crear() {
        if ($this->sigla && $this->nombre && $this->departamento && $this->rti) {
            $values = "('{$this->sigla}','{$this->nombre}', {$this->departamento}, {$this->disponibilidad}, {$this->integridad}, {$this->confidencialidad}, {$this->autenticidad}, '{$this->rti}', 'Activo')";
            $creacion = SQLServer::instancia()->insertar("ser_servicio_interno", $values);
            $this->mensaje = $this->getNombre() . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->crearRelacion();
            }
            return $creacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    private function crearRelacion() {
        $consulta = "INSERT INTO ser_servicio_interno_inventario "
                . "SELECT {$this->id}, id FROM inv_inventario WHERE estado = 'Activo'";
        $creacion = SQLServer::instancia()->ejecutar($consulta);
        $this->mensaje = $this->getNombre() . ": " . SQLServer::instancia()->getMensaje();
        if ($creacion == 2) {
            return $this->registrarActividad("CREACION", $this->id);
        }
        return $creacion;
    }

    public function modificar() {
        if ($this->sigla && $this->nombre && $this->departamento && $this->rti) {
            $campos = "sigla='{$this->sigla}', nombre='{$this->nombre}', departamento={$this->departamento}, "
                    . "disponibilidad={$this->disponibilidad}, integridad={$this->integridad}, confidencialidad={$this->confidencialidad}, "
                    . "autenticidad={$this->autenticidad}, rti='{$this->rti}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("ser_servicio_interno", $campos, $condicion);
            $this->mensaje = $this->getNombre() . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM ser_servicio_interno WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!empty($fila)) {
                $this->nombre = $fila['sigla'];
                $this->nombre = $fila['nombre'];
                $this->disponibilidad = $fila['disponibilidad'];
                $this->integridad = $fila['integridad'];
                $this->confidencialidad = $fila['confidencialidad'];
                $this->autenticidad = $fila['autenticidad'];
                $this->rti = $fila['rti'];
                $this->estado = $fila['estado'];
                return $this->obtenerDepartamento($fila['departamento']);
            }
            $this->mensaje = "No se obtuvo la información del servicio interno";
            return 1;
        }
        $this->mensaje = "No se pudo hacer referencia al servicio interno";
        return 0;
    }

    private function obtenerDepartamento($idDepartamento) {
        $departamento = new Departamento($idDepartamento);
        $resultado = $departamento->obtener();
        $this->departamento = ($resultado == 2) ? $departamento : NULL;
        $this->mensaje = ($resultado == 2) ? $this->mensaje : "No se pudo obtener el departamento";
        return $resultado;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("ser_servicio_interno", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
