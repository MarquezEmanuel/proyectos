<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ServicioExterno {

    private $id;
    private $sigla;
    private $nombre;
    private $proveedores;
    private $disponibilidad;
    private $integridad;
    private $confidencialidad;
    private $autenticidad;
    private $rti;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $sigla = NULL, $nombre = NULL, $proveedores = NULL, $disponibilidad = NULL, $integridad = NULL, $confidencialidad = NULL, $autenticidad = NULL, $rti = NULL, $estado = NULL) {
        $this->id = $id;
        $this->sigla = utf8_decode(strtoupper($sigla));
        $this->nombre = utf8_decode($nombre);
        $this->proveedores = $proveedores;
        $this->disponibilidad = $disponibilidad;
        $this->integridad = $integridad;
        $this->confidencialidad = $confidencialidad;
        $this->autenticidad = $autenticidad;
        $this->rti = utf8_decode($rti);
        $this->estado = $estado;
    }

    public function getId() {
        return $this->id;
    }

    public function getSigla() {
        return utf8_encode($this->sigla);
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getProveedores() {
        return $this->proveedores;
    }

    public function getDisponibilidad() {
        return $this->disponibilidad;
    }

    public function getIntegridad() {
        return $this->integridad;
    }

    public function getConfidencialidad() {
        return $this->confidencialidad;
    }

    public function getAutenticidad() {
        return $this->autenticidad;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setSigla($sigla) {
        $this->sigla = utf8_decode(strtoupper($sigla));
    }

    public function setNombre($nombre) {
        $this->nombre = utf8_decode($nombre);
    }

    public function setProveedores($proveedores) {
        $this->proveedores = $proveedores;
    }

    public function setDisponibilidad($disponibilidad) {
        $this->disponibilidad = $disponibilidad;
    }

    public function setIntegridad($integridad) {
        $this->integridad = $integridad;
    }

    public function setConfidencialidad($confidencialidad) {
        $this->confidencialidad = $confidencialidad;
    }

    public function setAutenticidad($autenticidad) {
        $this->autenticidad = $autenticidad;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    private function borrarRelacionProveedores() {
        $rproveedores = new ServicioExternoProveedor();
        $eliminacion = $rproveedores->borrar($this->id);
        $this->mensaje = ($eliminacion == 2) ? $this->mensaje : $rproveedores->getMensaje();
        return $eliminacion;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = '{$this->estado}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("ser_servicio_interno", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 'Activo') ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crear() {
        if ($this->sigla && $this->nombre && $this->rti) {
            $values = "('{$this->sigla}','{$this->nombre}', {$this->departamento}, {$this->disponibilidad}, {$this->integridad}, {$this->confidencialidad}, {$this->autenticidad}, '{$this->rti}', 'Activo')";
            $creacion = SQLServer::instancia()->insertar("ser_servicio_interno", $values);
            $this->mensaje = $this->getNombre() . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion != 2) {
                return $creacion;
            }
            $this->id = SQLServer::instancia()->getUltimoId();
            $creaRelacionProveedores = $this->crearRelacionProveedores();
            if ($creaRelacionProveedores != 2) {
                return $creaRelacionProveedores;
            }
            return $this->crearRelacionInventario();
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    private function crearRelacionProveedores() {
        $rproveedores = new ServicioExternoProveedor();
        $creacion = $rproveedores->crear($this->id, $this->proveedores);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : $rproveedores->getMensaje();
        return $creacion;
    }

    private function crearRelacionInventario() {
        $consulta = "INSERT INTO ser_servicio_externo_inventario SELECT {$this->id}, id FROM inv_inventario WHERE estado = 'Activo'";
        $creacion = SQLServer::instancia()->ejecutar($consulta);
        $this->mensaje = $this->getNombre() . ": " . SQLServer::instancia()->getMensaje();
        return ($creacion == 2) ? $this->registrarActividad("CREACION", $this->id) : $creacion;
    }

    public function modificar() {
        if ($this->sigla && $this->nombre && $this->departamento && $this->rti) {
            $campos = "sigla='{$this->sigla}', nombre='{$this->nombre}', departamento={$this->departamento}, "
                    . "disponibilidad={$this->disponibilidad}, integridad={$this->integridad}, confidencialidad={$this->confidencialidad}, "
                    . "autenticidad={$this->autenticidad}, rti='{$this->rti}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("ser_servicio_interno", $campos, $condicion);
            $this->mensaje = $this->getNombre() . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion != 2) {
                return $modificacion;
            }
            $borrar = $this->borrarRelacionProveedores();
            $crear = $this->crearRelacionProveedores();
            if ($borrar == 2 && $crear == 2) {
                return $this->registrarActividad("MODIFICACION", $this->id);
            }
            return ($borrar <= $crear) ? $borrar : $crear;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM ser_servicio_externo WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!empty($fila)) {
                $this->nombre = $fila['sigla'];
                $this->nombre = $fila['nombre'];
                $this->disponibilidad = $fila['disponibilidad'];
                $this->integridad = $fila['integridad'];
                $this->confidencialidad = $fila['confidencialidad'];
                $this->autenticidad = $fila['autenticidad'];
                $this->rti = $fila['rti'];
                $this->estado = $fila['estado'];
                return $this->obtenerProveedores();
            }
            $this->mensaje = "No se obtuvo la información del servicio interno";
            return 1;
        }
        $this->mensaje = "No se pudo hacer referencia al servicio interno";
        return 0;
    }

    private function obtenerProveedores() {
        return 2;
    }

}
