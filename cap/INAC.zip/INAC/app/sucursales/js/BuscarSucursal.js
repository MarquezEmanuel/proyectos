/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function () {

    /* INICIALIZA DATATABLE */

    $('#tbSucursales').dataTable({
        lengthChange: false
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editarSucursal').click(function () {
        var idSucursal = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./app/sucursales/vistas/formModificarSucursal.php",
            data: "idSucursal=" + idSucursal,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('.bajaSucursal').click(function () {
        $("#tituloModal").html("<i class='fas fa-trash'></i> CONFIRME LA BAJA DE LA SUCURSAL");
        $("#modalAccion").val("BAJA");
        $("#modalCodigo").val($(this).parents("tr").find("td").eq(0).html());
        $("#modalNombre").val($(this).parents("tr").find("td").eq(2).html());
        $("#ModalCambioEstadoSucursal").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('.altaSucursal').click(function () {
        $("#tituloModal").html("<i class='fas fa-plus-circle'></i> CONFIRME EL ALTA DE LA SUCURSAL");
        $("#modalAccion").val("ALTA");
        $("#modalCodigo").val($(this).parents("tr").find("td").eq(0).html());
        $("#modalNombre").val($(this).parents("tr").find("td").eq(2).html());
        $("#ModalCambioEstadoSucursal").modal({backdrop: 'static', keyboard: false});
    });

    /* ENVIA LA OPERACION DE ALTA O BAJA Y MUESTRA EL RESULTADO EN EL MODAL */

    $('#btnCambiarEstadoSucursal').click(function () {
        $.ajax({
            type: "POST",
            url: "./app/sucursales/vistas/procesaCambiarEstadoSucursal.php",
            data: $("#formCambioEstadoSucursal").serialize(),
            success: function (data) {
                $('#cuerpoModal').html(data);
                $('#btnCambiarEstadoSucursal').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                $("#cuerpoModal").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });
    
    /* ACTUALIZA LA PANTALLA LUEGO DE HACER EL ALTA O BAJA */

    $('#btnRefrescarPantalla').click(function () {
        location.reload();
    });

});