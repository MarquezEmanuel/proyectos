/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    $('#tbSwitchs').dataTable({
        lengthChange: false
    });

    $('.editar').click(function () {
        var idSwitch = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formModificarSwitch.php",
            data: "idSwitch=" + idSwitch,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#seccionInferior").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    $('.baja').click(function () {
        $("#tituloModal").html("<i class='fas fa-trash'></i> CONFIRME LA BAJA DEL SWITCH");
        $("#modalAccion").val("BAJA");
        $("#modalCodigo").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalCambioEstadoSwitch").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('.alta').click(function () {
        $("#tituloModal").html("<i class='fas fa-plus-circle'></i> CONFIRME EL ALTA DEL SWITCH");
        $("#modalAccion").val("ALTA");
        $("#modalCodigo").val($(this).parents("tr").find("td").eq(0).html());
        $("#modalNombre").val($(this).parents("tr").find("td").eq(2).html());
        $("#ModalCambioEstadoSwitch").modal({backdrop: 'static', keyboard: false});
    });

    $('#btnCambiarEstadoSwitch').click(function () {
        $.ajax({
            type: "POST",
            url: "./procesaCambiarEstadoSwitch.php",
            data: $("#formCambioEstadoSwitch").serialize(),
            success: function (data) {
                $('#cuerpoModal').html(data);
                $('#btnCambiarEstadoSwitch').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                $("#cuerpoModal").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    $('#btnRefrescarPantalla').click(function () {
        location.reload();
    });

});

