<?php

/**
 * Description of Permisos
 *
 * @author Emanuel
 */
class Permisos {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $nivel) {
        $consulta = "SELECT * FROM reportePermisos WHERE titulo LIKE '%{$nombre}%' AND nivel = '{$nivel}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listar() {
        $consulta = "SELECT * FROM reportePermisos";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        return $this->evaluarResultado($resultado);
    }

    public function listarPorNivel($nivel) {
        $consulta = "SELECT * FROM seg_permisos WHERE nivel = {$nivel} ORDER BY titulo";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimosCreados() {
        $consulta = "SELECT TOP(10) * FROM reportePermisos ORDER BY id DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
