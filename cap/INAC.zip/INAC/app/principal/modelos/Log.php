<?php

class Log {

    public static function escribirLineaError($texto) {
        $date = date("H:i:s");
        $url = LOG . "\\" . date("Y_m_d") . ".txt";
        $file = file_exists($url) ? fopen($url, 'a') : fopen($url, 'w');
        $ip = $_SERVER["REMOTE_ADDR"];
        $script = $_SERVER["SCRIPT_NAME"];
        $user = ($_SESSION['usuario']) ? $_SESSION['usuario']->getId() : "";
        $data = "[HORA: {$date}][USUARIO: {$user}][IP: {$ip}][SCRIPT: {$script}][{$texto}]" . PHP_EOL;
        fwrite($file, $data);
    }

    public static function guardarActividad($tabla, $operacion, $registro) {
        if ($tabla && $operacion) {
            $values = "('07489', '{$tabla}', '{$operacion}', '{$registro}', GETDATE())";
            $creacion = SQLServer::instancia()->insertar("log_actividades", $values);
            return $creacion;
        }
        $this->escribirLineaError("No se pudo guardar actividad por falta de datos");
        return 1;
    }

}
