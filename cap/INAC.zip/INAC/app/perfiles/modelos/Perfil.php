<?php

/**
 * Description of Perfil
 *
 * @author 07489
 */
class Perfil {

    private $id;
    private $nombre;
    private $descripcion;
    private $permisos;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $nombre = NULL, $descripcion = NULL, $permisos = NULL, $estado = NULL) {
        $this->id = $id;
        $this->nombre = utf8_decode($nombre);
        $this->descripcion = utf8_decode($descripcion);
        $this->permisos = $permisos;
        $this->estado = $estado;
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function getPermisos() {
        return $this->permisos;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = utf8_decode($nombre);
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = utf8_encode($descripcion);
    }

    public function setPermisos($permisos) {
        $this->permisos = $permisos;
    }

    private function borrarRelacionPermisos() {
        $rpermisos = new PerfilPermiso();
        $borrar = $rpermisos->borrar($this->id);
        $this->mensaje = ($borrar == 2) ? $this->mensaje : $rpermisos->getMensaje();
        return $borrar;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = '{$this->estado}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("seg_perfil", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 'Activo') ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crear() {
        if ($this->nombre && $this->descripcion && $this->permisos) {
            $values = "('{$this->nombre}','{$this->descripcion}', 'Activo')";
            $creacion = SQLServer::instancia()->insertar("seg_perfil", $values);
            $this->mensaje = $this->getNombre() . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion != 2) {
                return $creacion;
            }
            $this->id = SQLServer::instancia()->getUltimoId();
            $crearRelacion = $this->crearRelacionPermisos();
            return ($crearRelacion == 2) ? $this->registrarActividad("CREACION", $this->id) : $crearRelacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    private function crearRelacionPermisos() {
        $rpermisos = new PerfilPermiso();
        $creacion = $rpermisos->crear($this->id, $this->permisos);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : $rpermisos->getMensaje();
        return $creacion;
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->descripcion && $this->permisos) {
            $campos = "nombre='{$this->nombre}', descripcion={$this->descripcion}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("seg_perfil", $campos, $condicion);
            $this->mensaje = $this->getNombre() . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion != 2) {
                return $modificacion;
            }
            $borrar = $this->borrarRelacionPermisos();
            $crear = $this->crearRelacionPermisos();
            if ($borrar == 2 && $crear == 2) {
                return $this->registrarActividad("MODIFICACION", $this->id);
            }
            return ($borrar <= $crear) ? $borrar : $crear;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM seg_perfiles WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->nombre = $fila['nombre'];
                $this->descripcion = $fila['descripcion'];
                $this->permisos = $this->obtenerPermisos();
                return 2;
            }
            $this->mensaje = "No se obtuvo la información del perfil";
            return 1;
        }
        $this->mensaje = "No se pudo hacer referencia al perfil";
        return 0;
    }

    private function obtenerPermisos() {
        $consulta = "SELECT id, titulo FROM [dbo].[seg_permisos] PER "
                . "INNER JOIN [dbo].[seg_perfiles_permisos] REL ON REL.permiso = PER.id AND "
                . "REL.perfil = {$this->id} WHERE PER.nivel = 1";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $arregloMenu = array();
        while ($menu = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
            $consultaSM = "SELECT * FROM [dbo].[seg_permisos] PER "
                    . "INNER JOIN [dbo].[seg_perfiles_permisos] REL ON REL.permiso = PER.id AND "
                    . "REL.perfil = {$this->id} WHERE PER.nivel = 2 AND padre = {$menu['id']}";
            $resultadoSM = SQLServer::instancia()->seleccionar($consultaSM);
            $arregloSubmenu = array();
            if (gettype($resultadoSM) != 'resource') {
                continue;
            }
            while ($submenu = sqlsrv_fetch_array($resultadoSM, SQLSRV_FETCH_ASSOC)) {
                $arregloSubmenu[] = array($submenu['id'], $submenu['titulo'], $submenu['link']);
            }
            $arregloMenu[] = array($menu['id'], $menu['titulo'], $arregloSubmenu);
        }
        return $arregloMenu;
    }

    public function obtenerVistas() {
        $consulta = "SELECT PER.link FROM [dbo].[seg_permisos] PER INNER JOIN [dbo].[seg_perfiles_permisos] REL ON REL.permiso = PER.id AND REL.perfil = {$this->id} WHERE PER.nivel = 2";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $vistas = array();
        while ($vista = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_NUMERIC)) {
            $vistas[] = $vista;
        }
        return $vistas;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("seg_perfiles", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
