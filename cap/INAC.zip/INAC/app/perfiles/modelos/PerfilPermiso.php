<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class PerfilPermiso {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function borrar($idPerfil) {
        if ($idPerfil) {
            $condicion = "id={$idPerfil}";
            $eliminacion = SQLServer::$instancia->borrar("seg_perfil_permiso", $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            return $eliminacion;
        }
        $this->mensaje = "No se pudo hacer referencia al perfil";
        return 0;
    }

    public function crear($idPerfil, $permisos) {
        if ($idPerfil && !empty($permisos)) {
            $registros = "";
            foreach ($permisos as $idPermiso) {
                $registros = "({$idPerfil}, {$idPermiso}),";
            }
            $values = substr($registros, 0, -1);
            $creacion = SQLServer::instancia()->insertar("seg_perfil_permiso", $values);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            return $creacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

}
