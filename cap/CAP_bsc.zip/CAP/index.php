<?php
/* Incluye el archivo con las constantes del sistema y el autocargador */
require_once './app/principal/modelos/Constantes.php';
require_once './app/principal/modelos/AutoCargador.php';

/* Se cargan los modulos que sean necesarios */
AutoCargador::cargarModulos();

session_start();
$mensaje = "";
if (isset($_POST['btnIngreso'])) {
    $legajo = $_POST['legajo'];
    $controlador = new ControladorPrincipal();
    $autorizado = $controlador->verificarUsuarioSistema($legajo);
    if ($autorizado) {
        header("Location: app/principal/vistas/home.php");
    } else {
        $mensaje = '<div class="alert alert-danger"><strong>Usuario no autorizado</strong></div>';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <title>CAP</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="./lib/cap/cap-admin.min.css">
        <link rel="stylesheet" href="./lib/cap/cap.css">
    </head> 
    <body class="bg-dark">
        <div class="container">
            <div class="card card-login mx-auto mt-5">
                <div class="card-header">Formulario de ingreso</div>
                <div class="card-body">
                    <?= $mensaje; ?>
                    <form method="POST" >
                        <div class="form-group">
                            <div class="form-label-group">
                                <input type="text" class="form-control" 
                                       name="legajo" id="legajo" 
                                       placeholder="Legajo" required>
                                <label for="legajo">Legajo</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-label-group">
                                <input type="password" class="form-control" 
                                       name="clave" id="clave"
                                       placeholder="Clave personal" required>
                                <label for="clave">Clave</label>
                            </div>
                        </div>
                        <input type="submit" name="btnIngreso" id="btnIngreso" 
                               class="btn btn-outline-success btn-block" 
                               value="INGRESAR">
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>