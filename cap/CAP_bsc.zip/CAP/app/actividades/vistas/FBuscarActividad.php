<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3">
            <div class="col text-left">
                <h4> BUSCAR ACTIVIDAD USUARIOS</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionCentral" class="mt-3 mb-4">
            <form id="formBuscarActividad" name="formBuscarActividad" method="POST">
                <input type="hidden" name="peticion" id="peticion">
                <div class="card border-azul-clasico mt-3">
                    <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                    <div class="card-body">
                        <div class="form-row">
                            <label for="modulo" class="col-2 col-form-label text-left">* Modulo:</label>
                            <div class="col">
                                <select id="modulo" name="modulo" class="form-control mb-2" required>
                                    <option value="sis">Aplicaciones</option>
                                    <option value="bas">Bases de datos</option>
                                    <option value="com">Comunicaciones</option>
                                    <option value="fir">Firewalls</option>
                                    <option value="ger">Gerencias</option>
                                    <option value="pce">Procesos</option>
                                    <option value="pro">Proveedores</option>
                                    <option value="ser">Servicios</option>
                                    <option value="srv">Servidores</option>
                                    <option value="sit">Sitios</option>
                                </select>
                            </div>
                            <label for="operacion" class="col-2 col-form-label text-left">* Operación:</label>
                            <div class="col">
                                <select id="operacion" name="operacion" class="form-control mb-2" required>
                                    <option value="CREACION">Creación</option>
                                    <option value="ALTA">Alta</option>
                                    <option value="MODIFICACION">Modificación</option>
                                    <option value="BAJA">Baja</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-row mt-2">
                    <div class="col text-right">
                        <button type="submit" class="btn btn-success" 
                                name="btnBuscarActividad"><i class="fas fa-search"></i> BUSCAR</button>
                    </div>
                </div>
            </form>
        </div>
        <br>
        <div id="seccionInferior" class="mt-4 mb-3"></div>
    </div>
</div>
<script type="text/javascript" src="../js/BuscarActividad.js"></script>
