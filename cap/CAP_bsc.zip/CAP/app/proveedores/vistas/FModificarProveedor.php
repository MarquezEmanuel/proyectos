<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$formulario = $boton = "";
if (isset($_POST['idProveedor'])) {
    $provedor = new Proveedor($_POST['idProveedor']);
    $obtencion = $provedor->obtener();
    if ($obtencion == 2) {

        $provincia = $provedor->getProvincia();
        $provincias = ($provincia == "No aplica") ? '<option value="No aplica" selected>No aplica</option>' : '<option value="No aplica">No aplica</option>';
        $provincias .= ($provincia == "Buenos Aires") ? '<option value="Buenos Aires" selected>Buenos Aires</option>' : '<option value="Buenos Aires">Buenos Aires</option>';
        $provincias .= ($provincia == "Catamarca") ? '<option value="Catamarca" selected>Catamarca</option>' : '<option value="Catamarca">Catamarca</option>';
        $provincias .= ($provincia == "Chaco") ? '<option value="Chaco" selected>Chaco</option>' : '<option value="Chaco">Chaco</option>';
        $provincias .= ($provincia == "Chubut") ? '<option value="Chubut" selected>Chubut</option>' : '<option value="Chubut">Chubut</option>';
        $provincias .= ($provincia == "Córdoba") ? '<option value="Córdoba" selected>Córdoba</option>' : '<option value="Córdoba">Córdoba</option>';
        $provincias .= ($provincia == "Corrientes") ? '<option value="Corrientes" selected>Corrientes</option>' : '<option value="Corrientes">Corrientes</option>';
        $provincias .= ($provincia == "Entre Rios") ? '<option value="Entre Rios" selected>Entre Rios</option>' : '<option value="Entre Rios">Entre Rios</option>';
        $provincias .= ($provincia == "Formosa") ? '<option value="Formosa" selected>Formosa</option>' : '<option value="Formosa">Formosa</option>';
        $provincias .= ($provincia == "Jujuy") ? '<option value="Jujuy" selected>Jujuy</option>' : '<option value="Jujuy">Jujuy</option>';
        $provincias .= ($provincia == "La Pampa") ? '<option value="La Pampa" selected>La Pampa</option>' : '<option value="La Pampa">La Pampa</option>';
        $provincias .= ($provincia == "La Rioja") ? '<option value="La Rioja" selected>La Rioja</option>' : '<option value="La Rioja">La Rioja</option>';
        $provincias .= ($provincia == "Mendoza") ? '<option value="Mendoza" selected>Mendoza</option>' : '<option value="Mendoza">Mendoza</option>';
        $provincias .= ($provincia == "Misiones") ? '<option value="Misiones" selected>Misiones</option>' : '<option value="Misiones">Misiones</option>';
        $provincias .= ($provincia == "Neuquén") ? '<option value="Neuquén" selected>Neuquén</option>' : '<option value="Neuquén">Neuquén</option>';
        $provincias .= ($provincia == "Rio Negro") ? '<option value="Rio Negro" selected>Rio Negro</option>' : '<option value="Rio Negro">Rio Negro</option>';
        $provincias .= ($provincia == "Salta") ? '<option value="Salta" selected>Salta</option>' : '<option value="Salta">Salta</option>';
        $provincias .= ($provincia == "San Juan") ? '<option value="San Juan" selected>San Juan</option>' : '<option value="San Juan">San Juan</option>';
        $provincias .= ($provincia == "San Luis") ? '<option value="San Luis" selected>San Luis</option>' : '<option value="San Luis">San Luis</option>';
        $provincias .= ($provincia == "Santa Cruz") ? '<option value="Santa Cruz" selected>Santa Cruz</option>' : '<option value="Santa Cruz">Santa Cruz</option>';
        $provincias .= ($provincia == "Santa Fe") ? '<option value="Santa Fe" selected>Santa Fé</option>' : '<option value="Santa Fe">Santa Fé</option>';
        $provincias .= ($provincia == "Santiago del Estero") ? '<option value="Santiago del Estero" selected>Santiago del Estero</option>' : '';
        $provincias .= ($provincia == "Tierra del Fuego") ? '<option value="Tierra del Fuego" selected>Tierra del Fuego</option>' : '<option value="Tierra del Fuego">Tierra del Fuego</option>';
        $provincias .= ($provincia == "Tucuman") ? '<option value="Tucuman" selected>Tucuman</option>' : '<option value="Tucuman">Tucuman</option>';

        $formulario = '
            <input type="hidden" name="idProveedor" id="idProveedor" value="' . $provedor->getId() . '">
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label text-left">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" 
                           value="' . $provedor->getNombre() . '" 
                           placeholder="Nombre del proveedor" required>
                </div>
                <label for="telefono" class="col-sm-2 col-form-label text-left">* Telefono:</label>
                <div class="col">
                    <input type="tel" class="form-control mb-2" 
                           name="telefono" id="telefono" 
                           value="' . $provedor->getTelefono() . '" 
                           placeholder="Número de telefono" required>
                </div>
            </div>
            <div class="form-row">
                <label for="correo" class="col-sm-2 col-form-label text-left">* Correo:</label>
                <div class="col">
                    <input type="email" class="form-control mb-2" 
                           name="correo" id="correo" 
                           value="' . $provedor->getCorreo() . '" 
                           placeholder="Correo electrónico" required>
                </div>
                <label for="provincia" class="col-sm-2 col-form-label text-left">* Provincia:</label>
                <div class="col">
                    <select id="provincia" name="provincia" class="form-control mb-2" >' . $provincias . '</select>
                </div>
            </div>
            <div class="form-row">
                <label for="localidad" class="col-sm-2 col-form-label text-left">* Localidad:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="localidad" id="localidad" 
                           value="' . $provedor->getLocalidad() . '" 
                           placeholder="Nombre de localidad" required>
                </div>
                <label for="direccion" class="col-sm-2 col-form-label text-left">* Dirección:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="direccion" id="direccion" 
                           value="' . $provedor->getDireccion() . '" 
                           placeholder="Direccion" required>
                </div>
            </div>';
        $boton = '
            <button type="submit" class="btn btn-success" id="btnModificarProveedor" disabled>
                    <i class="far fa-save"></i> GUARDAR</button>
            <a href="proveedores_buscarProveedor">
                <button type="button" class="btn btn-outline-info">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </a>';
    } else {
        $formulario = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> 
                <strong>{$provedor->getMensaje()}</strong>
            </div>";
        $boton = '
            <a href="proveedores_buscarProveedor">
                <button type="button" class="btn btn-outline-info">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </a>';
    }
} else {
    $formulario = "
        <div class='alert alert-danger text-center' role='alert'> 
            <i class='fas fa-exclamation-triangle'></i> 
            <strong>No se obtuvo la información desde el formulario</strong>
        </div>";
    $boton = '
        <a href="proveedores_buscarProveedor">
            <button type="button" class="btn btn-outline-info">
                <i class="fas fa-search"></i> BUSCAR
            </button>
        </a>';
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-address-card"></i> MODIFICAR PROVEEDOR</h4>
        </div>
        <div class="col text-right">
            <a href="proveedores_buscarProveedor"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <div id="seccionCentral">
        <form id="formModificarProveedor" name="formModificarProveedor" method="POST">
            <div class="card mt-3 ">
                <div class="card-header text-left bg-azul-clasico text-white">Formulario de modificación</div>
                <div class="card-body">
                    <?= $formulario; ?>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <?= $boton; ?>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="./app/proveedores/js/ModificarProveedor.js"></script>