<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Aplicacion {

    private $id;
    private $tipo;
    private $sigla;
    private $nombre;
    private $gerencia;
    private $proveedor;
    private $lenguaje;
    private $empleado;
    private $confidencialidad;
    private $integridad;
    private $disponibilidad;
    private $criticidad;
    private $descripcion;
    private $estado;
    private $mensaje;

}
