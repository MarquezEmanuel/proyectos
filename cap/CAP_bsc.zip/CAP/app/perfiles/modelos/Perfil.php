<?php

/**
 * Description of Perfil
 *
 * @author 07489
 */
class Perfil {

    private $id;
    private $nombre;
    private $descripcion;
    private $mensaje;
    private $permisos;

    public function __construct($id = NULL, $nombre = NULL, $descripcion = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setDescripcion($descripcion);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function getPermisos() {
        return $this->permisos;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function setPermisos($permisos) {
        $this->permisos = $permisos;
    }

    public function crear() {
        
    }

    public function modificar() {
        
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM seg_perfil WHERE id = ?";
            $fila = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if (gettype($fila) == "array") {
                $this->nombre = $fila['nombre'];
                $this->descripcion = $fila['descripcion'];
                $this->permisos = $this->obtenerPermisos();
                return 2;
            }
            $this->mensaje = "No se obtuvo la información del perfil";
            return 1;
        }
        $this->mensaje = "No se pudo hacer referencia al perfil";
        return 0;
    }

    private function obtenerPermisos() {
        $permisos = new Permisos();
        $resultado = $permisos->listarMenu($this->id);
        $arregloMenu = array();
        while ($menu = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
            $resultadoSM = $permisos->listarSubMenu($this->id, $menu['id']);
            $arregloSubmenu = array();
            if (gettype($resultadoSM) == 'resource') {
                while ($submenu = sqlsrv_fetch_array($resultadoSM, SQLSRV_FETCH_ASSOC)) {
                    $arregloSubmenu[] = array($submenu['id'], $submenu['titulo'], $submenu['link']);
                }
                $arregloMenu[] = array($menu['id'], $menu['titulo'], $arregloSubmenu);
            }
        }
        return $arregloMenu;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("seg_perfiles", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
