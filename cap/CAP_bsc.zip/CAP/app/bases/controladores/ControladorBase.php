<?php

/**
 * Description of ControladorBase
 *
 * @author Emanuel
 */
class ControladorBase {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $estado) {
        $bases = new BasesDatos();
        $resultado = $bases->buscar($nombre, $estado);
        $this->mensaje = $bases->getMensaje();
        return $resultado;
    }

    public function modificar($id, $test, $desarrollo, $descripcion) {
        $base = new BaseDatos($id, $test, $desarrollo, $descripcion);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $modificacion = $base->modificar();
            $this->mensaje = $base->getMensaje();
            if ($modificacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar con la base";
        return 1;
    }

    public function listar($nombre) {
        $bases = new BasesDatos();
        $resultado = $bases->listar($nombre);
        $this->mensaje = $bases->getMensaje();
        return $resultado;
    }

    public function listarUltimasActualizadas() {
        $bases = new BasesDatos();
        $resultado = $bases->listarUltimasActualizadas();
        $this->mensaje = $bases->getMensaje();
        return $resultado;
    }

    public function obtener($idBase) {
        $bases = new BasesDatos();
        $resultado = $bases->obtener($idBase);
        $this->mensaje = $bases->getMensaje();
        return $resultado;
    }

}
