<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

if (isset($_POST['idTabla'])) {
    $id = $_POST['idTabla'];
    $controlador = new ControladorCampo();
    $tabla = new Tabla($id);
    $resultado = $tabla->obtener();
    $campos = $controlador->listarPorTabla($id);
    if ($resultado == 2 && gettype($campos) == "resource") {
        $creacion = date_format($tabla->getFechaCreacion(), 'd/m/Y');
        $edicion = date_format($tabla->getFechaEdicion(), 'd/m/Y');
        $proceso = date_format($tabla->getFechaProceso(), 'd/m/Y');
        $cuerpoInformacion = '
            <input type="hidden" name="idTabla" id="idTabla" value="' . $tabla->getId() . '">
            <div class="form-row">
                <label for="sigla" class="col-sm-2 col-form-label">Base de datos:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . utf8_encode($tabla->getBase()) . '" disabled>
                </div>
                <label for="nombre" class="col-sm-2 col-form-label">Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . $tabla->getNombre() . '" disabled>
                </div>
            </div>
            <div class="form-row">
                <label for="sigla" class="col-sm-2 col-form-label">Fecha creación:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . $creacion . '" disabled>
                </div>
                <label for="nombre" class="col-sm-2 col-form-label">Fecha edición:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . $edicion . '" disabled>
                </div>
            </div>
            <div class="form-row">
                <label for="sigla" class="col-sm-2 col-form-label">Fecha proceso:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . $proceso . '" disabled>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col">
                </div>
            </div>
            <div class="form-row">
                <label for="descripcion" class="col-sm-2 col-form-label">Descripción:</label>
                <div class="col">
                    <textarea class="form-control mb-2"
                              placeholder="Descripción de la vista"
                              disabled>' . $tabla->getDescripcion() . '</textarea>
                </div>
            </div>';

        $filas = "";
        while ($campo = sqlsrv_fetch_array($campos, SQLSRV_FETCH_ASSOC)) {
            $maximo = ($campo['maximo']) ? $campo['maximo'] : "";
            $fechaProceso = isset($campo['fechaProceso']) ? date_format($campo['fechaProceso'], 'd/m/Y') : "";
            $filas .= "
            <tr>
                <td>" . utf8_encode($campo['nombreCampo']) . "</td>
                <td>{$campo['nulos']}</td>
                <td>{$campo['tipo']}</td>
                <td>{$maximo}</td>
                <td>{$fechaProceso}</td>
            </tr>";
        }
        $tabla = '
            <div class="table-responsive">
                <table id="tbCamposTabla" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th>Campo</th>
                            <th>Nulos</th>
                            <th>Tipo</th>
                            <th>Máximo</th>
                            <th>Proceso</th>
                        </tr>
                    </thead>
                    <tbody>' . $filas . '</tbody>
                </table>
            </div>';
        $formulario = ControladorHTML::getCard($cuerpoInformacion, "Información básica");
        $formulario .= "<br>" . ControladorHTML::getCard($tabla, "Campos asociados");
    } else {
        $cuerpo = ControladorHTML::getAlertaOperacion($resultado, $tabla->getMensaje());
        $formulario = ControladorHTML::getCard($cuerpo, "Información básica");
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = ControladorHTML::getAlertaOperacion(0, $mensaje);
    $formulario = ControladorHTML::getCard($cuerpo, "Información básica");
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-database"></i> DETALLE TABLA</h4>
        </div>
        <div class="col text-right">
            <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
        </div>
    </div>
    <?= $formulario; ?>
    <div class="form-row mt-2 mb-4">
        <div class="col text-right">
            <a href="formBuscarTabla.php">
                <button type="button" class="btn btn-outline-info">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </a>
        </div>
    </div>
</div>