<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$controlador = new ControladorProcedimiento();

if (isset($_POST['btnBuscarProcedimiento'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $definicion = $_POST['definicion'];
    $datos = ($nombre) ? "'{$nombre}', " : "TODOS, ";
    $datos .= ($definicion) ? "'{$definicion}', " : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $procedimientos = $controlador->buscar($nombre, $definicion);
    $_SESSION['BUSPRO'] = array($nombre, $definicion, $datos);
} else {
    if (isset($_SESSION['BUSPRO'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSPRO'];
        $nombre = $parametros[0];
        $definicion = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $procedimientos = $controlador->buscar($nombre, $definicion);
        $_SESSION['BUSPRO'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $procedimientos = $controlador->listarUltimosModificados();
        $filtro = "Últimos procedimientos modificados";
        $_SESSION['BUSPRO'] = NULL;
    }
}

if (gettype($procedimientos) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($procedimiento = sqlsrv_fetch_array($procedimientos, SQLSRV_FETCH_ASSOC)) {
        $fechaCreacion = isset($procedimiento['fechaCreacion']) ? date_format($procedimiento['fechaCreacion'], 'd/m/Y') : "";
        $fechaEdicion = isset($procedimiento['fechaModificacion']) ? date_format($procedimiento['fechaModificacion'], 'd/m/Y H:i:s') : "";
        $filas .= "
            <tr>
                <td>" . utf8_encode($procedimiento['nombreBase']) . "</td>
                <td>" . utf8_encode($procedimiento['nombreSP']) . "</td>
                <td>{$fechaCreacion}</td>
                <td>{$fechaEdicion}</td>
                <td style='display: none;'>" . utf8_encode($procedimiento['descripcion']) . "</td> 
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' 
                                name='{$procedimiento['idSP']}' title='Editar'>
                            <i class='far fa-edit'></i></button>
                        <button class='btn btn-outline-primary datos' title='Ver información básica'>
                            <i class='fas fa-info-circle'></i></button>
                        <a href='procesaDescargarSQLProcedimiento.php?ref={$procedimiento['idSP']}' class='btn btn-outline-success'>
                            <i class='fas fa-download'></i>
                        </a>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbProcedimientos" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Base de datos</th>
                        <th>Nombre</th>
                        <th>Fecha creación</th>
                        <th>Fecha edición</th>
                        <th style="display: none;">Descripción</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($procedimientos == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($procedimientos, $mensaje);
}

$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
