<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$controlador = new ControladorTabla();

if (isset($_POST['btnBuscarTabla'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $base = isset($_POST['base']) ? $_POST['base'] : '';
    $nombre = $_POST['nombre'];
    $datos = ($base) ? "ESPECIFICADA, '" . $nombre . "'" : "TODAS, '" . $nombre . "'";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $tablas = $controlador->buscar($base, $nombre);
    $_SESSION['BUSTAB'] = array($base, $nombre, $datos);
} else {
    if (isset($_SESSION['BUSTAB'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSTAB'];
        $base = $parametros[0];
        $nombre = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $tablas = $controlador->buscar($base, $nombre);
        $_SESSION['BUSTAB'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $tablas = $controlador->listarUltimasModificadas();
        $filtro = "Ultimas tablas modificadas";
        $_SESSION['BUSTAB'] = NULL;
    }
}

if (gettype($tablas) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($tabla = sqlsrv_fetch_array($tablas, SQLSRV_FETCH_ASSOC)) {
        $fechaCreacion = isset($tabla['fechaCreacion']) ? date_format($tabla['fechaCreacion'], 'd/m/Y') : "";
        $fechaModificacion = isset($tabla['fechaModificacion']) ? date_format($tabla['fechaModificacion'], 'd/m/Y') : "";
        $fechaProceso = isset($tabla['fechaProceso']) ? date_format($tabla['fechaProceso'], 'd/m/Y') : "";
        $filas .= "
            <tr>
                <td>" . utf8_encode($tabla['nombreBase']) . "</td>
                <td>" . utf8_encode($tabla['nombreTabla']) . "</td>
                <td>{$fechaCreacion}</td>
                <td>{$fechaModificacion}</td>
                <td>{$fechaProceso}</td>
                <td style='display: none;'>" . utf8_encode($tabla['descripcion']) . "</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' 
                            name='{$tabla['idTabla']}' title='Editar'><i class='far fa-edit'></i>
                        </button>
                        <button class='btn btn-outline-primary datos' 
                                name='{$tabla['idTabla']}' title='Ver información básica'><i class='fas fa-info-circle'></i>
                        </button>
                        <button class='btn btn-outline-primary detalle' 
                            name='{$tabla['idTabla']}' title='Ver detalle'><i class='fas fa-eye'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbTablas" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Base de datos</th>
                        <th>Nombre</th>
                        <th>Creación</th>
                        <th>Modificación</th>
                        <th>Proceso</th>
                        <th style="display: none;">Descripción</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($tablas == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($tablas, $mensaje);
}

$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
