
$(document).ready(function () {

    /* EJECUTA LA FUNCION QUE REALIZA LA BUSQUEDA */

    realizarBusqueda();

    /* ENVIA EL FORMULARIO DE BUSQUEDA INDICANDO QUE SE PETICIONO POR EL USUARIO */

    $('#formBuscarServidor').submit(function (event) {
        event.preventDefault();
        $("#peticion").val("true");
        realizarBusqueda();
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('#seccionInferior').on('click', '.editar', function () {
        var idServidor = $(this).attr("name");
        event.preventDefault();
        $.ajax({
            type: "POST",
            url: "./FModificarServidor.php",
            data: "idServidor=" + idServidor,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<strong>No se procesó la petición (Informe al administrador)</strong>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            }
        });
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('#seccionInferior').on('click', '.baja', function () {
        $("#mcepTitulo").html("<i class='fas fa-trash'></i> CONFIRME LA BAJA DEL SERVIDOR");
        $("#mcepAccion").val("BAJA");
        $("#mcepIdServidor").val($(this).attr("name"));
        $("#mcepNombre").text($(this).parents("tr").find("td").eq(0).html() + ": ");
        $("#ModalCambioEstadoServidor").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('#seccionInferior').on('click', '.alta', function () {
        $("#mcepTitulo").html("<i class='fas fa-plus-circle'></i> CONFIRME EL ALTA DE LA SERVIDOR");
        $("#mcepAccion").val("ALTA");
        $("#mcepIdServidor").val($(this).attr("name"));
        $("#mcepNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalCambioEstadoServidor").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('#seccionInferior').on('click', '.datos', function () {
        $("#modalInventario").val($(this).parents("tr").find("td").eq(0).html());
        $("#modalNombre").val($(this).parents("tr").find("td").eq(1).html());
        $("#modalIP").val($(this).parents("tr").find("td").eq(2).html());
        $("#modalAmbiente").val($(this).parents("tr").find("td").eq(3).html());
        $("#modalTipo").val($(this).parents("tr").find("td").eq(4).html());
        $("#modalDescripcion").val($(this).parents("tr").find("td").eq(5).html());
        $("#ModalDatosServidor").modal({});
    });

    /* ENVIA LA OPERACION Y MUESTRA EL RESULTADO EN EL MODAL */

    $('#seccionInferior').on('click', '#btnCambiarEstadoServidor', function () {
        $.ajax({
            type: "POST",
            url: "./PBorrarServidor.php",
            data: $("#formCambiarEstadoServidor").serialize(),
            success: function (data) {
                $('#mcepCuerpo').html(data);
                $('#btnCambiarEstadoServidor').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                var men = '<strong>No se procesó la petición (Informe al administrador)</strong>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#mcepCuerpo").html(div);
            }
        });
    });

    /* ACTUALIZA LA PANTALLA LUEGO DE HACER EL ALTA O BAJA */

    $('#btnRefrescarPantalla').click(function () {
        location.reload();
    });

    /* ENVIA LA PETICION AJAX PARA CARGAR EL RESULTADO PREVIO DE UNA BUSQUEDA */

    function realizarBusqueda() {
        $.ajax({
            type: "POST",
            url: "./PBuscarServidor.php",
            data: $("#formBuscarServidor").serialize(),
            success: function (data) {
                $('#seccionInferior').html(data);
                $('#tbServidores').dataTable({
                    lengthChange: false
                });
            },
            error: function (data) {
                console.log(data);
                var men = '<strong>No se procesó la petición (Informe al administrador)</strong>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            }
        });
    }

});