<?php

/**
 * Description of ControladorProceso
 *
 * @author Emanuel
 */
class ControladorProceso {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function crear($inventario, $codigo, $nombre, $valor, $rti) {
        $proceso = new Proceso(NULL, $inventario, $codigo, $nombre, $valor, $rti);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $proceso->crear();
            $this->mensaje = $proceso->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 0;
    }

}
