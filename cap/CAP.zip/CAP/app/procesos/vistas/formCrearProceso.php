<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$controlador = new ControladorInventario();

$inventarios = $controlador->listar();
$formulario = $botones = "";
if (gettype($inventarios) == "resource") {
    $opciones = "";
    while ($inventario = sqlsrv_fetch_array($inventarios, SQLSRV_FETCH_ASSOC)) {
        $opciones .= "<option value='{$inventario['id']}'>{$inventario['sigla']}</option>";
    }
    $formulario = '
        <div class="form-row">
            <label for="titulo" class="col-sm-2 col-form-label">* Inventario:</label>
            <div class="col">
                <select class="form-control mb-2" id="inventario" name="inventario">' . $opciones . '</select>
            </div>
            <label for="codigo" class="col-sm-2 col-form-label">* Código:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="codigo" id="codigo" pattern="[0-9/-]{1,10}"
                       placeholder="Código del proceso" required>
            </div>
        </div>
        <div class="form-row">
            <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="nombre" id="nombre" 
                       placeholder="Nombre del proceso" required>
            </div>
            <label for="valor" class="col-sm-2 col-form-label">* Valor:</label>
            <div class="col">
                <input type="number" class="form-control mb-2" 
                       name="valor" id="valor" min="1"
                       placeholder="Valor del proceso" required>
            </div>
        </div>
        <div class="form-row">
            <label for="rti" class="col-sm-2 col-form-label">* RTI:</label>
            <div class="col">
                <select class="form-control mb-2" id="rti" name="rti">
                    <option value="SI">SI</option>
                    <option value="NO">NO</option>
                </select>
            </div>
            <label class="col-sm-2 col-form-label"></label>
            <div class="col"></div>
        </div>';
    $botones = '
        <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
        <a href="procesos_buscar">
            <button type="button" class="btn btn-outline-info">
                <i class="fas fa-search"></i> BUSCAR
            </button>
        </a>
        <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">';
} else {
    if ($inventarios == 1) {
        $formulario = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    } else {
        $formulario = "
            <div class='alert alert-warning text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
    $botones = '
        <a href="procesos_buscar">
            <button type="button" class="btn btn-outline-info">
                <i class="fas fa-search"></i> BUSCAR
            </button>
        </a>';
}
require_once '../../principal/vistas/header.php';
?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-tasks"></i> CREAR PROCESO</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearProceso" name="formCrearProceso" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
                <div class="card-body">
                    <?= $formulario; ?>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <?= $botones; ?>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="../js/CrearProceso.js"></script>


