<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="fas fa-tasks"></i> BUSCAR PROCESO</h4>
                </div>
                <div class="col text-right">
                    <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
                </div>
            </div>
            <div class="mt-3 mb-4">
                <form method="POST" id="formBuscarProceso" name="formBuscarProceso">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="codigo" class="col-2 col-form-label">Código:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="codigo" id="codigo" 
                                           maxlength="9" pattern="[A-Za-z0-9]{1,9}"
                                           title="Código del proceso: campo no obligatorio"
                                           placeholder="Código del proceso">
                                </div>
                                <label for="nombre" class="col-2 col-form-label">Nombre:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombre" id="nombre" 
                                           maxlength="20" pattern="[A-Za-z0-9]{1,20}"
                                           title="Nombre del proceso: campo no obligatorio"
                                           placeholder="Nombre del proceso">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success" name="btnBuscarPermiso"><i class="fas fa-search"></i>  BUSCAR</button>
                            <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                        </div>
                    </div>
                </form>
            </div>
            <br>
            <div id="seccionInferior" class="mt-4 mb-2">
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="./app/procesos/js/BuscarProceso.js"></script>