<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Proceso
 *
 * @author Emanuel
 */
class Proceso {

    private $id;
    private $inventario;
    private $codigo;
    private $nombre;
    private $valor;
    private $rti;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $inventario = NULL, $codigo = NULL, $nombre = NULL, $valor = NULL, $rti = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setInventario($inventario);
        $this->setCodigo($codigo);
        $this->setNombre($nombre);
        $this->setValor($valor);
        $this->setRti($rti);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getInventario() {
        return $this->inventario;
    }

    public function getCodigo() {
        return $this->codigo;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getValor() {
        return $this->valor;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setInventario($inventario) {
        $this->inventario = $inventario;
    }

    public function setCodigo($codigo) {
        $this->codigo = $codigo;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setValor($valor) {
        $this->valor = $valor;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }
    
     public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("pce_procesos", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        return 1;
    }

    public function crear() {
        if ($this->inventario && $this->codigo && $this->nombre && $this->valor && $this->rti) {
            $values = "({$this->inventario}, '{$this->codigo}', '{$this->nombre}', {$this->valor}, '{$this->rti}', 1)";
            $creacion = SQLServer::instancia()->insertar("pce_procesos", $values);
            $this->mensaje = $this->codigo . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        return 0;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("pce_procesos", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
