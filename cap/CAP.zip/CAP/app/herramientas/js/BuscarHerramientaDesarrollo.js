/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    realizarBusqueda();

    $('#formBuscarHerramienta').submit(function (event) {
        event.preventDefault();
        $("#peticion").val("true");
        realizarBusqueda();
    });

    $('#seccionInferior').on('click', '.editar', function () {
        alert("ffff");
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('#seccionInferior').on('click', '.baja', function () {
        $("#tituloModal").html("<i class='fas fa-code-branch'></i> CONFIRME LA BAJA DE LA HERRAMIENTA");
        $("#modalAccion").val("BAJA");
        $("#modalIdHerramienta").val($(this).attr("name"));
        $("#modalNombre").text($(this).parents("tr").find("td").eq(0).html() + ": ");
        $("#ModalCambioEstadoHerramienta").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('#seccionInferior').on('click', '.alta', function () {
        $("#tituloModal").html("<i class='fas fa-code-branch'></i> CONFIRME EL ALTA DE LA HERRAMIENTA");
        $("#modalAccion").val("ALTA");
        $("#modalIdHerramienta").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalCambioEstadoHerramienta").modal({backdrop: 'static', keyboard: false});
    });

    function realizarBusqueda() {
        $.ajax({
            type: "POST",
            url: "./PBuscarHerramienta.php",
            data: $("#formBuscarHerramienta").serialize(),
            success: function (data) {
                $('#seccionInferior').html(data);
                $('#tbHerramientas').dataTable({
                    lengthChange: false
                });
            },
            error: function (data) {
                console.log(data);
                var div = '<div class="alert alert-danger text-center" role="alert">No se procesó la petición por un error interno</div>';
                $("#seccionInferior").html(div);
            }
        });
    }

});




