<?php

/**
 * Description of Inventario
 *
 * @author Emanuel
 */
class Inventario {

    private $id;
    private $sigla;
    private $descripcion;
    private $fecha;
    private $mensaje;

    public function __construct($id = NULL, $sigla = NULL, $descripcion = NULL, $fecha = NULL) {
        $this->setId($id);
        $this->setSigla($sigla);
        $this->setDescripcion($descripcion);
        $this->setFecha($fecha);
    }

    public function getId() {
        return $this->id;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function getFecha() {
        return $this->fecha;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setSigla($sigla) {
        $this->sigla = $sigla;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function setFecha($fecha) {
        $this->fecha = $fecha;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function crear() {
        if ($this->descripcion) {
            $baja = $this->desactivar();
            $values = "('INV'+replace(convert(varchar, getdate(),3),'/',''), '{$this->descripcion}', GETDATE(), 1)";
            $creacion = SQLServer::instancia()->insertar("inv_inventarios", $values);
            if ($baja == 2 && $creacion == 2) {
                $this->mensaje = SQLServer::instancia()->getMensaje();
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            $this->mensaje = "No se creó el registro";
            return ($creacion == 2) ? $creacion : $baja;
        }
        return 1;
    }

    private function desactivar() {
        $campos = "estado = 0";
        $condicion = "id > 0";
        $modificacion = SQLServer::instancia()->modificar("inv_inventarios", $campos, $condicion);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $modificacion;
    }

    public function modificar() {
        if ($this->id && $this->descripcion) {
            $campos = "descripcion = '{$this->descripcion}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("inv_inventarios", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM inv_inventarios WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->sigla = $fila['sigla'];
                $this->descripcion = $fila['descripcion'];
                $this->fecha = date_format($fila['fechaCreacion'], 'd/m/Y');
                return 2;
            }
            $this->mensaje = "No se obtuvo la información del inventario";
            return 1;
        }
        return 0;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("inv_inventarios", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
