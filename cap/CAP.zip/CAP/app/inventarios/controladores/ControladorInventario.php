<?php

/**
 * Description of ControladorInventario
 *
 * @author Emanuel
 */
class ControladorInventario {

    //put your code here

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($sigla, $descripcion) {
        $inventarios = new Inventarios();
        $resultado = $inventarios->buscar($sigla, $descripcion);
        $this->mensaje = $inventarios->getMensaje();
        return $resultado;
    }

    public function crear($descripcion) {
        $inventario = new Inventario(NULL, NULL, $descripcion);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $inventario->crear();
            $this->mensaje = $inventario->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function modificar($id, $descripcion) {
        $inventario = new Inventario($id, NULL, $descripcion);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $inventario->crear();
            $this->mensaje = $inventario->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function listar() {
        $inventarios = new Inventarios();
        $resultado = $inventarios->listar();
        $this->mensaje = $inventarios->getMensaje();
        return $resultado;
    }

    public function listarUltimosCreados() {
        $inventarios = new Inventarios();
        $resultado = $inventarios->listarUltimosCreados();
        $this->mensaje = $inventarios->getMensaje();
        return $resultado;
    }

}
