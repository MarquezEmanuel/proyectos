/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    /* INICIALIZA EL DATATABLE */

    $('#tbInventarios').dataTable({
        lengthChange: false
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editarInventario').click(function () {
        var idInventario = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./app/inventarios/vistas/formModificarInventario.php",
            data: "idInventario=" + idInventario,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.datosInventario').click(function () {
        $("#modalNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalDatosInventario").modal({});
    });

});