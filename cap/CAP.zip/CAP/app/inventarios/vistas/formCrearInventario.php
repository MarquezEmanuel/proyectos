<?php
$fecha = getdate();
$fechaCreacion = str_pad($fecha['mday'], 2, "0", STR_PAD_LEFT) . "/" . str_pad($fecha['mon'], 2, "0", STR_PAD_LEFT) . "/" . $fecha['year'];
$inventario = "INV" . str_pad($fecha['mday'], 2, "0", STR_PAD_LEFT) . str_pad($fecha['mon'], 2, "0", STR_PAD_LEFT) . substr($fecha['year'], 2);

require_once '../../principal/vistas/header.php';
?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-file-signature"></i> CREAR INVENTARIO</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearInventario" name="formCrearInventario" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico  text-white">Complete el formulario</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="codigo" class="col-sm-2 col-form-label text-left">* Fecha:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" value="<?= $fechaCreacion; ?>" readonly>
                        </div>
                        <label for="sigla" class="col-sm-2 col-form-label text-left">* Sigla:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" value="<?= $inventario; ?>" readonly>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="nombre" class="col-sm-2 col-form-label text-left">* Descripción:</label>
                        <div class="col">
                            <textarea class="form-control mb-2" 
                                      id="descripcion" name="descripcion" 
                                      maxlength="300" pattern="[A-Za-z]{1, 300}"
                                      placeholder="Descripción del inventario" required></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
                    <a href="inventarios_buscar">
                        <button type="button" class="btn btn-outline-info">
                            <i class="fas fa-search"></i> BUSCAR
                        </button>
                    </a>
                    <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="../js/CrearInventario.js"></script>