<?php

require_once './app/principal/modelos/Constantes.php';
require_once './app/principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorInventario();

if (isset($_POST['btnBuscarInventario'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $sigla = $_POST['sigla'];
    $descripcion = $_POST['descripcion'];
    $filtro = "Resultado de la búsqueda: ";
    $inventarios = $controlador->buscar($sigla, $descripcion);
    $_SESSION['BUSINV'] = array($sigla, $descripcion);
} else {
    if (isset($_SESSION['BUSINV'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSINV'];
        $sigla = $parametros[0];
        $descripcion = $parametros[1];
        $filtro = "Ultima búsqueda realizada: ";
        $inventarios = $controlador->buscar($sigla, $descripcion);
        $_SESSION['BUSINV'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $inventarios = $controlador->listarUltimosCreados();
        $filtro = "Ultimas inventarios creados";
        $_SESSION['BUSINV'] = NULL;
    }
}

if (gettype($inventarios) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($inventario = sqlsrv_fetch_array($inventarios, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr>
                <td>{$inventario['sigla']}</td>
                <td></td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editarInventario' name='{$inventario['id']}' title='Editar inventario'><i class='far fa-edit'></i></button>
                        <button class='btn btn-outline-primary datosInventario' title='Ver información básica'><i class='fas fa-info-circle'></i></button>
                        <button class='btn btn-outline-info detalleInventario' name='{$inventario['id']}' title='Ver detalle'><i class='fas fa-eye'></i></button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbInventarios" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Sigla</th>
                        <th>Elementos</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    if ($inventarios == 2) {
        $cuerpo = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>{$controlador->getMensaje()} para el filtro ingresado</strong>
            </div>";
    } else {
        $cuerpo = "
            <div class='alert alert-danger text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
}


$formulario = '
    <div class="card border-azul-clasico">
        <div class="card-header bg-azul-clasico text-white"><i class="fas fa-table"></i> ' . $filtro . '</div>
        <div class="card-body">' . $cuerpo . '</div>
    </div>';

echo $formulario;
