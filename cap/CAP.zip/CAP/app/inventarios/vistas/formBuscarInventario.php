<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="fas fa-file-signature"></i> BUSCAR INVENTARIO</h4>
                </div>
                <div class="col text-right">
                    <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
                </div>
            </div>
            <div class="mt-3 mb-4">
                <form method="POST" id="formBuscarInventario" name="formBuscarInventario">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="sigla" class="col-2 col-form-label text-left">Sigla:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="sigla" id="sigla" 
                                           maxlength="9" pattern="[A-Za-z0-9]{1,9}"
                                           title="Sigla del inventario: campo no obligatorio"
                                           placeholder="Sigla del inventario">
                                </div>
                                <label for="descripcion" class="col-2 col-form-label text-left">* Descripción:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="descripcion" id="descripcion" 
                                           maxlength="20" pattern="[A-Za-z0-9]{1,20}"
                                           title="Descripción del inventario: campo no obligatorio"
                                           placeholder="Descripción del inventario">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success" name="btnBuscarPermiso"><i class="fas fa-search"></i>  BUSCAR</button>
                            <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                        </div>
                    </div>
                </form>
            </div>
            <br>
            <div id="seccionInferior" class="mt-4 mb-2">
                 <?php require_once './procesaBuscarInventario.php'; ?>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="./app/inventarios/js/BuscarInventario.js"></script>