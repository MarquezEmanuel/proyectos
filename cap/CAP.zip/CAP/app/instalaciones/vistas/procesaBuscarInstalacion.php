<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorInstalacion();

if (isset($_POST['btnBuscarInstalacion'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " . $estado : "TODOS, " . $estado;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $instalaciones = $controlador->buscar($nombre, $estado);
    $_SESSION['BUSINS'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['BUSINS'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSINS'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $instalaciones = $controlador->buscar($nombre, $estado);
        $_SESSION['BUSINS'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $instalaciones = $controlador->listarUltimasCreadas();
        $filtro = "Últimas instalaciones creadas y en estado activa";
        $_SESSION['BUSINS'] = NULL;
    }
}

if (gettype($instalaciones) == "resource") {
    $filas = "";
    while ($instalacion = sqlsrv_fetch_array($instalaciones, SQLSRV_FETCH_ASSOC)) {
        if ($instalacion['codEstadoInstalacion'] == 1) {
            $operaciones = "
                <button class='btn btn-outline-info datos' 
                        name='{$instalacion['idInstalacion']}' title='Datos básicos'>
                    <i class='fas fa-eye'></i>
                </button>
                <button class='btn btn-outline-warning editar' 
                        name='{$instalacion['idInstalacion']}' title='Editar'>
                    <i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger baja' 
                        name='{$instalacion['idInstalacion']}' title='Dar de baja'>
                    <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-success alta' 
                    name='{$instalacion['idInstalacion']}' title='Dar de alta'>
                        <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td>{$instalacion['sigla']}</td>
                <td>{$instalacion['siglaInstalacion']}</td>
                <td style='display: none;'>{$instalacion['nombreInstalacion']}</td>
                <td>{$instalacion['nombreGerencia']}</td>
                <td style='display: none;'>{$instalacion['idResponsable']}</td> 
                <td>{$instalacion['nombreResponsable']}</td> 
                <td>{$instalacion['nombreSitio']}</td>
                <td style='display: none;'>{$instalacion['plataforma']}</td> 
                <td style='display: none;'>{$instalacion['rti']}</td> 
                <td style='display: none;'>{$instalacion['descripcion']}</td> 
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>{$operaciones}</div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbInstalaciones" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Inventario</th>
                        <th>Nombre corto</th>
                        <th style="display: none;">Nombre largo</th>
                        <th>Gerencia</th>
                        <th>Legajo responsable</th>
                        <th style="display: none;">Responsable</th>
                        <th>Ubicación</th>
                        <th style="display: none;">Plataforma</th>
                        <th style="display: none;">RTI</th>
                        <th style="display: none;">Descripcion</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($instalaciones == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($instalaciones, $mensaje);
}

$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
