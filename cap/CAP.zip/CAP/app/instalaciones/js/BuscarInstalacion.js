/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {

    $('#tbInstalaciones').dataTable({
        lengthChange: false
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editar').click(function () {
        var idInstalacion = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formModificarInstalacion.php",
            data: "idInstalacion=" + idInstalacion,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#seccionInferior").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.datos').click(function () {
        $("#mdiInventario").val($(this).parents("tr").find('td:eq(0)').text());
        $("#mdiSigla").val($(this).parents("tr").find('td:eq(1)').text());
        $("#mdiNombre").val($(this).parents("tr").find('td:eq(2)').text());
        $("#mdiGerencia").val($(this).parents("tr").find('td:eq(3)').text());
        $("#mdiLegajo").val($(this).parents("tr").find('td:eq(4)').text());
        $("#mdiResponsable").val($(this).parents("tr").find('td:eq(5)').text());
        $("#mdiSitio").val($(this).parents("tr").find('td:eq(6)').text());
        $("#mdiPlataforma").val($(this).parents("tr").find('td:eq(7)').text());
        $("#mdiRTI").val($(this).parents("tr").find('td:eq(8)').text());
        $("#mdiDescripcion").val($(this).parents("tr").find('td:eq(9)').text());
        $("#ModalDatosInstalacion").modal({});
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('.baja').click(function () {
        $("#tituloModal").html("<i class='fas fa-code-branch'></i> CONFIRME LA BAJA DE LA INSTALACIÓN");
        $("#modalAccion").val("BAJA");
        $("#modalIdInstalacion").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find("td").eq(2).html());
        $("#ModalCambioEstadoInstalacion").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('.alta').click(function () {
        $("#tituloModal").html("<i class='fas fa-code-branch'></i> CONFIRME EL ALTA DE LA INSTALACIÓN");
        $("#modalAccion").val("ALTA");
        $("#modalIdInstalacion").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find("td").eq(2).html());
        $("#ModalCambioEstadoInstalacion").modal({backdrop: 'static', keyboard: false});
    });

    /* ENVIA LA OPERACION DE ALTA O BAJA Y MUESTRA EL RESULTADO EN EL MODAL */

    $('#btnCambiarEstadoInstalacion').click(function () {
        $.ajax({
            type: "POST",
            url: "./procesaCambiarEstadoInstalacion.php",
            data: $("#formCambioEstadoInstalacion").serialize(),
            success: function (data) {
                $('#cuerpoModal').html(data);
                $('#btnCambiarEstadoInstalacion').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                $("#cuerpoModal").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ACTUALIZA LA PANTALLA LUEGO DE HACER EL ALTA O BAJA */

    $('#btnRefrescarPantalla').click(function () {
        location.reload();
    });

});
