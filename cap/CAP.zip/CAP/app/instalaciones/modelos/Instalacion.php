<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Instalacion {

    private $id;
    private $sigla;
    private $nombre;
    private $gerencia;
    private $descripcion;
    private $plataforma;
    private $responsable;
    private $ubicacion;
    private $rti;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $sigla = NULL, $nombre = NULL, $gerencia = NULL, $descripcion = NULL, $plataforma = NULL, $responsable = NULL, $ubicacion = NULL, $rti = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setSigla($sigla);
        $this->setNombre($nombre);
        $this->setGerencia($gerencia);
        $this->setDescripcion($descripcion);
        $this->setPlataforma($plataforma);
        $this->setResponsable($responsable);
        $this->setUbicacion($ubicacion);
        $this->setRti($rti);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getGerencia() {
        return $this->gerencia;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function getPlataforma() {
        return $this->plataforma;
    }

    public function getResponsable() {
        return $this->responsable;
    }

    public function getUbicacion() {
        return $this->ubicacion;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setSigla($sigla) {
        $this->sigla = $sigla;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setGerencia($gerencia) {
        $this->gerencia = $gerencia;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function setPlataforma($plataforma) {
        $this->plataforma = $plataforma;
    }

    public function setResponsable($responsable) {
        $this->responsable = $responsable;
    }

    public function setUbicacion($ubicacion) {
        $this->ubicacion = $ubicacion;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("ins_instalaciones", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crear() {
        if ($this->sigla && $this->nombre && $this->gerencia && $this->responsable && $this->ubicacion) {
            $values = "('{$this->sigla}', '{$this->nombre}', {$this->gerencia}, '{$this->responsable}', "
                    . "'{$this->ubicacion}', '{$this->plataforma}', '{$this->rti}', '{$this->descripcion}', 1)";
            $creacion = SQLServer::instancia()->insertar("ins_instalaciones", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->crearRelacion();
            }
            return $creacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    private function crearRelacion() {
        $consulta = "INSERT INTO ins_instalaciones_inventarios SELECT {$this->id}, id FROM inv_inventarios WHERE estado = 1";
        $creacion = SQLServer::instancia()->ejecutar($consulta);
        $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
        if ($creacion == 2) {
            return $this->registrarActividad("CREACION", $this->id);
        }
        return $creacion;
    }

    public function modificar() {
        if ($this->sigla && $this->nombre && $this->gerencia && $this->responsable && $this->ubicacion) {
            $campos = "sigla='{$this->sigla}', nombre='{$this->nombre}', gerencia={$this->gerencia}, "
                    . "descripcion='{$this->descripcion}', plataforma='{$this->plataforma}', "
                    . "responsable='{$this->responsable}', ubicacion = '{$this->ubicacion}', rti = '{$this->rti}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("ins_instalaciones", $campos, $condicion);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM ins_instalaciones WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->sigla = $fila['sigla'];
                $this->nombre = $fila['nombre'];
                $this->descripcion = $fila['descripcion'];
                $this->rti = $fila['rti'];
                $this->plataforma = $fila['plataforma'];
                $gerencia = $this->obtenerGerencia($fila['gerencia']);
                $ubicacion = $this->obtenerUbicacion($fila['ubicacion']);
                $responsable = $this->obtenerResponsable($fila['responsable']);
                return (($gerencia == 2) && ($ubicacion == 2) && ($responsable == 2)) ? 2 : 1;
            }
            $this->mensaje = "No se obtuvo la información de la instalación";
            return 1;
        }
        $this->mensaje = "No se pudo hacer referencia a la instalación";
        return 0;
    }

    public function obtenerDatosPropios() {
        if ($this->id) {
            $consulta = "SELECT * FROM ins_instalaciones WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->sigla = $fila['sigla'];
                $this->nombre = $fila['nombre'];
                $this->descripcion = $fila['descripcion'];
                $this->rti = $fila['rti'];
                $this->plataforma = $fila['plataforma'];
                $this->gerencia = $fila['gerencia'];
                $this->ubicacion = $fila['ubicacion'];
                $this->responsable = $fila['responsable'];
                return 2;
            }
            $this->mensaje = "No se obtuvo la información de la instalación";
            return 1;
        }
        $this->mensaje = "No se pudo hacer referencia a la instalación";
        return 0;
    }

    private function obtenerGerencia($idGerencia) {
        $gerencia = new Gerencia($idGerencia);
        $resultado = $gerencia->obtener();
        $this->gerencia = ($resultado == 2) ? $gerencia : NULL;
        $this->mensaje = ($resultado == 2) ? $this->descripcion : "No se pudo obtener la gerencia";
        return $resultado;
    }

    private function obtenerResponsable($idResponsable) {
        $responsable = new Persona($idResponsable);
        $resultado = $responsable->obtener();
        $this->responsable = ($resultado == 2) ? $responsable : NULL;
        $this->mensaje = ($resultado == 2) ? $this->descripcion : "No se pudo obtener el responsable";
        return $resultado;
    }

    private function obtenerUbicacion($idSitio) {
        $ubicacion = new Sitio($idSitio);
        $resultado = $ubicacion->obtener();
        $this->ubicacion = ($resultado == 2) ? $ubicacion : NULL;
        $this->mensaje = ($resultado == 2) ? $this->descripcion : "No se pudo obtener la ubicacion";
        return $resultado;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("ins_instalaciones", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
