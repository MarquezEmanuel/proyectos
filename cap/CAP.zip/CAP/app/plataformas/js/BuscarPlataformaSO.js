/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    realizarBusqueda();

    $('#formBuscarPlataforma').submit(function (event) {
        event.preventDefault();
        $("#peticion").val("true");
        realizarBusqueda();
    });

    $('#seccionInferior').on('click', '.editar', function () {
        var idPlataforma = $(this).attr("name");
        event.preventDefault();
        $.ajax({
            type: "POST",
            url: "./FModificarPlataformaSO.php",
            data: "idPlataforma=" + idPlataforma,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<strong>No se procesó la petición por un error interno</strong>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            }
        });
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('#seccionInferior').on('click', '.baja', function () {
        $("#tituloModal").html("<i class='fas fa-trash'></i> CONFIRME LA BAJA DE LA PLATAFORMA");
        $("#modalAccion").val("BAJA");
        $("#modalIdModo").val($(this).attr("name"));
        $("#modalNombre").text($(this).parents("tr").find("td").eq(0).html() + ": ");
        $("#ModalCambioEstadoPlataforma").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('#seccionInferior').on('click', '.alta', function () {
        $("#tituloModal").html("<i class='fas fa-plus-circle'></i> CONFIRME EL ALTA DE LA PLATAFORMA");
        $("#modalAccion").val("ALTA");
        $("#modalIdModo").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalCambioEstadoPlataforma").modal({backdrop: 'static', keyboard: false});
    });

    function realizarBusqueda() {
        $.ajax({
            type: "POST",
            url: "./PBuscarPlataformaSO.php",
            data: $("#formBuscarPlataforma").serialize(),
            success: function (data) {
                $('#seccionInferior').html(data);
                $('#tbPlataformas').dataTable({
                    lengthChange: false
                });
            },
            error: function (data) {
                console.log(data);
                var men = '<strong>No se procesó la petición por un error interno</strong>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            }
        });
    }

});

