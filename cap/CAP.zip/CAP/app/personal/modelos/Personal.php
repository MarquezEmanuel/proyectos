<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Personal {

    private $id;
    private $inventario;
    private $sigla;
    private $nombre;
    private $departamento;
    private $rti;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $inventario = NULL, $sigla = NULL, $nombre = NULL, $departamento = NULL, $rti = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setInventario($inventario);
        $this->setSigla($sigla);
        $this->setNombre($nombre);
        $this->setDepartamento($departamento);
        $this->setRti($rti);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getInventario() {
        return $this->inventario;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getDepartamento() {
        return $this->departamento;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
        $this->mensaje = ($id) ? $this->mensaje : "No se pudo hacer referencia al personal";
    }

    public function setInventario($inventario) {
        $this->inventario = $inventario;
        $this->mensaje = ($inventario) ? $this->mensaje : "No se pudo hacer referencia al inventario";
    }

    public function setSigla($sigla) {
        $this->sigla = $sigla;
        $this->mensaje = ($sigla) ? $this->mensaje : "No se indicó la sigla";
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
        $this->mensaje = ($nombre) ? $this->mensaje : "No se indicó el nombre";
    }

    public function setDepartamento($departamento) {
        $this->departamento = $departamento;
        $this->mensaje = ($departamento) ? $this->mensaje : "No se pudo hacer referencia al departamento";
    }

    public function setRti($rti) {
        $this->rti = $rti;
        $this->mensaje = ($rti) ? $this->mensaje : "No se indicó el RTI";
    }

    public function setEstado($estado) {
        $this->estado = $estado;
        $this->mensaje = ($estado) ? $this->mensaje : "No se indicó el estado";
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("per_personales", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function crear() {
        if ($this->sigla && $this->nombre && $this->getDepartamento() && $this->rti) {
            $values = "('{$this->nombre}', {$this->gerencia}, 1)";
            $creacion = SQLServer::instancia()->insertar("per_personales", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        return 0;
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->getDepartamento() && $this->rti) {
            $campos = "sigla = '{$this->sigla}', nombre = '{$this->nombre}', departamento = {$this->departamento}, rti='{$this->rti}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("per_personales", $campos, $condicion);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM per_personales WHERE id = {$this->id}";
        }
        return 0;
    }

    private function obtenerInventario($id) {
        $inventario = new Inventario($id);
        if ($inventario->obtener() == 2) {
            return $inventario;
        }
        $this->mensaje = $inventario->getMensaje();
        return null;
    }

    private function obtenerDepartamento($id) {
        $departamento = new Departamento($id);
        if ($departamento->obtener() == 2) {
            return $departamento;
        }
        $this->mensaje = $departamento->getMensaje();
        return null;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("per_personales", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
