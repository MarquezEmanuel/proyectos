<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$formulario = $boton = "";
if ($_POST['idFirewall']) {

    $firewall = new Firewall($_POST['idFirewall']);
    $controladorInventario = new ControladorInventario();
    $controladorSucursal = new ControladorSucursal();

    $inventarios = $controladorInventario->listar();
    $sucursales = $controladorSucursal->listar(1);
    $resultado = $firewall->obtener();

    if (($resultado == 2) && (gettype($inventarios) == "resource") && gettype($sucursales) == "resource") {
        /* SE LISTARON LOS INVENTARIOS Y LAS SUCURSALES */
        $opcionesInventario = $opcionesSucursales = "";
        while ($inventario = sqlsrv_fetch_array($inventarios, SQLSRV_FETCH_ASSOC)) {
            $selected = ($firewall->getInventario()->getId() == $inventario['id']) ? "selected" : "";
            $opcionesInventario .= "<option value='{$inventario['id']}'>{$inventario['sigla']}</option>";
        }
        while ($sucursal = sqlsrv_fetch_array($sucursales, SQLSRV_FETCH_ASSOC)) {
            $selected = ($firewall->getSucursal()->getId() == $sucursal['id']) ? "selected" : "";
            $opcionesSucursales .= "<option value='{$sucursal['id']}' {$selected}>{$sucursal['nombre']}</option>";
        }
        $formulario = '
            <input type="hidden" name="idFirewall" id="idFirewall" value="' . $firewall->getId() . '">
            <div class="form-row">
                <label for="inventario" class="col-sm-2 col-form-label">* Inventario:</label>
                <div class="col">
                    <select class="form-control mb-2" id="inventario" name="inventario">' . $opcionesInventario . '</select>
                </div>
                <label for="sucursal" class="col-sm-2 col-form-label">* Sucursal:</label>
                <div class="col">
                    <select class="form-control mb-2" id="sucursal" name="sucursal">' . $opcionesSucursales . '</select>
                </div>
            </div>
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" 
                           value="' . $firewall->getFirewall() . '"
                           placeholder="Nombre del firewall" required>
                </div>
                <label for="marca" class="col-sm-2 col-form-label">* Marca:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="marca" id="marca"
                           value="' . $firewall->getMarca() . '"
                           placeholder="Nombre de la marca" required>
                </div>
            </div>
            <div class="form-row">
                <label for="modelo" class="col-sm-2 col-form-label">* Modelo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="modelo" id="modelo" maxlength="50"
                           value="' . $firewall->getModelo() . '"
                           placeholder="Modelo" required>
                </div>
                <label for="nroSerie" class="col-sm-2 col-form-label">* Nro Serie:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nroSerie" id="nroSerie" maxlength="50"
                           value="' . $firewall->getNroSerie() . '"
                           placeholder="Número de serie" required>
                </div>
            </div>
            <div class="form-row">
                <label for="version" class="col-sm-2 col-form-label">* Versión:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="version" id="version" maxlength="50"
                           value="' . $firewall->getVersion() . '"
                           placeholder="Versión" required>
                </div>
                <label for="ip" class="col-sm-2 col-form-label">* IP:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="ip" id="ip" maxlength="15"
                           value="' . $firewall->getIp() . '"
                           placeholder="IP" required>
                </div>
            </div>';
        $boton = '
            <button type="submit" class="btn btn-success" id="btnModificarFirewall" disabled>
                    <i class="far fa-save"></i> GUARDAR</button>
            <a href="firewalls_buscar">
                <button type="button" class="btn btn-outline-info">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </a>';
    } else {
        $formulario = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> 
                <strong>No se obtuvo la información para cargar el formulario</strong>
            </div>";
        $boton = '
            <a href="firewalls_buscar">
                <button type="button" class="btn btn-outline-info">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </a>';
    }
} else {
    $formulario = "
        <div class='alert alert-danger text-center' role='alert'> 
            <i class='fas fa-exclamation-triangle'></i> 
            <strong>No se obtuvo la información desde el formulario</strong>
        </div>";
    $boton = '
        <a href="firewalls_buscar">
            <button type="button" class="btn btn-outline-info">
                <i class="fas fa-search"></i> BUSCAR
            </button>
        </a>';
}
?>

<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-fire-alt"></i> MODIFICAR FIREWALL</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formModificarFirewall" name="formModificarFirewall" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
                <div class="card-body">
                    <?= $formulario; ?>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <?= $boton; ?>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="./app/firewalls/js/ModificarFirewall.js"></script>

