<?php

require_once './app/principal/modelos/Constantes.php';
require_once './app/principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorFirewall();

if (isset($_POST['btnBuscarFirewall'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " . $estado : "TODOS, " . $estado;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $firewalls = $controlador->buscar($nombre, $estado);
    $_SESSION['BUSFIR'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['BUSFIR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSFIR'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $firewalls = $controlador->buscar($nombre, $estado);
        $_SESSION['BUSFIR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $firewalls = $controlador->listarUltimosCreados();
        $filtro = "Últimos firewalls creados";
        $_SESSION['BUSFIR'] = NULL;
    }
}

if (gettype($firewalls) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($firewall = sqlsrv_fetch_array($firewalls, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr>
                <td>{$firewall['siglaInventario']}</td>
                <td>{$firewall['nombreSucursal']}</td>
                <td>{$firewall['nombre']}</td>
                <td>{$firewall['marca']}</td>
                <td>{$firewall['modelo']}</td> 
                <td>{$firewall['numeroSerie']}</td>    
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editarFirewall' name='{$firewall['idFirewall']}' title='Editar'><i class='far fa-edit'></i></button>
                        <button class='btn btn-outline-primary datosFirewall' title='Ver información básica'><i class='fas fa-info-circle'></i></button>
                        <button class='btn btn-outline-info detalleFirewall' name='{$firewall['idFirewall']}' title='Ver detalle'><i class='fas fa-eye'></i></button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbFirewalls" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Inventario</th>
                        <th>Sucursal</th>
                        <th>Nombre</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Nro serie</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    if ($firewalls == 1) {
        $cuerpo = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>{$controlador->getMensaje()} para el filtro ingresado</strong>
            </div>";
    } else {
        $cuerpo = "
            <div class='alert alert-danger text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
}



$formulario = '
    <div class="card border-azul-clasico">
        <div class="card-header bg-azul-clasico text-white"><i class="fas fa-table"></i> ' . $filtro . '</div>
        <div class="card-body">' . $cuerpo . '</div>
    </div>';

echo $formulario;
