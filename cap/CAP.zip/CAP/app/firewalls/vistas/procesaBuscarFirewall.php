<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorFirewall();

if (isset($_POST['btnBuscarFirewall'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " . $estado : "TODOS, " . $estado;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $firewalls = $controlador->buscar($nombre, $estado);
    $_SESSION['BUSFIR'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['BUSFIR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSFIR'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $firewalls = $controlador->buscar($nombre, $estado);
        $_SESSION['BUSFIR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $firewalls = $controlador->listarUltimosCreados();
        $filtro = "Últimos firewalls creados";
        $_SESSION['BUSFIR'] = NULL;
    }
}

if (gettype($firewalls) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($firewall = sqlsrv_fetch_array($firewalls, SQLSRV_FETCH_ASSOC)) {
        if ($firewall['firEstado'] == 'Activo') {
            $operaciones = "
                <button class='btn btn-outline-info detalleFirewall' 
                        name='{$firewall['firId']}' title='Ver detalle'>
                    <i class='fas fa-eye'></i>
                </button>
                <button class='btn btn-outline-warning editarFirewall' 
                        name='{$firewall['firId']}' title='Editar'>
                    <i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger bajaFirewall' 
                        name='{$firewall['firId']}' title='Dar de baja'>
                    <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-success altaFirewall' 
                    name='{$firewall['firId']}' title='Dar de alta'>
                        <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td>{$firewall['invSigla']}</td>
                <td>{$firewall['sitNombre']}</td>
                <td>{$firewall['firNombre']}</td>
                <td>{$firewall['firMarca']}</td>
                <td>{$firewall['firModelo']}</td> 
                <td>{$firewall['firNumeroSerie']}</td>    
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>{$operaciones}</div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbFirewalls" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Inventario</th>
                        <th>Sucursal</th>
                        <th>Nombre</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Nro serie</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($firewalls == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($firewalls, $mensaje);
}

$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
