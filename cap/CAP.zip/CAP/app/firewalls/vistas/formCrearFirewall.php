<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$controladorInventario = new ControladorInventario();
$controladorSucursal = new ControladorSucursal();

$inventarios = $controladorInventario->listar();
$sucursales = $controladorSucursal->listar(1);

$formulario = $botones = "";
if ((gettype($inventarios) == "resource") && gettype($sucursales) == "resource") {
    /* SE LISTARON LOS INVENTARIOS Y LAS SUCURSALES */

    $opcionesInventario = $opcionesSucursales = "";
    while ($inventario = sqlsrv_fetch_array($inventarios, SQLSRV_FETCH_ASSOC)) {
        $opcionesInventario .= "<option value='{$inventario['id']}'>{$inventario['sigla']}</option>";
    }
    while ($sucursal = sqlsrv_fetch_array($sucursales, SQLSRV_FETCH_ASSOC)) {
        $opcionesSucursales .= "<option value='{$sucursal['id']}'>{$sucursal['nombre']}</option>";
    }
    $formulario = '
        <div class="form-row">
            <label for="inventario" class="col-sm-2 col-form-label">* Inventario:</label>
            <div class="col">
                <select class="form-control mb-2" id="inventario" name="inventario">' . $opcionesInventario . '</select>
            </div>
            <label for="sucursal" class="col-sm-2 col-form-label">* Sucursal:</label>
            <div class="col">
                <select class="form-control mb-2" id="sucursal" name="sucursal">' . $opcionesSucursales . '</select>
            </div>
        </div>
        <div class="form-row">
            <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="nombre" id="nombre" 
                       placeholder="Nombre del firewall" required>
            </div>
            <label for="marca" class="col-sm-2 col-form-label">* Marca:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="marca" id="marca"
                       placeholder="Nombre de la marca" required>
            </div>
        </div>
        <div class="form-row">
            <label for="modelo" class="col-sm-2 col-form-label">* Modelo:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="modelo" id="modelo" maxlength="50"
                       placeholder="Modelo" required>
            </div>
            <label for="nroSerie" class="col-sm-2 col-form-label">* Nro Serie:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="nroSerie" id="nroSerie" maxlength="50"
                       placeholder="Número de serie" required>
            </div>
        </div>
        <div class="form-row">
            <label for="version" class="col-sm-2 col-form-label">* Versión:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="version" id="version" maxlength="50"
                       placeholder="Versión" required>
            </div>
            <label for="ip" class="col-sm-2 col-form-label">* IP:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="ip" id="ip" maxlength="15"
                       placeholder="IP" required>
            </div>
        </div>';
    $botones = '
        <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
        <a href="formBuscarFirewall.php">
            <button type="button" class="btn btn-outline-info">
                <i class="fas fa-search"></i> BUSCAR
            </button>
        </a>
        <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">';
} else {
    /* NO SE LISTARON INVENTARIOS O SUCURSALES */
    if (($inventarios == 1) || ($sucursales == 1)) {
        $formulario = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>Ocurrió un error al realizar la consulta de inventarios y/o sucursales (informe al administrador)</strong>
            </div>";
    } else {
        $formulario = "
            <div class='alert alert-warning text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>No se encontraron inventarios y/o sucursales para cargar el formulario</strong>
            </div>";
    }
    $botones = '
        <a href="formBuscarFirewall.php">
            <button type="button" class="btn btn-outline-info">
                <i class="fas fa-search"></i> BUSCAR
            </button>
        </a>';
}

require_once '../../principal/vistas/header.php';
?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-fire-alt"></i> CREAR FIREWALL</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearFirewall" name="formCrearFirewall" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
                <div class="card-body">
                    <?= $formulario; ?>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <?= $botones; ?>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="../js/CrearFirewall.js"></script>
