/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    var formOriginal = $("#formModificarFirewall").serialize();

    /* DETECTA LOS CAMBIOS EN LOS CAMPOS DEL FORMULARIO PARA ACTIVAR/DESACTIVAR EL BOTON DE GUARDADO */

    $("#formModificarFirewall").change(function () {
        comparaFormularios();
    });

    /* ENVIA EL FORMULARIO PARA REALIZAR LA MODIFICACION */

    $('#formModificarFirewall').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: "./app/firewalls/vistas/procesaModificarFirewall.php",
            data: $("#formModificarFirewall").serialize(),
            success: function (data) {
                $('#seccionResultado').html(data[0]['resultado']);
                if (data[0]['exito'] === true) {
                    $("#btnModificarFirewall").prop("disabled", true);
                }
            },
            error: function (data) {
                console.log(data);
                $("#seccionResultado").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* COMPARA EL FORMULARIO ORIGINAL CON EL MODIFICADO PARA VER QUE NO SEAN IGUALES */

    function comparaFormularios() {
        var formModificado = $("#formModificarFirewall").serialize();
        if (formOriginal !== formModificado) {
            $("#btnModificarFirewall").prop("disabled", false);
        } else {
            $("#btnModificarFirewall").prop("disabled", true);
        }
    }

});



