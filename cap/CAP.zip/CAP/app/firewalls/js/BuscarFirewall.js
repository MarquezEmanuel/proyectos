/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    $('#tbFirewalls').dataTable({
        lengthChange: false
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editarFirewall').click(function () {
        var idFirewall = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./app/firewalls/vistas/formModificarFirewall.php",
            data: "idFirewall=" + idFirewall,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.datosFirewall').click(function () {
        $("#modalNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalDatosFirewall").modal({});
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('.bajaFirewall').click(function () {
        $("#tituloModal").html("<i class='fas fa-fire-alt'></i> CONFIRME LA BAJA DEL FIREWALL");
        $("#modalAccion").val("BAJA");
        $("#modalIdFirewall").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find("td").eq(2).html());
        $("#ModalCambioEstadoFirewall").modal({backdrop: 'static', keyboard: false});
    });
    
    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('.altaFirewall').click(function () {
        $("#tituloModal").html("<i class='fas fa-fire-alt'></i> CONFIRME EL ALTA DEL FIREWALL");
        $("#modalAccion").val("ALTA");
        $("#modalIdFirewall").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find("td").eq(2).html());
        $("#ModalCambioEstadoFirewall").modal({backdrop: 'static', keyboard: false});
    });
    
    /* ENVIA LA OPERACION DE ALTA O BAJA Y MUESTRA EL RESULTADO EN EL MODAL */

    $('#btnCambiarEstadoFirewall').click(function () {
        $.ajax({
            type: "POST",
            url: "./app/firewalls/vistas/procesaCambiarEstadoFirewall.php",
            data: $("#formCambioEstadoFirewall").serialize(),
            success: function (data) {
                $('#cuerpoModal').html(data);
                $('#btnCambiarEstadoFirewall').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                $("#cuerpoModal").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });
    
    /* ACTUALIZA LA PANTALLA LUEGO DE HACER EL ALTA O BAJA */

    $('#btnRefrescarPantalla').click(function () {
        location.reload();
    });

});

