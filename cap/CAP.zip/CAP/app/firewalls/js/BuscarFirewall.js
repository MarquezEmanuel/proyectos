/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    $('#tbFirewalls').dataTable({
        lengthChange: false
    });
    
    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editarFirewall').click(function () {
        var idFirewall = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./app/firewalls/vistas/formModificarFirewall.php",
            data: "idFirewall=" + idFirewall,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });
    
    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.datosFirewall').click(function () {
        $("#modalNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalDatosFirewall").modal({});
    });
    

});

