<?php

/**
 * Description of ControladorFirewall
 *
 * @author Emanuel
 */
class ControladorFirewall {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $firewalls = new Firewalls();
        $resultado = $firewalls->buscar($nombre, $estado);
        $this->mensaje = $firewalls->getMensaje();
        return $resultado;
    }

    public function cambiarEstado($id, $estado) {
        $firewall = new Firewall($id, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, $estado);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $firewall->cambiarEstado();
            $this->mensaje = $firewall->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function crear($inventario, $nombre, $marca, $modelo, $nroSerie, $version, $sucursal, $ip) {
        $firewall = new Firewall(NULL, $inventario, $nombre, $marca, $modelo, $nroSerie, $version, $sucursal, $ip);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $creacion = $firewall->crear();
            $this->mensaje = $firewall->getMensaje();
            $confirmar = ($creacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function listarUltimosCreados() {
        $firewalls = new Firewalls();
        $resultado = $firewalls->listarUltimosCreados();
        $this->mensaje = $firewalls->getMensaje();
        return $resultado;
    }

    public function modificar($id, $inventario, $nombre, $marca, $modelo, $nroSerie, $version, $sucursal, $ip) {
        $firewall = new Firewall($id, $inventario, $nombre, $marca, $modelo, $nroSerie, $version, $sucursal, $ip);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $firewall->modificar();
            $this->mensaje = $firewall->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

}
