<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Firewall {

    private $id;
    private $inventario;
    private $firewall;
    private $marca;
    private $modelo;
    private $nroSerie;
    private $version;
    private $sucursal;
    private $ip;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $inventario = NULL, $firewall = NULL, $marca = NULL, $modelo = NULL, $nroSerie = NULL, $version = NULL, $sucursal = NULL, $ip = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setInventario($inventario);
        $this->setFirewall($firewall);
        $this->setMarca($marca);
        $this->setModelo($modelo);
        $this->setNroSerie($nroSerie);
        $this->setVersion($version);
        $this->setSucursal($sucursal);
        $this->setIp($ip);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getInventario() {
        return $this->inventario;
    }

    public function getFirewall() {
        return $this->firewall;
    }

    public function getMarca() {
        return $this->marca;
    }

    public function getModelo() {
        return $this->modelo;
    }

    public function getNroSerie() {
        return $this->nroSerie;
    }

    public function getVersion() {
        return $this->version;
    }

    public function getSucursal() {
        return $this->sucursal;
    }

    public function getIp() {
        return $this->ip;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setInventario($inventario) {
        $this->inventario = $inventario;
    }

    public function setFirewall($firewall) {
        $this->firewall = $firewall;
    }

    public function setMarca($marca) {
        $this->marca = $marca;
    }

    public function setModelo($modelo) {
        $this->modelo = $modelo;
    }

    public function setNroSerie($nroSerie) {
        $this->nroSerie = $nroSerie;
    }

    public function setVersion($version) {
        $this->version = $version;
    }

    public function setSucursal($sucursal) {
        $this->sucursal = $sucursal;
    }

    public function setIp($ip) {
        $this->ip = $ip;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("fir_firewall", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        return 1;
    }

    public function crear() {
        if ($this->firewall && $this->marca && $this->modelo && $this->nroSerie && $this->version && $this->ip && $this->sucursal) {
            $values = "('{$this->firewall}','{$this->marca}','{$this->modelo}', '{$this->nroSerie}', '$this->version', '{$this->ip}', '{$this->sucursal}', 1)";
            $creacion = SQLServer::instancia()->insertar("fir_firewall", $values);
            $this->mensaje = $this->firewall . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->crearRelacion();
            }
            return $creacion;
        }
        return 1;
    }

    private function crearRelacion() {
        $consulta = "INSERT INTO fir_firewalls_inventarios SELECT {$this->id}, id FROM inv_inventarios WHERE estado = 1";
        $creacion = SQLServer::instancia()->ejecutar($consulta);
        $this->mensaje = $this->firewall . ": " . SQLServer::instancia()->getMensaje();
        if ($creacion == 2) {
            return $this->registrarActividad("CREACION", $this->id);
        }
        return $creacion;
    }

    public function modificar() {
        if ($this->firewall && $this->marca && $this->modelo && $this->nroSerie && $this->version && $this->ip && $this->sucursal) {
            $campos = "firewall = '{$this->firewall}', marca='{$this->marca}', "
                    . "modelo = '{$this->modelo}', numeroSerie='{$this->nroSerie}', "
                    . "version='{$this->version}', ip='{$this->ip}', sucursal='{$this->sucursal}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("fir_firewall", $campos, $condicion);
            $this->mensaje = $this->firewall . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM fir_firewall WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->firewall = $fila['firewall'];
                $this->marca = $fila['marca'];
                $this->modelo = $fila['modelo'];
                $this->nroSerie = $fila['numeroSerie'];
                $this->version = $fila['version'];
                $this->ip = $fila['ip'];
                $this->estado = $fila['estado'];
                return $this->obtenerSitio($fila['sucursal']);
            }
            $this->mensaje = "No se obtuvo la información del firewall";
            return 1;
        }
        return 0;
    }

    private function obtenerSitio($idSitio) {
        $sitio = new Sitio($idSitio);
        if ($sitio->obtener() == 2) {
            $this->sucursal = $sitio;
            return 2;
        }
        $this->mensaje = $sitio->getMensaje();
        return 1;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("fir_firewall", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
