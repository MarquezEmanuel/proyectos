<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Firewalls {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM reporteFirewalls WHERE nombre LIKE '%{$nombre}%' AND nomEstadoFirewall = '{$estado}' AND codEstadoInventario = 1";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarPorInventario($siglaInventario) {
        $consulta = "SELECT * FROM reporteFirewalls WHERE siglaInventario = '{$siglaInventario}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimosCreados() {
        $consulta = "SELECT TOP(10) * FROM reporteFirewalls WHERE codEstadoFirewall = 1 AND codEstadoInventario = 1 ORDER BY idFirewall DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
