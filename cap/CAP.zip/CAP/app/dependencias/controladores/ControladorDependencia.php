<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ControladorDependencia {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $dependencias = new Dependencias();
        $resultado = $dependencias->buscar($nombre, $estado);
        $this->mensaje = $dependencias->getMensaje();
        return $resultado;
    }

    public function cambiarEstado($id, $estado) {
        $dependencia = new Dependencia($id, NULL, NULL, NULL, NULL, NULL, $estado);
        $modificacion = $dependencia->cambiarEstado();
        $this->mensaje = $dependencia->getMensaje();
        return $modificacion;
    }

    public function crear() {
        
    }

    public function listarUltimasCreadas() {
        $dependencias = new Dependencias();
        $resultado = $dependencias->listarUltimasCreadas();
        $this->mensaje = $dependencias->getMensaje();
        return $resultado;
    }

    public function modificar($id) {
        
    }

}
