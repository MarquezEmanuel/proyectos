<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Dependencia {

    private $id;
    private $categoria;
    private $nivel;
    private $sigla;
    private $nombre;
    private $padre;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $categoria = NULL, $nivel = NULL, $sigla = NULL, $nombre = NULL, $padre = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setCategoria($categoria);
        $this->setNivel($nivel);
        $this->setSigla($sigla);
        $this->setNombre($nombre);
        $this->setPadre($padre);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getCategoria() {
        return $this->categoria;
    }

    public function getNivel() {
        return $this->nivel;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getPadre() {
        return $this->padre;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
        $this->mensaje = ($id) ? $this->mensaje : "No se pudo hacer referencia a la dependencia";
    }

    public function setCategoria($categoria) {
        $this->categoria = $categoria;
        $this->mensaje = ($categoria) ? $this->mensaje : "No se indicó la categoria";
    }

    public function setNivel($nivel) {
        $this->nivel = $nivel;
        $this->mensaje = ($nivel) ? $this->mensaje : "No se indicó el nivel";
    }

    public function setSigla($sigla) {
        $this->sigla = $sigla;
        $this->mensaje = ($sigla) ? $this->mensaje : "No se indicó la sigla";
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
        $this->mensaje = ($nombre) ? $this->mensaje : "No se indicó el nombre";
    }

    public function setPadre($padre) {
        $this->padre = $padre;
        $this->mensaje = ($padre) ? $this->mensaje : "No se indicó el padre";
    }

    public function setEstado($estado) {
        $this->estado = $estado;
        $this->mensaje = ($estado) ? $this->mensaje : "No se indicó el estado";
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("dep_dependencias", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function crear() {
        if ($this->categoria && $this->nivel && $this->padre && $this->sigla && $this->nombre) {
            $values = "('{$this->categoria}', {$this->nivel}, {$this->padre}, '{$this->sigla}', '{$this->nombre}' 1)";
            $creacion = SQLServer::instancia()->insertar("dep_dependencias", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        return 0;
    }

    public function modificar() {
        if ($this->categoria && $this->nivel && $this->padre && $this->sigla && $this->nombre) {
            $campos = "categoria = '{$this->categoria}', nivel = {$this->nivel}, padre = {$this->padre}, sigla='{$this->sigla}', nombre='{$this->nombre}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("dep_dependencias", $campos, $condicion);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("dep_dependencias", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
