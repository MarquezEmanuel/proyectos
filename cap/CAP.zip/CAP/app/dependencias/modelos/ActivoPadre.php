<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ActivoPadre {

    private $id;
    private $categoria;
    private $sigla;
    private $nombre;
    private $estado;
    private $hijos;
    private $mensaje;

    public function __construct($id = NULL, $categoria = NULL, $sigla = NULL, $nombre = NULL, $estado = NULL, $hijos = NULL) {
        $this->setId($id);
        $this->setCategoria($categoria);
        $this->setSigla($sigla);
        $this->setNombre($nombre);
        $this->setEstado($estado);
        $this->setHijos($hijos);
    }

    public function getId() {
        return $this->id;
    }

    public function getCategoria() {
        return utf8_encode($this->categoria);
    }

    public function getSigla() {
        return utf8_encode($this->sigla);
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getHijos() {
        return $this->hijos;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setCategoria($categoria) {
        $this->categoria = utf8_decode($categoria);
    }

    public function setSigla($sigla) {
        $this->sigla = utf8_decode($sigla);
    }

    public function setNombre($nombre) {
        $this->nombre = utf8_decode($nombre);
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setHijos($hijos) {
        $this->hijos = $hijos;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("dep_activos_padres", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crear() {
        if ($this->categoria && $this->sigla && $this->nombre) {
            $values = "('{$this->categoria}', '{$this->sigla}', '{$this->nombre}', 1)";
            $creacion = SQLServer::instancia()->insertar("dep_activos_padres", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion != 2) {
                return $creacion;
            }
            $this->id = SQLServer::instancia()->getUltimoId();
            $creacionHijos = $this->crearRelacionHijos();
            if ($creacionHijos == 2) {
                return $this->crearRelacionInventario();
            }
            return $creacionHijos;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    private function crearRelacionHijos() {
        if ($this->hijos && !empty($this->hijos)) {
            $values = "";
            foreach ($this->hijos as $hijo) {
                $values = "({$this->id}, {$hijo}),";
            }
            $creacion = SQLServer::instancia()->insertar("dep_dependencias", substr($values, 0, -1));
            $this->mensaje = $this->nombre . ":" . SQLServer::instancia()->getMensaje();
            return $creacion;
        }
        $this->mensaje = "No se recibieron los activos hijos a asociar";
        return 0;
    }

    private function crearRelacionInventario() {
        $consulta = "INSERT INTO dep_activos_inventarios SELECT {$this->id}, id FROM inv_inventarios WHERE estado = 1";
        $creacion = SQLServer::instancia()->ejecutar($consulta);
        $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
        if ($creacion == 2) {
            return $this->registrarActividad("CREACION", $this->id);
        }
        return $creacion;
    }

    public function modificar() {
        
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM dep_activos_padres WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->categoria = $fila['categoria'];
                $this->sigla = $fila['sigla'];
                $this->nombre = $fila['nombre'];
                $this->estado = $fila['estado'];
                return $this->obtenerHijos();
            }
            $this->mensaje = "No se obtuvo la información del activo hijo";
            return 1;
        }
        $this->mensaje = "No se pudo hacer referencia al activo padre";
        return 0;
    }

    private function obtenerHijos() {
        $activos = new ActivosHijos();
        $resultado = $activos->listarPorPadre($this->id);
        if ($resultado == 2) {
            $this->hijos = $resultado;
            return 2;
        }
        $this->mensaje = "Activos hijos: " . $activos->getMensaje();
        return 1;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("dep_activos_padres", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
