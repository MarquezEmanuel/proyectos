<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ActivosHijos {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM reporteActivosHijos WHERE nombre LIKE '%{$nombre}%' AND nomEstado = '{$estado}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarPorPadre($idPadre) {
        if ($idPadre) {
            $consulta = "";
            $resultado = SQLServer::instancia()->seleccionar($consulta);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            return $resultado;
        }
        $this->mensaje = "No se pudo hacer referencia al activo padre";
        return 0;
    }

    public function listarUltimosCreados() {
        $consulta = "SELECT TOP(10) * FROM reporteActivosHijos WHERE codEstado = 1 ORDER BY id DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
