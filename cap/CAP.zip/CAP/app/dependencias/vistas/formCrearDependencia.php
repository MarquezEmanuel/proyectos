<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3">
            <div class="col text-left">
                <h4><i class="far fa-building"></i> CREAR DEPENDENCIA</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearDependencia" name="formCrearDependencia" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="categoria" class="col-sm-2 col-form-label text-left">* Categoria:</label>
                        <div class="col">
                            <select id="categoria" name="categoria" class="form-control mb-2" required>
                                <option value="Datos/Información">Datos/Información</option>
                                <option value="Entorno">Entorno</option>
                                <option value="Macro procesos">Macro procesos</option>
                                <option value="Recursos informaticos">Recursos informaticos</option>
                                <option value="Servicios internos">Servicios internos</option>
                                <option value="Servicios subcontratados">Servicios subcontratados</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="nivel" class="col-sm-2 col-form-label text-left">* Nivel:</label>
                        <div class="col">
                            <select id="nivel" name="nivel" class="form-control mb-2" required>
                                <option value="1">1</option>
                                <option value="2">2</option>
                            </select>
                        </div>
                        <label for="padre" class="col-sm-2 col-form-label text-left">* Padre:</label>
                        <div class="col">
                            <select id="padre" name="padre" class="form-control mb-2" required>
                                <option value="1">1</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="sigla" class="col-sm-2 col-form-label text-left">* Sigla:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="sigla" id="sigla" 
                                   maxlength="20"
                                   placeholder="Siglas de la dependencia">
                        </div>
                        <label for="padre" class="col-sm-2 col-form-label text-left">* Nombre:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="nombre" id="nombre" 
                                   maxlength="50"
                                   placeholder="Nombre de la dependencia">
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
                    <a href="dependencias_buscar">
                        <button type="button" class="btn btn-outline-info">
                            <i class="fas fa-search"></i> BUSCAR
                        </button>
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="../js/CrearDependencia.js"></script>