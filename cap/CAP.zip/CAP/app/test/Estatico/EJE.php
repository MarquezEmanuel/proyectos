<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class EJE {

    private static $mensaje;

    public static function getMensaje() {
        return self::$mensaje;
    }

    public static function buscar() {
        self::$mensaje = "Metodo buscar";
    }

    public static function listar() {
        self::$mensaje = "listar";
    }

}
