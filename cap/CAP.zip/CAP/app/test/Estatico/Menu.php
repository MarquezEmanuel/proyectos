<?php

include './EJE.php';


EJE::buscar();
echo EJE::getMensaje();

EJE::listar();
echo "<br><br>" . EJE::getMensaje();


