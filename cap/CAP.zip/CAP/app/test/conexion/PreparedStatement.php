<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require '../../principal/modelos/Constantes.php';
require '../../principal/modelos/Log.php';
require '../../principal/modelos/Encriptador.php';
require '../../principal/modelos/ConfiguracionBD.php';
require '../../principal/modelos/SQLServerPE.php';

session_start();
$id = '07484';
$nombre = 'Maria Lopez';
$estado = 1;
$perfil = 1;
$parametros = array(&$id, &$nombre, &$perfil, &$estado);
$consulta = "INSERT INTO seg_usuarios OUTPUT INSERTED.id VALUES (?,?,?,?)";
/*
  $resultado = SQLServerPE::instancia()->insertar($consulta, $parametros);
  echo SQLServerPE::instancia()->getMensaje();
  echo '<br>' . SQLServerPE::instancia()->getUltimoId();
 */

/*
  $select = "SELECT * FROM seg_usuarios";
  $aprametros = array(&$estado);
  $resultado2 = SQLServerPE::instancia()->seleccionar($select, array());
  echo gettype($resultado2); */


$update = "UPDATE seg_usuarios SET nombre = ? where id = ?";
$nombre = "D'Alessandro Andrés";
$resultado = SQLServerPE::instancia()->modificar($update, array(&$nombre, &$id));
echo SQLServerPE::instancia()->getMensaje();
