<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require '../../principal/modelos/Constantes.php';
require '../../principal/modelos/Log.php';
require '../../principal/modelos/Encriptador.php';
require '../../principal/modelos/ConfiguracionBD.php';
require '../../principal/modelos/SQLServer.php';

session_start();
$id = '07460';
$nombre = 'Maria Lopez';
$estado = 1;
$perfil = 1;

$id2 = '07461';
$nombre2 = 'Pepe Gonzalez';
$estado2 = 1;
$perfil2 = 1;

$parametros = array(&$id, &$nombre, &$perfil, &$estado, &$id2, &$nombre2, &$perfil2, &$estado2);

$consulta = "INSERT INTO seg_usuario VALUES (?,?,?,?), (?,?,?,?)";

$resultado = SQLServer::instancia()->insertar($consulta, $parametros);
echo SQLServer::instancia()->getMensaje();
echo '<br>' . SQLServer::instancia()->getUltimoId();


/*
  $select = "SELECT * FROM seg_usuarios";
  $aprametros = array(&$estado);
  $resultado2 = SQLServerPE::instancia()->seleccionar($select, array());
  echo gettype($resultado2); */

/*
$update = "UPDATE seg_usuarios SET nombre = ? where id = ?";
$nombre = "D'Alessandro Andrés";
$resultado = SQLServerPE::instancia()->modificar($update, array(&$nombre, &$id));
echo SQLServerPE::instancia()->getMensaje();
*/