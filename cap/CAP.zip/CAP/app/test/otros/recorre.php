<?php

$rutina = "En un post anterior titulado Control de sesiones – \r\n Autenticación de usuarios usando PHP y MySQL, se habló referente a cómo realizar un inicio de sesión que se autentique contra un tabla de usuarios en mysql y éste cree una sesión para éste usuario, de tal manera que nuestra aplicación esté protegida mediante ésta sesión y, cuando el usuario se salga del aplicativo web, se destruya la sesión. Bien, en ésta entrada veremos otra opción de autenticación; en lugar de una tabla en mysql, podemos usar Active Directory de un Windows Server (probado con versión 2000, 2003, 2008 y 2012). Si desean saber cómo gestionar los usuarios, ver la entrada: Uso básico de Active Directory – Windows Server.
    Bien, un poco de teoría: ¿Qué es Active Directory? Implementación de un servicio de directorio en una red distribuida de computadores; almacena y organiza la información sobre los usuarios de una red de computadoras, sobre recursos de red, y permite a los administradores gestionar el acceso de usuarios a los recursos sobre dicha red.
    Yo lo veo (puntualmente hablando) como una base de datos de usuarios, grupos de usuarios, computadoras, etc. de tal manera nos pueda servir para centralizar la autenticación de los usuarios y aplicar políticas a nivel de dominio.
    Ahora, a lo que venimos… El requisito que necesitamos es que nuestra instalación PHP tenga la extensión o librerías que soporte LDAP. Como soy bastante «Linuxero», éste tutorial va enfocado para Ubuntu, pero para Windows es la misma lógica. Para los que tengan duda de PHP… Se recuerdan de la tecnología LAMP?
    Instalando ldap en php. Nos vamos a una terminal y digitamos:";


for ($index = 0; $index < strlen($rutina); $index++) {
    echo "<br>" . $rutina[$index];
}

