<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

echo "<br>" . date("Y-m-d");

$fecha1 = new DateTime('1900-01-01');
$fecha2 = new DateTime('now');
$diff = $fecha1->diff($fecha2);

echo "<br>" . $diff->days . ' days ';

$fecha3 = new DateTime('1957-01-01');
$fecha4 = new DateTime('now');
$diff2 = $fecha3->diff($fecha4);
echo "<br>" . $diff2->days . ' days ';


echo "<br>" . ($diff->days - $diff2->days);
