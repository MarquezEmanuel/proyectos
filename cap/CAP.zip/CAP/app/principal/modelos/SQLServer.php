<?php

class SQLServer {

    /** Instancia de la conexion con la BD */
    public static $instancia;

    /** @var Conexion con la base de datos */
    private $conexion;

    /** @var integer Identificador de registro */
    private $id;

    /** @var string Mensaje que describe el resultado de una operacion */
    private $mensaje;

    public function __construct() {
        $configuracion = new ConfiguracionBD();
        $lectura = $configuracion->leerConfiguracion();
        if ($lectura) {
            $host = $configuracion->getHost();
            $usuario = $configuracion->getUsuario();
            $clave = $configuracion->getPassword();
            $baseDatos = $configuracion->getBaseDatos();
            $datosConexion = array("Database" => $baseDatos, "UID" => $usuario, "PWD" => $clave);
            $this->conectar($host, $datosConexion);
        } else {
            Log::escribirError("Error al leer archivo de configuracion", "__construct()");
        }
    }

    /**
     * Realiza la eliminacion de un registro en la BD. El metodo retorna 1 cuando
     * ocurre un error durante la ejecucion de la consulta, retorna 2 si no se ha
     * eliminado el registro indicado o 3 en caso de realizar la operacion en forma
     * correcta.
     * @param string $tabla Nombre de la tabla donde operar.
     * @param string $condicion Condicion para el o los registros a eliminar.
     * @return integer Retorna 1 para error, 2 para no eliminado o 3 para exito.
     */
    public function borrar($tabla, $condicion) {
        $consulta = "DELETE FROM {$tabla} WHERE {$condicion}";
        $resultado = sqlsrv_query($this->conexion, $consulta);
        if ($resultado) {
            if (sqlsrv_rows_affected($resultado) > 0) {
                $this->mensaje = "Se eliminó el registro correctamente";
                return 2;
            }
            $this->mensaje = "No se eliminó el registro";
            return 1;
        }
        Log::escribirError("Error al realizar DELETE en la BD", "borrar({$consulta})");
        $this->mensaje = "No se eliminó el registro por un error interno (comunicar al administrador)";
        return 0;
    }

    /**
     * Realiza la conexion con la BD. Cuando se establece la conexion se asigna el
     * recurso al objeto conexion, en caso contrario sera nulo. 
     * @param string $host Nombre del host donde realizar la conexion.
     * @param array $datos Arreglo que contiene el nombre de la BD, usuario y clave.
     */
    private function conectar($host, $datos) {
        $this->conexion = sqlsrv_connect($host, $datos);
        if (!$this->conexion) {
            $this->conexion = NULL;
            Log::escribirError("Error al realizar la conexion a la BD", "conectar($host, {$datos['Database']}, {$datos['UID']}, {$datos['PWD']})");
        }
    }

    /**
     * Finaliza la transaccion con la BD. Cuando se indica que el resultado es true
     * se aplica un commit en la BD, cuando se indica que el resultado es false se
     * aplica un rollback en la BD. 
     * @param boolean $resultado Resultado del conjunto de operaciones realizadas.
     */
    public function finalizarTransaccion($resultado = TRUE) {
        ($resultado) ? sqlsrv_commit($this->conexion) : sqlsrv_rollback($this->conexion);
    }

    public function getUltimoId() {
        return $this->id;
    }

    /**
     * Devuelve el mensaje sobre el resultado de alguna consulta a la BD.
     * @return string Mensaje que describe el resultado de alguna operacion.
     */
    public function getMensaje() {
        return $this->mensaje;
    }

    /**
     * Inicia el proceso de transaccion. El metodo retorna true cuando la inicializacion
     * es correcta y false en caso contrario.
     * @return boolean True si se inicializa, false en caso contrario.
     */
    public function iniciarTransaccion() {
        if (sqlsrv_begin_transaction($this->conexion) === false) {
            $this->mensaje = "No se pudo incializar la transaccion para operar";
            Log::escribirLineaError("Error al inicializar transaccion con la BD");
            return false;
        }
        return true;
    }

    /**
     * Realiza la creacion de un nuevo registro en la BD. El metodo retorna 1 cuando
     * ocurre un error durante la ejecucion de la consulta, retorna 2 cuando no se
     * creo el registro por duplicidad o retorna 3 cuando se realiza la creacion del
     * registro correctamente.
     * @param string $tabla Nombre de la tabla donde se realiza la creacion.
     * @param string $valores Los valores de los campos a insertar.
     * @return integer Retorna 1 para error, 2 cuando no se crea 3 si se crea.
     */
    public function insertar($tabla, $valores) {
        $consulta = "INSERT INTO {$tabla} OUTPUT INSERTED.id VALUES {$valores}";
        $resultado = sqlsrv_query($this->conexion, $consulta);
        if ($resultado) {
            $row = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC);
            $this->id = $row['id'];
            $this->mensaje = "Se creó el registro correctamente";
            return 2;
        }
        if (($errores = sqlsrv_errors() ) != null) {
            foreach ($errores as $error) {
                if ($error['code'] == 3621) {
                    $this->mensaje = "No se creó el registro solicitado porque ya existe";
                    return 1;
                }
            }
        }
        Log::escribirLineaError("Error al realizar INSERT en la BD - insertar($consulta)");
        $this->mensaje = "No se creó el registro por un error interno (comunicar al administrador)";
        return 0;
    }

    public function ejecutar($consulta) {
        $resultado = sqlsrv_query($this->conexion, $consulta);
        if ($resultado) {
            $this->mensaje = "Se creó el registro correctamente";
            return 2;
        }
        if (($errores = sqlsrv_errors() ) != null) {
            foreach ($errores as $error) {
                if ($error['code'] == 3621) {
                    $this->mensaje = "No se creó el registro solicitado porque ya existe";
                    return 1;
                }
            }
        }
        Log::escribirLineaError("Error al realizar INSERT en la BD - insertar($consulta)");
        $this->mensaje = "No se creó el registro por un error interno (comunicar al administrador)";
        return 0;
    }

    /**
     * Realiza la creacion de una nueva instancia de la conexion a la BD o devuelve
     * la instancia existente.
     */
    public static function instancia() {
        if (!self::$instancia instanceof self) {
            try {
                self::$instancia = new self;
            } catch (Exception $e) {
                Log::escribirError("Error al obtener instancia de la conexion a la BD - {$e->getCode()} - {$e->getMessage()}", "instancia()");
            }
        }
        return self::$instancia;
    }

    /**
     * Realiza una actualizacion sobre la BD. El metodo retorna 1 cuando ocurre un
     * error durante la ejecucion de la consulta, retorna 2 cuando se encuentra un
     * error de duplicidad (campo UNIQUE) o retorna 3 cuando se realiza la operacion
     * correctamente.
     * @param string $tabla Nombre de la tabla donde se realiza la modificacion.
     * @param string $campos Campos de la tabla que se van a modificar.
     * @param string $condicion Condicion para los registros a modificar.
     */
    public function modificar($tabla, $campos, $condicion) {
        $consulta = "UPDATE {$tabla} SET {$campos} WHERE {$condicion}";
        $resultado = sqlsrv_query($this->conexion, $consulta);
        if ($resultado) {
            if (sqlsrv_rows_affected($resultado) > 0) {
                $this->mensaje = "Se modificó el registro correctamente";
                return 2;
            }
        }
        if (($errores = sqlsrv_errors() ) != null) {
            foreach ($errores as $error) {
                if ($error['code'] == 2627) {
                    $this->mensaje = "No se modificó el registro solicitado porque ya existe";
                    return 1;
                }
            }
        }
        Log::escribirLineaError("Error al realizar UPDATE en la BD (QUERY: $consulta)");
        $this->mensaje = "No se modificó el registro por un error interno (comunicar al administrador)";
        return 0;
    }

    public function obtener($consulta) {
        $resultado = sqlsrv_query($this->conexion, $consulta);
        if ($resultado) {
            return sqlsrv_has_rows($resultado) ? sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC) : array();
        }
        $this->descripcion = "Error al obtener registro";
        Log::escribirLineaError("[METODO: obtener][ERROR: Error al obtener registro (QUERY: $consulta)");
        return NULL;
    }

    /**
     * Realiza una consulta a la BD con el objetivo de obtener una serie de registros.
     * El metodo retorna NULL cuando ocurre un errror de ejecucion de la consulta,
     * retorna un array vacio cuando no se han obtenido resultados o un array
     * asociativo cuando se obtuvieron resultados.
     * @param string $consulta Consulta SQL a realizar sobre la BD.
     */
    public function seleccionar($consulta) {
        $resultado = sqlsrv_query($this->conexion, $consulta, array(), array('Scrollable' => SQLSRV_CURSOR_KEYSET));
        if ($resultado) {
            if (sqlsrv_has_rows($resultado)) {
                $this->mensaje = "Se encontraron resultados";
                return $resultado;
            }
            $this->mensaje = "No se encontraron resultados";
            return 1;
        }
        Log::escribirLineaError("SELECCIONAR: Error al realizar SELECT en la BD (QUERY: $consulta)");
        $this->mensaje = "Ocurrio un error al realizar la consulta (informe al administrador)";
        return 0;
    }

    /**
     * Realiza una consulta a la BD con el objetivo de verificar alguna existencia 
     * de registro o la relacion entre tablas. El metodo retorna 1 cuando ocurre un
     * error de ejecucion de la consulta, retorna 2 cuando no se han obtenido filas
     * al ejecutar la consulta o retorna 3 cuando se obtuvieron resultados.
     * @param string $consulta Consulta SQL a realizar sobre la BD.
     * @return integer Retorna 1 para error, 2 sin resultados o 3 con resultados. 
     */
    public function verificar($consulta) {
        $resultado = sqlsrv_query($this->conexion, $consulta);
        if ($resultado) {
            $existe = (sqlsrv_has_rows($resultado)) ? 3 : 2;
            $this->mensaje = ($existe == 3) ? "Existe al menos un registro que coincide con el indicado" : "No existen registros que coincidan con el indicado";
            return $existe;
        }
        $this->mensaje = "No se pudo verificar el registro por un error interno (comunicar al administrador)";
        Log::escribirError("Error al realizar SELECT en la BD", "verificar($consulta)");
        return 1;
    }

    /**
     * Realiza la verificacion sobre la conexion a la BD. El metodo retorna true
     * cuando existe instanciada la conexion con la BD o retorna false cuando esta
     * es nula.
     * @return boolean True si hay conexion o false si no hay conexion.
     */
    public function verificarConexion() {
        return ($this->conexion) ? true : false;
    }

}
