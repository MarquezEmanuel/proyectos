<?php

/* ESTRUCTURA DE DIRECTORIOS DEL SISTEMA */

const ROOT = "C:\\xampp\\htdocs\\CAP";
const APP = ROOT . "\\app";
const LOG = ROOT . "\\logs";
const ACT = APP . "\\actividades";
const BAS = APP . "\\bases";
const FIR = APP . "\\firewalls";
const GER = APP . "\\gerencias";
const HAR = APP . "\\hardwares";
const HER = APP . "\\herramientas";
const INS = APP . "\\instalaciones";
const INV = APP . "\\inventarios";
const LEN = APP . "\\lenguajes";
const ROL = APP . "\\perfiles";
const PER = APP . "\\permisos";
const PLA = APP . "\\plataformas";
const PRI = APP . "\\principal";
const PRO = APP . "\\proveedores";
const PSA = APP . "\\procesamientos";
const SRV = APP . "\\servidores";
const SIT = APP . "\\sitios";
const USU = APP . "\\usuarios";
const UTI = APP . "\\utilidades";

const LDAP_HOST = "ldap://192.168.250.150";
const LDAP_PORT = 389;
const LDAP_DOMI = "desarrollo\\";


