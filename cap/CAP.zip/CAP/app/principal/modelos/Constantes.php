<?php

/* ESTRUCTURA DE DIRECTORIOS DEL SISTEMA */

const ROOT = "C:\\xampp\\htdocs\\CAP";
const APP = ROOT . "\\app";
const LOG = ROOT . "\\logs";
const ACT = APP . "\\actividades";
const APL = APP . "\\aplicaciones";
const BAS = APP . "\\bases";
const LEN = APP . "\\lenguajes";
const ROL = APP . "\\perfiles";
const PER = APP . "\\permisos";
const PRI = APP . "\\principal";
const PRO = APP . "\\proveedores";
const SRV = APP . "\\servidores";
const USU = APP . "\\usuarios";
const UTI = APP . "\\utilidades";

const LDAP_HOST = "ldap://192.168.250.150";
const LDAP_PORT = 389;
const LDAP_DOMI = "desarrollo\\";

const IMG = ROOT . "\\lib\\img";
const DOCS_BASE = ROOT . "\\docs\\baseDatos";

