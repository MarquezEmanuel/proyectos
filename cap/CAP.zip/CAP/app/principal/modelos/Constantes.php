<?php

/* ESTRUCTURA DE DIRECTORIOS DEL SISTEMA */

const ROOT = "C:\\xampp\\htdocs\\CAP";
const APP = ROOT . "\\app";
const LOG = ROOT . "\\logs";
const ACT = APP . "\\actividades";
const BAS = APP . "\\bases";
const COM = APP . "\\comunicaciones";
const FIR = APP . "\\firewalls";
const GER = APP . "\\gerencias";
const HAR = APP . "\\hardwares";
const INS = APP . "\\instalaciones";
const INV = APP . "\\inventarios";
const ROL = APP . "\\perfiles";
const PER = APP . "\\permisos";
const PRI = APP . "\\principal";
const PCE = APP . "\\procesos";
const PRO = APP . "\\proveedores";
const SER = APP . "\\servicios";
const SRV = APP . "\\servidores";
const SIT = APP . "\\sitios";
const USU = APP . "\\usuarios";

