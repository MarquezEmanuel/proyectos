<?php

/**
 * Description of ControladorPrincipal
 *
 * @author Emanuel
 */
class ControladorPrincipal {

    private $controladorFormulario;

    public function __construct($ruta) {
        $this->controladorFormulario = new ControladorFormulario();
        if (isset($_SESSION['usuario'])) {
            $this->evaluarAccesoVistas($ruta);
        } else {
            if ($ruta == "principal_home" && isset($_POST['legajo'])) {
                $legajo = $_POST['legajo'];
                $this->verificarUsuarioSistema($legajo);
            } else {
                $_SESSION['mensajeLogin'] = "NO INGRESAS " . $ruta;
                $this->controladorFormulario->cargarLogin();
            }
        }
    }

    private function verificarUsuarioSistema($legajo) {
        $usuario = new Usuario();
        $usuario->setId($legajo);
        $resultado = $usuario->obtener();
        if ($resultado == 2) {
            $_SESSION['usuario'] = $usuario;
            $_SESSION['vistas'] = $usuario->getPerfil()->obtenerVistas();
            $this->controladorFormulario->cargarVista("principal", "home");
        } else {
            $_SESSION['mensajeLogin'] = "NO EXISTIS";
            $this->controladorFormulario->cargarLogin();
        }
    }

    private function evaluarAccesoVistas($ruta) {
        if ($ruta) {
            $this->controladorFormulario->evaluarVista($ruta);
        }
    }

}
