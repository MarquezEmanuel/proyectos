<?php
/**
 * Description of ControladorPrincipal
 *
 * @author Emanuel
 */
class ControladorPrincipal {

    public function verificarUsuarioSistema($legajo) {
        $usuario = new Usuario();
        $usuario->setId($legajo);
        $resultado = $usuario->obtener();
        if ($resultado == 2) {
            $_SESSION['usuario'] = $usuario;
            $_SESSION['vistas'] = $usuario->getPerfil()->obtenerVistas();
            return true;
        }
        return false;
    }

}