<?php

/**
 * Description of ControladorAcceso
 *
 * @author Emanuel
 */
class ControladorAcceso {

    
    public function __construct() {
        ;
    }
    
    
    
    
}
