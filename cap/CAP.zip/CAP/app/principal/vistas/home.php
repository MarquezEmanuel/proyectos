<?php require_once './header.php'; ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <div class="col text-left">
                <li class="breadcrumb-item active">TITULO HOME</li>
            </div>
            <div class="col text-left">
                <li class="breadcrumb-item active">TITULO HOME</li>
            </div>
        </ol>
        <div class="card mb-3">
            <div class="card-header"><i class="fas fa-table"></i> <i class="fas fa-angle-right"></i>  Data Table Example </div>
            <div class="card-body">
                
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
        </div>
    </div>
</div>