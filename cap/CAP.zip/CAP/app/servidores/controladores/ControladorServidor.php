<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ControladorServidor
 *
 * @author Emanuel
 */
class ControladorServidor {

    //put your code here

    private $mensaje;

    public function __construct() {
        
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $tipo) {
        $servidores = new Servidores();
        $resultado = $servidores->buscar($nombre, $tipo);
        $this->mensaje = $servidores->getMensaje();
        return $resultado;
    }

    public function crear($nombre, $ip, $ambiente, $tipo, $descripcion) {
        $servidor = new Servidor(NULL, $nombre, $ip, $ambiente, $tipo, $descripcion);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $servidor->crear();
            $this->mensaje = $servidor->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar con el servidor";
        return 0;
    }

    public function listarUltimosCreados() {
        $servidores = new Servidores();
        $resultado = $servidores->listarUltimosCreados();
        $this->mensaje = $servidores->getMensaje();
        return $resultado;
    }

    public function modificar($id, $nombre, $ip, $ambiente, $tipo, $descripcion) {
        $servidor = new Servidor($id, $nombre, $ip, $ambiente, $tipo, $descripcion);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $modificacion = $servidor->modificar();
            $this->mensaje = $servidor->getMensaje();
            if ($modificacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar con el servidor";
        return 0;
    }

}
