<?php

class Servidor {

    private $id;
    private $nombre;
    private $ip;
    private $ambiente;
    private $tipo;
    private $descripcion;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $nombre = NULL, $ip = NULL, $ambiente = NULL, $tipo = NULL, $descripcion = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setIp($ip);
        $this->setAmbiente($ambiente);
        $this->setTipo($tipo);
        $this->setDescripcion($descripcion);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getIp() {
        return $this->ip;
    }

    public function getAmbiente() {
        return $this->ambiente;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setIp($ip) {
        $this->ip = $ip;
    }

    public function setAmbiente($ambiente) {
        $this->ambiente = $ambiente;
    }

    public function setTipo($tipo) {
        $this->tipo = $tipo;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function crear() {
        if ($this->nombre && $this->ambiente && $this->tipo && $this->descripcion) {
            $values = "('{$this->nombre}', '{$this->ip}',{$this->ambiente}, {$this->tipo}, '{$this->descripcion}', 1)";
            $creacion = SQLServer::instancia()->insertar("srv_servidores", $values);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->crearRelacion();
            }
            return $creacion;
        }
        $this->mensaje = "No se recibieron todos los campos obligatorios";
        return 0;
    }

    private function crearRelacion() {
        $consulta = "INSERT INTO srv_servidores_inventarios SELECT {$this->id}, id FROM inv_inventarios WHERE estado = 1";
        $creacion = SQLServer::instancia()->ejecutar($consulta);
        $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
        if ($creacion == 2) {
            return $this->registrarActividad("CREACION", $this->id);
        }
        return $creacion;
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->ambiente && $this->tipo && $this->descripcion) {
            $campos = "nombre = '{$this->nombre}', ambiente = {$this->ambiente}, tipo = {$this->tipo}, descripcion='{$this->descripcion}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("srv_servidores", $campos, $condicion);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron todos los campos obligatorios";
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM srv_servidores WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->nombre = $fila['nombre'];
                $this->ip = $fila['ip'];
                $this->ambiente = $fila['ambiente'];
                $this->tipo = $fila['tipo'];
                $this->descripcion = $fila['descripcion'];
                $this->estado = $fila['estado'];
                return 2;
            }
            $this->mensaje = "No se obtuvo la información del servidor";
            return 1;
        }
        $this->mensaje = "No se pudo hacer referencia al servidor";
        return 0;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("srv_servidores", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
