<?php

/**
 * Description of Servidores
 *
 * @author Emanuel
 */
class Servidores {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $tipo) {
        $consulta = "SELECT * FROM ser_servidor WHERE nombre LIKE ? AND ambiente = ? AND tipo = ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$nombre, &$tipo));
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimosCreados() {
        $consulta = "SELECT TOP(10) * FROM ser_servidor WHERE estado = 'Activo' ORDER BY id";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function seleccionar($nombre, $ambiente, $tipo) {
        $consulta = "SELECT * FROM ser_servidor WHERE nombre LIKE ? AND ambiente = ? AND tipo = ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$nombre, &$ambiente, &$tipo));
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
