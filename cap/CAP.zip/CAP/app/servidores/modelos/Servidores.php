<?php

/**
 * Description of Servidores
 *
 * @author Emanuel
 */
class Servidores {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $tipo) {
        $consulta = "SELECT * FROM reporteServidores WHERE nombreServidor LIKE '%{$nombre}%' "
                . "AND codigoTipo = {$tipo} AND codEstadoInventario = 1";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimosCreados() {
        $consulta = "SELECT TOP(10) * FROM reporteServidores WHERE codEstadoInventario = 1 ORDER BY idServidor DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarPorAmbiente($ambiente) {
        $consulta = "SELECT * FROM reporteServidores WHERE codigoAmbiente = {$ambiente} ORDER BY nombre DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
