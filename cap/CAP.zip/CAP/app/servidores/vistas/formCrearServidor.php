<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-server"></i> CREAR SERVIDOR</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearServidor" name="formCrearServidor" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header text-left bg-azul-clasico text-white">Complete el formulario</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="nombre" class="col-sm-2 col-form-label text-left">* Nombre:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="nombre" id="nombre" 
                                   placeholder="Nombre del servidor" required>
                        </div>
                        <label for="ip" class="col-sm-2 col-form-label text-left">* IP:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="ip" id="ip" 
                                   placeholder="IP del servidor" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="ambiente" class="col-sm-2 col-form-label text-left">* Ambiente:</label>
                        <div class="col">
                            <select id="ambiente" name="ambiente" class="form-control mb-2" required>
                                <option value="1">Producción</option>
                                <option value="2">Test</option>
                                <option value="3">Desarrollo</option>
                            </select>
                        </div>
                        <label for="tipo" class="col-sm-2 col-form-label text-left">* Tipo:</label>
                        <div class="col">
                            <select id="tipo" name="tipo" class="form-control mb-2" required>
                                <option value="1">Aplicaciones</option>
                                <option value="2">Base de datos</option>
                                <option value="3">Ambas</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="ambiente" class="col-sm-2 col-form-label text-left">* Descripción:</label>
                        <div class="col">
                            <textarea class="form-control mb-2" placeholder="Descripción del servidor" required></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
                    <a href="servidores_buscar">
                        <button type="button" class="btn btn-outline-info">
                            <i class="fas fa-search"></i> BUSCAR
                        </button>
                    </a>
                    <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="../jsCrearServidor.js"></script>