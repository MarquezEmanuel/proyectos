<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorServidor();
    $nombre = $_POST['nombre'];
    $servidores = $controlador->buscar($nombre);
    if (gettype($servidores) == "resource") {
        while ($servidor = sqlsrv_fetch_array($servidores, SQLSRV_FETCH_ASSOC)) {
            $arreglo[] = array('id' => $servidor["idServidor"], 'text' => $servidor["nombreServidor"]);
        }
    } else {
        $texto = ($servidores == 1) ? "Sin resultados" : "Error";
        $arreglo[] = array('id' => "NO", 'text' => $texto);
    }
} else {
    $arreglo[] = array('id' => "NO", 'text' => "Sin parametros");
}

echo json_encode($arreglo);