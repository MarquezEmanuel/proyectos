<?php

require_once './app/principal/modelos/Constantes.php';
require_once './app/principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();
$controlador = new ControladorServidor();

if (isset($_POST['btnBuscarServidor'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $tipo = $_POST['tipo'];
    $servidores = $controlador->buscar($nombre, $tipo);
    $filtro = "Resultado de la búsqueda";
    $_SESSION['BUSSRV'] = array($nombre, $tipo);
} else {
    if (isset($_SESSION['BUSSRV'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSSRV'];
        $nombre = $parametros[0];
        $tipo = $parametros[1];
        $servidores = $controlador->buscar($nombre, $tipo);
        $filtro = "Ultima búsqueda realizada";
        $_SESSION['BUSSRV'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $servidores = $controlador->listarUltimosCreados();
        $filtro = "Ultimos servidores creados y en estado activo";
        $_SESSION['BUSSRV'] = NULL;
    }
}

if (gettype($servidores) == "resource") {
    $filas = "";
    while ($servidor = sqlsrv_fetch_array($servidores, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr>
                <td>{$servidor['nombre']}</td>
                <td>{$servidor['ip']}</td>
                <td>" . utf8_encode($servidor['nombreAmbiente']) . "</td>
                <td>{$servidor['nombreTipo']}</td>
                <td>" . utf8_encode($servidor['descripcion']) . "</td> 
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editarServidor' name='{$servidor['id']}' title='Editar servidor'><i class='far fa-edit'></i></button>
                        <button class='btn btn-outline-primary datosServidor' title='Ver información básica'><i class='fas fa-info-circle'></i></button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbServidores" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>IP</th>
                        <th>Ambiente</th>
                        <th>Tipo</th>
                        <th>Descripción</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    if ($servidores == 2) {
        $cuerpo = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>{$controlador->getMensaje()} para el filtro ingresado</strong>
            </div>";
    } else {
        $cuerpo = "
            <div class='alert alert-danger text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
}
$formulario = '
    <div class="card border-azul-clasico mt-4">
        <div class="card-header text-left bg-azul-clasico text-white"><i class="fas fa-table"></i> ' . $filtro . '</div>
        <div class="card-body">' . $cuerpo . '</div>
    </div>';

echo $formulario;
