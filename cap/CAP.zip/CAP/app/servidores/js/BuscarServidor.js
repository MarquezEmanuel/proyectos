
$(document).ready(function () {

    /* INICIALIZA EL DATATABLE */

    $('#tbServidores').DataTable({
        lengthChange: false
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editarServidor').click(function () {
        var idServidor = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./app/servidores/vistas/formModificarServidor.php",
            data: "idServidor=" + idServidor,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.datosServidor').click(function () {
        $("#modalNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#modalIP").val($(this).parents("tr").find("td").eq(1).html());
        $("#modalAmbiente").val($(this).parents("tr").find("td").eq(2).html());
        $("#modalTipo").val($(this).parents("tr").find("td").eq(3).html());
        $("#modalDescripcion").val($(this).parents("tr").find("td").eq(4).html());
        $("#ModalDatosServidor").modal({});
    });

});