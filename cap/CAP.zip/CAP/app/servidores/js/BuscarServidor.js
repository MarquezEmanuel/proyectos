
$(document).ready(function () {
    
    /* INICIALIZA EL DATATABLE */

    $('#tbServidores').DataTable({
        lengthChange: false
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editar').click(function () {
        var idServidor = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formModificarServidor.php",
            data: "idServidor=" + idServidor,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.datos').click(function () {
        $("#modalInventario").val($(this).parents("tr").find("td").eq(0).html());
        $("#modalNombre").val($(this).parents("tr").find("td").eq(1).html());
        $("#modalIP").val($(this).parents("tr").find("td").eq(2).html());
        $("#modalAmbiente").val($(this).parents("tr").find("td").eq(3).html());
        $("#modalTipo").val($(this).parents("tr").find("td").eq(4).html());
        $("#modalDescripcion").val($(this).parents("tr").find("td").eq(5).html());
        $("#ModalDatosServidor").modal({});
    });

});