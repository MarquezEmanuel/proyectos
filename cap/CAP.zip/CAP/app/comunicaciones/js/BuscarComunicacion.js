/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    $('#tbComunicaciones').dataTable({
        lengthChange: false
    });

    $('.editar').click(function () {
        var idComunicacion = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formModificarComunicacion.php",
            data: "idComunicacion=" + idComunicacion,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#seccionInferior").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    $('.baja').click(function () {
        $("#tituloModal").html("<i class='fas fa-trash'></i> CONFIRME LA BAJA DE LA COMUNICACIÓN");
        $("#modalAccion").val("BAJA");
        $("#modalCodigo").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalCambioEstadoComunicacion").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('.alta').click(function () {
        $("#tituloModal").html("<i class='fas fa-plus-circle'></i> CONFIRME EL ALTA DE LA COMUNICACIÓN");
        $("#modalAccion").val("ALTA");
        $("#modalCodigo").val($(this).parents("tr").find("td").eq(0).html());
        $("#modalNombre").val($(this).parents("tr").find("td").eq(2).html());
        $("#ModalCambioEstadoComunicacion").modal({backdrop: 'static', keyboard: false});
    });

    $('#btnCambiarEstadoComunicacion').click(function () {
        $.ajax({
            type: "POST",
            url: "./procesaCambiarEstadoComunicacion.php",
            data: $("#formCambioEstadoComunicacion").serialize(),
            success: function (data) {
                $('#cuerpoModal').html(data);
                $('#btnCambiarEstadoComunicacion').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                $("#cuerpoModal").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    $('#btnRefrescarPantalla').click(function () {
        location.reload();
    });

});


