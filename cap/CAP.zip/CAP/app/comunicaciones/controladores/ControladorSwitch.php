<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class ControladorSwitch {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($modelo, $estado) {
        $switch = new Switches();
        $resultado = $switch->buscar($modelo, $estado);
        $this->mensaje = $switch->getMensaje();
        return $resultado;
    }

    public function cambiarEstado($id, $estado) {
        $switch = new Switchs($id, NULL, NULL, NULL, NULL, NULL, $estado);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $switch->cambiarEstado();
            $this->mensaje = $switch->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function crear($modelo, $version, $ubicacion, $instalacion, $rti) {
        $switch = new Switchs(NULL, $modelo, $version, $ubicacion, $instalacion, $rti);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $creacion = $switch->crear();
            $this->mensaje = $switch->getMensaje();
            $confirmar = ($creacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function listarUltimosCreados() {
        $switches = new Switches();
        $resultado = $switches->listarUltimosCreados();
        $this->mensaje = $switches->getMensaje();
        return $resultado;
    }

    public function modificar($id, $modelo, $version, $ubicacion, $instalacion, $rti) {
        $switch = new Switchs($id, $modelo, $version, $ubicacion, $instalacion, $rti);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $switch->modificar();
            $this->mensaje = $switch->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

}
