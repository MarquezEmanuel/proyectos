<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Comunicacion {

    private $id;
    private $sigla;
    private $nombre;
    private $cantidad;
    private $gerencia;
    private $delegado;
    private $ubicacion;
    private $proveedor;
    private $rti;
    private $descripcion;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $sigla = NULL, $nombre = NULL, $cantidad = NULL, $gerencia = NULL, $delegado = NULL, $ubicacion = NULL, $proveedor = NULL, $rti = NULL, $descripcion = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setSigla($sigla);
        $this->setNombre($nombre);
        $this->setCantidad($cantidad);
        $this->setGerencia($gerencia);
        $this->setDelegado($delegado);
        $this->setUbicacion($ubicacion);
        $this->setProveedor($proveedor);
        $this->setRti($rti);
        $this->setDescripcion($descripcion);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getCantidad() {
        return $this->cantidad;
    }

    public function getGerencia() {
        return $this->gerencia;
    }

    public function getDelegado() {
        return $this->delegado;
    }

    public function getUbicacion() {
        return $this->ubicacion;
    }

    public function getProveedor() {
        return $this->proveedor;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setSigla($sigla) {
        $this->sigla = $sigla;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setCantidad($cantidad) {
        $this->cantidad = $cantidad;
    }

    public function setGerencia($gerencia) {
        $this->gerencia = $gerencia;
    }

    public function setDelegado($delegado) {
        $this->delegado = $delegado;
    }

    public function setUbicacion($ubicacion) {
        $this->ubicacion = $ubicacion;
    }

    public function setProveedor($proveedor) {
        $this->proveedor = $proveedor;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $modificacion = SQLServer::instancia()->modificar("com_comunicaciones", "estado={$this->estado}", "id={$this->id}");
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crear() {
        if ($this->sigla && $this->nombre && $this->cantidad && $this->gerencia && $this->delegado && $this->ubicacion && $this->proveedor && $this->descripcion && $this->rti) {
            $values = "('{$this->sigla}', '{$this->nombre}', {$this->cantidad}, {$this->gerencia}, '{$this->delegado}', '{$this->ubicacion}', {$this->proveedor}, '{$this->descripcion}', '{$this->rti}', 1)";
            $creacion = SQLServer::instancia()->insertar("com_comunicaciones", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->crearRelacionInventario();
            }
            return $creacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crearRelacionInventario() {
        $consulta = "INSERT INTO com_comunicaciones_inventarios SELECT {$this->id}, id FROM inv_inventarios WHERE estado = 1";
        $creacion = SQLServer::instancia()->ejecutar($consulta);
        $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
        if ($creacion == 2) {
            return $this->registrarActividad("CREACION", $this->id);
        }
        return $creacion;
    }

    public function modificar() {
        if ($this->sigla && $this->nombre && $this->cantidad && $this->gerencia && $this->delegado && $this->ubicacion && $this->proveedor && $this->descripcion && $this->rti) {
            $campos = "modelo='{$this->modelo}', version='{$this->version}', ubicacion='{$this->ubicacion}', "
                    . "instalacion={$this->instalacion}, rti='{$this->rti}'";
            $modificacion = SQLServer::instancia()->modificar("com_comunicaciones", $campos, "id = {$this->id}");
            $this->mensaje = $this->modelo . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM com_comunicaciones WHERE id = '{$this->id}'";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!empty($fila)) {
                $this->sigla = $fila['sigla'];
                $this->nombre = $fila['nombre'];
                $this->cantidad = $fila['cantidad'];
                $this->descripcion = $fila['descripcion'];
                $this->rti = $fila['rti'];
                $this->estado = $fila['estado'];
                $ubi = $this->obtenerUbicacion($fila['ubicacion']);
                $ger = $this->obtenerGerencia($fila['gerencia']);
                $pro = $this->obtenerProveedor($fila['proveedor']);
                $del = $this->obtenerDelegado($fila['delegado']);
                return (($ubi == 2) && ($ger == 2) && ($pro == 2) && ($del == 2)) ? 2 : 1;
            }
            $this->mensaje = "No se pudo obtener la información del switch";
            return 1;
        }
        $this->descripcion = "No se pudo hacer referencia al switch";
        return 0;
    }

    private function obtenerGerencia($idGerencia) {
        $gerencia = new Gerencia($idGerencia);
        $resultado = $gerencia->obtener();
        $this->instalacion = ($resultado == 2) ? $gerencia : NULL;
        $this->mensaje = ($resultado == 2) ? $this->descripcion : "No se pudo obtener la gerencia";
        return $resultado;
    }

    private function obtenerUbicacion($idSitio) {
        $ubicacion = new Sitio($idSitio);
        $resultado = $ubicacion->obtener();
        $this->ubicacion = ($resultado == 2) ? $ubicacion : NULL;
        $this->mensaje = ($resultado == 2) ? $this->descripcion : "No se pudo obtener la ubicación";
        return $resultado;
    }

    public function obtenerDelegado($idDelegado) {
        $delegado = new Persona($idDelegado);
        $resultado = $delegado->obtenerDatosPropios();
        $this->delegado = ($resultado == 2) ? $delegado : NULL;
        $this->mensaje = ($resultado == 2) ? $this->descripcion : "No se pudo obtener al delegado";
        return $resultado;
    }

    public function obtenerProveedor($idProveedor) {
        $proveedor = new Proveedor($idProveedor);
        $resultado = $proveedor->obtener();
        $this->proveedor = ($resultado == 2) ? $proveedor : NULL;
        $this->mensaje = ($resultado == 2) ? $this->descripcion : "No se pudo obtener al proveedor";
        return $resultado;
    }

}
