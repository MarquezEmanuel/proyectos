<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Switchs {

    private $id;
    private $modelo;
    private $version;
    private $ubicacion;
    private $instalacion;
    private $rti;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $modelo = NULL, $version = NULL, $ubicacion = NULL, $instalacion = NULL, $rti = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setModelo($modelo);
        $this->setVersion($version);
        $this->setUbicacion($ubicacion);
        $this->setInstalacion($instalacion);
        $this->setRti($rti);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getModelo() {
        return $this->modelo;
    }

    public function getVersion() {
        return $this->version;
    }

    public function getUbicacion() {
        return $this->ubicacion;
    }

    public function getInstalacion() {
        return $this->instalacion;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setModelo($modelo) {
        $this->modelo = $modelo;
    }

    public function setVersion($version) {
        $this->version = $version;
    }

    public function setUbicacion($ubicacion) {
        $this->ubicacion = $ubicacion;
    }

    public function setInstalacion($instalacion) {
        $this->instalacion = $instalacion;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $modificacion = SQLServer::instancia()->modificar("swi_switchs", "estado={$this->estado}", "id={$this->id}");
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crear() {
        if ($this->modelo && $this->version && $this->ubicacion && $this->instalacion && $this->rti) {
            $values = "('{$this->modelo}', '{$this->version}', '{$this->ubicacion}', {$this->instalacion}, '{$this->rti}', 1)";
            $creacion = SQLServer::instancia()->insertar("swi_switchs", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->crearRelacionInventario();
            }
            return $creacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crearRelacionInventario() {
        $consulta = "INSERT INTO swi_switchs_inventarios SELECT {$this->id}, id FROM inv_inventarios WHERE estado = 1";
        $creacion = SQLServer::instancia()->ejecutar($consulta);
        $this->mensaje = $this->modelo . ": " . SQLServer::instancia()->getMensaje();
        if ($creacion == 2) {
            return $this->registrarActividad("CREACION", $this->id);
        }
        return $creacion;
    }

    public function modificar() {
        if ($this->modelo && $this->version && $this->ubicacion && $this->instalacion && $this->rti) {
            $campos = "modelo='{$this->modelo}', version='{$this->version}', ubicacion='{$this->ubicacion}', "
                    . "instalacion={$this->instalacion}, rti='{$this->rti}'";
            $modificacion = SQLServer::instancia()->modificar("swi_switchs", $campos, "id = {$this->id}");
            $this->mensaje = $this->modelo . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM swi_switchs WHERE id = '{$this->id}'";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!empty($fila)) {
                $this->modelo = $fila['modelo'];
                $this->nombre = $fila['version'];
                $this->rti = $fila['rti'];
                $this->estado = $fila['estado'];
                $ubicacion = $this->obtenerUbicacion($fila['ubicacion']);
                $instalacion = $this->obtenerInstalacion($fila['instalacion']);
                return (($ubicacion == 2) && ($instalacion == 2)) ? 2 : 1;
            }
            $this->mensaje = "No se pudo obtener la información del switch";
            return 1;
        }
        $this->descripcion = "No se pudo hacer referencia al switch";
        return 0;
    }

    private function obtenerUbicacion($idSitio) {
        $ubicacion = new Sitio($idSitio);
        $resultado = $ubicacion->obtener();
        $this->ubicacion = ($resultado == 2) ? $ubicacion : NULL;
        $this->mensaje = ($resultado == 2) ? $this->descripcion : "No se pudo obtener la ubicación";
        return $resultado;
    }

    private function obtenerInstalacion($idInstalacion) {
        $instalacion = new Instalacion($idInstalacion);
        $resultado = $instalacion->obtenerDatosPropios();
        $this->instalacion = ($resultado == 2) ? $instalacion : NULL;
        $this->mensaje = ($resultado == 2) ? $this->descripcion : "No se pudo obtener la instalación";
        return $resultado;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("swi_switchs", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
