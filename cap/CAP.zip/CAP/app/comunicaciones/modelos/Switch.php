<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class MSwitch {

    private $id;
    private $inventario;
    private $sucursal;
    private $modelo;
    private $version;
    private $instalacion;
    private $rti;
    private $estado;
    private $mensaje;

    public function __construct($id, $inventario, $sucursal, $modelo, $version, $instalacion, $rti, $estado) {
        $this->setId($id);
        $this->setInventario($inventario);
        $this->setSucursal($sucursal);
        $this->setModelo($modelo);
        $this->setVersion($version);
        $this->setInstalacion($instalacion);
        $this->setRti($rti);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getInventario() {
        return $this->inventario;
    }

    public function getSucursal() {
        return $this->sucursal;
    }

    public function getModelo() {
        return $this->modelo;
    }

    public function getVersion() {
        return $this->version;
    }

    public function getInstalacion() {
        return $this->instalacion;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setInventario($inventario) {
        $this->inventario = $inventario;
    }

    public function setSucursal($sucursal) {
        $this->sucursal = $sucursal;
    }

    public function setModelo($modelo) {
        $this->modelo = $modelo;
    }

    public function setVersion($version) {
        $this->version = $version;
    }

    public function setInstalacion($instalacion) {
        $this->instalacion = $instalacion;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("com_switches", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function crear() {
        if ($this->inventario && $this->sucursal && $this->modelo && $this->version && $this->instalacion && $this->rti) {
            $values = "({$this->inventario}, {$this->sucursal},'{$this->modelo}','{$this->version}', '{$this->instalacion}', '$this->rti', 1)";
            $creacion = SQLServer::instancia()->insertar("com_switches", $values);
            $this->mensaje = $this->modelo . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        return 0;
    }

    public function modificar() {
        if ($this->id && $this->inventario && $this->sucursal && $this->modelo && $this->version && $this->instalacion && $this->rti) {
            $campos = "inventario = {$this->inventario}, sucursal = {$this->sucursal}, "
                    . "modelo = '{$this->modelo}', instalacion = '{$this->instalacion}', "
                    . "version = '{$this->version}', rti = '{$this->version}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("com_switches", $campos, $condicion);
            $this->mensaje = $this->modelo . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM com_switches WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->modelo = $fila['modelo'];
                $this->version = $fila['version'];
                $this->instalacion = $fila['instalacion'];
                $this->rti = $fila['rti'];
                $this->estado = $fila['estado'];
                $obtenerInventario = $this->obtenerInventario($fila['inventario']);
                $obtenerSucursal = $this->obtenerSucursal($fila['sucursal']);
                return (($obtenerInventario == 2) && ($obtenerSucursal == 2)) ? 2 : 1;
            }
            $this->mensaje = "No se obtuvo la información del switch";
            return 1;
        }
        return 0;
    }

    private function obtenerInventario($idInventario) {
        $inventario = new Inventario($idInventario);
        if ($inventario->obtener() == 2) {
            $this->inventario = $inventario;
            return 2;
        }
        $this->mensaje = $inventario->getMensaje();
        return 1;
    }

    private function obtenerSucursal($idSucursal) {
        $sucursal = new Sucursal($idSucursal);
        if ($sucursal->obtener() == 2) {
            $this->sucursal = $sucursal;
            return 2;
        }
        $this->mensaje = $sucursal->getMensaje();
        return 1;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("com_switches", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
