<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Switches {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($modelo, $estado) {
        $consulta = "SELECT * FROM reporteSwitches WHERE modelo LIKE '%{$modelo}%' AND nomEstadoSwitch = '{$estado}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarPorInventario($siglaInventario) {
        $consulta = "SELECT * FROM reporteSwitches WHERE siglaInventario = '{$siglaInventario}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimosCreados() {
        $consulta = "SELECT TOP(10) * FROM reporteSwitches WHERE codEstadoSwitch = 1 ORDER BY idSwitch DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
