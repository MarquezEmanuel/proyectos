<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3">
            <div class="col text-left">
                <h4> BUSCAR ACTIVIDAD</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionCentral" class="mt-3 mb-4">
            <form id="formBuscarActividad" name="formBuscarActividad" method="POST">
                <div class="card border-azul-clasico mt-3">
                    <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                    <div class="card-body">
                        <div class="form-row">
                            <label for="modulo" class="col-2 col-form-label text-left">Modulo:</label>
                            <div class="col">
                               <select id="modulo" name="modulo" class="form-control mb-2" required>
                                    <option value="1">Aplicaciones</option>
                                    <option value="2">Bases de datos</option>
                                    <option value="2">Comunicaciones</option>
                                    <option value="2">Firewalls</option>
                                    <option value="2">Gerencias</option>
                                    <option value="2">Inventarios</option>
                                    <option value="2">Usuarios</option>
                                    <option value="2">Procesos</option>
                                    <option value="2">Proveedores</option>
                                    <option value="2">Servicios</option>
                                    <option value="2">Servidores</option>
                                    <option value="2">Sucursales</option>
                                    <option value="2">Usuarios</option>
                                </select>
                            </div>
                            <label for="operacion" class="col-2 col-form-label text-left">* Operaci[on:</label>
                            <div class="col">
                                <select id="operacion" name="operacion" class="form-control mb-2" required>
                                    <option value="1">Creación</option>
                                    <option value="2">Modificación</option>
                                    <option value="2">Baja</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-row mt-2">
                    <div class="col text-right">
                        <button type="submit" class="btn btn-success" name="formBuscarActividad"><i class="fas fa-search"></i>  BUSCAR</button>
                        <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                    </div>
                </div>
            </form>
        </div>
        <div id="seccionInferior" class="mt-4 mb-3">

        </div>
    </div>
</div>
