<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorActividad();

if (isset($_POST['btnBuscarActividad'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $modulo = $_POST['modulo'];
    $operacion = $_POST['operacion'];
    $datos = "'{$modulo}', '{$operacion}'";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $actividades = $controlador->buscar($modulo, $operacion);
    $_SESSION['BUSACT'] = array($modulo, $operacion, $datos);
} else {
    if (isset($_SESSION['BUSACT'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSACT'];
        $modulo = $parametros[0];
        $operacion = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $actividades = $controlador->buscar($modulo, $operacion);
        $_SESSION['BUSACT'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $actividades = $controlador->listarUltimasCreadas();
        $filtro = "Últimas actividades registradas";
        $_SESSION['BUSACT'] = NULL;
    }
}

if (gettype($actividades) == "resource") {
    $filas = "";
    while ($actividad = sqlsrv_fetch_array($actividades, SQLSRV_FETCH_ASSOC)) {
        $fecha = date_format($actividad['fecha'], 'd/m/Y H:m:s');
        $filas .= "
            <tr>
                <td>{$actividad['legajo']}</td>
                <td>" . utf8_encode($actividad['usuario']) . "</td>
                <td>{$actividad['estado']}</td>
                <td>{$actividad['tabla']}</td>
                <td>{$fecha}</td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbActividades" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Legajo</th>
                        <th>Usuario</th>
                        <th>Estado</th>
                        <th>Tabla</th>
                        <th>Fecha</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($actividades == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($actividades, $mensaje);
}

$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
