<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ControladorActividad {

    private $mensaje;

    public function buscar($tabla, $operacion) {
        $actividades = new Actividades();
        $resultado = $actividades->buscar($tabla, $operacion);
        $this->mensaje = $actividades->getMensaje();
        return $resultado;
    }

    public function listarUltimasCreadas() {
        $actividades = new Actividades();
        $resultado = $actividades->listarUltimasCreadas();
        $this->mensaje = $actividades->getMensaje();
        return $resultado;
    }

}
