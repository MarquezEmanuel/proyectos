<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Actividades {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($modulo, $operacion) {
        $consulta = "SELECT * FROM vwlog_actividad WHERE SUBSTRING(tabla,0,4) = ? AND operacion = ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$modulo, &$operacion));
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimasCreadas() {
        $consulta = "select TOP(10) * from vwlog_actividad ORDER BY id DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
