<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Aplicacion {

    private $id;
    private $sigla;
    private $nombre;
    private $tipo;
    private $seguridad;
    private $proveedor;
    private $lenguaje;
    private $base;
    private $winpaprod;
    private $produccion;
    private $test;
    private $desarrollo;
    private $puertoProd;
    private $puertoTest;
    private $puertoDesa;
    private $descripcion;
    private $estado;
    private $mensaje;

    public function __construct($id, $sigla, $nombre, $tipo, $seguridad, $proveedor, $lenguaje, $base, $winpaprod, $produccion, $test, $desarrollo, $puertoProd, $puertoTest, $puertoDesa, $descripcion, $estado) {
        $this->id = $id;
        $this->sigla = $sigla;
        $this->nombre = $nombre;
        $this->tipo = $tipo;
        $this->seguridad = $seguridad;
        $this->proveedor = $proveedor;
        $this->lenguaje = $lenguaje;
        $this->base = $base;
        $this->winpaprod = $winpaprod;
        $this->produccion = $produccion;
        $this->test = $test;
        $this->desarrollo = $desarrollo;
        $this->puertoProd = $puertoProd;
        $this->puertoTest = $puertoTest;
        $this->puertoDesa = $puertoDesa;
        $this->descripcion = $descripcion;
        $this->estado = $estado;
    }

    public function getId() {
        return $this->id;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getSeguridad() {
        return $this->seguridad;
    }

    public function getProveedor() {
        return $this->proveedor;
    }

    public function getLenguaje() {
        return $this->lenguaje;
    }

    public function getBase() {
        return $this->base;
    }

    public function getWinpaprod() {
        return $this->winpaprod;
    }

    public function getProduccion() {
        return $this->produccion;
    }

    public function getTest() {
        return $this->test;
    }

    public function getDesarrollo() {
        return $this->desarrollo;
    }

    public function getPuertoProd() {
        return $this->puertoProd;
    }

    public function getPuertoTest() {
        return $this->puertoTest;
    }

    public function getPuertoDesa() {
        return $this->puertoDesa;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setSigla($sigla) {
        $this->sigla = $sigla;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setTipo($tipo) {
        $this->tipo = $tipo;
    }

    public function setSeguridad($seguridad) {
        $this->seguridad = $seguridad;
    }

    public function setProveedor($proveedor) {
        $this->proveedor = $proveedor;
    }

    public function setLenguaje($lenguaje) {
        $this->lenguaje = $lenguaje;
    }

    public function setBase($base) {
        $this->base = $base;
    }

    public function setWinpaprod($winpaprod) {
        $this->winpaprod = $winpaprod;
    }

    public function setProduccion($produccion) {
        $this->produccion = $produccion;
    }

    public function setTest($test) {
        $this->test = $test;
    }

    public function setDesarrollo($desarrollo) {
        $this->desarrollo = $desarrollo;
    }

    public function setPuertoProd($puertoProd) {
        $this->puertoProd = $puertoProd;
    }

    public function setPuertoTest($puertoTest) {
        $this->puertoTest = $puertoTest;
    }

    public function setPuertoDesa($puertoDesa) {
        $this->puertoDesa = $puertoDesa;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE apl_aplicacion SET estado = ? WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            $modificacion = SQLServer::instancia()->modificar($consulta, $datos);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 'Activa') ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crear() {
        if ($this->sigla && $this->nombre && $this->tipo && $this->seguridad && $this->winpaprod && $this->descripcion) {
            $consulta = "INSERT INTO apl_aplicacion OUTPUT INSERTED.id VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $datos = array(&$this->sigla, &$this->nombre, &$this->tipo,
                &$this->seguridad, &$this->proveedor, &$this->lenguaje, &$this->base,
                &$this->winpaprod, &$this->descripcion, &$this->produccion,
                &$this->test, &$this->desarrollo, &$this->puertoProd, &$this->puertoTest, &$this->puertoDesa);
            $creacion = SQLServer::instancia()->insertar($consulta, $datos);
            $this->mensaje = $this->getNombre() . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function modificar() {
        
    }

    public function obtener() {
        
    }

}
