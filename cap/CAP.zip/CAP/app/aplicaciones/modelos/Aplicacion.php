<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Aplicacion {

    private $id;
    private $sigla;
    private $nombre;
    private $tipo;
    private $seguridad;
    private $proveedor;
    private $lenguaje;
    private $base;
    private $gerencia;
    private $empleado;
    private $sProduccion;
    private $sTest;
    private $sDesarrollo;
    private $pProduccion;
    private $pTest;
    private $pDesarrollo;
    private $confidencialidad;
    private $integridad;
    private $disponibilidad;
    private $criticidad;
    private $descripcion;
    private $estado;
    private $mensaje;
    
    public function __construct($id, $sigla, $nombre, $tipo, $seguridad, $proveedor, $lenguaje, $base, $gerencia, $empleado, $sProduccion, $sTest, $sDesarrollo, $pProduccion, $pTest, $pDesarrollo, $confidencialidad, $integridad, $disponibilidad, $criticidad, $descripcion, $estado) {
        $this->id = $id;
        $this->sigla = $sigla;
        $this->nombre = $nombre;
        $this->tipo = $tipo;
        $this->seguridad = $seguridad;
        $this->proveedor = $proveedor;
        $this->lenguaje = $lenguaje;
        $this->base = $base;
        $this->gerencia = $gerencia;
        $this->empleado = $empleado;
        $this->sProduccion = $sProduccion;
        $this->sTest = $sTest;
        $this->sDesarrollo = $sDesarrollo;
        $this->pProduccion = $pProduccion;
        $this->pTest = $pTest;
        $this->pDesarrollo = $pDesarrollo;
        $this->confidencialidad = $confidencialidad;
        $this->integridad = $integridad;
        $this->disponibilidad = $disponibilidad;
        $this->criticidad = $criticidad;
        $this->descripcion = $descripcion;
        $this->estado = $estado;
    }
    
    public function getId() {
        return $this->id;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getSeguridad() {
        return $this->seguridad;
    }

    public function getProveedor() {
        return $this->proveedor;
    }

    public function getLenguaje() {
        return $this->lenguaje;
    }

    public function getBase() {
        return $this->base;
    }

    public function getGerencia() {
        return $this->gerencia;
    }

    public function getEmpleado() {
        return $this->empleado;
    }

    public function getSProduccion() {
        return $this->sProduccion;
    }

    public function getSTest() {
        return $this->sTest;
    }

    public function getSDesarrollo() {
        return $this->sDesarrollo;
    }

    public function getPProduccion() {
        return $this->pProduccion;
    }

    public function getPTest() {
        return $this->pTest;
    }

    public function getPDesarrollo() {
        return $this->pDesarrollo;
    }

    public function getConfidencialidad() {
        return $this->confidencialidad;
    }

    public function getIntegridad() {
        return $this->integridad;
    }

    public function getDisponibilidad() {
        return $this->disponibilidad;
    }

    public function getCriticidad() {
        return $this->criticidad;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setSigla($sigla) {
        $this->sigla = $sigla;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setTipo($tipo) {
        $this->tipo = $tipo;
    }

    public function setSeguridad($seguridad) {
        $this->seguridad = $seguridad;
    }

    public function setProveedor($proveedor) {
        $this->proveedor = $proveedor;
    }

    public function setLenguaje($lenguaje) {
        $this->lenguaje = $lenguaje;
    }

    public function setBase($base) {
        $this->base = $base;
    }

    public function setGerencia($gerencia) {
        $this->gerencia = $gerencia;
    }

    public function setEmpleado($empleado) {
        $this->empleado = $empleado;
    }

    public function setSProduccion($sProduccion) {
        $this->sProduccion = $sProduccion;
    }

    public function setSTest($sTest) {
        $this->sTest = $sTest;
    }

    public function setSDesarrollo($sDesarrollo) {
        $this->sDesarrollo = $sDesarrollo;
    }

    public function setPProduccion($pProduccion) {
        $this->pProduccion = $pProduccion;
    }

    public function setPTest($pTest) {
        $this->pTest = $pTest;
    }

    public function setPDesarrollo($pDesarrollo) {
        $this->pDesarrollo = $pDesarrollo;
    }

    public function setConfidencialidad($confidencialidad) {
        $this->confidencialidad = $confidencialidad;
    }

    public function setIntegridad($integridad) {
        $this->integridad = $integridad;
    }

    public function setDisponibilidad($disponibilidad) {
        $this->disponibilidad = $disponibilidad;
    }

    public function setCriticidad($criticidad) {
        $this->criticidad = $criticidad;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }



}
