<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-fire-alt"></i> REGISTRAR APLICACIÓN</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formRegistrarAplicacion" name="formRegistrarAplicacion" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico text-white">Información básica</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="sigla" class="col-sm-2 col-form-label">* Nombre corto:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="sigla" id="sigla" 
                                   placeholder="Nombre corto del aplicativo" required>
                        </div>
                        <label for="nombre" class="col-sm-2 col-form-label">* Nombre largo:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="nombre" id="nombre" 
                                   placeholder="Nombre largo del aplicativo" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="sucursal" class="col-sm-2 col-form-label">* Tipo de software:</label>
                        <div class="col">
                            <select class="form-control mb-2" id="tipo" name="tipo">
                                <option value="Web">Web</option>
                                <option value="Escritorio">Escritorio</option>
                                <option value="Otro">Otro</option>
                            </select>
                        </div>
                        <label for="seguridad" class="col-sm-2 col-form-label">* Seguridad:</label>
                        <div class="col">
                            <select class="form-control mb-2" id="seguridad" name="seguridad">
                                <option value="Web">Integrada</option>
                                <option value="Escritorio">Base de datos</option>
                                <option value="Otro">Active Directory</option>
                            </select>
                        </div>

                    </div>
                    <div class="form-row">
                        <label for="proveedor" class="col-sm-2 col-form-label">Proveedor:</label>
                        <div class="col">
                            <select class="form-control mb-2" id="proveedor" name="proveedor"></select>
                        </div>
                        <label for="lenguaje" class="col-sm-2 col-form-label">Lenguaje:</label>
                        <div class="col">
                            <select class="form-control mb-2" id="lenguaje" name="lenguaje"></select>
                        </div>

                    </div>
                    <div class="form-row">
                        <label for="base" class="col-sm-2 col-form-label">Base de datos:</label>
                        <div class="col">
                            <select class="form-control mb-2" id="base" name="base"></select>
                        </div>
                        <label for="winpaprod" class="col-sm-2 col-form-label">* WinPaProd:</label>
                        <div class="col">
                            <select class="form-control mb-2" id="winpaprod" name="winpaprod">
                                <option value="Si">Si</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="descripcion" class="col-sm-2 col-form-label">* Descripción:</label>
                        <div class="col">
                            <textarea class="form-control mb-2" 
                                      name="descripcion" id="descripcion" 
                                      placeholder="Descripción del aplicativo" required></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico text-white">Información de servidores de aplicación</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="produccion" class="col-sm-2 col-form-label">* S. Producción:</label>
                        <div class="col">
                            <select class="form-control mb-2" id="produccion" name="produccion"></select>
                        </div>
                        <label for="puertoProduccion" class="col-sm-2 col-form-label">* Puerto producción:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="puertoProduccion" id="puertoProduccion" 
                                   placeholder="Puerto del servidor en prodcucción" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="test" class="col-sm-2 col-form-label">S. Test:</label>
                        <div class="col">
                            <select class="form-control mb-2" id="test" name="test"></select>
                        </div>
                        <label for="puertoTest" class="col-sm-2 col-form-label">Puerto test:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="puertoTest" id="puertoTest" 
                                   placeholder="Puerto del servidor en test" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="desarrollo" class="col-sm-2 col-form-label">S. Desarrollo:</label>
                        <div class="col">
                            <select class="form-control mb-2" id="desarrollo" name="desarrollo"></select>
                        </div>
                        <label for="puertoDesarrollo" class="col-sm-2 col-form-label">Puerto desarrollo:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="puertoDesarrollo" id="puertoDesarrollo" 
                                   placeholder="Puerto del servidor en desarrollo" required>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
                    <a href="formBuscarFirewall.php">
                        <button type="button" class="btn btn-outline-info">
                            <i class="fas fa-search"></i> BUSCAR
                        </button>
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="../js/CrearFirewall.js"></script>