<?php

/**
 * Description of ServicioInterno
 *
 * @author Emanuel
 */
class ServicioInterno {

    private $id;
    private $sigla;
    private $nombre;
    private $departamento;
    private $disponibilidad;
    private $integridad;
    private $confidencialidad;
    private $autenticidad;
    private $rti;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $sigla = NULL, $nombre = NULL, $departamento = NULL, $disponibilidad = NULL, $integridad = NULL, $confidencialidad = NULL, $autenticidad = NULL, $rti = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setSigla($sigla);
        $this->setNombre($nombre);
        $this->setDepartamento($departamento);
        $this->setDisponibilidad($disponibilidad);
        $this->setIntegridad($integridad);
        $this->setConfidencialidad($confidencialidad);
        $this->setAutenticidad($autenticidad);
        $this->setRti($rti);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getInventario() {
        return $this->inventario;
    }

    public function getDepartamento() {
        return $this->departamento;
    }

    public function getDisponibilidad() {
        return $this->disponibilidad;
    }

    public function getIntegridad() {
        return $this->integridad;
    }

    public function getConfidencialidad() {
        return $this->confidencialidad;
    }

    public function getAutenticidad() {
        return $this->autenticidad;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setSigla($sigla) {
        $this->sigla = $sigla;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setInventario($inventario) {
        $this->inventario = $inventario;
    }

    public function setDepartamento($departamento) {
        $this->departamento = $departamento;
    }

    public function setDisponibilidad($disponibilidad) {
        $this->disponibilidad = $disponibilidad;
    }

    public function setIntegridad($integridad) {
        $this->integridad = $integridad;
    }

    public function setConfidencialidad($confidencialidad) {
        $this->confidencialidad = $confidencialidad;
    }

    public function setAutenticidad($autenticidad) {
        $this->autenticidad = $autenticidad;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = '{$this->estado}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("ser_servicios_internos", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 'Activo') ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crear() {
        if ($this->sigla && $this->nombre && $this->departamento && $this->rti) {
            $values = "('{$this->sigla}','{$this->nombre}', {$this->departamento}, {$this->disponibilidad}, {$this->integridad}, {$this->confidencialidad}, {$this->autenticidad}, '{$this->rti}', 'Activo')";
            $creacion = SQLServer::instancia()->insertar("ser_servicios_internos", $values);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->crearRelacion();
            }
            return $creacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function modificar() {
        if ($this->sigla && $this->nombre && $this->departamento && $this->rti) {
            $campos = "sigla='{$this->sigla}', nombre='{$this->nombre}', departamento={$this->departamento}, "
                    . "disponibilidad={$this->disponibilidad}, integridad={$this->integridad}, confidencialidad={$this->confidencialidad}, "
                    . "autenticidad={$this->autenticidad}, rti='{$this->rti}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("ser_servicios_internos", $campos, $condicion);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    private function crearRelacion() {
        $consulta = "INSERT INTO ser_servicios_internos_inventarios SELECT {$this->id}, id FROM inv_inventarios WHERE estado = 'Activo'";
        $creacion = SQLServer::instancia()->ejecutar($consulta);
        $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
        if ($creacion == 2) {
            return $this->registrarActividad("CREACION", $this->id);
        }
        return $creacion;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("ser_servicios_internos", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
