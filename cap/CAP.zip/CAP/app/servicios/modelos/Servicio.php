<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Servicio {

    private $id;
    private $sigla;
    private $nombre;
    private $tipo;
    private $inventario;
    private $departamento;
    private $disponibilidad;
    private $integridad;
    private $confidencialidad;
    private $autenticidad;
    private $rti;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $sigla = NULL, $nombre = NULL, $tipo = NULL, $inventario = NULL, $departamento = NULL, $disponibilidad = NULL, $integridad = NULL, $confidencialidad = NULL, $autenticidad = NULL, $rti = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setSigla($sigla);
        $this->setNombre($nombre);
        $this->setTipo($tipo);
        $this->setInventario($inventario);
        $this->setDepartamento($departamento);
        $this->setDisponibilidad($disponibilidad);
        $this->setIntegridad($integridad);
        $this->setConfidencialidad($confidencialidad);
        $this->setAutenticidad($autenticidad);
        $this->setRti($rti);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getInventario() {
        return $this->inventario;
    }

    public function getDepartamento() {
        return $this->departamento;
    }

    public function getDisponibilidad() {
        return $this->disponibilidad;
    }

    public function getIntegridad() {
        return $this->integridad;
    }

    public function getConfidencialidad() {
        return $this->confidencialidad;
    }

    public function getAutenticidad() {
        return $this->autenticidad;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setSigla($sigla) {
        $this->sigla = $sigla;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setTipo($tipo) {
        $this->tipo = $tipo;
    }

    public function setInventario($inventario) {
        $this->inventario = $inventario;
    }

    public function setDepartamento($departamento) {
        $this->departamento = $departamento;
    }

    public function setDisponibilidad($disponibilidad) {
        $this->disponibilidad = $disponibilidad;
    }

    public function setIntegridad($integridad) {
        $this->integridad = $integridad;
    }

    public function setConfidencialidad($confidencialidad) {
        $this->confidencialidad = $confidencialidad;
    }

    public function setAutenticidad($autenticidad) {
        $this->autenticidad = $autenticidad;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("ser_servicios", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function crear() {
        if ($this->sigla && $this->nombre && $this->tipo && $this->inventario && $this->departamento) {
            $values = "('{$this->sigla}','{$this->nombre}','{$this->tipo}',{$this->inventario}, {$this->departamento}, {$this->disponibilidad}, {$this->integridad}, {$this->confidencialidad}, {$this->autenticidad}, '{$this->rti}', 1)";
            $creacion = SQLServer::instancia()->insertar("ser_servicios", $values);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        return 0;
    }

    public function modificar() {
        if ($this->id && $this->sigla && $this->nombre && $this->inventario) {
            $campos = "sigla='{$this->sigla}', nombre='{$this->nombre}', inventario={$this->inventario}, departamento={$this->departamento}, "
                    . "disponibilidad={$this->disponibilidad}, integridad={$this->integridad}, confidencialidad={$this->confidencialidad}, "
                    . "autenticidad={$this->autenticidad}, rti='{$this->rti}', tipo='{$this->tipo}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("ser_servicios", $campos, $condicion);
            $this->mensaje = $this->firewall . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM ser_servicios WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->sigla = $fila['sigla'];
                $this->nombre = $fila['nombre'];
                $this->disponibilidad = $fila['disponibilidad'];
                $this->integridad = $fila['integridad'];
                $this->confidencialidad = $fila['confidencialidad'];
                $this->autenticidad = $fila['autenticidad'];
                $this->rti = $fila['rti'];
                $this->estado = $fila['estado'];
                $obtenerInventario = $this->obtenerInventario($fila['inventario']);
                $obtenerDepartamento = $this->obtenerDepartamento($fila['departamento']);
                return (($obtenerInventario == 2) && ($obtenerDepartamento == 2)) ? 2 : 1;
            }
            $this->mensaje = "No se obtuvo la informacion del servicio";
            return 1;
        }
        return 0;
    }

    private function obtenerInventario($idInventario) {
        $inventario = new Inventario($idInventario);
        if ($inventario->obtener() == 2) {
            $this->inventario = $inventario;
            return 2;
        }
        $this->mensaje = $inventario->getMensaje();
        return 1;
    }

    private function obtenerDepartamento($idDepartamento) {
        $departamento = new Departamento($idDepartamento);
        if ($departamento->obtener() == 2) {
            $this->departamento = $departamento;
            return 2;
        }
        $this->mensaje = $departamento->getMensaje();
        return 1;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("ser_servicios", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
