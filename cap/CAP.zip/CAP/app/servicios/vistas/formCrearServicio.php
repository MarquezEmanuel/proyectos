<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-file-signature"></i> CREAR SERVICIO</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearServicio" name="formCrearServicio" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico  text-white">Complete el formulario</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="tipo" class="col-sm-2 col-form-label">* Tipo:</label>
                        <div class="col">
                            <select class="form-control mb-2" name="tipo" id="tipo">
                                <option value="Interno">Interno</option>
                                <option value="Externo">Externo</option>
                            </select>
                        </div>
                        <label class="col-sm-2 col-form-label"></label>
                        <div class="col"></div>
                    </div>
                    <div class="form-row">
                        <label for="sigla" class="col-sm-2 col-form-label">* Sigla:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2"
                                   name="sigla" id="sigla"
                                   placeholder="Sigla del servicio"
                                   required>
                        </div>
                        <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="nombre" id="nombre"
                                   placeholder="Nombre del servicio"
                                   required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="departamento" class="col-sm-2 col-form-label">* Departamento:</label>
                        <div class="col">
                            <select class="form-control mb-2">

                            </select>
                        </div>
                        <label for="departamento" class="col-sm-2 col-form-label">* Proveedor:</label>
                        <div class="col">
                            <select class="form-control mb-2" disabled>

                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="disponibilidad" class="col-sm-2 col-form-label">* Disponibilidad:</label>
                        <div class="col">
                            <input type="number" class="form-control mb-2" 
                                   name="disponibilidad" id="disponibilidad"
                                   placeholder="Valor de disponibilidad"
                                   required>
                        </div>
                        <label for="integridad" class="col-sm-2 col-form-label">* Integridad:</label>
                        <div class="col">
                            <input type="number" class="form-control mb-2" 
                                   name="integridad" id="integridad"
                                   placeholder="Valor de integridad"
                                   required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="confidencialidad" class="col-sm-2 col-form-label">* Confidencialidad:</label>
                        <div class="col">
                            <input type="number" class="form-control mb-2" 
                                   name="confidencialidad" id="confidencialidad"
                                   placeholder="Valor de confidencialidad"
                                   required>
                        </div>
                        <label for="autenticidad" class="col-sm-2 col-form-label">* Autenticidad:</label>
                        <div class="col">
                            <input type="number" class="form-control mb-2" 
                                   name="autenticidad" id="autenticidad"
                                   placeholder="Valor de autenticidad"
                                   required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="rti" class="col-sm-2 col-form-label">* RTI:</label>
                        <div class="col">
                            <select class="form-control mb-2">
                                <option value="SI">SI</option>
                                <option value="NO">NO</option>
                            </select>
                        </div>
                        <label class="col-sm-2 col-form-label"></label>
                        <div class="col"></div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
                    <a href="formBuscarServicio.php">
                        <button type="button" class="btn btn-outline-info">
                            <i class="fas fa-search"></i> BUSCAR
                        </button>
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="../js/CrearInventario.js"></script>