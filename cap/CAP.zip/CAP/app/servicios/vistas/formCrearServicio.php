<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-file-signature"></i> CREAR SERVICIO</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearServicio" name="formCrearServicio" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico  text-white">Complete el formulario</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="inventario" class="col-sm-2 col-form-label text-left">* Inventario:</label>
                        <div class="col">
                            <select class="form-control mb-2">

                            </select>
                        </div>
                        <label for="departamento" class="col-sm-2 col-form-label text-left">* Departamento:</label>
                        <div class="col">
                            <select class="form-control mb-2">

                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="sigla" class="col-sm-2 col-form-label text-left">* Sigla:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2"
                                   name="sigla" id="sigla"
                                   required>
                        </div>
                        <label for="nombre" class="col-sm-2 col-form-label text-left">* Nombre:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="nombre" id="nombre"
                                   required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="tipo" class="col-sm-2 col-form-label text-left">* Tipo:</label>
                        <div class="col">
                            <select class="form-control mb-2" name="tipo" id="tipo">
                                <option value="Interno">Interno</option>
                                <option value="Externo">Externo</option>
                            </select>
                        </div>
                        <label for="disponibilidad" class="col-sm-2 col-form-label text-left">* Disponibilidad:</label>
                        <div class="col">
                            <input type="number" class="form-control mb-2" 
                                   name="disponibilidad" id="disponibilidad"
                                   required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="integridad" class="col-sm-2 col-form-label text-left">* Integridad:</label>
                        <div class="col">
                            <input type="number" class="form-control mb-2" 
                                   name="integridad" id="integridad"
                                   required>
                        </div>
                        <label for="disponibilidad" class="col-sm-2 col-form-label text-left">* Confidencialidad:</label>
                        <div class="col">
                            <input type="number" class="form-control mb-2" 
                                   name="disponibilidad" id="disponibilidad"
                                   required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="integridad" class="col-sm-2 col-form-label text-left">* Autenticidad:</label>
                        <div class="col">
                            <input type="number" class="form-control mb-2" 
                                   name="integridad" id="integridad"
                                   required>
                        </div>
                        <label for="rti" class="col-sm-2 col-form-label text-left">* RTI:</label>
                        <div class="col">
                            <select class="form-control mb-2">
                                <option>SI</option>
                                <option>NO</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
                    <a href="formBuscarServicio.php">
                        <button type="button" class="btn btn-outline-info">
                            <i class="fas fa-search"></i> BUSCAR
                        </button>
                    </a>
                    <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="../js/CrearInventario.js"></script>