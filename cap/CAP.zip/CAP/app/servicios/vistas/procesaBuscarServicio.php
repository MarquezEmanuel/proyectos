<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorServicio();

if (isset($_POST['btnBuscarServicio'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " . $estado : "TODOS, " . $estado;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $servicios = $controlador->buscar($nombre, $estado);
    $_SESSION['BUSSER'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['BUSSER'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSSER'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $servicios = $controlador->buscar($nombre, $estado);
        $_SESSION['BUSSER'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $servicios = $controlador->listarUltimosCreados();
        $filtro = "Últimos servicios creados";
        $_SESSION['BUSSER'] = NULL;
    }
}

if (gettype($servicios) == "resource") {
    
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($servicios == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($servicios, $mensaje);
}