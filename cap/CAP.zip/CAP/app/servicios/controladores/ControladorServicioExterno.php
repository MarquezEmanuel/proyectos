<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ControladorServicioExterno
 *
 * @author Emanuel
 */
class ControladorServicioExterno {

    private $mensaje;

    public function __construct() {
        ;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function crear($sigla, $nombre, $inventario, $departamento, $disponibilidad, $integridad, $confidencialidad, $autenticidad, $rti) {
        $servicio = new ServicioExterno(NULL, $sigla, $nombre, $inventario, $departamento, $disponibilidad, $integridad, $confidencialidad, $autenticidad, $rti);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $servicio->crear();
            $this->mensaje = $servicio->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 0;
    }

}
