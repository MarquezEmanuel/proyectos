<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ControladorServicio {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $servicios = new Servicios();
        $resultado = $servicios->buscar($nombre, $estado);
        $this->mensaje = $servicios->getMensaje();
        return $resultado;
    }

    public function cambiarEstado($id, $estado) {
        $servicio = new Servicio($id, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, $estado);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $servicio->cambiarEstado();
            $this->mensaje = $servicio->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function crear($sigla, $nombre, $tipo, $inventario, $departamento, $disponibilidad, $integridad, $confidencialidad, $autenticidad, $rti) {
        $servicio = new Servicio(NULL, $sigla, $nombre, $tipo, $inventario, $departamento, $disponibilidad, $integridad, $confidencialidad, $autenticidad, $rti);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $creacion = $servicio->crear();
            $this->mensaje = $servicio->getMensaje();
            $confirmar = ($creacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 0;
    }

    public function listarUltimosCreados() {
        $servicios = new Servicios();
        $resultado = $servicios->listarUltimosCreados();
        $this->mensaje = $servicios->getMensaje();
        return $resultado;
    }

    public function modificar($id, $sigla, $nombre, $tipo, $inventario, $departamento, $disponibilidad, $integridad, $confidencialidad, $autenticidad, $rti) {
        $servicio = new Servicio($id, $sigla, $nombre, $tipo, $inventario, $departamento, $disponibilidad, $integridad, $confidencialidad, $autenticidad, $rti);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $servicio->modificar();
            $this->mensaje = $servicio->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

}
