/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {

    var formOriginal = $("#formModificarSucursal").serialize();

    /* DETECTA LOS CAMBIOS EN LOS CAMPOS DEL FORMULARIO PARA ACTIVAR/DESACTIVAR EL BOTON DE GUARDADO */

    $("#formModificarSucursal").change(function () {
        comparaFormularios();
    });
    
    /* ENVIA EL FORMULARIO PARA REALIZAR LA MODIFICACION */
    
    $('#formModificarSucursal').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: "./app/sucursales/vistas/procesaModificarSucursal.php",
            data: $("#formModificarSucursal").serialize(),
            success: function (data) {
                $('#seccionResultado').html(data[0]['resultado']);
                if (data[0]['exito'] === true) {
                    $("#codigo").prop("disabled", true);
                    $("#sigla").prop("disabled", true);
                    $("#nombre").prop("disabled", true);
                    $("#btnModificarSucursal").prop("disabled", true);
                }
            },
            error: function (data) {
                console.log(data);
                $("#seccionResultado").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* COMPARA EL FORMULARIO ORIGINAL CON EL MODIFICADO PARA VER QUE NO SEAN IGUALES */

    function comparaFormularios() {
        var formModificado = $("#formModificarSucursal").serialize();
        if (formOriginal !== formModificado) {
            $("#btnModificarSucursal").prop("disabled", false);
        } else {
            $("#btnModificarSucursal").prop("disabled", true);
        }
    }

});
