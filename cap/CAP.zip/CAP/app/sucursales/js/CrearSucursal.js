
$(document).ready(function () {
    
    $('#formCrearSucursal').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: "./app/sucursales/vistas/procesaCrearSucursal.php",
            data: $("#formCrearSucursal").serialize(),
            success: function (data) {
                $('#seccionResultado').html(data[0]['resultado']);
                if (data[0]['exito'] === true) {
                    $("#formCrearSucursal")[0].reset();
                }
            },
            error: function (data) {
                console.log(data);
                var div = '<div class="alert alert-danger text-center" role="alert">No se procesó la petición por un error interno</div>';
                $("#seccionResultado").html(div);
            }
        });
    });

});