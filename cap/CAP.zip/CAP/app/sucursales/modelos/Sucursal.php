<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Sucursal {

    private $id;
    private $sigla;
    private $nombre;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $sigla = NULL, $nombre = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setSigla($sigla);
        $this->setNombre($nombre);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setSigla($sigla) {
        $this->sigla = $sigla;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("suc_sucursales", $campos, $condicion);
            $this->mensaje = "Sucursal " . $this->id . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        return 1;
    }

    public function crear() {
        if ($this->id && $this->sigla && $this->nombre) {
            $values = "({$this->id}, '{$this->sigla}', '{$this->nombre}', 1)";
            $creacion = SQLServer::instancia()->insertar("suc_sucursales", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        return 1;
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->sigla) {
            $campos = "nombre = '{$this->nombre}', sigla = '{$this->sigla}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("suc_sucursales", $campos, $condicion);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM suc_sucursales WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!empty($fila)) {
                $this->nombre = $fila['nombre'];
                $this->sigla = $fila['sigla'];
                $this->estado = $fila['estado'];
                return 2;
            }
            $this->mensaje = "No se pudo obtener la información de la sucursal";
            return 1;
        }
        return 0;
    }

    private function registrarActividad($operacion, $values) {
        $detalle = str_replace("'", " ", $values);
        $creacion = Log::guardarActividad("suc_sucursales", $operacion, $detalle);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
