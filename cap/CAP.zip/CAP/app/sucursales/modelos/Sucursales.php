<?php

class Sucursales {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM reporteSucursales WHERE nombre LIKE '%{$nombre}%' and nombreEstado = '{$estado}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listar($estado) {
        $consulta = "SELECT id, sigla, nombre FROM suc_sucursales WHERE estado = {$estado}";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimasCreadas() {
        $consulta = "SELECT TOP(10) * FROM reporteSucursales WHERE codigoEstado = 1 ORDER BY id DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
