<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$formulario = $boton = "";
if (isset($_POST['idSucursal'])) {
    $sucursal = new Sucursal($_POST['idSucursal']);
    $obtencion = $sucursal->obtener();
    if ($obtencion == 2) {
        $formulario = '
            <div class="form-row">
                <label for="codigo" class="col-sm-2 col-form-label text-left">* Código:</label>
                <div class="col">
                    <input type="number" class="form-control mb-2" 
                           name="codigo" id="codigo" max="999" maxlength="3"
                           value="' . $sucursal->getId() . '"
                           placeholder="Código de la sucursal">
                </div>
                <label for="sigla" class="col-sm-2 col-form-label text-left">* Sigla:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="sigla" id="sigla" maxlength="5"
                           value="' . $sucursal->getSigla() . '"
                           placeholder="Sigla de la sucursal">
                </div>
            </div>
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label text-left">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" maxlength="50"
                           value="' . $sucursal->getNombre() . '"
                           placeholder="Nombre de la sucursal">
                </div>
                <label class="col-sm-2 col-form-label text-left"></label>
                <div class="col"></div>
            </div>';
        $boton = '
            <button type="submit" class="btn btn-success" id="btnModificarSucursal" disabled>
                    <i class="far fa-save"></i> GUARDAR</button>
            <a href="sucursales_buscar">
                <button type="button" class="btn btn-outline-info">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </a>';
    } else {
        $formulario = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> 
                <strong>{$sucursal->getMensaje()}</strong>
            </div>";
        $boton = '
            <a href="sucursales_buscar">
                <button type="button" class="btn btn-outline-info">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </a>';
    }
} else {
    $formulario = "
        <div class='alert alert-danger text-center' role='alert'> 
            <i class='fas fa-exclamation-triangle'></i> 
            <strong>No se obtuvo la información desde el formulario</strong>
        </div>";
    $boton = '
        <a href="sucursales_buscar">
            <button type="button" class="btn btn-outline-info">
                <i class="fas fa-search"></i> BUSCAR
            </button>
        </a>';
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="far fa-building"></i> MODIFICAR SUCURSAL</h4>
        </div>
        <div class="col text-right">
            <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <div id="seccionCentral">
        <form id="formModificarSucursal" name="formModificarSucursal" method="POST">
            <div class="card mt-3 ">
                <div class="card-header text-left bg-azul-clasico text-white">Formulario de modificación</div>
                <div class="card-body">
                    <?= $formulario; ?>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <?= $boton; ?>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="./app/sucursales/js/ModificarSucursal.js"></script>