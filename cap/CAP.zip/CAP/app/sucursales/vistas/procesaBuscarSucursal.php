<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorSucursal();

if (isset($_POST['btnBuscarSucursal'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $sucursales = $controlador->buscar($nombre, $estado);
    $datos = ($nombre) ? "'{$nombre}', " . $estado : "TODAS, " . $estado;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $_SESSION['BUSSUC'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['BUSSUC'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSSUC'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $sucursales = $controlador->buscar($nombre, $estado);
        $_SESSION['BUSSUC'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $sucursales = $controlador->listarUltimasCreadas();
        $filtro = "Últimas sucursales creadas";
        $_SESSION['BUSSUC'] = NULL;
    }
}

if (gettype($sucursales) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = $operaciones = "";
    while ($sucursal = sqlsrv_fetch_array($sucursales, SQLSRV_FETCH_ASSOC)) {
        if ($sucursal['codigoEstado'] == 1) {
            $operaciones = "<button class='btn btn-outline-warning editarSucursal' 
                                name='{$sucursal['id']}' title='Editar'>
                                    <i class='far fa-edit'></i>
                            </button>
                            <button class='btn btn-outline-danger bajaSucursal' 
                                name='{$sucursal['id']}' title='Dar de baja'>
                                    <i class='fas fa-trash'></i>
                            </button>";
        } else {
            $operaciones = "<button class='btn btn-outline-success altaSucursal' 
                                name='{$sucursal['id']}' title='Dar de alta'>
                                    <i class='fas fa-plus-circle'></i>
                            </button>";
        }
        $filas .= "
            <tr>
                <td class='align-middle'>{$sucursal['id']}</td>
                <td class='align-middle'>{$sucursal['sigla']}</td>
                <td class='align-middle'>{$sucursal['nombre']}</td> 
                <td class='text-center align-middle'>
                    <div class='btn-group btn-group-sm'>
                        {$operaciones}
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbSucursales" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Sigla</th>
                        <th>Nombre</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    if ($sucursales == 1) {
        $cuerpo = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> 
                <strong>{$controlador->getMensaje()} para el filtro ingresado</strong>
            </div>";
    } else {
        $cuerpo = "
            <div class='alert alert-danger text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> 
                <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
}

$formulario = '
    <div class="card border-azul-clasico">
        <div class="card-header bg-azul-clasico text-white"><i class="fas fa-table"></i> ' . $filtro . '</div>
        <div class="card-body">' . $cuerpo . '</div>
    </div>';

echo $formulario;
