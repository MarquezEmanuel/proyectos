<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

if (isset($_POST['modalAccion'])) {
    $codigo = $_POST['modalCodigo'];
    $controlador = new ControladorSucursal();
    $estado = ($_POST['modalAccion'] == "ALTA") ? 1 : 2;
    $modificacion = $controlador->cambiarEstado($codigo, $estado);
    $mensaje = $controlador->getMensaje();
    switch ($modificacion) {
        case 2:
            $exito = true;
            $icono = "<i class='far fa-check-circle'></i>";
            $clase = 'class="alert alert-success text-center"';
            break;
        case 1:
            $icono = "<i class='fas fa-exclamation-circle'></i>";
            $clase = 'class="alert alert-warning text-center"';
            break;
        case 0:
            $icono = "<i class='fas fa-exclamation-triangle'></i>";
            $clase = 'class="alert alert-danger text-center"';
            break;
    }
    $resultado = "<div {$clase} role='alert'>{$icono} <strong>{$mensaje}</strong></div>";
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = "<div class='alert alert-danger text-center' role='alert'>
                    <i class='fas fa-exclamation-circle'></i> 
                    <strong>{$mensaje}</strong>
                </div>";
}

echo $resultado;
