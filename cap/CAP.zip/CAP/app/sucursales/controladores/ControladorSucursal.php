<?php

/**
 * Description of ControladorSucursal
 *
 * @author Emanuel
 */
class ControladorSucursal {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $sucursales = new Sucursales();
        $resultado = $sucursales->buscar($nombre, $estado);
        $this->mensaje = $sucursales->getMensaje();
        return $resultado;
    }

    public function cambiarEstado($codigo, $estado) {
        $sucursal = new Sucursal($codigo, NULL, NULL, $estado);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $modificacion = $sucursal->cambiarEstado();
            $this->mensaje = $sucursal->getMensaje();
            if ($modificacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function crear($codigo, $sigla, $nombre) {
        $sucursal = new Sucursal($codigo, $sigla, $nombre);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $sucursal->crear();
            $this->mensaje = $sucursal->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 0;
    }

    public function listar($estado) {
        $sucursales = new Sucursales();
        return $sucursales->listar($estado);
    }

    public function listarUltimasCreadas() {
        $sucursales = new Sucursales();
        $resultado = $sucursales->listarUltimasCreadas();
        $this->mensaje = $sucursales->getMensaje();
        return $resultado;
    }

    public function modificar($codigo, $sigla, $nombre) {
        $sucursal = new Sucursal($codigo, $sigla, $nombre, NULL);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $modificacion = $sucursal->modificar();
            $this->mensaje = $sucursal->getMensaje();
            if ($modificacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

}
