/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {

    /* INICIALIZA EL DATATABLE */

    $('#tbProveedores').DataTable({
        lengthChange: false
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editarProveedor').click(function () {
        var idProveedor = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./app/proveedores/vistas/formModificarProveedor.php",
            data: "idProveedor=" + idProveedor,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.datosProveedor').click(function () {
        $("#modalDatosNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#modalDatosTelefono").val($(this).parents("tr").find("td").eq(1).html());
        $("#modalDatosCorreo").val($(this).parents("tr").find("td").eq(2).html());
        $("#modalDatosProvincia").val($(this).parents("tr").find("td").eq(3).html());
        $("#modalDatosLocalidad").val($(this).parents("tr").find("td").eq(4).html());
        $("#modalDatosDireccion").val($(this).parents("tr").find("td").eq(5).html());
        $("#ModalDatosServidor").modal({});
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('.bajaProveedor').click(function () {
        $("#tituloModal").html("<i class='fas fa-trash'></i> CONFIRME LA BAJA DEL PROVEEDOR");
        $("#modalAccion").val("BAJA");
        $("#modalIdProveedor").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalCambioEstadoProveedor").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('.altaProveedor').click(function () {
        $("#tituloModal").html("<i class='fas fa-plus-circle'></i> CONFIRME EL ALTA DEL PROVEEDOR");
        $("#modalAccion").val("ALTA");
        $("#modalIdProveedor").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalCambioEstadoProveedor").modal({backdrop: 'static', keyboard: false});
    });

    /* ENVIA LA OPERACION DE ALTA O BAJA Y MUESTRA EL RESULTADO EN EL MODAL */

    $('#btnCambiarEstadoProveedor').click(function () {
        $.ajax({
            type: "POST",
            url: "./app/proveedores/vistas/procesaCambiarEstadoProveedor.php",
            data: $("#formCambioEstadoProveedor").serialize(),
            success: function (data) {
                $('#cuerpoModal').html(data);
                $('#btnCambiarEstadoProveedor').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                $("#cuerpoModal").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ACTUALIZA LA PANTALLA LUEGO DE HACER EL ALTA O BAJA */

    $('#btnRefrescarPantalla').click(function () {
        location.reload();
    });

});
