/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    /* INICIALIZA EL DATATABLE */

    $('#tbResponsables').DataTable({
        lengthChange: false
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editarResponsable').click(function () {
        var idResponsable = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./app/proveedores/vistas/formModificarResponsable.php",
            data: "idResponsable=" + idResponsable,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('.bajaResponsable').click(function () {
        $("#tituloModal").html("<i class='fas fa-trash'></i> CONFIRME LA BAJA DEL RESPONSABLE");
        $("#modalAccion").val("BAJA");
        $("#modalIdResponsable").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalCambioEstadoResponsable").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('.altaResponsable').click(function () {
        $("#tituloModal").html("<i class='fas fa-plus-circle'></i> CONFIRME EL ALTA DEL RESPONSABLE");
        $("#modalAccion").val("ALTA");
        $("#modalIdResponsable").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalCambioEstadoResponsable").modal({backdrop: 'static', keyboard: false});
    });

    /* ENVIA LA OPERACION DE ALTA O BAJA Y MUESTRA EL RESULTADO EN EL MODAL */

    $('#btnCambiarEstadoResponsable').click(function () {
        $.ajax({
            type: "POST",
            url: "./app/proveedores/vistas/procesaCambiarEstadoResponsable.php",
            data: $("#formCambioEstadoResponsable").serialize(),
            success: function (data) {
                $('#cuerpoModal').html(data);
                $('#btnCambiarEstadoResponsable').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                $("#cuerpoModal").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ACTUALIZA LA PANTALLA LUEGO DE HACER EL ALTA O BAJA */

    $('#btnRefrescarPantalla').click(function () {
        location.reload();
    });


});
