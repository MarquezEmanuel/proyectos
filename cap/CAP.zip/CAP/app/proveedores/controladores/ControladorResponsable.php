<?php

/**
 * Description of ControladorResponsable
 *
 * @author Emanuel
 */
class ControladorResponsable {

    private $mensaje;

    public function __construct() {
        
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $estado) {
        $responsables = new Responsables();
        $resultado = $responsables->buscar($nombre, $estado);
        $this->mensaje = $responsables->getMensaje();
        return $resultado;
    }

    public function crear($nombre, $telefono, $correo, $proveedor) {
        $responsable = new Responsable(NULL, $nombre, $telefono, $correo, $proveedor);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $responsable->crear();
            $this->mensaje = $responsable->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
    }

    public function listarUltimosCreados() {
        $responsables = new Responsables();
        $resultado = $responsables->listarUltimosCreados();
        $this->mensaje = $responsables->getMensaje();
        return $resultado;
    }

}
