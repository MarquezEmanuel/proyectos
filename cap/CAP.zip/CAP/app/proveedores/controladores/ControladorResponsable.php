<?php

/**
 * Description of ControladorResponsable
 *
 * @author Emanuel
 */
class ControladorResponsable {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $responsables = new Responsables();
        $resultado = $responsables->buscar($nombre, $estado);
        $this->mensaje = $responsables->getMensaje();
        return $resultado;
    }

    public function cambiarEstado($id, $estado) {
        $responsable = new Responsable($id, NULL, NULL, NULL, NULL, $estado);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $responsable->cambiarEstado();
            $this->mensaje = $responsable->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function crear($nombre, $telefono, $correo, $proveedor) {
        $responsable = new Responsable(NULL, $nombre, $telefono, $correo, $proveedor);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $creacion = $responsable->crear();
            $this->mensaje = $responsable->getMensaje();
            $confirmar = ($creacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
    }

    public function listarUltimosCreados() {
        $responsables = new Responsables();
        $resultado = $responsables->listarUltimosCreados();
        $this->mensaje = $responsables->getMensaje();
        return $resultado;
    }

    public function modificar($id, $nombre, $telefono, $correo, $proveedor) {
        $responsable = new Responsable($id, $nombre, $telefono, $correo, $proveedor);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $responsable->modificar();
            $this->mensaje = $responsable->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
    }

}
