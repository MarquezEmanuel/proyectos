<?php

/**
 * Description of ControladorProveedor
 *
 * @author Emanuel
 */
class ControladorProveedor {

    private $mensaje;

    public function __construct() {
        ;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function crear($nombre, $telefono, $correo, $provincia, $localidad, $direccion) {
        $proveedor = new Proveedor(NULL, $nombre, $telefono, $correo, $provincia, $localidad, $direccion);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $proveedor->crear();
            $this->mensaje = $proveedor->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
    }

    public function buscar($nombre, $estado) {
        $proveedores = new Proveedores();
        $resultado = $proveedores->buscar($nombre, $estado);
        $this->mensaje = $proveedores->getMensaje();
        return $resultado;
    }

    public function listarUltimosCreados() {
        $proveedores = new Proveedores();
        $resultado = $proveedores->listarUltimosCreados();
        $this->mensaje = $proveedores->getMensaje();
        return $resultado;
    }

}
