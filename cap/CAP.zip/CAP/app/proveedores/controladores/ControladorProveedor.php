<?php

/**
 * Description of ControladorProveedor
 *
 * @author Emanuel
 */
class ControladorProveedor {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $proveedores = new Proveedores();
        $resultado = $proveedores->buscar($nombre, $estado);
        $this->mensaje = $proveedores->getMensaje();
        return $resultado;
    }

    public function cambiarEstado($id, $estado) {
        $proveedor = new Proveedor($id, NULL, NULL, NULL, NULL, NULL, NULL, $estado);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $modificacion = $proveedor->cambiarEstado();
            $this->mensaje = $proveedor->getMensaje();
            if ($modificacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function crear($nombre, $telefono, $correo, $provincia, $localidad, $direccion) {
        $proveedor = new Proveedor(NULL, $nombre, $telefono, $correo, $provincia, $localidad, $direccion);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $proveedor->crear();
            $this->mensaje = $proveedor->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
    }
    
    public function listar() {
        $proveedores = new Proveedores();
        $resultado = $proveedores->listar();
        $this->mensaje = $proveedores->getMensaje();
        return $resultado;
    }

    public function listarUltimosCreados() {
        $proveedores = new Proveedores();
        $resultado = $proveedores->listarUltimosCreados();
        $this->mensaje = $proveedores->getMensaje();
        return $resultado;
    }

    public function modificar($id, $nombre, $telefono, $correo, $provincia, $localidad, $direccion) {
        $proveedor = new Proveedor($id, $nombre, $telefono, $correo, $provincia, $localidad, $direccion);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $proveedor->modificar();
            $this->mensaje = $proveedor->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

}
