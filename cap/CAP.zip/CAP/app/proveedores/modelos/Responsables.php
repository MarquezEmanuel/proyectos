<?php

class Responsables {

    private static $mensaje;

    public function getMensaje() {
        return self::$mensaje;
    }

    public static function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public static function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM vwpro_responsable WHERE resNombre LIKE '%{$nombre}%' AND resEstado = '{$estado}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array('%' . $nombre . '%', &$estado));
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public static function listarUltimosCreados() {
        $consulta = "SELECT TOP(10) * FROM vwpro_responsable WHERE resEstado = 'Activo' ORDER BY resId DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
