<?php

/**
 * Description of Responsable
 *
 * @author Emanuel
 */
class Responsable {

    private $id;
    private $nombre;
    private $telefono;
    private $correo;
    private $proveedor;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $nombre = NULL, $telefono = NULL, $correo = NULL, $proveedor = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setTelefono($telefono);
        $this->setCorreo($correo);
        $this->setProveedor($proveedor);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getTelefono() {
        return $this->telefono;
    }

    public function getCorreo() {
        return $this->correo;
    }

    public function getProveedor() {
        return $this->proveedor;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setTelefono($telefono) {
        $this->telefono = $telefono;
    }

    public function setCorreo($correo) {
        $this->correo = $correo;
    }

    public function setProveedor($proveedor) {
        $this->proveedor = $proveedor;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function crear() {
        if ($this->nombre && $this->proveedor) {
            $values = "('{$this->nombre}', '{$this->telefono}', '{$this->correo}', {$this->proveedor}, 1)";
            $creacion = SQLServer::instancia()->insertar("pro_responsables", $values);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        return 1;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM pro_responsables WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->nombre = $fila['nombre'];
                $this->telefono = $fila['telefono'];
                $this->correo = $fila['correo'];
                $this->proveedor = $this->obtenerProveedor($fila['proveedor']);
                return 2;
            }
            $this->mensaje = "No se obtuvo la información del responsable";
            return 1;
        }
        return 0;
    }

    private function obtenerProveedor($id) {
        $proveedor = new Proveedor($id);
        if ($proveedor->obtener() == 2) {
            return $proveedor;
        }
        $this->mensaje = "No se obtuvo la información del proveedor";
        return NULL;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("pro_responsables", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
