<?php

/**
 * Description of Proveedor
 *
 * @author Emanuel
 */
class Proveedor {

    private $id;
    private $nombre;
    private $telefono;
    private $correo;
    private $provincia;
    private $localidad;
    private $direccion;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $nombre = NULL, $telefono = NULL, $correo = NULL, $provincia = NULL, $localidad = NULL, $direccion = NULL, $estado = NULL) {
        $this->id = $id;
        $this->nombre = utf8_decode($nombre);
        $this->telefono = $telefono;
        $this->correo = $correo;
        $this->provincia = utf8_decode($provincia);
        $this->localidad = utf8_decode($localidad);
        $this->direccion = utf8_decode($direccion);
        $this->estado = $estado;
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getTelefono() {
        return $this->telefono;
    }

    public function getCorreo() {
        return $this->correo;
    }

    public function getProvincia() {
        return utf8_encode($this->provincia);
    }

    public function getLocalidad() {
        return utf8_encode($this->localidad);
    }

    public function getDireccion() {
        return utf8_encode($this->direccion);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = utf8_decode($nombre);
    }

    public function setTelefono($telefono) {
        $this->telefono = $telefono;
    }

    public function setCorreo($correo) {
        $this->correo = $correo;
    }

    public function setProvincia($provincia) {
        $this->provincia = utf8_decode($provincia);
    }

    public function setLocalidad($localidad) {
        $this->localidad = utf8_decode($localidad);
    }

    public function setDireccion($direccion) {
        $this->direccion = utf8_decode($direccion);
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE pro_proveedor SET estado = ? WHERE id = ?";
            $modificacion = SQLServer::instancia()->modificar($consulta, array(&$this->estado, &$this->id));
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 'Activo') ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crear() {
        if ($this->nombre && $this->provincia && $this->localidad && $this->direccion) {
            $consulta = "INSERT INTO pro_proveedor OUTPUT INSERTED.id VALUES (?, ?, ?, ?, ?, ?, 'Activo')";
            $datos = array(&$this->nombre, &$this->telefono, &$this->correo, &$this->provincia, &$this->localidad, &$this->direccion);
            $creacion = SQLServer::instancia()->insertar($consulta, $datos);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->telefono && $this->correo && $this->provincia && $this->localidad && $this->direccion) {
            $campos = "nombre = '{$this->nombre}', telefono = '{$this->telefono}', "
                    . "correo='{$this->correo}', provincia='{$this->provincia}', "
                    . "localidad='{$this->localidad}', direccion='{$this->direccion}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("pro_proveedores", $campos, $condicion);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM pro_proveedores WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->nombre = $fila['nombre'];
                $this->telefono = $fila['telefono'];
                $this->correo = $fila['correo'];
                $this->provincia = $fila['provincia'];
                $this->localidad = $fila['localidad'];
                $this->direccion = $fila['direccion'];
                return 2;
            }
            $this->mensaje = "No se obtuvo la información del proveedor";
            return 1;
        }
        $this->mensaje = "No se pudo hacer referencia al proveedor";
        return 0;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("pro_proveedor", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
