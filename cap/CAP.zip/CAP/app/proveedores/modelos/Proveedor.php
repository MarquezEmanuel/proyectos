<?php

/**
 * Description of Proveedor
 *
 * @author Emanuel
 */
class Proveedor {

    private $id;
    private $nombre;
    private $telefono;
    private $correo;
    private $provincia;
    private $localidad;
    private $direccion;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $nombre = NULL, $telefono = NULL, $correo = NULL, $provincia = NULL, $localidad = NULL, $direccion = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setTelefono($telefono);
        $this->setCorreo($correo);
        $this->setProvincia($provincia);
        $this->setLocalidad($localidad);
        $this->setDireccion($direccion);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getTelefono() {
        return $this->telefono;
    }

    public function getCorreo() {
        return $this->correo;
    }

    public function getProvincia() {
        return $this->provincia;
    }

    public function getLocalidad() {
        return $this->localidad;
    }

    public function getDireccion() {
        return $this->direccion;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setTelefono($telefono) {
        $this->telefono = $telefono;
    }

    public function setCorreo($correo) {
        $this->correo = $correo;
    }

    public function setProvincia($provincia) {
        $this->provincia = $provincia;
    }

    public function setLocalidad($localidad) {
        $this->localidad = $localidad;
    }

    public function setDireccion($direccion) {
        $this->direccion = $direccion;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("pro_proveedores", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        return 1;
    }

    public function crear() {
        if ($this->nombre) {
            $values = "('{$this->nombre}', '{$this->telefono}', '{$this->correo}', '{$this->provincia}', '{$this->localidad}','{$this->direccion}', 1)";
            $creacion = SQLServer::instancia()->insertar("pro_proveedores", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        return 1;
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->telefono && $this->correo && $this->provincia && $this->localidad && $this->direccion) {
            $campos = "nombre = '{$this->nombre}', telefono = '{$this->telefono}', "
                    . "correo='{$this->correo}', provincia='{$this->provincia}', "
                    . "localidad='{$this->localidad}', direccion='{$this->direccion}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("pro_proveedores", $campos, $condicion);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM pro_proveedores WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->nombre = $fila['nombre'];
                $this->telefono = $fila['telefono'];
                $this->correo = $fila['correo'];
                $this->provincia = $fila['provincia'];
                $this->localidad = $fila['localidad'];
                $this->direccion = $fila['direccion'];
                return 2;
            }
            $this->mensaje = "No se obtuvo la información del proveedor";
            return 1;
        }
        return 0;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("pro_proveedores", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
