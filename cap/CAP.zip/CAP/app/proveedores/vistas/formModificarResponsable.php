<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$formulario = $boton = "";
if (isset($_POST['idResponsable'])) {
    $responsable = new Responsable($_POST['idResponsable']);
    $controladorProveedor = new ControladorProveedor();
    $obtencion = $responsable->obtener();
    $proveedores = $controladorProveedor->listar();
    if ($obtencion == 2 && (gettype($proveedores) == "resource")) {
        $opcionesProveedores = "";
        while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
            if ($responsable->getProveedor()->getId() == $proveedor['id']) {
                $opcionesProveedores .= "<option value='{$proveedor['id']}' selected>{$proveedor['nombre']}</option>";
            } else {
                $opcionesProveedores .= "<option value='{$proveedor['id']}'>{$proveedor['nombre']}</option>";
            }
        }
        $formulario = '
            <input type="hidden" name="idResponsable" id="idResponsable" value="' . $responsable->getId() . '">
            <div class="form-row">
                <label for="proveedor" class="col-sm-2 col-form-label">* Proveedor:</label>
                <div class="col">
                    <select class="form-control mb-2" 
                            id="proveedor" name="proveedor">' . $opcionesProveedores . '</select>
                </div>
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" value="' . $responsable->getNombre() . '"
                           placeholder="Nombre del responsable" required>
                </div>
            </div>
            <div class="form-row">
                <label for="telefono" class="col-sm-2 col-form-label">* Telefono:</label>
                <div class="col">
                    <input type="tel" class="form-control mb-2" 
                           name="telefono" id="telefono" value="' . $responsable->getTelefono() . '"
                           placeholder="Número de telefono" required>
                </div>
                <label for="correo" class="col-sm-2 col-form-label">* Correo:</label>
                <div class="col">
                    <input type="email" class="form-control mb-2" 
                           name="correo" id="correo" value="' . $responsable->getCorreo() . '"
                           placeholder="Correo electrónico" required>
                </div>
            </div>';
        $boton = '
            <button type="submit" class="btn btn-success" id="btnModificarResponsable" disabled>
                    <i class="far fa-save"></i> GUARDAR</button>
            <a href="proveedores_buscarResponsable">
                <button type="button" class="btn btn-outline-info">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </a>';
    } else {
        $formulario = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> 
                <strong>No se obtuvo la información para cargar el formulario</strong>
            </div>";
        $boton = '
            <a href="proveedores_buscarResponsable">
                <button type="button" class="btn btn-outline-info">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </a>';
    }
} else {
    $formulario = "
        <div class='alert alert-danger text-center' role='alert'> 
            <i class='fas fa-exclamation-triangle'></i> 
            <strong>No se obtuvo la información desde el formulario</strong>
        </div>";
    $boton = '
        <a href="proveedores_buscarResponsable">
            <button type="button" class="btn btn-outline-info">
                <i class="fas fa-search"></i> BUSCAR
            </button>
        </a>';
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="far fa-address-card"></i> MODIFICAR RESPONSABLE</h4>
        </div>
        <div class="col text-right">
            <a href="proveedores_buscarResponsable"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <div id="seccionCentral">
        <form id="formModificarResponsable" name="formModificarResponsable" method="POST">
            <div class="card mt-3 ">
                <div class="card-header text-left bg-azul-clasico text-white">Formulario de modificación</div>
                <div class="card-body">
                    <?= $formulario; ?>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <?= $boton; ?>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="./app/proveedores/js/ModificarResponsable.js"></script>