<?php

require_once './app/principal/modelos/Constantes.php';
require_once './app/principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorProveedor();

if (isset($_POST['btnBuscarProveedor'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $filtro = ($nombre) ? "Resultado de la búsqueda: " . $nombre . ", " : "Resultado de la búsqueda: ";
    $filtro .= ($estado == 1) ? "Activo" : "Inactivo";
    $proveedores = $controlador->buscar($nombre, $estado);
    $_SESSION['BUSPRO'] = array($nombre, $estado);
} else {
    if (isset($_SESSION['BUSPRO'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSPRO'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = ($nombre) ? "Ultima búsqueda realizada: " . $nombre . ", " : "Ultima búsqueda realizada: ";
        $filtro .= ($estado == 1) ? "Activo" : "Inactivo";
        $proveedores = $controlador->buscar($nombre, $estado);
        $_SESSION['BUSPRO'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $proveedores = $controlador->listarUltimosCreados();
        $filtro = "Ultimos proveedores creados y en estado activo";
        $_SESSION['BUSPRO'] = NULL;
    }
}

if (gettype($proveedores) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
        
        $filas .= "
            <tr>
                <td>{$proveedor['nombre']}</td>
                <td>{$proveedor['telefono']}</td>
                <td>{$proveedor['correo']}</td>
                <td>{$proveedor['provincia']}</td>
                <td>{$proveedor['localidad']}</td>
                <td style='display: none;'>{$proveedor['direccion']}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editarProveedor' name='{$proveedor['id']}' title='Editar proveedor'><i class='far fa-edit'></i></button>
                        <button class='btn btn-outline-primary datosProveedor' title='Ver información básica'><i class='fas fa-info-circle'></i></button>
                        <button class='btn btn-outline-danger borrarProveedor' title='Dar de baja'><i class='fas fa-trash'></i></button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbProveedores" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Telefono</th>
                        <th>Correo</th>
                        <th>Provincia</th>
                        <th>Localidad</th>
                        <th style="display: none;">Dirección</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    if ($proveedores == 1) {
        $cuerpo = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>{$controlador->getMensaje()} para el filtro ingresado</strong>
            </div>";
    } else {
        $cuerpo = "
            <div class='alert alert-danger text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
}

$formulario = '
    <div class="card border-azul-clasico mt-4">
        <div class="card-header text-left bg-azul-clasico text-white"><i class="fas fa-table"></i> ' . $filtro . '</div>
        <div class="card-body">' . $cuerpo . '</div>
    </div>';

echo $formulario;
