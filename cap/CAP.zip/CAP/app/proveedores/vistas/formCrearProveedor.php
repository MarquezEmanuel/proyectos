<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3">
            <div class="col text-left">
                <h4><i class="fas fa-address-card"></i> CREAR PROVEEDOR</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearProveedor" name="formCrearProveedor" method="POST">
            <input type="hidden" name="datos" value="SI">
            <div class="card mt-3">
                <div class="card-header text-left">Complete el formulario</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="nombre" class="col-sm-2 col-form-label text-left">* Nombre:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="nombre" id="nombre" 
                                   placeholder="Nombre del proveedor" required>
                        </div>
                        <label for="telefono" class="col-sm-2 col-form-label text-left">* Telefono:</label>
                        <div class="col">
                            <input type="tel" class="form-control mb-2" 
                                   name="telefono" id="telefono" 
                                   placeholder="Número de telefono" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="correo" class="col-sm-2 col-form-label text-left">* Correo:</label>
                        <div class="col">
                            <input type="email" class="form-control mb-2" 
                                   name="correo" id="correo" 
                                   placeholder="Correo electrónico" required>
                        </div>
                        <label for="provincia" class="col-sm-2 col-form-label text-left">* Provincia:</label>
                        <div class="col">
                            <select id="provincia" name="provincia" class="form-control mb-2" >
                                <option value="No aplica">No aplica</option>
                                <option value="Buenos Aires">Buenos Aires</option>
                                <option value="Catamarca">Catamarca</option>
                                <option value="Chaco">Chaco</option>
                                <option value="Chubut">Chubut</option>
                                <option value="Córdoba">Córdoba</option>
                                <option value="Corrientes">Corrientes</option>
                                <option value="Entre Rios">Entre Rios</option>
                                <option value="Formosa">Formosa</option>
                                <option value="Jujuy">Jujuy</option>
                                <option value="La Pampa">La Pampa</option>
                                <option value="La Rioja">La Rioja</option>
                                <option value="Mendoza">Mendoza</option>
                                <option value="Misiones">Misiones</option>
                                <option value="Neuquén">Neuquén</option>
                                <option value="Río Negro">Río Negro</option>
                                <option value="Salta">Salta</option>
                                <option value="San Juan">San Juan</option>
                                <option value="San Luis">San Luis</option>
                                <option value="Santa Cruz">Santa Cruz</option>
                                <option value="Santa Fé">Santa Fé</option>
                                <option value="Santiago del Estero">Santiago del Estero</option>
                                <option value="Tierra del Fuego">Tierra del Fuego</option>
                                <option value="Tucuman">Tucuman</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="localidad" class="col-sm-2 col-form-label text-left">* Localidad:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="localidad" id="localidad" 
                                   placeholder="Nombre de localidad" required>
                        </div>
                        <label for="direccion" class="col-sm-2 col-form-label text-left">* Dirección:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="direccion" id="direccion" 
                                   placeholder="Direccion" required>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <button type="submit" class="btn btn-success" name="btnCrearProveedor">
                        <i class="far fa-save"></i> GUARDAR
                    </button>
                    <a href="proveedores_buscarProveedor">
                        <button type="button" class="btn btn-outline-info">
                            <i class="fas fa-search"></i> BUSCAR
                        </button>
                    </a>
                    <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="./app/proveedores/js/CrearProveedor.js"></script>
