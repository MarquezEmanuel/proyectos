<?php
$formulario = $boton = "";
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-address-card"></i> MODIFICAR PROVEEDOR</h4>
        </div>
        <div class="col text-right">
            <a href="proveedores_buscarProveedor"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <div id="seccionCentral">
        <form id="formModificarServidor" name="formModificarServidor" method="POST">
            <div class="card mt-3 ">
                <div class="card-header text-left bg-azul-clasico text-white">Formulario de modificación</div>
                <div class="card-body">
                    <?= $formulario; ?>
                </div>
            </div>
            <?= $boton; ?>
        </form>
    </div>
</div>
<script type="text/javascript" src="./app/proveedores/js/ModificarProveedor.js"></script>