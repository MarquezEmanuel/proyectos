<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3">
            <div class="col text-left">
                <h4><i class="fas fa-address-card"></i> CREAR PROVEEDOR</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearProveedor" name="formCrearProveedor" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="nombre" class="col-sm-2 col-form-label text-left">* Nombre:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="nombre" id="nombre" 
                                   placeholder="Nombre del proveedor" required>
                        </div>
                        <label for="telefono" class="col-sm-2 col-form-label text-left">* Telefono:</label>
                        <div class="col">
                            <input type="tel" class="form-control mb-2" 
                                   name="telefono" id="telefono" 
                                   placeholder="Número de telefono" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="correo" class="col-sm-2 col-form-label text-left">* Correo:</label>
                        <div class="col">
                            <input type="email" class="form-control mb-2" 
                                   name="correo" id="correo" 
                                   placeholder="Correo electrónico" required>
                        </div>
                        <label for="provincia" class="col-sm-2 col-form-label text-left">* Provincia:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="provincia" id="provincia" 
                                   placeholder="Provincia" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="localidad" class="col-sm-2 col-form-label text-left">* Localidad:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="localidad" id="localidad" 
                                   placeholder="Nombre de localidad" required>
                        </div>
                        <label for="direccion" class="col-sm-2 col-form-label text-left">* Dirección:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="direccion" id="direccion" 
                                   placeholder="Direccion" required>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <button type="submit" class="btn btn-success" name="btnCrearProveedor">
                        <i class="far fa-save"></i> GUARDAR
                    </button>
                    <a href="FBuscarProveedor.php">
                        <button type="button" class="btn btn-outline-info">
                            <i class="fas fa-search"></i> BUSCAR
                        </button>
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="../js/CrearProveedor.js"></script>
