<?php
require_once './app/principal/modelos/Constantes.php';
require_once './app/principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$controlador = new ControladorProveedor();
$proveedores = $controlador->listar();
$formulario = $botones = "";
if (gettype($proveedores) == "resource") {
    $opcionesProveedores = "";
    while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
        $opcionesProveedores .= "<option value='{$proveedor['id']}'>{$proveedor['nombre']}</option>";
    }
    $formulario = '
        <div class="form-row">
            <label for="proveedor" class="col-sm-2 col-form-label">* Proveedor:</label>
            <div class="col">
                <select class="form-control mb-2" 
                        id="proveedor" name="proveedor">' . $opcionesProveedores . '</select>
            </div>
            <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="nombre" id="nombre" 
                       placeholder="Nombre del responsable" required>
            </div>
        </div>
        <div class="form-row">
            <label for="telefono" class="col-sm-2 col-form-label">* Telefono:</label>
            <div class="col">
                <input type="tel" class="form-control mb-2" 
                       name="telefono" id="telefono" 
                       placeholder="Número de telefono" required>
            </div>
            <label for="correo" class="col-sm-2 col-form-label">* Correo:</label>
            <div class="col">
                <input type="email" class="form-control mb-2" 
                       name="correo" id="correo" 
                       placeholder="Correo electrónico" required>
            </div>
        </div>';
    $botones = '
        <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
        <a href="proveedores_buscarResponsable">
            <button type="button" class="btn btn-outline-info">
                <i class="fas fa-search"></i> BUSCAR
            </button>
        </a>
        <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">';
} else {
    if ($proveedores == 1) {
        $formulario = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>No se encontraron proveedores activos</strong>
            </div>";
    } else {
        $formulario = "
            <div class='alert alert-danger text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
    $botones = '
        <a href="proveedores_buscarResponsable">
            <button type="button" class="btn btn-outline-info">
                <i class="fas fa-search"></i> BUSCAR
            </button>
        </a>';
}
?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="far fa-address-card"></i> CREAR RESPONSABLE</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearResponsable" name="formCrearResponsable" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
                <div class="card-body">
                    <?= $formulario; ?>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <?= $botones; ?>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="./app/proveedores/js/CrearResponsable.js"></script>