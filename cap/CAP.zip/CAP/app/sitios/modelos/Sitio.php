<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Sitio {

    /** @var string Identidicador [NVARCHAR(10)] */
    private $id;

    /** @var string Tipo de sitio entre CPP, URP o SUC [NVARCHAR(10)] */
    private $tipo;

    /** @var string Nombre del sitio [NVARCHAR(50)] */
    private $nombre;

    /** @var string Nombre de la provincia [NVARCHAR(50)] */
    private $provincia;

    /** @var string Nombre de la localidad [NVARCHAR(50)] */
    private $localidad;

    /** @var bigint Codigo postal [BIGINT] */
    private $codigoPostal;

    /** @var string Direccion del sitio [NVARCHAR(60)] */
    private $direccion;

    /** @var string Origen entre Tercerizado o Propio [NVARCHAR(10)] */
    private $origen;

    /** @var integer Estado entre 0 o 1 [INT] */
    private $estado;

    /** @var string Mensaje que describe el estado del objeto u operacion */
    private $mensaje;

    public function __construct($id = NULL, $tipo = NULL, $nombre = NULL, $provincia = NULL, $localidad = NULL, $codigoPostal = NULL, $direccion = NULL, $origen = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setTipo($tipo);
        $this->setNombre($nombre);
        $this->setProvincia($provincia);
        $this->setLocalidad($localidad);
        $this->setCodigoPostal($codigoPostal);
        $this->setDireccion($direccion);
        $this->setOrigen($origen);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getProvincia() {
        return $this->provincia;
    }

    public function getLocalidad() {
        return $this->localidad;
    }

    public function getCodigoPostal() {
        return $this->codigoPostal;
    }

    public function getDireccion() {
        return $this->direccion;
    }

    public function getOrigen() {
        return $this->origen;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setTipo($tipo) {
        $this->tipo = $tipo;
    }

    public function setNombre($nombre) {
        $this->nombre = utf8_decode($nombre);
    }

    public function setProvincia($provincia) {
        $this->provincia = utf8_decode($provincia);
    }

    public function setLocalidad($localidad) {
        $this->localidad = utf8_decode($localidad);
    }

    public function setCodigoPostal($codigoPostal) {
        $this->codigoPostal = $codigoPostal;
    }

    public function setDireccion($direccion) {
        $this->direccion = utf8_decode($direccion);
    }

    public function setOrigen($origen) {
        $this->origen = $origen;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = '{$this->id}'";
            $modificacion = SQLServer::instancia()->modificar("sit_sitios", $campos, $condicion);
            $this->mensaje = "Sitio " . $this->id . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        $this->descripcion = "No se recibieron todos los parametros obligatorios";
        return 0;
    }

    public function crear() {
        if ($this->id && $this->tipo && $this->nombre) {
            $values = "('{$this->id}', '{$this->tipo}', '{$this->nombre}', '{$this->provincia}', '{$this->localidad}', {$this->codigoPostal}, '{$this->direccion}', '{$this->origen}', 1)";
            $creacion = SQLServer::instancia()->insertar("sit_sitios", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        $this->descripcion = "No se recibieron todos los parametros obligatorios";
        return 0;
    }

    public function modificar() {
        if ($this->id && $this->tipo && $this->nombre) {
            $campos = "nombre = '{$this->nombre}', tipo = '{$this->tipo}', provincia = '{$this->provincia}', "
                    . "localidad = '{$this->localidad}', codigoPostal = {$this->codigoPostal}, "
                    . "direccion='{$this->direccion}', origen='{$this->origen}'";
            $condicion = "id = '{$this->id}'";
            $modificacion = SQLServer::instancia()->modificar("sit_sitios", $campos, $condicion);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        $this->descripcion = "No se recibieron todos los parametros obligatorios";
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM sit_sitios WHERE id = '{$this->id}'";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!empty($fila)) {
                $this->tipo = $fila['tipo'];
                $this->nombre = utf8_encode($fila['nombre']);
                $this->provincia = utf8_encode($fila['provincia']);
                $this->localidad = utf8_encode($fila['localidad']);
                $this->codigoPostal = $fila['codigoPostal'];
                $this->direccion = utf8_encode($fila['direccion']);
                $this->origen = $fila['origen'];
                $this->estado = $fila['estado'];
                return 2;
            }
            $this->mensaje = "No se pudo obtener la información del sitio";
            return 1;
        }
        $this->descripcion = "No se pudo hacer referencia al sitio";
        return 0;
    }

    private function registrarActividad($operacion, $values) {
        $detalle = str_replace("'", " ", $values);
        $creacion = Log::guardarActividad("suc_sucursales", $operacion, $detalle);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
