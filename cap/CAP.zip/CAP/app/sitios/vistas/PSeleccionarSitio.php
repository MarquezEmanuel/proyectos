<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$arreglo = array();
if (isset($_POST['nombre']) && isset($_POST['estado'])) {
    $controlador = new ControladorSitio();
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $sitios = $controlador->buscar($nombre, $estado);
    if (gettype($sitios) == "resource") {
        while ($sitio = sqlsrv_fetch_array($sitios, SQLSRV_FETCH_ASSOC)) {
            $arreglo[] = array('id' => $sitio["id"], 'text' => $sitio["nombre"]);
        }
    } else {
        $texto = ($sitios == 1) ? "Sin resultados" : "Error";
        $arreglo[] = array('id' => "NO", 'text' => $texto);
    }
} else {
    $arreglo[] = array('id' => "NO", 'text' => "Sin parametros");
}

echo json_encode($arreglo);


