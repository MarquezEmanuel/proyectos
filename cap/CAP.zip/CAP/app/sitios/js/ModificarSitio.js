/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    var formOriginal = $("#formModificarSitio").serialize();

    /* DETECTA LOS CAMBIOS EN LOS CAMPOS DEL FORMULARIO PARA ACTIVAR/DESACTIVAR EL BOTON DE GUARDADO */

    $("#formModificarSitio").change(function () {
        var formModificado = $("#formModificarSitio").serialize();
        var disabled = (formOriginal !== formModificado) ? false : true;
        $("#btnModificarSitio").prop("disabled", disabled);
    });

    /* ENVIA EL FORMULARIO PARA REALIZAR LA MODIFICACION */

    $('#formModificarSitio').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: "./procesaModificarSitio.php",
            data: $("#formModificarSitio").serialize(),
            success: function (data) {
                $('#seccionResultado').html(data[0]['resultado']);
                if (data[0]['exito'] === true) {
                    $("#codigo").prop("disabled", true);
                    $("#tipo").prop("disabled", true);
                    $("#nombre").prop("disabled", true);
                    $("#provincia").prop("disabled", true);
                    $("#localidad").prop("disabled", true);
                    $("#codigoPostal").prop("disabled", true);
                    $("#direccion").prop("disabled", true);
                    $("#origen").prop("disabled", true);
                    $("#btnModificarSitio").prop("disabled", true);
                }
            },
            error: function (data) {
                console.log(data);
                $("#seccionResultado").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

});

