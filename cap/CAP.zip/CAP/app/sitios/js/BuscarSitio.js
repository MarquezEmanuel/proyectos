/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {

    /* INICIALIZA DATATABLE */

    $('#tbSitios').dataTable({
        lengthChange: false
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editar').click(function () {
        var idSitio = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formModificarSitio.php",
            data: "idSitio=" + idSitio,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#seccionInferior").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('.baja').click(function () {
        $("#tituloModal").html("<i class='fas fa-trash'></i> CONFIRME LA BAJA DEL SITIO");
        $("#modalAccion").val("BAJA");
        $("#modalCodigo").val($(this).parents("tr").find("td").eq(0).html());
        $("#modalNombre").val($(this).parents("tr").find("td").eq(2).html());
        $("#ModalCambioEstadoSitio").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('.alta').click(function () {
        $("#tituloModal").html("<i class='fas fa-plus-circle'></i> CONFIRME EL ALTA DEL SITIO");
        $("#modalAccion").val("ALTA");
        $("#modalCodigo").val($(this).parents("tr").find("td").eq(0).html());
        $("#modalNombre").val($(this).parents("tr").find("td").eq(2).html());
        $("#ModalCambioEstadoSitio").modal({backdrop: 'static', keyboard: false});
    });

    /* ENVIA LA OPERACION DE ALTA O BAJA Y MUESTRA EL RESULTADO EN EL MODAL */

    $('#btnCambiarEstadoSitio').click(function () {
        $.ajax({
            type: "POST",
            url: "./procesaCambiarEstadoSitio.php",
            data: $("#formCambioEstadoSitio").serialize(),
            success: function (data) {
                $('#cuerpoModal').html(data);
                $('#btnCambiarEstadoSitio').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                $("#cuerpoModal").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ACTUALIZA LA PANTALLA LUEGO DE HACER EL ALTA O BAJA */

    $('#btnRefrescarPantalla').click(function () {
        location.reload();
    });

});

