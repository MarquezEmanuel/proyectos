/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    $('#tbHardwares').dataTable({
        lengthChange: false
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editarHardware').click(function () {
        var idHardware = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formModificarHardware.php",
            data: "idHardware=" + idHardware,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#seccionInferior").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.datosHardware').click(function () {
        $("#mdhInventario").val($(this).parents("tr").find('td:eq(0)').text());
        $("#mdhTipo").val($(this).parents("tr").find('td:eq(1)').text());
        $("#mdhAmbiente").val($(this).parents("tr").find('td:eq(2)').text());
        $("#mdhSigla").val($(this).parents("tr").find('td:eq(3)').text());
        $("#mdhNombre").val($(this).parents("tr").find('td:eq(4)').text());
        $("#mdhUbicacion").val($(this).parents("tr").find('td:eq(5)').text());
        $("#mdhDominio").val($(this).parents("tr").find('td:eq(6)').text());
        $("#mdhSwBase").val($(this).parents("tr").find('td:eq(7)').text());
        $("#mdhMarca").val($(this).parents("tr").find('td:eq(8)').text());
        $("#mdhModelo").val($(this).parents("tr").find('td:eq(9)').text());
        $("#mdhArquitectura").val($(this).parents("tr").find('td:eq(10)').text());
        $("#mdhCore").val($(this).parents("tr").find('td:eq(11)').text());
        $("#mdhProcesador").val($(this).parents("tr").find('td:eq(12)').text());
        $("#mdhMhz").val($(this).parents("tr").find('td:eq(13)').text());
        $("#mdhMemoria").val($(this).parents("tr").find('td:eq(14)').text());
        $("#mdhDisco").val($(this).parents("tr").find('td:eq(15)').text());
        $("#mdhRaid").val($(this).parents("tr").find('td:eq(16)').text());
        $("#mdhRed").val($(this).parents("tr").find('td:eq(17)').text());
        $("#mdhRTI").val($(this).parents("tr").find('td:eq(18)').text());
        $("#mdhFuncion").val($(this).parents("tr").find('td:eq(19)').text());
        $("#ModalDatosHardware").modal({});
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('.bajaHardware').click(function () {
        $("#tituloModal").html("<i class='fas fa-microchip'></i> CONFIRME LA BAJA DEL HARDWARE");
        $("#modalAccion").val("BAJA");
        $("#modalIdHardware").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find('td:eq(4)').text());
        $("#ModalCambioEstadoHardware").modal({backdrop: 'static', keyboard: false});
    });
    
    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('.altaHardware').click(function () {
        $("#tituloModal").html("<i class='fas fa-microchip'></i> CONFIRME EL ALTA DEL HARDWARE");
        $("#modalAccion").val("ALTA");
        $("#modalIdHardware").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find('td:eq(4)').text());
        $("#ModalCambioEstadoHardware").modal({backdrop: 'static', keyboard: false});
    });
    
    /* ENVIA LA OPERACION DE ALTA O BAJA Y MUESTRA EL RESULTADO EN EL MODAL */

    $('#btnCambiarEstadoHardware').click(function () {
        $.ajax({
            type: "POST",
            url: "./procesaCambiarEstadoHardware.php",
            data: $("#formCambioEstadoHardware").serialize(),
            success: function (data) {
                $('#cuerpoModal').html(data);
                $('#btnCambiarEstadoHardware').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                $("#cuerpoModal").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });
    
    /* ACTUALIZA LA PANTALLA LUEGO DE HACER EL ALTA O BAJA */

    $('#btnRefrescarPantalla').click(function () {
        location.reload();
    });

});

