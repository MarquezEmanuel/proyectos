<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorHardware();

if (isset($_POST['btnBuscarHardware'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " . $estado : "TODOS, " . $estado;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $hardwares = $controlador->buscar($nombre, $estado);
    $_SESSION['BUSHAR'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['BUSHAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSHAR'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $hardwares = $controlador->buscar($nombre, $estado);
        $_SESSION['BUSHAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $hardwares = $controlador->listarUltimosCreados();
        $filtro = "Últimos elementos creados";
        $_SESSION['BUSHAR'] = NULL;
    }
}

if (gettype($hardwares) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($hardware = sqlsrv_fetch_array($hardwares, SQLSRV_FETCH_ASSOC)) {
        if ($hardware['codEstadoHardware'] == 1) {
            $operaciones = "
                <button class='btn btn-outline-info detalleHardware' 
                        name='{$hardware['id']}' title='Ver detalle'>
                    <i class='fas fa-eye'></i>
                </button>
                <button class='btn btn-outline-warning editarHardware' 
                        name='{$hardware['id']}' title='Editar'>
                    <i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger bajaHardware' 
                        name='{$hardware['id']}' title='Dar de baja'>
                    <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-success altaHardware' 
                    name='{$hardware['id']}' title='Dar de alta'>
                        <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td>{$hardware['siglaInventario']}</td>
                <td>{$hardware['nombreSucursal']}</td>
                <td>{$hardware['tipo']}</td>
                <td>{$hardware['sigla']}</td>
                <td>{$hardware['nombre']}</td> 
                <td>{$hardware['dominio']}</td>    
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>{$operaciones}</div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbHardwares" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Inventario</th>
                        <th>Sucursal</th>
                        <th>Tipo</th>
                        <th>Sigla</th>
                        <th>Nombre</th>
                        <th>Dominio</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    if ($hardwares == 1) {
        $cuerpo = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>{$controlador->getMensaje()} para el filtro ingresado</strong>
            </div>";
    } else {
        $cuerpo = "
            <div class='alert alert-danger text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
}

$formulario = '
    <div class="card border-azul-clasico">
        <div class="card-header bg-azul-clasico text-white"><i class="fas fa-table"></i> ' . $filtro . '</div>
        <div class="card-body">' . $cuerpo . '</div>
    </div>';

echo $formulario;
