<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$controladorInventario = new ControladorInventario();
$controladorSucursal = new ControladorSucursal();
$inventarios = $controladorInventario->listar();
$sucursales = $controladorSucursal->listar(1);
$formulario = $botones = "";
if ((gettype($inventarios) == "resource") && gettype($sucursales) == "resource") {
    $opcionesInventario = $opcionesSucursales = "";
    while ($inventario = sqlsrv_fetch_array($inventarios, SQLSRV_FETCH_ASSOC)) {
        $opcionesInventario .= "<option value='{$inventario['id']}'>{$inventario['sigla']}</option>";
    }
    while ($sucursal = sqlsrv_fetch_array($sucursales, SQLSRV_FETCH_ASSOC)) {
        $opcionesSucursales .= "<option value='{$sucursal['id']}'>{$sucursal['nombre']}</option>";
    }

    $formulario = '
        <div class="form-row">
            <label for="inventario" class="col-sm-2 col-form-label">* Inventario:</label>
            <div class="col">
                <select class="form-control mb-2" id="inventario" name="inventario">' . $opcionesInventario . '</select>
            </div>
            <label for="sucursal" class="col-sm-2 col-form-label">* Sucursal:</label>
            <div class="col">
                <select class="form-control mb-2" id="sucursal" name="sucursal">' . $opcionesSucursales . '</select>
            </div>
        </div>
        <div class="form-row">
            <label for="tipo" class="col-sm-2 col-form-label">* Tipo:</label>
            <div class="col">
                <select class="form-control mb-2" id="tipo" name="tipo">
                    <option value="Host virtual">Host virtual</option>
                    <option value="Maquina virtual">Máquina virtual</option>
                    <option value="Hardware fisico">Hardware físico</option>
                </select>
            </div>
            <label for="ambiente" class="col-sm-2 col-form-label">* Ambiente:</label>
            <div class="col">
                <select class="form-control mb-2" id="ambiente" name="ambiente">
                    <option value="Produccion">Producción</option>
                    <option value="DMZ">DMZ</option>
                </select>
            </div>
        </div>
        <div class="form-row">
            <label for="sigla" class="col-sm-2 col-form-label">* Sigla:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="sigla" id="sigla" maxlength="20"
                       placeholder="Sigla del equipamiento" required>
            </div>
            <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="nombre" id="nombre" maxlength="50"
                       placeholder="Nombre del equipamiento" required>
            </div>
        </div>
        <div class="form-row">
            <label for="dominio" class="col-sm-2 col-form-label">* Dominio:</label>
            <div class="col">
                <select class="form-control mb-2" id="dominio" name="dominio">
                    <option value="CORP">CORP</option>
                    <option value="DMZ">DMZ</option>
                    <option value="SANTACRUZ">SANTA CRUZ</option>
                </select>
            </div>
            <label for="swbase" class="col-sm-2 col-form-label">* Software base:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="swbase" id="swbase" maxlength="50"
                       placeholder="Software base" required>
            </div>
        </div>
        <div class="form-row">
            <label for="marca" class="col-sm-2 col-form-label">* Marca:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="marca" id="marca" maxlength="50"
                       placeholder="Marca" required>
            </div>
            <label for="modelo" class="col-sm-2 col-form-label">* Modelo:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="modelo" id="modelo" maxlength="50"
                       placeholder="Modelo" required>
            </div>
        </div>
        <div class="form-row">
            <label for="arquitectura" class="col-sm-2 col-form-label">* Arquitectura:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="arquitectura" id="arquitectura" maxlength="50"
                       placeholder="Arquitectura" required>
            </div>
            <label for="core" class="col-sm-2 col-form-label">* Core:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="core" id="core" maxlength="50"
                       placeholder="Core" required>
            </div>
        </div>
        <div class="form-row">
            <label for="procesador" class="col-sm-2 col-form-label">* Procesador:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="procesador" id="procesador" maxlength="50"
                       placeholder="Procesador" required>
            </div>
            <label for="mhz" class="col-sm-2 col-form-label">* Mhz:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="mhz" id="mhz" maxlength="50"
                       placeholder="Mhz" required>
            </div>
        </div>
        <div class="form-row">
            <label for="memoria" class="col-sm-2 col-form-label">* Memoria:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="memoria" id="memoria" maxlength="50"
                       placeholder="Memoria" required>
            </div>
            <label for="disco" class="col-sm-2 col-form-label">* Disco:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="disco" id="disco" maxlength="50"
                       placeholder="Disco" required>
            </div>
        </div>
        <div class="form-row">
            <label for="raid" class="col-sm-2 col-form-label">* Raid:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="raid" id="raid" maxlength="50"
                       placeholder="Raid" required>
            </div>
            <label for="disco" class="col-sm-2 col-form-label">* Red:</label>
            <div class="col">
                <input type="number" class="form-control mb-2" 
                       name="red" id="red" min="1"
                       placeholder="Red" required>
            </div>
        </div>
        <div class="form-row">
            <label for="funcion" class="col-sm-2 col-form-label">* Función: </label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="funcion" id="funcion" maxlength="50"
                       placeholder="Función" required>
            </div>
            <label for="rti" class="col-sm-2 col-form-label">* RTI:</label>
            <div class="col">
                <select class="form-control mb-2" id="rti" name="rti">
                    <option value="Si">Sí</option>
                    <option value="No">No</option>
                </select>
            </div>
        </div>';
    $botones = '
        <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
        <a href="hardwares_buscar">
            <button type="button" class="btn btn-outline-info">
                <i class="fas fa-search"></i> BUSCAR
            </button>
        </a>
        <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">';
} else {
    /* NO SE LISTARON INVENTARIOS O SUCURSALES */
    if (($inventarios == 1) || ($sucursales == 1)) {
        $formulario = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>Ocurrió un error al realizar la consulta de inventarios y/o sucursales (informe al administrador)</strong>
            </div>";
    } else {
        $formulario = "
            <div class='alert alert-warning text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>No se encontraron inventarios y/o sucursales para cargar el formulario</strong>
            </div>";
    }
    $botones = '
        <a href="hardwares_buscar">
            <button type="button" class="btn btn-outline-info">
                <i class="fas fa-search"></i> BUSCAR
            </button>
        </a>';
}

require_once '../../principal/vistas/header.php';
?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-microchip"></i> CREAR HARDWARE</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearHardware" name="formCrearHardware" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
                <div class="card-body">
                    <?= $formulario; ?>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <?= $botones; ?>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="./app/hardwares/js/CrearHardware.js"></script>


