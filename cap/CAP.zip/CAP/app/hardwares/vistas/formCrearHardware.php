<?php ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-fire-alt"></i> CREAR HARDWARE</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearHardware" name="formCrearHardware" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="inventario" class="col-sm-2 col-form-label">* Inventario:</label>
                        <div class="col">
                            <select class="form-control mb-2" 
                                    id="inventario" name="inventario"></select>
                        </div>
                        <label for="sucursal" class="col-sm-2 col-form-label">* Sucursal:</label>
                        <div class="col">
                            <select class="form-control mb-2" 
                                    id="sucursal" name="sucursal"></select>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="tipo" class="col-sm-2 col-form-label">* Tipo:</label>
                        <div class="col">
                            <select class="form-control mb-2" 
                                    id="tipo" name="tipo"></select>
                        </div>
                        <label for="sigla" class="col-sm-2 col-form-label">* Sigla:</label>
                        <div class="col">
                            <select class="form-control mb-2" 
                                    id="sigla" name="sigla"></select>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                        <div class="col">
                            <select class="form-control mb-2" 
                                    id="nombre" name="nombre"></select>
                        </div>
                        <label for="dominio" class="col-sm-2 col-form-label">* Dominio:</label>
                        <div class="col">
                            <select class="form-control mb-2" 
                                    id="dominio" name="dominio"></select>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="swbase" class="col-sm-2 col-form-label">* Software base:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                    name="swbase" id="swbase" maxlength="50"
                                    placeholder="Software base" required>
                        </div>
                        <label for="ambiente" class="col-sm-2 col-form-label">* Ambiente:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                    name="ambiente" id="ambiente" maxlength="50"
                                    placeholder="Ambiente" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="arquitectura" class="col-sm-2 col-form-label">* Arquitectura:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                    name="arquitectura" id="arquitectura" maxlength="50"
                                    placeholder="arquitectura" required>
                        </div>
                        <label for="core" class="col-sm-2 col-form-label">* Core:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                    name="core" id="core" maxlength="50"
                                    placeholder="Core" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="procesador" class="col-sm-2 col-form-label">* Procesador:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                    name="procesador" id="procesador" maxlength="50"
                                    placeholder="Procesador" required>
                        </div>
                        <label for="mhz" class="col-sm-2 col-form-label">* Mhz:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                    name="mhz" id="mhz" maxlength="50"
                                    placeholder="Mhz" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="memoria" class="col-sm-2 col-form-label">* Memoria:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                    name="memoria" id="memoria" maxlength="50"
                                    placeholder="Memoria" required>
                        </div>
                        <label for="disco" class="col-sm-2 col-form-label">* Disco:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                    name="disco" id="disco" maxlength="50"
                                    placeholder="Disco" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="raid" class="col-sm-2 col-form-label">* Raid:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                    name="raid" id="raid" maxlength="50"
                                    placeholder="Raid" required>
                        </div>
                        <label for="disco" class="col-sm-2 col-form-label">* Red:</label>
                        <div class="col">
                            <input type="number" class="form-control mb-2" 
                                    name="red" id="red" maxlength="50"
                                    placeholder="Red" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="rti" class="col-sm-2 col-form-label">* RTI:</label>
                        <div class="col">
                            <select class="form-control mb-2" 
                                    id="rti" name="rti"></select>
                        </div>
                        <label class="col-sm-2 col-form-label"></label>
                        <div class="col"></div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">

                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="./app/firewalls/js/CrearFirewall.js"></script>


