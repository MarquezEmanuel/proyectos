<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Hardware {

    private $id;
    private $tipo;
    private $sigla;
    private $nombre;
    private $dominio;
    private $swBase;
    private $ambiente;
    private $funcion;
    private $ubicacion;
    private $marca;
    private $modelo;
    private $arquitectura;
    private $core;
    private $procesador;
    private $mhz;
    private $memoria;
    private $disco;
    private $raid;
    private $red;
    private $rti;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $tipo = NULL, $sigla = NULL, $nombre = NULL, $dominio = NULL, $swBase = NULL, $ambiente = NULL, $funcion = NULL, $ubicacion = NULL, $marca = NULL, $modelo = NULL, $arquitectura = NULL, $core = NULL, $procesador = NULL, $mhz = NULL, $memoria = NULL, $disco = NULL, $raid = NULL, $red = NULL, $rti = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setTipo($tipo);
        $this->setSigla($sigla);
        $this->setNombre($nombre);
        $this->setDominio($dominio);
        $this->setSwBase($swBase);
        $this->setAmbiente($ambiente);
        $this->setFuncion($funcion);
        $this->setUbicacion($ubicacion);
        $this->setMarca($marca);
        $this->setModelo($modelo);
        $this->setArquitectura($arquitectura);
        $this->setCore($core);
        $this->setProcesador($procesador);
        $this->setMhz($mhz);
        $this->setMemoria($memoria);
        $this->setDisco($disco);
        $this->setRaid($raid);
        $this->setRed($red);
        $this->setRti($rti);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getDominio() {
        return $this->dominio;
    }

    public function getSwBase() {
        return utf8_encode($this->swBase);
    }

    public function getAmbiente() {
        return $this->ambiente;
    }

    public function getFuncion() {
        return utf8_encode($this->funcion);
    }

    public function getUbicacion() {
        return $this->ubicacion;
    }

    public function getMarca() {
        return utf8_encode($this->marca);
    }

    public function getModelo() {
        return utf8_encode($this->modelo);
    }

    public function getArquitectura() {
        return utf8_encode($this->arquitectura);
    }

    public function getCore() {
        return utf8_encode($this->core);
    }

    public function getProcesador() {
        return utf8_encode($this->procesador);
    }

    public function getMhz() {
        return ($this->mhz = "NULL") ? NULL : $this->mhz;
    }

    public function getMemoria() {
        return ($this->memoria = "NULL") ? NULL : $this->memoria;
    }

    public function getDisco() {
        return utf8_encode($this->disco);
    }

    public function getRaid() {
        return utf8_encode($this->raid);
    }

    public function getRed() {
        return ($this->red = "NULL") ? NULL : $this->red;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setTipo($tipo) {
        $this->tipo = utf8_decode($tipo);
    }

    public function setSigla($sigla) {
        $this->sigla = $sigla;
    }

    public function setNombre($nombre) {
        $this->nombre = utf8_decode($nombre);
    }

    public function setDominio($dominio) {
        $this->dominio = $dominio;
    }

    public function setSwBase($swBase) {
        $this->swBase = $swBase;
    }

    public function setAmbiente($ambiente) {
        $this->ambiente = $ambiente;
    }

    public function setFuncion($funcion) {
        $this->funcion = utf8_decode($funcion);
    }

    public function setUbicacion($ubicacion) {
        $this->ubicacion = $ubicacion;
    }

    public function setMarca($marca) {
        $this->marca = utf8_decode($marca);
    }

    public function setModelo($modelo) {
        $this->modelo = utf8_decode($modelo);
    }

    public function setArquitectura($arquitectura) {
        $this->arquitectura = utf8_decode($arquitectura);
    }

    public function setCore($core) {
        $this->core = utf8_decode($core);
    }

    public function setProcesador($procesador) {
        $this->procesador = utf8_decode($procesador);
    }

    public function setMhz($mhz) {
        $this->mhz = ($mhz) ? $mhz : "NULL";
    }

    public function setMemoria($memoria) {
        $this->memoria = ($memoria) ? $memoria : "NULL";
    }

    public function setDisco($disco) {
        $this->disco = utf8_decode($disco);
    }

    public function setRaid($raid) {
        $this->raid = utf8_decode($raid);
    }

    public function setRed($red) {
        $this->red = ($red) ? $red : "NULL";
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("har_hardware", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function crear() {
        if ($this->tipo && $this->ambiente && $this->sigla && $this->nombre && $this->ubicacion && $this->dominio && $this->rti) {
            $values = "('{$this->tipo}','{$this->sigla}', '{$this->nombre}', "
                    . "'{$this->dominio}', '{$this->swBase}', '{$this->ambiente}', '{$this->funcion}', "
                    . "'{$this->ubicacion}', '{$this->marca}', '{$this->modelo}', '{$this->arquitectura}', "
                    . "'{$this->core}', '{$this->procesador}', {$this->mhz}, {$this->memoria}, "
                    . "'{$this->disco}', '{$this->raid}', {$this->red}, '{$this->rti}', 1)";
            $creacion = SQLServer::instancia()->insertar("har_hardware", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->crearRelacion();
            }
            return $creacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    private function crearRelacion() {
        $consulta = "INSERT INTO har_hardwares_inventarios SELECT {$this->id}, id FROM inv_inventarios WHERE estado = 1";
        $creacion = SQLServer::instancia()->ejecutar($consulta);
        $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
        if ($creacion == 2) {
            return $this->registrarActividad("CREACION", $this->id);
        }
        return $creacion;
    }

    public function modificar() {
        if ($this->id && $this->tipo && $this->ambiente && $this->sigla && $this->nombre && $this->ubicacion && $this->dominio && $this->rti) {
            $campos = "tipo='{$this->tipo}', sigla='{$this->sigla}', nombre='{$this->nombre}', "
                    . "dominio='{$this->dominio}', softwareBase='{$this->swBase}', ambiente='{$this->ambiente}', funcion='{$this->funcion}', "
                    . "ubicacion='{$this->ubicacion}', arquitectura='{$this->arquitectura}', core='{$this->core}', procesador='{$this->procesador}', "
                    . "mhz={$this->mhz}, memoria={$this->memoria}, disco='{$this->disco}', raid='{$this->raid}', red={$this->red}, "
                    . "rti='{$this->rti}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("har_hardware", $campos, $condicion);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM har_hardware WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->tipo = $fila['tipo'];
                $this->sigla = $fila['sigla'];
                $this->nombre = $fila['nombre'];
                $this->dominio = $fila['dominio'];
                $this->swBase = $fila['softwareBase'];
                $this->ambiente = $fila['ambiente'];
                $this->funcion = $fila['funcion'];
                $this->arquitectura = $fila['arquitectura'];
                $this->core = $fila['core'];
                $this->procesador = $fila['procesador'];
                $this->mhz = $fila['mhz'];
                $this->memoria = $fila['memoria'];
                $this->disco = $fila['disco'];
                $this->raid = $fila['raid'];
                $this->red = $fila['red'];
                $this->rti = $fila['rti'];
                $this->estado = $fila['estado'];
                return $this->obtenerUbicacion($fila['ubicacion']);
            }
            $this->mensaje = "No se obtuvo la información del hardware";
            return 1;
        }
        $this->mensaje = "No se pudo hacer referencia al hardware";
        return 0;
    }

    private function obtenerUbicacion($idUbicacion) {
        $sitio = new Sitio($idUbicacion);
        if ($sitio->obtener() == 2) {
            $this->ubicacion = $sitio;
            return 2;
        }
        $this->mensaje = $sitio->getMensaje();
        return 1;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("har_hardware", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
