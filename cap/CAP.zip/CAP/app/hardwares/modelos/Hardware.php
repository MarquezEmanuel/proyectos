<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Hardware {

    private $id;
    private $inventario;
    private $tipo;
    private $sigla;
    private $nombre;
    private $dominio;
    private $swBase;
    private $ambiente;
    private $funcion;
    private $sucursal;
    private $marca;
    private $modelo;
    private $arquitectura;
    private $core;
    private $procesador;
    private $mhz;
    private $memoria;
    private $disco;
    private $raid;
    private $red;
    private $rti;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $inventario = NULL, $tipo = NULL, $sigla = NULL, $nombre = NULL, $dominio = NULL, $swBase = NULL, $ambiente = NULL, $funcion = NULL, $sucursal = NULL, $marca = NULL, $modelo = NULL, $arquitectura = NULL, $core = NULL, $procesador = NULL, $mhz = NULL, $memoria = NULL, $disco = NULL, $raid = NULL, $red = NULL, $rti = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setInventario($inventario);
        $this->setTipo($tipo);
        $this->setSigla($sigla);
        $this->setNombre($nombre);
        $this->setDominio($dominio);
        $this->setSwBase($swBase);
        $this->setAmbiente($ambiente);
        $this->setFuncion($funcion);
        $this->setSucursal($sucursal);
        $this->setMarca($marca);
        $this->setModelo($modelo);
        $this->setArquitectura($arquitectura);
        $this->setCore($core);
        $this->setProcesador($procesador);
        $this->setMhz($mhz);
        $this->setMemoria($memoria);
        $this->setDisco($disco);
        $this->setRaid($raid);
        $this->setRed($red);
        $this->setRti($rti);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getInventario() {
        return $this->inventario;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getDominio() {
        return $this->dominio;
    }

    public function getSwBase() {
        return $this->swBase;
    }

    public function getAmbiente() {
        return $this->ambiente;
    }

    public function getFuncion() {
        return $this->funcion;
    }

    public function getSucursal() {
        return $this->sucursal;
    }

    public function getMarca() {
        return $this->marca;
    }

    public function getModelo() {
        return $this->modelo;
    }

    public function getArquitectura() {
        return $this->arquitectura;
    }

    public function getCore() {
        return $this->core;
    }

    public function getProcesador() {
        return $this->procesador;
    }

    public function getMhz() {
        return $this->mhz;
    }

    public function getMemoria() {
        return $this->memoria;
    }

    public function getDisco() {
        return $this->disco;
    }

    public function getRaid() {
        return $this->raid;
    }

    public function getRed() {
        return $this->red;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setInventario($inventario) {
        $this->inventario = $inventario;
    }

    public function setTipo($tipo) {
        $this->tipo = $tipo;
    }

    public function setSigla($sigla) {
        $this->sigla = $sigla;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setDominio($dominio) {
        $this->dominio = $dominio;
    }

    public function setSwBase($swBase) {
        $this->swBase = $swBase;
    }

    public function setAmbiente($ambiente) {
        $this->ambiente = $ambiente;
    }

    public function setFuncion($funcion) {
        $this->funcion = $funcion;
    }

    public function setSucursal($sucursal) {
        $this->sucursal = $sucursal;
    }

    public function setMarca($marca) {
        $this->marca = $marca;
    }

    public function setModelo($modelo) {
        $this->modelo = $modelo;
    }

    public function setArquitectura($arquitectura) {
        $this->arquitectura = $arquitectura;
    }

    public function setCore($core) {
        $this->core = $core;
    }

    public function setProcesador($procesador) {
        $this->procesador = $procesador;
    }

    public function setMhz($mhz) {
        $this->mhz = $mhz;
    }

    public function setMemoria($memoria) {
        $this->memoria = $memoria;
    }

    public function setDisco($disco) {
        $this->disco = $disco;
    }

    public function setRaid($raid) {
        $this->raid = $raid;
    }

    public function setRed($red) {
        $this->red = $red;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("har_hardware", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function crear() {
        if ($this->inventario && $this->tipo) {
            $values = "({$this->inventario}, '{$this->tipo}','{$this->sigla}', '{$this->nombre}', "
                    . "'{$this->dominio}', '{$this->swBase}', '{$this->ambiente}', '{$this->funcion}', "
                    . "{$this->sucursal}, '{$this->marca}', '{$this->modelo}', '{$this->arquitectura}', "
                    . "'{$this->core}', '{$this->procesador}', '{$this->mhz}', '{$this->memoria}', "
                    . "'{$this->disco}', '{$this->raid}', {$this->red}, '{$this->rti}', 1)";
            $creacion = SQLServer::instancia()->insertar("har_hardware", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        return 0;
    }

    public function modificar() {
        if ($this->inventario && $this->tipo) {
            $campos = "inventario={$this->inventario}, tipo='{$this->tipo}', sigla='{$this->sigla}', nombre='{$this->nombre}', "
                    . "dominio='{$this->dominio}', softwareBase='{$this->swBase}', ambiente='{$this->ambiente}', funcion='{$this->funcion}', "
                    . "sucursal={$this->sucursal}, arquitectura='{$this->arquitectura}', core='{$this->core}', procesador='{$this->procesador}', "
                    . "mhz='{$this->mhz}', memoria='{$this->memoria}', disco='{$this->disco}', raid='{$this->raid}', red={$this->red}, "
                    . "rti='{$this->rti}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("har_hardware", $campos, $condicion);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM har_hardware WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->tipo = $fila['tipo'];
                $this->sigla = $fila['sigla'];
                $this->nombre = $fila['nombre'];
                $this->dominio = $fila['dominio'];
                $this->swBase = $fila['softwareBase'];
                $this->ambiente = $fila['ambiente'];
                $this->funcion = $fila['funcion'];
                $this->arquitectura = $fila['arquitectura'];
                $this->core = $fila['core'];
                $this->procesador = $fila['procesador'];
                $this->mhz = $fila['mhz'];
                $this->memoria = $fila['memoria'];
                $this->disco = $fila['disco'];
                $this->raid = $fila['raid'];
                $this->red = $fila['red'];
                $this->rti = $fila['rti'];
                $this->estado = $fila['estado'];
                $obtenerInventario = $this->obtenerInventario($fila['inventario']);
                $obtenerSucursal = $this->obtenerSucursal($fila['sucursal']);
                return (($obtenerInventario == 2) && ($obtenerSucursal == 2)) ? 2 : 1;
            }
            $this->mensaje = "No se obtuvo la información de la gerencia";
            return 1;
        }
        return 0;
    }

    private function obtenerInventario($idInventario) {
        $inventario = new Inventario($idInventario);
        if ($inventario->obtener() == 2) {
            $this->inventario = $inventario;
            return 2;
        }
        $this->mensaje = $inventario->getMensaje();
        return 1;
    }

    private function obtenerSucursal($idSucursal) {
        $sucursal = new Sucursal($idSucursal);
        if ($sucursal->obtener() == 2) {
            $this->sucursal = $sucursal;
            return 2;
        }
        $this->mensaje = $sucursal->getMensaje();
        return 1;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("har_hardware", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
