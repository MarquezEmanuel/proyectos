<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3">
            <div class="col text-left">
                <h4><i class="fas fa-user-friends"></i> BUSCAR PERFIL</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionCentral" class="mt-3 mb-4">
            <form id="formBuscarPerfil" name="formBuscarPerfil" method="POST">
                 <input type="hidden" name="peticion" id="peticion">
                <div class="card mt-2">
                    <div class="card-header text-left">Formulario de búsqueda</div>
                    <div class="card-body">
                        <div class="form-row">
                            <label for="nombre" class="col-2 col-form-label text-left">Nombre:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       name="nombre" id="nombre" 
                                       title="Nombre del perfil: campo no obligatorio"
                                       placeholder="Nombre del permiso">
                            </div>
                            <label for="estado" class="col-2 col-form-label text-left">* Estado:</label>
                            <div class="col">
                                <select id="estado" name="estado" class="form-control mb-2" required>
                                    <option value="1">Activo</option>
                                    <option value="2">Inactivo</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-row mt-2">
                    <div class="col text-right">
                        <button type="submit" class="btn btn-success" name="formBuscarPerfil"><i class="fas fa-search"></i>  BUSCAR</button>
                        <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                    </div>
                </div>
            </form>
        </div>
        <br>
        <div id="seccionInferior" class="mt-4 mb-3"></div>
    </div>
</div>