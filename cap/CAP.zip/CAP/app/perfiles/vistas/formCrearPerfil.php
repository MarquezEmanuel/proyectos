<?php
require_once './app/principal/modelos/Constantes.php';
require_once './app/principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorPermiso();

$permisos = $controlador->listar();
$formulario = "";
if (gettype($permisos) == "resource") {
    $filas = "";
    while ($permiso = sqlsrv_fetch_array($permisos, SQLSRV_FETCH_ASSOC)) {
        $filas .= "<tr>
                        <td></td>
                        <td>{$permiso['titulo']}</td>
                        <td>{$permiso['nombreNivel']}</td>
                        <td>{$permiso['nombrePadre']}</td>
                    </tr>";
    }
    $formulario = '
        <div class="form-row">
            <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
            <div class="col">
                <input type="text" class="form-control mb-2" 
                       name="nombre" id="nombre" 
                       placeholder="Nombre del perfil">
            </div>
        </div>
        <div class="form-row">
            <label for="nombre" class="col-sm-2 col-form-label">* Permisos:</label>
            <div class="col">
                <table class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Nombre</th>
                            <th>Nivel</th>
                            <th>Padre</th>
                        </tr>
                    </thead>
                    <tbody>' . $filas . ' </tbody>
                </table>
            </div>
        </div>';
} else {
    $formulario='sds';
}
?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-user-friends"></i> CREAR PERFIL</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearPerfil" name="formCrearPerfil" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
                <div class="card-body"><?= $formulario; ?></div>
            </div>
        </form>
    </div>
</div>
