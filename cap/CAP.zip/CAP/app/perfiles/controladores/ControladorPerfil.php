<?php

/**
 * Description of ControladorPerfil
 *
 * @author Emanuel
 */
class ControladorPerfil {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $perfiles = new Perfiles();
        $resultado = $perfiles->buscar($nombre, $estado);
        $this->mensaje = $perfiles->getMensaje();
        return $resultado;
    }

    public function crear($nombre, $descripcion, $permisos) {
        
    }

    public function cambiarEstado($id, $estado) {
        
    }

    public function modificar($id, $nombre, $descripcion, $permisos) {
        
    }

    public function listarUltimosCreados() {
        $perfiles = new Perfiles();
        $resultado = $perfiles->listarUltimosCreados();
        $this->mensaje = $perfiles->getMensaje();
        return $resultado;
    }

    public function seleccionar($nombre, $estado) {
        $perfiles = new Perfiles();
        $resultado = $perfiles->seleccionar($nombre, $estado);
        $this->mensaje = $perfiles->getMensaje();
        return $resultado;
    }

}
