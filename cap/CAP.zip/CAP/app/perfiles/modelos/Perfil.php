<?php

/**
 * Description of Perfil
 *
 * @author 07489
 */
class Perfil {

    private $id;
    private $nombre;
    private $descripcion;
    private $mensaje;
    private $permisos;

    public function __construct($id = NULL, $nombre = NULL, $descripcion = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setDescripcion($descripcion);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function getPermisos() {
        return $this->permisos;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function setPermisos($permisos) {
        $this->permisos = $permisos;
    }

    public function borrar() {
        
    }

    public function crear() {
        
    }

    public function modificar() {
        
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM seg_perfiles WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->nombre = $fila['nombre'];
                $this->descripcion = $fila['descripcion'];
                $this->permisos = $this->obtenerPermisos();
                return 2;
            }
            $this->mensaje = "No se obtuvo la información del perfil";
            return 1;
        }
        return 0;
    }

    private function obtenerPermisos() {
        $consulta = "SELECT id, titulo FROM [dbo].[seg_permisos] PER INNER JOIN [dbo].[seg_perfiles_permisos] REL ON REL.permiso = PER.id AND REL.perfil = {$this->id} WHERE PER.nivel = 1";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $arregloMenu = array();
        while ($menu = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
            $consultaSM = "SELECT * FROM [dbo].[seg_permisos] PER INNER JOIN [dbo].[seg_perfiles_permisos] REL ON REL.permiso = PER.id AND REL.perfil = {$this->id} WHERE PER.nivel = 2 AND padre = {$menu['id']}";
            $resultadoSM = SQLServer::instancia()->seleccionar($consultaSM);
            $arregloSubmenu = array();
            if (gettype($resultadoSM) != 'resource') {
                continue;
            }
            while ($submenu = sqlsrv_fetch_array($resultadoSM, SQLSRV_FETCH_ASSOC)) {
                $arregloSubmenu[] = array($submenu['id'], $submenu['titulo'], $submenu['link']);
            }
            $arregloMenu[] = array($menu['id'], $menu['titulo'], $arregloSubmenu);
        }
        return $arregloMenu;
    }

    public function obtenerVistas() {
        $consulta = "SELECT PER.link FROM [dbo].[seg_permisos] PER INNER JOIN [dbo].[seg_perfiles_permisos] REL ON REL.permiso = PER.id AND REL.perfil = {$this->id} WHERE PER.nivel = 2";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $vistas = array();
        while ($vista = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_NUMERIC)) {
            $vistas[] = $vista;
        }
        return $vistas;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("seg_perfiles", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
