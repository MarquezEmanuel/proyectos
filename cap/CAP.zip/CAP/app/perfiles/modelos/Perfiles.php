<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Perfiles {
    
    private $mensaje;

    public function __construct() {
        ;
    }
    
    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($campo, $valor) {
        
    }

    public function listar() {
        
    }
    

}
