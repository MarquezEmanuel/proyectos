/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    /* INICIALIZA EL DATATABLE */

    $('#tbDepartamentos').dataTable({
        lengthChange: false
    });
    
    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editarDepartamento').click(function () {
        var idDepartamento = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./app/gerencias/vistas/formModificarDepartamento.php",
            data: "idDepartamento=" + idDepartamento,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });
    
    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.datosDepartamento').click(function () {
        $("#modalNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalDatosDepartamento").modal({});
    });
    
});

