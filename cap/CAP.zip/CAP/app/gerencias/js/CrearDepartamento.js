$(document).ready(function () {

    $('#formCrearDepartamento').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: "./app/gerencias/vistas/procesaCrearDepartamento.php",
            data: $("#formCrearDepartamento").serialize(),
            success: function (data) {
                $('#seccionResultado').html(data[0]['resultado']);
                if (data[0]['exito'] === true) {
                    $("#formCrearDepartamento")[0].reset();
                }
            },
            error: function (data) {
                console.log(data);
                var div = '<div class="alert alert-danger text-center" role="alert">No se procesó la petición por un error interno</div>';
                $("#seccionResultado").html(div);
            }
        });
    });

});