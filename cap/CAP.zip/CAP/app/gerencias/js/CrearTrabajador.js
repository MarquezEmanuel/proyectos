$(document).ready(function () {

    $('#formCrearTrabajador').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: "./procesaCrearTrabajador.php",
            data: $("#formCrearTrabajador").serialize(),
            success: function (data) {
                $('#seccionResultado').html(data[0]['resultado']);
                if (data[0]['exito'] === true) {
                    $("#formCrearTrabajador")[0].reset();
                }
            },
            error: function (data) {
                console.log(data);
                var div = '<div class="alert alert-danger text-center" role="alert">No se procesó la petición por un error interno</div>';
                $("#seccionResultado").html(div);
            }
        });
    });

    $('select#departamento').select2({
        placeholder: 'Seleccione una opcion',
        theme: "bootstrap",
        minimumInputLength: 3,
        ajax: {
            url: "./procesaElegirDepartamento.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term, estado: "Activo"};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

});