<?php

/**
 * Description of Gerencias
 *
 * @author Emanuel
 */
class Gerencias {

    private static $mensaje;

    public static function getMensaje() {
        return self::$mensaje;
    }

    public static function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM vwger_gerencia WHERE gerNombre LIKE '%$nombre%' AND gerEstado = '{$estado}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public static function listar($jefe = TRUE, $estado = 'Activo') {
        $condicion = ($jefe) ? "jefe <> '' AND" : "jefe = '' AND";
        $consulta = "SELECT * FROM vwger_gerencia WHERE {$condicion} estado = '{$estado}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public static function seleccionar($nombre) {
        $consulta = "SELECT * FROM vwger_gerencia WHERE nombre LIKE ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array('%' . $nombre . '%'));
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public static function listarUltimasCreadas() {
        $consulta = "SELECT TOP(10) * FROM vwger_gerencia WHERE gerEstado = 'Activo' ORDER BY gerId DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
