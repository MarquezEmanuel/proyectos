<?php

/**
 * Description of Gerencias
 *
 * @author Emanuel
 */
class Gerencias {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM reporteGerencias WHERE nombreGerencia LIKE '%$nombre%' AND nomEstadoGerencia = '{$estado}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listar($jefe = TRUE, $estado = 1) {
        $condicion = ($jefe) ? "jefe <> '' AND" : "jefe = '' AND";
        $consulta = "SELECT * FROM ger_gerencias WHERE {$condicion} estado = {$estado}";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarPorEstado($estado) {
        $consulta = "SELECT * FROM ger_gerencias WHERE estado = {$estado}";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimasCreadas() {
        $consulta = "SELECT TOP(10) * FROM reporteGerencias WHERE codEstadoGerencia = 1 ORDER BY idGerencia DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
