<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Personas {

    public function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM reportePersonas WHERE nombrePersona LIKE '%{$nombre}%' AND estadoPersona = {$estado}";
        return SQLServer::instancia()->seleccionar($consulta);
    }

    public function listar() {
        
    }

    public function listarJefesSinAsociar() {
        $consulta = "SELECT idPersona, nombrePersona FROM [dbo].[reportePersonas] WHERE idDepto is null AND idGerencia is null AND estadoPersona = 1";
        return SQLServer::instancia()->seleccionar($consulta);
    }

}
