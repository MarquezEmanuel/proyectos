<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Personas {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM reportePersonas WHERE perNombre LIKE '%{$nombre}%' AND perEstado = '{$estado}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listar() {
        
    }

    public function listarJefesSinAsociar() {
        $consulta = "SELECT idPersona, nombrePersona FROM reportePersonas WHERE depId is null AND gerId is null AND perEstado = 'Activo'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimasCreadas() {
        $consulta = "SELECT * FROM reportePersonas WHERE perEstado = 'Activo' ORDER BY perId DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
