<?php

/**
 * Description of Gerencia
 *
 * @author Emanuel
 */
class Gerencia {

    private $id;
    private $nombre;
    private $jefe;
    private $estado;
    private $departamentos;
    private $mensaje;

    public function __construct($id = NULL, $nombre = NULL, $jefe = NULL, $estado = null) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setJefe($jefe);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getJefe() {
        return $this->jefe;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getDepartamentos() {
        return $this->departamentos;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setJefe($jefe) {
        $this->jefe = $jefe;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setDepartamentos($departamentos) {
        $this->departamentos = $departamentos;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("ger_gerencias", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function crear() {
        if ($this->nombre) {
            $values = "('{$this->nombre}','{$this->jefe}', 1)";
            $creacion = SQLServer::instancia()->insertar("ger_gerencias", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        return 0;
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->jefe) {
            $campos = "nombre = '{$this->nombre}', jefe = '{$this->jefe}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("ger_gerencias", $campos, $condicion);
            $this->mensaje = $this->titulo . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM ger_gerencias WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->nombre = $fila['nombre'];
                $this->estado = $fila['estado'];
                return $this->obtenerJefe($fila['jefe']);
            }
            $this->mensaje = "No se obtuvo la información de la gerencia";
            return 1;
        }
        return 0;
    }

    private function obtenerJefe($id) {
        $persona = new Persona($id);
        if ($persona->obtener() == 2) {
            $this->persona = $persona;
            return 2;
        }
        $this->mensaje = $persona->getMensaje();
        return 1;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("ger_gerencias", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
