<?php

class Departamentos {

    public function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM reporteDepartamentos WHERE nombreDepto LIKE '%{$nombre}%' AND estadoDepto = {$estado}";
        return SQLServer::instancia()->seleccionar($consulta);
    }

    public function listar($estado) {
        $consulta = "SELECT * FROM ger_departamentos WHERE estado = {$estado}";
        return SQLServer::instancia()->seleccionar($consulta);
    }

}
