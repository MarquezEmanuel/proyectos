<?php

class Departamentos {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM reporteDepartamentos WHERE depNombre LIKE '%{$nombre}%' AND depEstado = '{$estado}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listar($estado) {
        $consulta = "SELECT * FROM ger_departamentos WHERE estado = '{$estado}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }
    
    public function listarUltimosCreados() {
        $consulta = "SELECT TOP(10) * FROM reporteDepartamentos WHERE depEstado = 'Activo' ORDER BY depId DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
