<?php

class Departamentos {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM reporteDepartamentos WHERE nombreDepto LIKE '%{$nombre}%' AND estadoDepto = {$estado}";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listar($estado) {
        $consulta = "SELECT * FROM ger_departamentos WHERE estado = {$estado}";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
