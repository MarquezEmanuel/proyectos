<?php

/**
 * Description of Persona
 *
 * @author Emanuel
 */
class Persona {

    private $id;
    private $nombre;
    private $departamento;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $nombre = NULL, $departamento = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setDepartamento($departamento);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getDepartamento() {
        return $this->departamento;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setDepartamento($departamento) {
        $this->departamento = $departamento;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function crear() {
        if ($this->id && $this->nombre) {
            $values = "('{$this->id}','{$this->nombre}', {$this->departamento},1)";
            $creacion = SQLServer::instancia()->insertar("ger_personas", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        return 1;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM ger_personas WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->nombre = $fila['nombre'];
                $this->estado = $fila['estado'];
                $this->departamento = $this->obtenerDepartamento($fila['departamento']);
                return 2;
            }
            $this->mensaje = "No se obtuvo la información de la gerencia";
            return 1;
        }
        return 0;
    }

    private function obtenerDepartamento($id) {
        /* EL DEPARTAMENTO PARA LA PERSONA NO ES UN CAMPO OBLIGATORIO */
        if ($id) {
            $departamento = new Departamento($id);
            if ($departamento->obtener() == 2) {
                return $departamento;
            }
            $this->mensaje = "No se obtuvo la información del departamento";
        }
        return NULL;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("ger_personas", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
