<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$controlador = new ControladorDepartamento();
$resultado = $controlador->listar(1);
$opciones = $formulario = "";
if (gettype($resultado) == "resource") {
    $opciones = "<option value='NO'>No aplica</option>";
    while ($departamento = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
        $opciones .= "<option value='{$departamento['id']}'>{$departamento['nombre']}</option>";
    }
    $formulario = '
        <form id="formCrearTrabajador" name="formCrearTrabajador" method="POST">
            <div class="card mt-3">
                <div class="card-header text-left">Complete el formulario</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="legajo" class="col-sm-2 col-form-label text-left">* Legajo:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="legajo" id="legajo" 
                                   placeholder="Legajo del trabajador" required>
                        </div>
                        <label for="nombre" class="col-sm-2 col-form-label text-left">* Nombre:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="nombre" id="nombre" 
                                   placeholder="Nombre completo del trabajador" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="departamento" class="col-sm-2 col-form-label text-left">* Departamento:</label>
                        <div class="col">
                            <select id="departamento" name="departamento" class="form-control mb-2" required>' . $opciones . '</select>
                        </div>
                        <label class="col-sm-2 col-form-label text-left"></label>
                        <div class="col"></div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-4">
                <div class="col text-right">
                    <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
                    <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                </div>
            </div>
        </form>';
} else {
    if (!is_null($resultado)) {
        $mensaje = "No se encontraron departamentos activos para cargar el formulario";
        $formulario = "<div class='alert alert-warning text-center mt-2' role='alert'><strong>{$mensaje}</strong></div>";
    } else {
        $mensaje = "No se pudo realizar la consulta de departamentos activos para cargar el formulario";
        $formulario = "<div class='alert alert-danger text-center mt-2' role='alert'><strong>{$mensaje}</strong></div>";
    }
}
require_once '../../principal/vistas/header.php';
?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="far fa-id-badge"></i> CREAR TRABAJADOR</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <?= $formulario; ?>
    </div>
</div>
<script type="text/javascript" src="../js/CrearTrabajador.js"></script>



