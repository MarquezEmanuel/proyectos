<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$controlador = new ControladorGerencia();
$resultado = $controlador->listarPorEstado(1);
$opciones = $formulario = "";
if (gettype($resultado) == "resource") {
    while ($gerencia = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
        $opciones .= "<option value='{$gerencia['id']}'>{$gerencia['nombre']}</option>";
    }
    $formulario = '
        <form id="formCrearDepartamento" name="formCrearDepartamento" method="POST">
            <div class="card text-center mt-3">
                <div class="card-header text-left">Complete el formulario</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="nombre" class="col-sm-2 col-form-label text-left">* Nombre:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="nombre" id="nombre" 
                                   placeholder="Nombre del departamento">
                        </div>
                        <label for="gerencia" class="col-sm-2 col-form-label text-left">* Gerencia:</label>
                        <div class="col">
                            <select id="gerencia" name="gerencia" class="form-control mb-2" >' . $opciones . '</select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-2">
                <div class="col text-right">
                    <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
                    <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                </div>
            </div>
        </form>';
} else {
    if (!is_null($resultado)) {
        $mensaje = "No se encontraron gerencias activas para cargar el formulario";
        $formulario = "<div class='alert alert-warning text-center' role='alert'><strong>{$mensaje}</strong></div>";
    } else {
        $mensaje = "No se pudo realizar la consulta de gerencias activas para cargar el formulario";
        $formulario = "<div class='alert alert-danger text-center' role='alert'><strong>{$mensaje}</strong></div>";
    }
}
require_once '../../principal/vistas/header.php';

?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-building"></i> CREAR DEPARTAMENTO</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <?= $formulario; ?>
    </div>
</div>
<script type="text/javascript" src="../js/CrearDepartamento.js"></script>