<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3">
            <div class="col text-left">
                <h4><i class="far fa-id-badge"></i> BUSCAR TRABAJADOR</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"> <i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionCentral" class="mt-3 mb-4">
            <form method="POST" name="formBuscarTrabajador" id="formBuscarTrabajador">
                <input type="hidden" name="buscar" value="true">
                <div class="card  border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                    <div class="card-body">
                        <div class="form-row">
                            <label for="nombre" class="col-2 col-form-label text-left">Nombre:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       name="nombre" id="nombre" 
                                       title="Nombre del trabajador: campo no obligatorio"
                                       placeholder="Nombre del trabajador">
                            </div>
                            <label for="estado" class="col-2 col-form-label text-left">* Estado:</label>
                            <div class="col">
                                <select id="estado" name="estado" class="form-control mb-2" required>
                                    <option value="Activo">Activo</option>
                                    <option value="Inactivo">Inactivo</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-row mt-2">
                    <div class="col text-right">
                        <button type="submit" class="btn btn-success" name="btnBuscarTrabajador"><i class="fas fa-search"></i>  BUSCAR</button>
                        <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                    </div>
                </div>
            </form>
        </div>
        <div id="seccionInferior" class="mt-4 mb-3">
            <?php require_once './procesaBuscarTrabajador.php'; ?>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/BuscarTrabajador.js"></script>