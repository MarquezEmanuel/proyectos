<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

if (isset($_POST['idGerencia'])) {
    $gerencia = new Gerencia($_POST['idGerencia']);
    $controlador = new ControladorPersona();
    $jefes = $controlador->listarJefesSinAsociar();
    $resultado = $gerencia->obtener();
    if (gettype($jefes) == "resource" && $resultado == 2) {
        while ($jefe = sqlsrv_fetch_array($jefes, SQLSRV_FETCH_ASSOC)) {
            $selected = ($jefe['idPersona'] == $gerencia->getJefe()->getId()) ? "selected" : "";
            $opciones .= "<option value='{$jefe['idPersona']}' {$selected}>{$jefe['idPersona']} - {$jefe['nombrePersona']}</option>";
        }
    } else {
        $formulario = ControladorHTML::getAlertaOperacion(1, "No se obtuvo la información para cargar el formulario");
        $botones = ControladorHTML::getBotonBusqueda("formBuscarGerencia.php");
    }
} else {
    $formulario = ControladorHTML::getAlertaOperacion(0, "No se obtuvo la información desde el formulario");
    $botones = ControladorHTML::getBotonBusqueda("formBuscarGerencia.php");
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-sitemap"></i> MODIFICAR GERENCIA</h4>
        </div>
        <div class="col text-right">
            <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarGerencia" name="formModificarGerencia" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $formulario; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $botones; ?>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="../js/ModificarGerencia.js"></script>