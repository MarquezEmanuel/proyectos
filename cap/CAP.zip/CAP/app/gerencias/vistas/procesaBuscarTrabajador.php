<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$controlador = new ControladorPersona();
if (isset($_POST['btnBuscarTrabajador'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " . $estado : "TODAS, " . $estado;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $trabajadores = $controlador->buscar($nombre, $estado);
    $_SESSION['BUSTRA'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['BUSTRA'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSTRA'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $trabajadores = $controlador->buscar($nombre, $estado);
        $_SESSION['BUSTRA'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $trabajadores = $controlador->listarUltimasCreadas();
        $filtro = "Últimos trabajadores creados y en estado activo";
        $_SESSION['BUSTRA'] = NULL;
    }
}

if (gettype($trabajadores) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($trabajador = sqlsrv_fetch_array($trabajadores, SQLSRV_FETCH_ASSOC)) {
        if ($trabajador['codEstadoPersona'] == 1) {
            $operaciones = "
                <button class='btn btn-outline-warning editarTrabajador' 
                        name='{$trabajador['idPersona']}' title='Editar'>
                    <i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger bajaTrabajador' 
                        name='{$trabajador['idPersona']}' title='Dar de baja'>
                    <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-success altaTrabajador' 
                    name='{$trabajador['idPersona']}' title='Dar de alta'>
                        <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
                <tr>
                    <td>{$trabajador['idPersona']}</td>
                    <td>{$trabajador['nombrePersona']}</td>
                    <td>{$trabajador['nombreDepto']}</td>
                    <td>{$trabajador['nombreGerencia']}</td>
                    <td class='text-center'>
                        <div class='btn-group btn-group-sm'>{$operaciones}</div>
                    </td>
                </tr>";
    }
    $cuerpo = '
            <div class="card mt-4">
                <div class="card-header text-left"><i class="fas fa-table"></i> Resultado de búsqueda</div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="tbTrabajadores" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Legajo</th>
                                    <th>Nombre</th>
                                    <th>Departamento</th>
                                    <th>Gerencia</th>
                                    <th>Operaciones</th>
                                </tr>
                            </thead>
                            <tbody>' . $filas . '</tbody>
                        </table>
                    </div>
                </div>
            </div>';
} else {
    if ($trabajadores == 1) {
        $cuerpo = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>{$controlador->getMensaje()} para el filtro ingresado</strong>
            </div>";
    } else {
        $cuerpo = "
            <div class='alert alert-danger text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
}

$formulario = '
    <div class="card border-azul-clasico">
        <div class="card-header bg-azul-clasico text-white"><i class="fas fa-table"></i> ' . $filtro . '</div>
        <div class="card-body">' . $cuerpo . '</div>
    </div>';

echo $formulario;
