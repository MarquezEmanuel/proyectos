<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$resultado = "";
if (isset($_POST['buscar'])) {
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $filtro = ($nombre) ? $nombre . ", " : "";
    $filtro .= ($estado == 1) ? "Activo" : "Inactivo";
    $controlador = new ControladorDepartamento();
    $deparamentos = $controlador->buscar($nombre, $estado);
    if (gettype($deparamentos) == "resource") {
        /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
        $filas = "";
        while ($deparamento = sqlsrv_fetch_array($deparamentos, SQLSRV_FETCH_ASSOC)) {
            $filas .= "
                <tr>
                    <td>{$deparamento['nombreDepto']}</td>
                    <td>{$deparamento['nombreGerencia']}</td>
                    <td>{$deparamento['jefeGerencia']}</td>
                    <td></td>
                </tr>";
        }
        $resultado = '
            <div class="card mt-4">
                <div class="card-header text-left"><i class="fas fa-table"></i> Resultado de búsqueda: ' . $filtro . '</div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="tbDepartamentos" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Gerencia</th>
                                    <th>Gerente</th>
                                    <th>Operaciones</th>
                                </tr>
                            </thead>
                            <tbody>' . $filas . '</tbody>
                        </table>
                    </div>
                </div>
            </div>';
    } else {
        if (!is_null($deparamentos)) {
            $mensaje = "No se encontraron resultados: $filtro";
            $resultado = "<div class='alert alert-warning text-center' role='alert'><strong>{$mensaje}</strong></div>";
        } else {
            $mensaje = "No se pudo realizar la consulta. Por favor comunique al administrador";
            $resultado = "<div class='alert alert-danger text-center' role='alert'><strong>{$mensaje}</strong></div>";
        }
    }
} else {
    $mensaje = "No se recibió la información desde el formulario. Por favor comunique al administrador";
    $resultado = "<div class='alert alert-danger text-center' role='alert'><strong>{$mensaje}</strong></div>";
}

echo $resultado;
