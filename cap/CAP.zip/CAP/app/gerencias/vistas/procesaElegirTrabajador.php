<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$arreglo = array();
if (isset($_POST['nombre']) && isset($_POST['estado'])) {
    $controlador = new ControladorPersona();
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $trabajadores = $controlador->buscar($nombre, $estado);
    if (gettype($trabajadores) == "resource") {
        while ($trabajador = sqlsrv_fetch_array($trabajadores, SQLSRV_FETCH_ASSOC)) {
            $arreglo[] = array('id' => $trabajador["perId"], 'text' => $trabajador["perNombre"]);
        }
    } else {
        $texto = ($trabajadores == 1) ? "Sin resultados" : "Error";
        $arreglo[] = array('id' => "NO", 'text' => $texto);
    }
} else {
    $arreglo[] = array('id' => "NO", 'text' => "Sin parametros");
}

echo json_encode($arreglo);