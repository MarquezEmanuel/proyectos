<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();
$controlador = new ControladorPersona();
$jefes = $controlador->listarJefesSinAsociar();
$opciones = "";
if (gettype($jefes) == "resource") {
    while ($jefe = sqlsrv_fetch_array($jefes, SQLSRV_FETCH_ASSOC)) {
        $opciones .= "<option value='{$jefe['idPersona']}'>{$jefe['idPersona']} - {$jefe['nombrePersona']}</option>";
    }
}

require_once '../../principal/vistas/header.php';

?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-sitemap"></i> CREAR GERENCIA</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearGerencia" name="formCrearGerencia" method="POST">
            <div class="card mt-3">
                <div class="card-header text-left">Complete el formulario</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="nombre" class="col-sm-2 col-form-label text-left">* Nombre:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="nombre" id="nombre" 
                                   placeholder="Nombre de la gerencia">
                        </div>
                        <label for="jefe" class="col-sm-2 col-form-label text-left">* Jefe:</label>
                        <div class="col">
                            <select id="jefe" name="jefe" class="form-control mb-2" >
                                <option value="NO">No asociar</option>
                                <?= $opciones; ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
                    <a href="gerencias_buscarGerencia">
                        <button type="button" class="btn btn-outline-info">
                            <i class="fas fa-search"></i> BUSCAR
                        </button>
                    </a>
                    <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="./app/gerencias/js/CrearGerencia.js"></script>