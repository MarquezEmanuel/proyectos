<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$controlador = new ControladorGerencia();

if (isset($_POST['btnBuscarGerencia'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " . $estado : "TODAS, " . $estado;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $gerencias = $controlador->buscar($nombre, $estado);
    $_SESSION['BUSGER'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['BUSGER'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSGER'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $gerencias = $controlador->buscar($nombre, $estado);
        $_SESSION['BUSGER'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $gerencias = $controlador->listarUltimasCreadas();
        $filtro = "Ultimas gerencias creadas y en estado activo";
        $_SESSION['BUSGER'] = NULL;
    }
}

if (gettype($gerencias) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($gerencia = sqlsrv_fetch_array($gerencias, SQLSRV_FETCH_ASSOC)) {
        if ($gerencia['codEstadoGerencia'] == 1) {
            $operaciones = "
                <button class='btn btn-outline-warning editarGerencia' 
                        name='{$gerencia['idGerencia']}' title='Editar'>
                    <i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger bajaGerencia' 
                        name='{$gerencia['idGerencia']}' title='Dar de baja'>
                    <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-success altaGerencia' 
                    name='{$gerencia['idGerencia']}' title='Dar de alta'>
                        <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td>{$gerencia['nombreGerencia']}</td>
                <td>{$gerencia['legajoJefe']}</td>
                <td>{$gerencia['nombreJefe']}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>{$operaciones}</div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbGerencias" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Legajo</th>
                        <th>Nombre</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    if ($gerencias == 1) {
        $cuerpo = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>{$controlador->getMensaje()} para el filtro ingresado</strong>
            </div>";
    } else {
        $cuerpo = "
            <div class='alert alert-danger text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
}

$formulario = '
    <div class="card border-azul-clasico">
        <div class="card-header bg-azul-clasico text-white"><i class="fas fa-table"></i> ' . $filtro . '</div>
        <div class="card-body">' . $cuerpo . '</div>
    </div>';

echo $formulario;
