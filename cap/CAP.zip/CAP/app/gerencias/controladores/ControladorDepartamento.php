<?php

/**
 * Description of ControladorDepartamento
 *
 * @author Emanuel
 */
class ControladorDepartamento {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $departamentos = new Departamentos();
        $resultado = $departamentos->buscar($nombre, $estado);
        $this->mensaje = $departamentos->getMensaje();
        return $resultado;
    }

    public function cambiarEstado($id, $estado) {
        $departamento = new Departamento($id, NULL, NULL, $estado);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $departamento->cambiarEstado();
            $this->mensaje = $departamento->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function crear($nombre, $gerencia) {
        $departamento = new Departamento(NULL, $nombre, $gerencia);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $creacion = $departamento->crear();
            $this->mensaje = $departamento->getMensaje();
            $confirmar = ($creacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 0;
    }

    public function listar($estado) {
        $departamentos = new Departamentos();
        $resultado = $departamentos->listar($estado);
        $this->mensaje = $departamentos->getMensaje();
        return $resultado;
    }
    
    public function listarUltimosCreados() {
        $departamentos = new Departamentos();
        $resultado = $departamentos->listarUltimosCreados();
        $this->mensaje = $departamentos->getMensaje();
        return $resultado;
    }

    public function modificar($id, $nombre, $gerencia) {
        $departamento = new Departamento($id, $nombre, $gerencia);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $departamento->modificar();
            $this->mensaje = $departamento->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

}
