<?php

/**
 * Description of ControladorDepartamento
 *
 * @author Emanuel
 */
class ControladorDepartamento {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $estado) {
        $departamentos = new Departamentos();
        return $departamentos->buscar($nombre, $estado);
    }

    public function crear($nombre, $gerencia) {
        $departamento = new Departamento(NULL, $nombre, $gerencia);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $departamento->crear();
            $this->mensaje = $departamento->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 0;
    }

    public function listar($estado) {
        $departamentos = new Departamentos();
        return $departamentos->listar($estado);
    }

}
