<?php

/**
 * Description of ControladorPersona
 *
 * @author Emanuel
 */
class ControladorPersona {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $estado) {
        $personas = new Personas();
        return $personas->buscar($nombre, $estado);
    }

    public function crear($legajo, $nombre, $departamento) {
        $persona = new Persona($legajo, $nombre, $departamento);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $persona->crear();
            $this->mensaje = $persona->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 0;
    }

    public function listarJefesSinAsociar() {
        $personas = new Personas();
        return $personas->listarJefesSinAsociar();
    }

}
