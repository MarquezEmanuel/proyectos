<?php

/**
 * Description of ControladorPersona
 *
 * @author Emanuel
 */
class ControladorPersona {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $personas = new Personas();
        $resultado = $personas->buscar($nombre, $estado);
        $this->mensaje = $personas->getMensaje();
        return $resultado;
    }
    
    public function cambiarEstado($id, $estado) {
        $persona = new Persona($id, NULL, NULL, $estado);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $persona->cambiarEstado();
            $this->mensaje = $persona->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function crear($legajo, $nombre, $departamento) {
        $persona = new Persona($legajo, $nombre, $departamento);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $persona->crear();
            $this->mensaje = $persona->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 0;
    }

    public function listarJefesSinAsociar() {
        $personas = new Personas();
        $resultado = $personas->listarJefesSinAsociar();
        $this->mensaje = $personas->getMensaje();
        return $resultado;
    }
    
    public function modificar($id, $nombre, $departamento) {
        $persona = new Persona($id, $nombre, $departamento);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $persona->modificar();
            $this->mensaje = $persona->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

}
