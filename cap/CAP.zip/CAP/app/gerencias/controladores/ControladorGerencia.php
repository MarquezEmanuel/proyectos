<?php

/**
 * Description of ControladorGerencia
 *
 * @author Emanuel
 */
class ControladorGerencia {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $estado) {
        $gerencias = new Gerencias();
        return $gerencias->buscar($nombre, $estado);
    }

    public function cambiarEstado($id, $nombre) {
        $gerencia = new Gerencia($id, $nombre);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $modificacion = $gerencia->cambiarEstado();
            $this->mensaje = $gerencia->getMensaje();
            if ($modificacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function crear($nombre, $jefe) {
        $gerencia = new Gerencia(NULL, $nombre, $jefe);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $gerencia->crear();
            $this->mensaje = $gerencia->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 0;
    }

    public function listar($jefe, $estado) {
        $gerencias = new Gerencias();
        return $gerencias->listar($jefe, $estado);
    }

    public function listarPorEstado($estado) {
        $gerencias = new Gerencias();
        return $gerencias->listarPorEstado($estado);
    }

    public function listarUltimasCreadas() {
        $gerencias = new Gerencias();
        $resultado = $gerencias->listarUltimasCreadas();
        $this->mensaje = $gerencias->getMensaje();
        return $resultado;
    }

}
