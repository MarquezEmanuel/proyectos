<?php

/**
 * Description of ControladorGerencia
 *
 * @author Emanuel
 */
class ControladorGerencia {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($nombre, $estado) {
        $gerencias = new Gerencias();
        $resultado = $gerencias->buscar($nombre, $estado);
        $this->mensaje = $gerencias->getMensaje();
        return $resultado;
    }

    public function cambiarEstado($id, $estado) {
        $gerencia = new Gerencia($id, NULL, NULL, $estado);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $gerencia->cambiarEstado();
            $this->mensaje = $gerencia->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

    public function crear($nombre, $jefe) {
        $gerencia = new Gerencia(NULL, $nombre, $jefe);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $creacion = $gerencia->crear();
            $this->mensaje = $gerencia->getMensaje();
            $confirmar = ($creacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 0;
    }

    public function listar($jefe, $estado) {
        $gerencias = new Gerencias();
        return $gerencias->listar($jefe, $estado);
    }

    public function listarPorEstado($estado) {
        $gerencias = new Gerencias();
        return $gerencias->listarPorEstado($estado);
    }

    public function listarUltimasCreadas() {
        $gerencias = new Gerencias();
        $resultado = $gerencias->listarUltimasCreadas();
        $this->mensaje = $gerencias->getMensaje();
        return $resultado;
    }

    public function modificar($id, $nombre, $jefe) {
        $gerencia = new Gerencia($id, $nombre, $jefe);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modificacion = $gerencia->modificar();
            $this->mensaje = $gerencia->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 1;
    }

}
