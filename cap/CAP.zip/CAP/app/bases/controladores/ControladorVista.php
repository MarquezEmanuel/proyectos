<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ControladorVista {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $descripcion) {
        $vistas = new Vistas();
        $resultado = $vistas->buscar($nombre, $descripcion);
        $this->mensaje = $vistas->getMensaje();
        return $resultado;
    }

    public function modificar($id, $consulta, $descripcion) {
        $vista = new Vista($id, $consulta, $descripcion);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $modificacion = $vista->modificar();
            $this->mensaje = $vista->getMensaje();
            if ($modificacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar con la vista";
        return 1;
    }
   

}
