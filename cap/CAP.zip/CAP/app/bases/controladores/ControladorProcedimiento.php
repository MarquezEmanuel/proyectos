<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ControladorProcedimiento {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function modificar($id, $descripcion) {
        $tabla = new Procedimiento($id, $descripcion);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $modificacion = $tabla->modificar();
            $this->mensaje = $tabla->getMensaje();
            if ($modificacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar con el procedimiento";
        return 1;
    }

    public function buscar($nombre, $rutina) {
        $procedimientos = new Procedimientos();
        $resultado = $procedimientos->buscar($nombre, $rutina);
        $this->mensaje = $procedimientos->getMensaje();
        return $resultado;
    }

    public function listarPorBase($idBase) {
        $procedimientos = new Procedimientos();
        $resultado = $procedimientos->listarPorBase($idBase);
        $this->mensaje = $procedimientos->getMensaje();
        return $resultado;
    }

}
