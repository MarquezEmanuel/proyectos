<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ControladorColumna {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($base, $tabla, $nombre, $descripcion) {
        $resultado = Columnas::buscar($base, $tabla, $nombre, $descripcion);
        $this->mensaje = Columnas::getMensaje();
        return $resultado;
    }

    public function listarPorTabla($idTabla) {
        $resultado = Columnas::listarPorTabla($idTabla);
        $this->mensaje = Columnas::getMensaje();
        return $resultado;
    }

    public function listarUltimosActualizados() {
        $resultado = Columnas::listarUltimosActualizados();
        $this->mensaje = Columnas::getMensaje();
        return $resultado;
    }

}
