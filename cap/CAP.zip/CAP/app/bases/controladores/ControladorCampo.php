<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ControladorCampo {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($tabla, $nombre) {
        $campos = new Campos();
        $resultado = $campos->buscar($tabla, $nombre);
        $this->mensaje = $campos->getMensaje();
        return $resultado;
    }

    public function listarPorTabla($idTabla) {
        $campos = new Campos();
        $resultado = $campos->listarPorTabla($idTabla);
        $this->mensaje = $campos->getMensaje();
        return $resultado;
    }

    public function listarUltimosActualizados() {
        $campos = new Campos();
        $resultado = $campos->listarUltimosActualizados();
        $this->mensaje = $campos->getMensaje();
        return $resultado;
    }

}
