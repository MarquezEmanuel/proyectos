<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$controlador = new ControladorCampo();

if (isset($_POST['btnBuscarCampo'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $tabla = isset($_POST['tabla']) ? $_POST['tabla'] : '';
    $nombre = $_POST['nombre'];
    $datos = ($tabla) ? "ESPECIFICADA, '" . $nombre . "'" : "TODAS, '" . $nombre . "'";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $campos = $controlador->buscar($tabla, $nombre);
    $_SESSION['BUSCAM'] = array($tabla, $nombre, $datos);
} else {
    if (isset($_SESSION['BUSCAM'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSCAM'];
        $tabla = $parametros[0];
        $nombre = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $campos = $controlador->buscar($tabla, $nombre);
        $_SESSION['BUSCAM'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $campos = $controlador->listarUltimosActualizados();
        $filtro = "Ultimos campos actualizados";
        $_SESSION['BUSCAM'] = NULL;
    }
}

if (gettype($campos) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($campo = sqlsrv_fetch_array($campos, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr>
                <td>" . utf8_encode($campo['nombreBase']) . "</td>
                <td>" . utf8_encode($campo['nombreTabla']) . "</td>
                <td>" . utf8_encode($campo['nombreCampo']) . "</td>
                <td>{$campo['nulos']}</td>
                <td>{$campo['tipo']}</td>
                <td>{$campo['maximo']}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-primary datos' 
                                name='{$campo['idCampo']}' title='Ver información básica'><i class='fas fa-info-circle'></i>
                        </button>
                        <button class='btn btn-outline-warning editar' 
                            name='{$campo['idCampo']}' title='Editar'><i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbCampos" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Base de datos</th>
                        <th>Tabla</th>
                        <th>Nombre</th>
                        <th>Nulos</th>
                        <th>Tipo</th>
                        <th>Largo</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($campos == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($campos, $mensaje);
}

$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
