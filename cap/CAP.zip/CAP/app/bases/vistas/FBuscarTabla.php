<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="fas fa-database"></i> BUSCAR TABLA</h4>
                </div>
            </div>
            <div id="seccionCentral" class="mt-3 mb-4">
                <form method="POST" name="formBuscarTabla" id="formBuscarTabla">
                    <input type="hidden" name="peticion" id="peticion">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="base" class="col-sm-2 col-form-label text-left">Base de datos:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="base" id="base" maxlength="20"
                                           title="Nombre de la base de datos: campo no obligatorio"
                                           placeholder="Nombre de la base de datos">
                                </div>
                                <label for="nombre" class="col-sm-2 col-form-label text-left">Nombre:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombre" id="nombre" 
                                           minlength="1" maxlength="30" pattern="[A-Za-z0-9_]{1,30}"
                                           title="Nombre de la tabla: campo obligatorio"
                                           placeholder="Nombre de la tabla" required>
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="descripcion" class="col-sm-2 col-form-label text-left">Descripción:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="descripcion" id="descripcion" maxlength="20"
                                           title="Descripción de la tabla: campo no obligatorio"
                                           placeholder="Descripción">
                                </div>
                                <label class="col-sm-2 col-form-label text-left"></label>
                                <div class="col"></div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success" name="btnBuscarTabla">
                                <i class="fas fa-search"></i>  BUSCAR
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div id="seccionInferior" class="mt-4 mb-3"></div>
        </div>
        <div class="modal fade" id="ModalDatosTabla" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg border-azul-clasico">
                <div class="modal-content ">
                    <div class="modal-header bg-azul-clasico text-white">
                        <h4 class="modal-title text-center"><i class='fas fa-info-circle'></i> INFORMACIÓN BÁSICA</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-row">
                            <label class="col-sm-2 col-form-label text-left">Base de datos:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" name="mdtBase" id="mdtBase" readonly>
                            </div>
                            <label class="col-sm-2 col-form-label text-left">Nombre:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" name="mdtNombre" id="mdtNombre" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <label class="col-sm-2 col-form-label text-left">Fecha creación:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" name="mdtCreacion" id="mdtCreacion" readonly>
                            </div>
                            <label class="col-sm-2 col-form-label text-left">Fecha edición:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" name="mdtEdicion" id="mdtEdicion" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <label class="col-sm-2 col-form-label text-left">Fecha proceso:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" name="mdtProceso" id="mdtProceso" readonly>
                            </div>
                            <label class="col-sm-2 col-form-label text-left"></label>
                            <div class="col"></div>
                        </div>
                        <div class="form-row">
                            <label class="col-sm-2 col-form-label text-left">Descripción:</label>
                            <div class="col">
                                <textarea class="form-control mb-2" name="mdtDescripcion" id="mdtDescripcion" readonly></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type='submit' class='btn btn-outline-secondary' data-dismiss="modal" value='Aceptar'>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/BuscarTabla.js"></script>