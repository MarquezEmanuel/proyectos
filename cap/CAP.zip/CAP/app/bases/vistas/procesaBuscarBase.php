<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorBase();

if (isset($_POST['btnBuscarBase'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $filtro = ($nombre) ? "Resultado de la búsqueda: " . $nombre . ", " : "Resultado de la búsqueda: ";
    $bases = $controlador->buscar($nombre, $estado);
    $_SESSION['BUSBAS'] = array($nombre, $estado);
} else {
    if (isset($_SESSION['BUSBAS'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSBAS'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = ($nombre) ? "Ultima búsqueda realizada: " . $nombre . ", " : "Ultima búsqueda realizada: ";
        $bases = $controlador->buscar($nombre, $estado);
        $_SESSION['BUSBAS'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $bases = $controlador->listarUltimasActualizadas();
        $filtro = "Ultimas bases de datos actualizadas y en estado ONLINE";
        $_SESSION['BUSBAS'] = NULL;
    }
}

if (gettype($bases) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($base = sqlsrv_fetch_array($bases, SQLSRV_FETCH_ASSOC)) {
        $fechaCreacion = isset($base['fechaCreacionBase']) ? date_format($base['fechaCreacionBase'], 'd/m/Y') : "";
        $filas .= "
            <tr>
                <td>{$base['nombreBase']}</td>
                <td>{$fechaCreacion}</td>
                <td>{$base['servidorProduccion']}</td>
                <td>{$base['servidorTest']}</td>
                <td>{$base['servidorDesarrollo']}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editarBase' name='{$base['idBase']}' title='Editar base de datos'><i class='far fa-edit'></i></button>
                        <button class='btn btn-outline-primary datosBase' title='Ver información básica'><i class='fas fa-info-circle'></i></button>
                        <button class='btn btn-outline-info detalleBase' name='{$base['idBase']}' title='Ver detalle'><i class='fas fa-eye'></i></button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbBases" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Fecha creación</th>
                        <th>Producción</th>
                        <th>Test</th>
                        <th>Desarrollo</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    if ($bases == 1) {
        $cuerpo = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>{$controlador->getMensaje()} para el filtro ingresado</strong>
            </div>";
    } else {
        $cuerpo = "
            <div class='alert alert-danger text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
}

$formulario = '
    <div class="card mt-4">
        <div class="card-header text-left"><i class="fas fa-table"></i> ' . $filtro . '</div>
        <div class="card-body">' . $cuerpo . '</div>
    </div>';

echo $formulario;
