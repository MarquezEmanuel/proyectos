<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorBase();

if (isset($_POST['btnBuscarBase'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " . $estado : "TODAS, " . $estado;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $bases = $controlador->buscar($nombre, $estado);
    $_SESSION['BUSBAS'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['BUSBAS'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSBAS'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $bases = $controlador->buscar($nombre, $estado);
        $_SESSION['BUSBAS'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $bases = $controlador->listarUltimasActualizadas();
        $filtro = "Ultimas bases de datos actualizadas y en estado ONLINE";
        $_SESSION['BUSBAS'] = NULL;
    }
}

if (gettype($bases) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($base = sqlsrv_fetch_array($bases, SQLSRV_FETCH_ASSOC)) {
        $fechaCreacion = isset($base['fechaCreacionBase']) ? date_format($base['fechaCreacionBase'], 'd/m/Y') : "";
        $filas .= "
            <tr>
                <td>" . utf8_encode($base['nombreBase']) . "</td>
                <td>{$fechaCreacion}</td>
                <td>{$base['servidorProduccion']}</td>
                <td>{$base['servidorTest']}</td>
                <td>{$base['servidorDesarrollo']}</td>
                <td style='display: none;'>" . utf8_encode($base['collation']) . "</td>
                <td style='display: none;'>" . utf8_encode($base['estado']) . "</td>
                <td style='display: none;'>" . utf8_encode($base['rti']) . "</td>
                <td style='display: none;'>" . utf8_encode($base['tablas']) . "</td>
                <td style='display: none;'>" . utf8_encode($base['vistas']) . "</td>
                <td style='display: none;'>" . utf8_encode($base['sps']) . "</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' name='{$base['idBase']}' title='Editar base de datos'><i class='far fa-edit'></i></button>
                        <button class='btn btn-outline-primary datos' title='Ver información básica'><i class='fas fa-info-circle'></i></button>
                        <button class='btn btn-outline-info detalle' name='{$base['idBase']}' title='Ver detalle'><i class='fas fa-eye'></i></button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbBases" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Fecha creación</th>
                        <th>Producción</th>
                        <th>Test</th>
                        <th>Desarrollo</th>
                        <th style="display: none;">Collation</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">RTI</th>
                        <th style="display: none;">Total tablas</th>
                        <th style="display: none;">Total vistas</th>
                        <th style="display: none;">Total SP</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($bases == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($bases, $mensaje);
}

$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
