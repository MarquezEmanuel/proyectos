<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3">
            <div class="col text-left">
                <h4><i class="fas fa-database"></i> BUSCAR CAMPO</h4>
            </div>
        </div>
        <div id="seccionCentral" class="mt-3 mb-4">
            <form method="POST" name="formBuscarCampo" id="formBuscarCampo">
                <input type="hidden" name="peticion" id="peticion">
                <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                    <div class="card-body">
                        <div class="form-row">
                            <label for="tabla" class="col-sm-2 col-form-label text-left">Tabla:</label>
                            <div class="col">
                                <select class="form-control mb-2" name="tabla" id="tabla"></select>
                            </div>
                            <label for="nombre" class="col-sm-2 col-form-label text-left">Nombre:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       name="nombre" id="nombre" 
                                       minlength="1" maxlength="30" pattern="[A-Za-z0-9_]{1,30}"
                                       title="Nombre de campo: campo obligatorio"
                                       placeholder="Nombre del campo" required>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-row mt-2">
                    <div class="col text-right">
                        <button type="submit" class="btn btn-success" name="btnBuscarCampo">
                            <i class="fas fa-search"></i>  BUSCAR
                        </button>
                        <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                    </div>
                </div>
            </form>
        </div>
        <div id="seccionInferior" class="mt-4 mb-3"></div>
    </div>
</div>
<script type="text/javascript" src="../js/BuscarCampo.js"></script>