<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="fas fa-database"></i> BUSCAR VISTA</h4>
                </div>
                <div class="col text-right">
                    <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
                </div>
            </div>
            <div id="seccionCentral" class="mt-3 mb-4">
                <form method="POST" name="formBuscarVista" id="formBuscarVista">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="nombre" class="col-sm-2 col-form-label text-left">Nombre:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombre" id="nombre" 
                                           title="Nombre de la vista: campo no obligatorio"
                                           placeholder="Nombre">
                                </div>
                                <label for="nombre" class="col-sm-2 col-form-label text-left">Tipo de consulta:</label>
                                <div class="col">
                                    <select class="form-control mb-2" name="tipo" id="tipo">
                                        <option value="DESCONOCIDA">Desconocida</option>
                                        <option value="Interna">Interna</option>
                                        <option value="Externa">Externa</option>
                                        <option value="Combinada">Combinada</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success" name="btnBuscarVista">
                                <i class="fas fa-search"></i>  BUSCAR
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div id="seccionInferior" class="mt-4 mb-3">
                <?php include_once './procesaBuscarVista.php'; ?>
            </div>
        </div>
        <div class="modal fade" id="ModalDatosVista" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg border-azul-clasico">
                <div class="modal-content ">
                    <div class="modal-header bg-azul-clasico text-white">
                        <h4 class="modal-title text-center"><i class="fas fa-project-diagram"></i> DATOS BÁSICOS</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-row">
                            <label class="col-sm-2 col-form-label text-left">Base de datos:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" name="mdvBase" id="mdvBase" readonly>
                            </div>
                            <label class="col-sm-2 col-form-label text-left">Nombre:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" name="mdvNombre" id="mdvNombre" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <label class="col-sm-2 col-form-label text-left">Tipo de consulta:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" name="mdvConsulta" id="mdvConsulta" readonly>
                            </div>
                            <label class="col-sm-2 col-form-label text-left">Fecha proceso:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" name="mdvFecha" id="mdvFecha" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <label class="col-sm-2 col-form-label text-left">Descripción:</label>
                            <div class="col">
                                <textarea class="form-control mb-2" name="mdvDescripcion" id="mdvDescripcion" readonly></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type='submit' class='btn btn-outline-secondary' data-dismiss="modal" value='Aceptar'>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/BuscarVista.js"></script>