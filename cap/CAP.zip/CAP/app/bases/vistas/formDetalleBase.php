<?php
$idBase = $_POST['idBase'];

echo $idBase;
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3">
        <div class="col text-left">
            <h4><i class="fas fa-database"></i> DETALLE DE LA BASE DE DATOS</h4>
        </div>
        <div class="col text-right">
            <a href="bases_buscarBase"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
        </div>
    </div>
    <div id="seccionCentral" class="mt-3 mb-4">
        <div class="card mt-2">
            <div class="card-header text-left">Información básica</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="nombre" class="col-sm-2 col-form-label text-left">Nombre:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2">
                    </div>
                    <label for="nombre" class="col-sm-2 col-form-label text-left">Producción:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2">
                    </div>
                </div>
            </div>
        </div>
        <div class="card mt-3">
            <div class="card-header text-left">Listado de tablas</div>
            <div class="card-body">
                <table class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Fecha creación</th>
                            <th>Producción</th>
                            <th>Test</th>
                            <th>Desarrollo</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
        <div class="card mt-3">
            <div class="card-header text-left">Listado de procedimientos almacenados</div>
            <div class="card-body">
                <table class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Fecha creación</th>
                            <th>Producción</th>
                            <th>Test</th>
                            <th>Desarrollo</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
        <div class="card mt-3">
            <div class="card-header text-left">Listado de vistas</div>
            <div class="card-body">
                <table class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Fecha creación</th>
                            <th>Producción</th>
                            <th>Test</th>
                            <th>Desarrollo</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>