<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorVista();

if (isset($_POST['btnBuscarVista'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $tipo = $_POST['tipo'];
    $datos = ($nombre) ? "'{$nombre}', " . $tipo : "TODAS, " . $tipo;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $vistas = $controlador->buscar($nombre, $tipo);
    $_SESSION['BUSVIS'] = array($nombre, $tipo, $datos);
} else {
    if (isset($_SESSION['BUSVIS'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSVIS'];
        $nombre = $parametros[0];
        $tipo = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $vistas = $controlador->buscar($nombre, $tipo);
        $_SESSION['BUSVIS'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $vistas = $controlador->listarUltimasActualizadas();
        $filtro = "Últimas vistas actualizadas";
        $_SESSION['BUSVIS'] = NULL;
    }
}

if (gettype($vistas) == "resource") {
    $filas = "";
    while ($vista = sqlsrv_fetch_array($vistas, SQLSRV_FETCH_ASSOC)) {
        $fechaProceso = date_format($vista['fechaProceso'], 'd/m/Y');
        $filas .= "
            <tr>
                <td>" . utf8_encode($vista['nombreBase']) . "</td>
                <td>" . utf8_encode($vista['nombreVista']) . "</td>
                <td>{$vista['consulta']}</td>
                <td>{$fechaProceso}</td>
                <td style='display: none;'>" . utf8_encode($vista['descripcion']) . "</td>  
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-primary datos' 
                                name='{$vista['idVista']} title='Ver información básica'>
                                <i class='fas fa-info-circle'></i>
                        </button>
                        <button class='btn btn-outline-warning editar' 
                                name='{$vista['idVista']}' title='Editar'>
                            <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbVistas" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Base de datos</th>
                        <th>Nombre</th>
                        <th>Consulta</th>
                        <th>Fecha proceso</th>
                        <th style="display: none;">Descripción</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($vistas == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($vistas, $mensaje);
}

$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
