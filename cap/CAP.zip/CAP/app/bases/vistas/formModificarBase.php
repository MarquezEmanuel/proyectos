<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();


if (isset($_POST['idBase'])) {
    $idBase = $_POST['idBase'];
    $controladorBase = new ControladorBase();
    $resultado = $controladorBase->obtener($idBase);
    if (gettype($resultado) == "resource") {
        
    } else {
        
    }
}