<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

if (isset($_POST['idBase'])) {
    $idBase = $_POST['idBase'];
    $controladorBase = new ControladorBase();
    $resultado = $controladorBase->obtener($idBase);
    if (gettype($resultado) == "resource") {
        $base = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC);
        $elementos = $base['tablas'] + $base['vistas'] + $base['sps'];
        $fechaCreacion = isset($base['fechaCreacionBase']) ? date_format($base['fechaCreacionBase'], 'd/m/Y') : "";
        $cuerpoBase = '
            <div class="form-row">
                <label for="sigla" class="col-sm-2 col-form-label">Base de datos:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . utf8_encode($base['nombreBase']) . '" disabled>
                </div>
                <label for="nombre" class="col-sm-2 col-form-label">Fecha de creación:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . $fechaCreacion . '" disabled>
                </div>
            </div>
            <div class="form-row">
                <label for="sigla" class="col-sm-2 col-form-label">Collation:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . utf8_encode($base['collation']) . '" disabled>
                </div>
                <label for="nombre" class="col-sm-2 col-form-label">Estado:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . utf8_encode($base['estado']) . '" disabled>
                </div>
            </div>
            <div class="form-row">
                <label for="sigla" class="col-sm-2 col-form-label">Producción:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . utf8_encode($base['servidorProduccion']) . '" disabled>
                </div>
                <label for="nombre" class="col-sm-2 col-form-label">Test:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . utf8_encode($base['servidorTest']) . '" disabled>
                </div>
            </div>
            <div class="form-row">
                <label for="sigla" class="col-sm-2 col-form-label">Desarrollo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . utf8_encode($base['servidorDesarrollo']) . '" disabled>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col"></div>
            </div>
            <div class="form-row">
                <label for="sigla" class="col-sm-2 col-form-label">Total de tablas:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . utf8_encode($base['tablas']) . '" disabled>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col">
                    <a href="procesaDescargarPDFTabla.php?ref=' . $base['idBase'] . '&name=' . utf8_encode($base['nombreBase']) . '" >
                        <button type="button" class="btn btn-outline-success">
                            <i class="far fa-file-pdf"></i> DESCARGAR</button>
                    </a>
                </div>
            </div>
            <div class="form-row">
                <label for="sigla" class="col-sm-2 col-form-label">Total de vistas:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . utf8_encode($base['vistas']) . '" disabled>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col">
                    <a href="procesaDescargarPDFVista.php?ref=' . $base['idBase'] . '&name=' . utf8_encode($base['nombreBase']) . '">
                        <button type="button" class="btn btn-outline-success">
                            <i class="far fa-file-pdf"></i> DESCARGAR</button>
                    </a>
                </div>
            </div>
            <div class="form-row">
                <label for="sigla" class="col-sm-2 col-form-label">Total de SPs:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" value="' . utf8_encode($base['sps']) . '" disabled>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col">
                    <a href="procesaDescargarPDFSP.php?ref=' . $base['idBase'] . '&name=' . utf8_encode($base['nombreBase']) . '">
                        <button type="button" class="btn btn-outline-success">
                            <i class="far fa-file-pdf"></i> DESCARGAR</button>
                    </a>
                </div>
            </div>';
        $cardBase = ControladorHTML::getCardBusqueda("Información básica", $cuerpoBase);

        $controladorTabla = new ControladorTabla();

        /* SE CARGA LA INFORMACION DE LAS TABLAS QUE POSEE LA BASE */

        $tablas = $controladorTabla->listarPorBase($idBase);
        if (gettype($tablas) == "resource") {
            $filasTabla = "";
            while ($tabla = sqlsrv_fetch_array($tablas, SQLSRV_FETCH_ASSOC)) {
                $fechaCreacion = isset($tabla['fechaCreacion']) ? date_format($tabla['fechaCreacion'], 'd/m/Y') : "";
                $fechaEdicion = isset($tabla['fechaModificacion']) ? date_format($tabla['fechaModificacion'], 'd/m/Y H:i:s') : "";
                $filasTabla .= "
                <tr>
                    <td>" . utf8_encode($tabla['nombreTabla']) . "</td>
                    <td>{$fechaCreacion}</td>
                    <td>{$fechaEdicion}</td>
                </tr>";
            }
            $cuerpoTabla = '
                <table id="tbDetalleTabla" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Fecha creación</th>
                            <th>Fecha edición</th>
                        </tr>
                    </thead>
                    <tbody>' . $filasTabla . '</tbody>
                </table>';
        } else {
            $cuerpoTabla = ControladorHTML::getAlertaOperacion($tablas, $controladorTabla->getMensaje());
        }
        $filtroTabla = "Listado de tablas";
        $cardTabla = ControladorHTML::getCardBusqueda($filtroTabla, $cuerpoTabla);

        if ($elementos < 500) {
            $controladorProcedimiento = new ControladorProcedimiento();
            $controladorVista = new ControladorVista();

            /* SE CARGA LA INFOMRACION DE LOS PROCEDIMIENTOS QUE POSEE LA BASE */

            $procedimientos = $controladorProcedimiento->listarPorBase($idBase);
            if (gettype($procedimientos) == "resource") {
                $filasProcedimiento = "";
                while ($procedimiento = sqlsrv_fetch_array($procedimientos, SQLSRV_FETCH_ASSOC)) {
                    $fechaCreacion = isset($procedimiento['fechaCreacion']) ? date_format($procedimiento['fechaCreacion'], 'd/m/Y') : "";
                    $fechaEdicion = isset($procedimiento['fechaModificacion']) ? date_format($procedimiento['fechaModificacion'], 'd/m/Y H:i:s') : "";
                    $filasProcedimiento .= "
                <tr>
                    <td>" . utf8_encode($procedimiento['nombreSP']) . "</td>
                    <td>{$fechaCreacion}</td>
                    <td>{$fechaEdicion}</td>
                </tr>";
                }
                $cuerpoProcedimiento = '
                <table id="tbDetalleProcedimiento" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Fecha creación</th>
                            <th>Fecha edición</th>
                        </tr>
                    </thead>
                    <tbody>' . $filasProcedimiento . '</tbody>
                </table>';
            } else {
                $cuerpoProcedimiento = ControladorHTML::getAlertaOperacion($procedimientos, $controladorProcedimiento->getMensaje());
            }
            $filtroProcedimiento = "Listado de procedimientos almacenados";
            $cardProcedimiento = ControladorHTML::getCardBusqueda($filtroProcedimiento, $cuerpoProcedimiento);

            /* SE CARGA LA INFORMACION DE LAS VISTAS QUE POSEE LA BASE */

            $vistas = $controladorVista->listarPorBase($idBase);
            if (gettype($vistas) == "resource") {
                $filasVista = "";
                while ($vista = sqlsrv_fetch_array($vistas, SQLSRV_FETCH_ASSOC)) {
                    $filasVista .= "
                <tr>
                    <td>" . utf8_encode($vista['nombreVista']) . "</td>
                    <td>" . utf8_encode($vista['consulta']) . "</td>
                </tr>";
                }
                $cuerpoVista = '
                <table id="tbDetalleVista" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Tipo consulta</th>
                        </tr>
                    </thead>
                    <tbody>' . $filasVista . '</tbody>
                </table>';
            } else {
                $cuerpoVista = ControladorHTML::getAlertaOperacion($vistas, $controladorVista->getMensaje());
            }
            $filtroVista = "Listado de vistas";
            $cardVista = ControladorHTML::getCardBusqueda($filtroVista, $cuerpoVista);
        } else {
            $cardVista = $cardProcedimiento = "dsds";
        }
    } else {
        
    }
    $formulario = $cardBase . "<br>" . $cardTabla . "<br>" . $cardProcedimiento . "<br>" . $cardVista;
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $filtro = "Información básica";
    $cuerpo = ControladorHTML::getAlertaOperacion(0, $mensaje);
    $formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3">
        <div class="col text-left">
            <h4><i class="fas fa-database"></i> DETALLE DE LA BASE DE DATOS</h4>
        </div>
        <div class="col text-right">
            <a href="bases_buscarBase"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
        </div>
    </div>
    <div id="seccionCentral" class="mt-3 mb-4">
        <?= $formulario; ?>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <a href="formBuscarBase.php">
                    <button type="button" class="btn btn-outline-info">
                        <i class="fas fa-search"></i> BUSCAR
                    </button>
                </a>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/DetalleBaseDatos.js"></script>