<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
AutoCargador::cargarModulos();

$controlador = new ControladorTabla();

if (isset($_POST['btnBuscarTabla'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $filtro = ($nombre) ? "Resultado de la búsqueda: " . $nombre . ", " : "Resultado de la búsqueda: ";
    $tablas = $controlador->buscar($nombre, $descripcion);
    $_SESSION['BUSTAB'] = array($nombre, $descripcion);
} else {
    if (isset($_SESSION['BUSTAB'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSTAB'];
        $nombre = $parametros[0];
        $descripcion = $parametros[1];
        $filtro = ($nombre) ? "Ultima búsqueda realizada: " . $nombre . ", " : "Ultima búsqueda realizada: ";
        $tablas = $controlador->buscar($nombre, $descripcion);
        $_SESSION['BUSTAB'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $tablas = $controlador->listarUltimasModificadas();
        $filtro = "Ultimas tablas modificadas";
        $_SESSION['BUSTAB'] = NULL;
    }
}

if (gettype($tablas) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($tabla = sqlsrv_fetch_array($tablas, SQLSRV_FETCH_ASSOC)) {
        $fechaCreacion = isset($tabla['fechaCreacion']) ? date_format($tabla['fechaCreacion'], 'd/m/Y') : "";
        $fechaModificacion = isset($tabla['fechaModificacion']) ? date_format($tabla['fechaModificacion'], 'd/m/Y') : "";
        $filas .= "
            <tr>
                <td>{$tabla['nombreTabla']}</td>
                <td>{$tabla['nombreBase']}</td>
                <td>{$fechaCreacion}</td>
                <td>{$fechaModificacion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning'><i class='far fa-edit'></i></button>
                        <button class='btn btn-outline-primary'><i class='fas fa-eye'></i></button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbTablas" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Base de datos</th>
                        <th>Creación</th>
                        <th>Modificación</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    if ($tablas == 2) {
        $cuerpo = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>{$controlador->getMensaje()} para el filtro ingresado</strong>
            </div>";
    } else {
        $cuerpo = "
            <div class='alert alert-danger text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
}

$formulario = '
    <div class="card mt-4">
        <div class="card-header text-left"><i class="fas fa-table"></i> ' . $filtro . '</div>
        <div class="card-body">' . $cuerpo . '</div>
    </div>';

echo $formulario;
