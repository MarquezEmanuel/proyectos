<?php

class BasesDatos {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM reporteBaseDatos WHERE nombreBase LIKE '%$nombre%' AND nombreEstado = '{$estado}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listar($nombre) {
        $consulta = "SELECT idBase, nombreBase FROM reporteBaseDatos WHERE nombreBase LIKE '%$nombre%'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimasActualizadas() {
        $consulta = "SELECT TOP(10) * FROM reporteBaseDatos WHERE nombreEstado = 'ONLINE' ORDER BY fechaProcesoBase DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
