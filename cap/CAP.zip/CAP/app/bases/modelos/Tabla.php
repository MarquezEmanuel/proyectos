<?php

class Tabla {

    private $id;
    private $base;
    private $objeto;
    private $nombre;
    private $descripcion;
    private $fechaCreacion;
    private $fechaEdicion;
    private $fechaProceso;
    private $mensaje;

    public function __construct($id = NULL, $base = NULL, $objeto = NULL, $nombre = NULL, $descripcion = NULL, $fechaCreacion = NULL, $fechaEdicion = NULL, $fechaProceso = NULL) {
        $this->id = $id;
        $this->base = $base;
        $this->objeto = $objeto;
        $this->nombre = utf8_decode($nombre);
        $this->descripcion = utf8_decode($descripcion);
        $this->fechaCreacion = $fechaCreacion;
        $this->fechaEdicion = $fechaEdicion;
        $this->fechaProceso = $fechaProceso;
    }

    public function getId() {
        return $this->id;
    }

    public function getBase() {
        return $this->base;
    }

    public function getObjeto() {
        return $this->objeto;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function getFechaProceso() {
        return $this->fechaProceso;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setBase($base) {
        $this->base = $base;
    }

    public function setObjeto($objeto) {
        $this->objeto = $objeto;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function setFechaProceso($fechaProceso) {
        $this->fechaProceso = $fechaProceso;
    }

    public function modificar() {
        if ($this->id && $this->descripcion) {
            $campos = "descripcion = '{$this->descripcion}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("bas_tablas", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM reporteTablas WHERE idTabla = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->base = $fila['nombreBase'];
                $this->objeto = $fila['objeto'];
                $this->nombre = $fila['nombreTabla'];
                $this->descripcion = $fila['descripcion'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaModificacion'];
                $this->fechaProceso = $fila['fechaProceso'];
                return 2;
            }
            $this->mensaje = "No se obtuvo la información de la tabla";
            return 1;
        }
        $this->mensaje = "No se pudo hacer referencia a la tabla";
        return 0;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("bas_tablas", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
