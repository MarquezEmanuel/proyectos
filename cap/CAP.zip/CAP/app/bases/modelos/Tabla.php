<?php

class Tabla {

    private $id;
    private $descripcion;
    
}
