<?php

class Tablas {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($base, $nombre) {
        $consulta = "SELECT * FROM reporteTablas WHERE idBase LIKE '%{$base}%' AND nombreTabla LIKE '%{$nombre}%'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listar($nombre) {
        $consulta = "SELECT * FROM reporteTablas WHERE nombreTabla LIKE '%{$nombre}%'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimasModificadas() {
        $consulta = "SELECT TOP(10) * FROM reporteTablas ORDER BY fechaModificacion DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarPorBase($idBase) {
        $consulta = "SELECT * FROM reporteTablas WHERE idBase = '{$idBase}'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
