<?php

/**
 * Description of ProcedimientosAlmacenados
 *
 * @author Emanuel
 */
class Procedimientos {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $descripcion) {
        $consulta = "SELECT * FROM reporteProcedimientos WHERE nombre LIKE '%{$nombre}%' AND descripcion LIKE '%{$descripcion}%'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listar() {
        
    }

    public function listarPorBase($idBase) {
        $consulta = "SELECT * FROM reporteProcedimientos WHERE idBase = {$idBase} ORDER BY nombreSP";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
