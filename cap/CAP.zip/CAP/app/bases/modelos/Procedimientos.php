<?php

/**
 * Description of ProcedimientosAlmacenados
 *
 * @author Emanuel
 */
class Procedimientos {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $definicion) {
        $consulta = "SELECT * FROM reporteProcedimientos WHERE nombreSP LIKE '%{$nombre}%' AND definicion LIKE '%{$definicion}%'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listar() {
        
    }

    public function listarPorBase($idBase) {
        $consulta = "SELECT * FROM reporteProcedimientos WHERE idBase = {$idBase} ORDER BY nombreSP";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimosModificados() {
        $consulta = "SELECT TOP(10) * FROM reporteProcedimientos ORDER BY fechaModificacion DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
