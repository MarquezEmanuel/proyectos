<?php

/**
 * Description of ProcedimientosAlmacenados
 *
 * @author Emanuel
 */
class Procedimientos {

    private static $mensaje;

    public static function getMensaje() {
        return self::$mensaje;
    }

    public static function buscar($nombre, $definicion) {
        $consulta = "SELECT * FROM vwbas_procedimiento WHERE snombre LIKE ? AND sdefinicion LIKE ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array('%' . $nombre . '%', '%' . $definicion . '%'));
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public static function listarPorBase($idBase) {
        $consulta = "SELECT * FROM vwbas_procedimiento WHERE idBase = {$idBase} ORDER BY nombreSP";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public static function listarUltimosModificados() {
        $consulta = "SELECT TOP(10) * FROM vwbas_procedimiento ORDER BY fechaModificacion DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
