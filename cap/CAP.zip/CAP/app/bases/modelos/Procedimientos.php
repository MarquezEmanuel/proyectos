<?php

/**
 * Description of ProcedimientosAlmacenados
 *
 * @author Emanuel
 */
class Procedimientos {

    private static $mensaje;

    public static function getMensaje() {
        return self::$mensaje;
    }

    public static function buscar($base, $nombre, $definicion, $descripcion) {
        $consulta = "SELECT * FROM vwbas_procedimiento WHERE bnombre LIKE ? AND snombre LIKE ? AND sdefinicion LIKE ? AND sdescripcion LIKE ?";
        $datos = array('%' . $base . '%', '%' . $nombre . '%', '%' . $definicion . '%', '%' . $descripcion . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public static function listarPorBase($idBase) {
        $consulta = "SELECT * FROM vwbas_procedimiento WHERE idBase = {$idBase} ORDER BY nombreSP";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public static function listarUltimosModificados() {
        $consulta = "SELECT TOP(10) * FROM vwbas_procedimiento ORDER BY fechaModificacion DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
