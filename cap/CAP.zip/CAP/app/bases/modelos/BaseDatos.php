<?php

class BaseDatos {

    private $id;
    private $nombre;
    private $produccion;
    private $test;
    private $desarrollo;
    private $creacion;
    private $collation;
    private $proceso;
    private $rti;
    private $estado;
    private $mensaje;

    public function __construct($id = NULL, $nombre = NULL, $produccion = NULL, $test = NULL, $desarrollo = NULL, $creacion = NULL, $collation = NULL, $proceso = NULL, $rti = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setProduccion($produccion);
        $this->setTest($test);
        $this->setDesarrollo($desarrollo);
        $this->setCreacion($creacion);
        $this->setCollation($collation);
        $this->setProceso($proceso);
        $this->setEstado($estado);
        $this->setRti($rti);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getProduccion() {
        return $this->produccion;
    }

    public function getTest() {
        return $this->test;
    }

    public function getDesarrollo() {
        return $this->desarrollo;
    }

    public function getCreacion() {
        return $this->creacion;
    }

    public function getCollation() {
        return $this->collation;
    }

    public function getProceso() {
        return $this->proceso;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setProduccion($produccion) {
        $this->produccion = $produccion;
    }

    public function setTest($test) {
        $this->test = $test;
    }

    public function setDesarrollo($desarrollo) {
        $this->desarrollo = $desarrollo;
    }

    public function setCreacion($creacion) {
        $this->creacion = $creacion;
    }

    public function setCollation($collation) {
        $this->collation = $collation;
    }

    public function setProceso($proceso) {
        $this->proceso = $proceso;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function modificar() {
        
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM bas_bases WHERE id = '{$this->id}'";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->nombre = $fila['nombre'];
                $this->creacion = isset($fila['fechaCreacion']) ? date_format($fila['fechaCreacion'], 'd/m/Y') : "";
                $this->collation = $fila['collation'];
                $this->proceso = isset($fila['fechaProceso']) ? date_format($fila['fechaProceso'], 'd/m/Y') : "";
                $this->rti = $fila['rti'];
                $this->estado = $fila['estado'];
                return $this->obtenerServidores($fila['produccion'], $fila['test'], $fila['desarrollo']);
            }
            return 1;
        }
        return 0;
    }

    private function obtenerServidores($produccion, $test, $desarrollo) {
        if ($produccion) {
            $this->produccion = new Servidor($produccion);
            $this->produccion->obtener();
        } else {
            $this->produccion = NULL;
        }

        $this->test = new Servidor($test);
        $this->desarrollo = new Servidor($desarrollo);
        $resultadoP = $resultadoT = $this->test->obtener();
        $resultadoD = $this->desarrollo->obtener();
        if ($resultadoP || 2 && $resultadoT || 2 && $resultadoD || 2) {
            return 2;
        }
        return 0;
    }

}
