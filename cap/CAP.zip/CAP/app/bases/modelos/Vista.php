<?php

/**
 * Description of Vistas
 *
 * @author Emanuel
 */
class Vista {

    private $id;
    private $consulta;
    private $descripcion;
    private $mensaje;

    public function __construct($id, $consulta, $descripcion) {
        $this->setId($id);
        $this->setConsulta($consulta);
        $this->setDescripcion($descripcion);
    }

    public function getId() {
        return $this->id;
    }

    public function getConsulta() {
        return $this->consulta;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setConsulta($consulta) {
        $this->consulta = $consulta;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function modificar() {
        if ($this->id && $this->consulta && $this->descripcion) {
            $campos = "consulta = '{$this->consulta}', descripcion = '{$this->descripcion}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("bas_vistas", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 1;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("bas_vistas", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
