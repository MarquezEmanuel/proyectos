<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Vistas {

    private $vistas;

    public function getVistas() {
        return $this->vistas;
    }

    public function setVistas($vistas) {
        $this->vistas = $vistas;
    }

    public function buscar($nombre, $descripcion) {
        $consulta = "SELECT * FROM reporteVistas WHERE nombre LIKE '%{$nombre}%' AND descripcion LIKE '%{$descripcion}%'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listar($idBase) {
        $consulta = "SELECT * FROM reporteVistas WHERE idBase = {$idBase} ORDER BY nombre";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
