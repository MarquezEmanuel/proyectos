<?php

/**
 * Description of campos
 *
 * @author Emanuel
 */
class Campos {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function buscar($tabla, $nombre) {
        $consulta = "SELECT * FROM reporteCampos WHERE idTabla = {$tabla} AND nombreCampo LIKE '%{$nombre}%'";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarPorTabla($idTabla) {
        $consulta = "SELECT * FROM reporteCampos WHERE idTabla = {$idTabla}";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

    public function listarUltimosActualizados() {
        $consulta = "SELECT TOP(10) * FROM reporteCampos ORDER BY idCampo DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta);
        $this->mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
