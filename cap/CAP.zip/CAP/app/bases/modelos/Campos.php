<?php

/**
 * Description of campos
 *
 * @author Emanuel
 */
class Campos {
    
   
    public function __construct() {
        ;
    }
    
    public function buscar() {}
    
    public function listar() {}
    
}
