/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    realizarBusqueda();

    $('#formBuscarCampo').submit(function (event) {
        event.preventDefault();
        $("#peticion").val("true");
        realizarBusqueda();
        $('html, body').animate({scrollTop: $("#seccionInferior").offset().top}, '1250');
    });

    $('select#tabla').select2({
        placeholder: 'Seleccione una opcion',
        theme: "bootstrap",
        minimumInputLength: 2,
        ajax: {
            url: "../vistas/procesaElegirTabla.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    function realizarBusqueda() {
        $.ajax({
            type: "POST",
            url: "./PBuscarCampo.php",
            data: $("#formBuscarCampo").serialize(),
            success: function (data) {
                $('#seccionInferior').html(data);
                $('#tbCampos').dataTable({
                    lengthChange: false,
                    language: {url: "../../../lib/JQuery/Spanish.json"}
                });
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            }
        });
    }

});

