/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {

    $('#tbVistas').dataTable({
        lengthChange: false
    });

    $('.datos').click(function () {
        $("#mdvBase").val($(this).parents("tr").find('td:eq(0)').text());
        $("#mdvNombre").val($(this).parents("tr").find('td:eq(1)').text());
        $("#mdvConsulta").val($(this).parents("tr").find('td:eq(2)').text());
        $("#mdvFecha").val($(this).parents("tr").find('td:eq(3)').text());
        $("#mdvDescripcion").val($(this).parents("tr").find('td:eq(4)').text());
        $("#ModalDatosVista").modal({});
    });

    $('.editar').click(function () {
        var idVista = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formModificarVista.php",
            data: "idVista=" + idVista,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#seccionInferior").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

});
