/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function () {

    $('#tbProcedimientos').dataTable({
        lengthChange: false
    });

    $('.editar').click(function () {
        var idProcedimiento = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formModificarProcedimiento.php",
            data: "idProcedimiento=" + idProcedimiento,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#seccionInferior").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    $('.datos').click(function () {
        $("#mdpBase").val($(this).parents("tr").find('td:eq(0)').text());
        $("#mdpNombre").val($(this).parents("tr").find('td:eq(1)').text());
        $("#mdpCreacion").val($(this).parents("tr").find('td:eq(2)').text());
        $("#mdpEdicion").val($(this).parents("tr").find('td:eq(3)').text());
        $("#mdpDescripcion").val($(this).parents("tr").find('td:eq(4)').text());
        $("#ModalDatosProcedimiento").modal({});
    });

});
