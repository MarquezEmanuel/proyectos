/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function () {

    $('#tbBases').dataTable({
        lengthChange: false
    });

    $('.editarBase').click(function () {
        $("#ModalDatosBase").modal({});
    });

    $('.datosBase').click(function () {
        $("#ModalDatosBase").modal({});
    });

    $('.detalleBase').click(function () {
        var idBase = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formDetalleBase.php",
            data: "idBase=" + idBase,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

});