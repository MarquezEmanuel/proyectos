/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function () {

    $('#tbBases').dataTable({
        lengthChange: false
    });

    $('.editar').click(function () {
        var idBase = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formModificarBase.php",
            data: "idBase=" + idBase,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#seccionInferior").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    $('.datos').click(function () {
        $("#mdbNombre").val($(this).parents("tr").find('td:eq(0)').text());
        $("#mdbCreacion").val($(this).parents("tr").find('td:eq(1)').text());
        $("#mdbProduccion").val($(this).parents("tr").find('td:eq(2)').text());
        $("#mdbTest").val($(this).parents("tr").find('td:eq(3)').text());
        $("#mdbDesarrollo").val($(this).parents("tr").find('td:eq(4)').text());
        $("#mdbEstado").val($(this).parents("tr").find('td:eq(5)').text());
        $("#mdbCollation").val($(this).parents("tr").find('td:eq(6)').text());
        $("#mdbRTI").val($(this).parents("tr").find('td:eq(7)').text());
        $("#mdbTablas").val($(this).parents("tr").find('td:eq(8)').text());
        $("#mdbVistas").val($(this).parents("tr").find('td:eq(9)').text());
        $("#mdbSPS").val($(this).parents("tr").find('td:eq(10)').text());
        $("#ModalDatosBase").modal({});
    });

    $('.detalle').click(function () {
        var idBase = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formDetalleBase.php",
            data: "idBase=" + idBase,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

});