<?php

/**
 * Description of Usuarios
 *
 * @author 07489
 */
class Usuarios {

    private $usuarios;

    public function __construct() {
        
    }

    public function buscar() {
        
    }

    public function listar() {
        
    }

   
}
