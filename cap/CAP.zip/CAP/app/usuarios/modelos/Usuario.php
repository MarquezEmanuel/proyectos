<?php

/**
 * Description of Usuario
 *
 * @author 07489
 */
class Usuario {

    private $id;
    private $nombre;
    private $estado;
    private $perfil;
    private $mensaje;

    public function __construct($id = NULL, $nombre = NULL, $estado = NULL, $perfil = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setEstado($estado);
        $this->setPerfil($perfil);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getPerfil() {
        return $this->perfil;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setPerfil($perfil) {
        $this->perfil = $perfil;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $campos = "estado = {$this->estado}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("seg_usuarios", $campos, $condicion);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $operacion = ($this->estado == 1) ? "ALTA" : "BAJA";
                $modificacion = $this->registrarActividad($operacion, $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function crear() {
        if ($this->id && $this->nombre && $this->perfil) {
            $values = "('{$this->id}', '{$this->nombre}', {$this->perfil}, 1)";
            $creacion = SQLServer::instancia()->insertar("seg_usuarios", $values);
            $this->mensaje = $this->nombre . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        return 0;
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->perfil) {
            $campos = "id = '{$this->id}', nombre = '{$this->gerencia}', perfil = {$this->perfil}";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("seg_usuarios", $campos, $condicion);
            $this->mensaje = $this->titulo . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM [dbo].[seg_usuarios] WHERE id = '{$this->id}'";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->nombre = $fila['nombre'];
                $this->estado = $fila['estado'];
                $this->perfil = $this->obtenerPerfil($fila['perfil']);
                return 2;
            }
            $this->mensaje = "No se obtuvo la información del usuario";
            return 1;
        }
        return 0;
    }

    private function obtenerPerfil($id) {
        $perfil = new Perfil($id);
        if ($perfil->obtener() == 2) {
            return $perfil;
        }
        $this->mensaje = "No se obtuvo la información del perfil";
        return null;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("seg_usuarios", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
