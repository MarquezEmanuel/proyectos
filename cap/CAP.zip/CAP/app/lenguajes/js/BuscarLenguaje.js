/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {

    realizarBusqueda();

    $('#formBuscarLenguaje').submit(function (event) {
        event.preventDefault();
        $("#peticion").val("true");
        realizarBusqueda();
    });

    $('#seccionInferior').on('click', '.editar', function () {
        alert("ffff");
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('#seccionInferior').on('click', '.baja', function () {
        $("#tituloModal").html("<i class='fas fa-code-branch'></i> CONFIRME LA BAJA DEL LENGUAJE");
        $("#modalAccion").val("BAJA");
        $("#modalIdLenguaje").val($(this).attr("name"));
        $("#modalNombre").text($(this).parents("tr").find("td").eq(0).html() + ": ");
        $("#ModalCambioEstadoLenguaje").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('#seccionInferior').on('click', '.alta', function () {
        $("#tituloModal").html("<i class='fas fa-code-branch'></i> CONFIRME EL ALTA DEL LENGUAJE");
        $("#modalAccion").val("ALTA");
        $("#modalIdInstalacion").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find("td").eq(2).html());
        $("#ModalCambioEstadoInstalacion").modal({backdrop: 'static', keyboard: false});
    });

    function realizarBusqueda() {
        $.ajax({
            type: "POST",
            url: "./PBuscarLenguaje.php",
            data: $("#formBuscarLenguaje").serialize(),
            success: function (data) {
                $('#seccionInferior').html(data);
                $('#tbLenguajes').dataTable({
                    lengthChange: false
                });
            },
            error: function (data) {
                console.log(data);
                var div = '<div class="alert alert-danger text-center" role="alert">No se procesó la petición por un error interno</div>';
                $("#seccionInferior").html(div);
            }
        });
    }

});


