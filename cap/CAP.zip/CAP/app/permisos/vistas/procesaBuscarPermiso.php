<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

$controlador = new ControladorPermiso();

if (isset($_POST['btnBuscarPermiso'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $nivel = $_POST['nivel'];
    $nombreNivel = ($nivel == 1) ? "Menú" : "Submenú";
    $permisos = $controlador->buscar($nombre, $nivel);
    $filtro = "Resultado de la búsqueda: ";
    $filtro .= ($nombre) ? $nombre . ", " . $nombreNivel : $nombreNivel;
    $_SESSION['BUSPER'] = array($nombre, $nivel);
} else {
    if (isset($_SESSION['BUSPER'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSPER'];
        $nombre = $parametros[0];
        $nivel = $parametros[1];
        $nombreNivel = ($nivel == 1) ? "Menú" : "Submenú";
        $permisos = $controlador->buscar($nombre, $nivel);
        $filtro = "Ultima búsqueda realizada: ";
        $filtro .= ($nombre) ? $nombre . ", " . $nombreNivel : $nombreNivel;
        $_SESSION['BUSPER'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $permisos = $controlador->listarUltimosCreados();
        $filtro = "Ultimos permisos creados y en estado activo";
        $_SESSION['BUSPER'] = NULL;
    }
}

if (gettype($permisos) == "resource") {
    $filas = "";
    while ($permiso = sqlsrv_fetch_array($permisos, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr>
                <td>{$permiso['titulo']}</td>
                <td>" . utf8_encode($permiso['nombreNivel']) . "</td>
                <td>{$permiso['nombrePadre']}</td>
                <td>{$permiso['link']}</td>
                <td>{$permiso['formulario']}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editarPermiso' name='{$permiso['id']}' title='Editar servidor'><i class='far fa-edit'></i></button>
                        <button class='btn btn-outline-primary datosServidor' title='Ver información básica'><i class='fas fa-info-circle'></i></button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbPermisos" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Titulo</th>
                        <th>Nivel</th>
                        <th>Padre</th>
                        <th>Link</th>
                        <th>Formulario</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    if ($permisos == 2) {
        $cuerpo = "
            <div class='alert alert-warning text-center' role='alert'>
                <i class='fas fa-exclamation-circle'></i> <strong>{$controlador->getMensaje()} para el filtro ingresado</strong>
            </div>";
    } else {
        $cuerpo = "
            <div class='alert alert-danger text-center' role='alert'> 
                <i class='fas fa-exclamation-triangle'></i> <strong>{$controlador->getMensaje()}</strong>
            </div>";
    }
}
$formulario = '
    <div class="card border-azul-clasico mt-4">
        <div class="card-header text-left bg-azul-clasico text-white"><i class="fas fa-table"></i> ' . $filtro . '</div>
        <div class="card-body">' . $cuerpo . '</div>
    </div>';

echo $formulario;
