<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';


AutoCargador::cargarModulos();

$controlador = new ControladorPermiso();

$menus = $controlador->listarPorNivel(1);

if (gettype($menus) == "resource") {
    $opciones = "";
    while ($menu = sqlsrv_fetch_array($menus, SQLSRV_FETCH_ASSOC)) {
        $opciones .= "<option value='{$menu['id']}'>{$menu['titulo']}</option>";
    }
}

require_once '../../principal/vistas/header.php';
?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3 mb-3">
            <div class="col text-left">
                <h4><i class="fas fa-user-lock"></i> CREAR PERMISO</h4>
            </div>
            <div class="col text-right">
                <a href="principal_home"><button class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i> CERRAR</button></a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <form id="formCrearPermiso" name="formCrearPermiso" method="POST">
            <div class="card border-azul-clasico mt-3">
                <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="titulo" class="col-sm-2 col-form-label text-left">* Titulo:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" name="titulo" id="titulo" placeholder="Titulo del permiso">
                        </div>
                        <label for="nivel" class="col-sm-2 col-form-label text-left">* Nivel:</label>
                        <div class="col">
                            <select class="form-control mb-2" id="nivel" name="nivel">
                                <option value="1">Menú</option>
                                <option value="2">Submenú</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="padre" class="col-sm-2 col-form-label text-left">* Padre:</label>
                        <div class="col">
                            <select class="form-control mb-2" id="padre" name="padre" disabled>
                                <?= $opciones; ?>
                            </select>
                        </div>
                        <label for="link" class="col-sm-2 col-form-label text-left">* Link:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" name="link" id="link" placeholder="Link de acceso" disabled>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="formulario" class="col-sm-2 col-form-label text-left">* Formulario:</label>
                        <div class="col">
                            <input type="text" class="form-control mb-2" name="formulario" id="formulario" placeholder="Nombre del formulario" disabled>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
                    <a href="permisos_buscar">
                        <button type="button" class="btn btn-outline-info">
                            <i class="fas fa-search"></i> BUSCAR
                        </button>
                    </a>
                    <input type="reset" class="btn btn-outline-secondary" value="LIMPIAR">
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="../js/CrearPermiso.js"></script>