<?php

class ControladorPermiso {

    private $mensaje;

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function buscar($nombre, $nivel) {
        $permisos = new Permisos();
        $resultado = $permisos->buscar($nombre, $nivel);
        $this->mensaje = $permisos->getMensaje();
        return $resultado;
    }

    public function crear($titulo, $nivel, $padre, $link, $formulario) {
        $permiso = new Permiso(NULL, $titulo, $nivel, $padre, $link, $formulario);
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $confirmar = FALSE;
            $creacion = $permiso->crear();
            $this->mensaje = $permiso->getMensaje();
            if ($creacion == 2) {
                $confirmar = TRUE;
            }
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar";
        return 0;
    }

    public function borrar() {
        
    }

    public function listar() {
        
    }

    public function listarPorNivel($nivel) {
        $permisos = new Permisos();
        $resultado = $permisos->listarPorNivel($nivel);
        return $resultado;
    }

    public function listarUltimosCreados() {
        $permisos = new Permisos();
        $resultado = $permisos->listarUltimosCreados();
        $this->mensaje = $permisos->getMensaje();
        return $resultado;
    }

    public function modificar() {
        
    }

}
