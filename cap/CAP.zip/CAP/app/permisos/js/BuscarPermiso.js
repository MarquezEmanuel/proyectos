/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    /* INICIALIZA EL DATATABLE */

    $('#tbPermisos').DataTable({
        lengthChange: false
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('.editar').click(function () {
        var idPermiso = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./formModificarPermiso.php",
            data: "idPermiso=" + idPermiso,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('.borrar').click(function () {
        $("#tituloModal").html("<i class='fas fa-user-lock'></i>  CONFIRME LA BAJA DEL PERMISO");
        $("#modalIdPermiso").val($(this).attr("name"));
        $("#modalNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalBorrarPermiso").modal({backdrop: 'static', keyboard: false});
    });
    
    /* ENVIA LA OPERACION Y MUESTRA EL RESULTADO EN EL MODAL */

    $('#btnBorrarPermiso').click(function () {
        $.ajax({
            type: "POST",
            url: "./procesaBorrarPermiso.php",
            data: $("#formBorrarPermiso").serialize(),
            success: function (data) {
                $('#cuerpoModal').html(data);
                $('#btnBorrarPermiso').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                $("#cuerpoModal").html('<div class="alert alert-danger text-center" role="alert">No se procesó la petición</div>');
            }
        });
    });

    /* ACTUALIZA LA PANTALLA LUEGO DE HACER EL ALTA O BAJA */

    $('#btnRefrescarPantalla').click(function () {
        location.reload();
    });

});

