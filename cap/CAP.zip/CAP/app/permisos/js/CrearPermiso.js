/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    $("#nivel").change(function () {
        if ($(this).find(":selected").val() === 1) {
            $("#padre").prop("disabled", true);
            $("#link").prop("disabled", true);
            $("#formulario").prop("disabled", true);
        } else {
            $("#padre").prop("disabled", false);
            $("#link").prop("disabled", false);
            $("#formulario").prop("disabled", false);
        }
    });

});