<?php

/**
 * Description of Permiso
 *
 * @author 07489
 */
class Permiso {

    private $id;
    private $titulo;
    private $nivel;
    private $padre;
    private $link;
    private $formulario;
    private $mensaje;

    public function __construct($id = NULL, $titulo = NULL, $nivel = NULL, $padre = NULL, $link = NULL, $formulario = NULL) {
        $this->setId($id);
        $this->setTitulo($titulo);
        $this->setNivel($nivel);
        $this->setPadre($padre);
        $this->setLink($link);
        $this->setFormulario($formulario);
    }

    public function getId() {
        return $this->id;
    }

    public function getTitulo() {
        return utf8_encode($this->titulo);
    }

    public function getNivel() {
        return $this->nivel;
    }

    public function getPadre() {
        return $this->padre;
    }

    public function getLink() {
        return $this->link;
    }

    public function getFormulario() {
        return $this->formulario;
    }

    public function getMensaje() {
        return $this->mensaje;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setTitulo($titulo) {
        $this->titulo = utf8_decode($titulo);
    }

    public function setNivel($nivel) {
        $this->nivel = $nivel;
    }

    public function setPadre($padre) {
        $this->padre = $padre;
    }

    public function setLink($link) {
        $this->link = $link;
    }

    public function setFormulario($formulario) {
        $this->formulario = $formulario;
    }

    public function setMensaje($mensaje) {
        $this->mensaje = $mensaje;
    }

    public function borrar() {
        
    }

    public function crear() {
        if ($this->titulo && $this->nivel) {
            $values = "('{$this->titulo}',{$this->nivel}, {$this->padre}, '{$this->link}')";
            $creacion = SQLServer::instancia()->insertar("seg_permisos", $values);
            $this->mensaje = $this->titulo . ": " . SQLServer::instancia()->getMensaje();
            if ($creacion == 2) {
                $this->id = SQLServer::instancia()->getUltimoId();
                $creacion = $this->registrarActividad("CREACION", $this->id);
            }
            return $creacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 1;
    }

    public function modificar() {
        if ($this->id && $this->titulo && $this->nivel) {
            $campos = "titulo = '{$this->titulo}', nivel = {$this->nivel}, padre = {$this->padre}, link='{$this->link}', formulario = '{$this->formulario}'";
            $condicion = "id = {$this->id}";
            $modificacion = SQLServer::instancia()->modificar("seg_permisos", $campos, $condicion);
            $this->mensaje = $this->titulo . ": " . SQLServer::instancia()->getMensaje();
            if ($modificacion == 2) {
                $modificacion = $this->registrarActividad("MODIFICACION", $this->id);
            }
            return $modificacion;
        }
        return 0;
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM seg_permisos WHERE id = {$this->id}";
            $fila = SQLServer::instancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->titulo = $fila['titulo'];
                $this->nivel = $fila['nivel'];
                $this->padre = $fila['padre'];
                $this->link = $fila['link'];
                $this->formulario = $fila['formulario'];
                return 2;
            }
            $this->mensaje = "No se obtuvo la información del permiso";
            return 1;
        }
        return 0;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("seg_permisos", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
