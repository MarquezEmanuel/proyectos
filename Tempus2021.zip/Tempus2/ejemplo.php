<?php
include_once './app/modelo/Autocargador.php';
include_once './config/inc_config.php';

use app\modelo\Encriptador;
use app\modelo\AutoCargador;
use app\modelo\Log;
use app\modelo\Resultado;
use app\repositorio\MySQL;
use app\repositorio\Repositorio;

AutoCargador::cargarModulos();

$encriptador = new Encriptador();

echo '<br>HOSTNAME: ' . $encriptador->desencriptar($g_db_hostname, $g_crypto_key);
echo '<br>BASENAME: ' . $encriptador->desencriptar($g_db_basename, $g_crypto_key);
echo '<br>USERNAME: ' . $encriptador->desencriptar($g_db_username, $g_crypto_key);
echo '<br>PASSWORD: ' . $encriptador->desencriptar($g_db_password, $g_crypto_key);

$log = Log::getInstancia();

$log->error('Error');

$repositorio = new Repositorio();
$query = 'SELECT * FROM asignatur WHERE id = ?';
$datos = array(190);
$listado = array();
$resultado = $repositorio->select($query, $datos);
if ($resultado->isSuccess()) {
    $listado = $resultado->getDatos();
    var_dump($listado);
} else {
    var_dump($repositorio->getLogs());
    echo '<br>' .  $resultado->getMensaje();
}

$query = 'insert into asignatura values ( ?,?)';
$datos = array('CB', 'Ciencias Biologicas 3');
$resultado = $repositorio->insert($query, $datos);
if ($resultado->isSuccess()) {
    echo '<br>' . $resultado->getMensaje();
    $listado = $resultado->getDatos();
    var_dump($listado);
} else {
    var_dump($repositorio->getLogs());
    echo '<br>' .  $resultado->getMensaje();
}


$query = 'update asignatura set nombreCoro = ? where id=?';
$datos = array('CB2', 190);
$resultado = $repositorio->update($query, $datos);
if ($resultado->isSuccess()) {
    echo '<br>' . $resultado->getMensaje();
    $listado = $resultado->getDatos();
    var_dump($listado);
} else {
    var_dump($repositorio->getLogs());
    echo '<br>' .  $resultado->getMensaje();
}