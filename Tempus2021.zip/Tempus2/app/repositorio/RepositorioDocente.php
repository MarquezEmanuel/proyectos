<?php

namespace app\repositorio;

use app\modelo\Constantes;
use app\modelo\Resultado;
use app\modelo\Docente;

/**
 * 
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class RepositorioDocente extends Repositorio
{

    public function borrarDocentes()
    {
        $query = 'DELETE FROM docente';
        return $this->delete($query, array());
    }



    /**
     * Crea un nuevo docente. 
     * @param Docente Docente a crear.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function crear(Docente $docente)
    {
        if ($docente) {
            $query = "INSERT INTO docente (id, nombre) VALUES (NULL, ?)";
            $parametros = $docente->toArray(true);
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $id = $resultado->getDatos();
                $docente->setId($id);
                $resultado->setDatos($docente);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Obtener informacion del docente a partir de su identificador.
     * @param Docente $docente Objeto docente a cargar.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorID(Docente $docente)
    {
        if ($docente) {
            $query = "SELECT id, nombre FROM docente WHERE id = ?";
            $parametros = array($docente->getId());
            $resultado = $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $datos = $resultado->getDatos();
                $docente->setear($datos);
                $resultado->setDatos($docente);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Obtener informacion del docente a partir de su nombre.
     * @param Docente $docente Objeto docente a cargar.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorNombre(Docente $docente)
    {
        if ($docente) {
            $query = "SELECT id, nombre FROM docente WHERE nombre = ?";
            $parametros = array($docente->getNombre());
            $resultado = $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $datos = $resultado->getDatos();
                $docente->setear($datos);
                $resultado->setDatos($docente);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    public function reiniciarAutoIncrementador()
    {
        $query = 'ALTER TABLE docente AUTO_INCREMENT = 1';
    }

    /**
     * Seleccionar docente por su nombre.
     * @param string $nombre Nombre del docente (LIKE).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function seleccionar($nombre)
    {
        $query = "SELECT id, nombre FROM docente WHERE nombre LIKE ? ORDER BY nombre";
        $parametros = array("%{$nombre}%");
        return $this->select($query, $parametros);
    }
}
