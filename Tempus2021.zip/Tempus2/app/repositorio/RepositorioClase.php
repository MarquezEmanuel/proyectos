<?php

namespace app\repositorio;

use app\modelo\Constantes;
use app\modelo\Resultado;