<?php

namespace app\repositorio;

use app\modelo\Constantes;
use app\modelo\Resultado;
use app\modelo\Llamado;

/**
 * 
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class RepositorioLlamado extends Repositorio
{
}
