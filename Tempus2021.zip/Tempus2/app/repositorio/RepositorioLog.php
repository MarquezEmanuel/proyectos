<?php

namespace app\repositorio;

use app\modelo\Log;

class RepositorioLog
{

    private $log;

    public function __construct()
    {
        $this->log = Log::getInstancia();
    }

    public function guardarErrores($listado)
    {
        foreach ($listado as $error) {
            $this->log->error($error);
        }
    }
}
