<?php

namespace app\repositorio;

use app\modelo\Asignatura;
use app\modelo\Constantes;
use app\modelo\Resultado;

/**
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class RepositorioAsignatura extends Repositorio
{

    public function borrar()
    {
        $query = "DELETE FROM asignatura WHERE id NOT IN (SELECT DISTINCT idAsignatura FROM Plan)";
        return $this->delete($query, array());
    }

    /**
     * Crea una nueva asignatura. 
     * @param Asignatura $asignatura Asignatura a crear.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function crear(Asignatura $asignatura)
    {
        if ($asignatura->esValida()) {
            $query = "INSERT INTO asignatura (id, nombreCorto, nombreLargo, fechaCreacion) VALUES (NULL, ?, ?, NOW())";
            $parametros = $asignatura->getArrayInsert();
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $id = $resultado->getDatos();
                $asignatura->setId($id);
                $resultado->setDatos($asignatura);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    public function listarInforme()
    {
        $query = "SELECT * FROM vw_informe WHERE modulo = 'ASIGNATURAS'";
        return $this->select($query, array());
    }

    /**
     * Listar las asignaturas que coincidan por nombre largo. El listado se ordena por nombre largo.
     * @param string $nombreAsignatura Nombre de la asignatura o parte del nombre.
     * @return array Arreglo de dos posiciones (codigo, datos).
     */
    public function listarPorNombreLargo($nombreLargo)
    {
        $query = "SELECT id, nombreCorto, nombreLargo, fechaCreacion, carreras FROM vw_asignatura WHERE nombreLargo LIKE ? ORDER BY nombreLargo";
        $parametros = array("%$nombreLargo%");
        return $this->select($query, $parametros);
    }

    /**
     * Listar las asignaturas que pertenecen a una carrera. El listado se ordena por anio y nombre.
     * @param int $codigo Codigo de la carrera.
     * @return Resultado Objeto de tipo Resultado
     */
    public function listarPorCodigoCarrera($codigo)
    {
        if ($codigo > 0) {
            $query = "SELECT a.id, a.nombreCorto, a.nombreLargo, a.fechaCreacion, p.anio FROM plan p "
                . "INNER JOIN asignatura a ON a.id = p.idAsignatura "
                . "WHERE p.idCarrera = ? ORDER BY p.anio, a.nombreLargo";
            $parametros = array($codigo);
            return $this->select($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Listar asignaturas por su nombre largo condicion en una carrera (Pertenece o no pertenece). 
     * El resultado se orderna por nombre largo.
     * @param string $codigoCarrera Codigo de la carrera.
     * @param string $nombreAsignatura Nombre de la asignatura o parte del nombre.
     * @param bool $pertenece True si la asignatura pertenece a la carrera o false.
     * @return Resultado Objeto de tipo Resultado
     */
    public function listarPorCondicionCarrera($codigoCarrera, $nombreAsignatura, $pertenece)
    {
        $expresion = "/^[a-záéíóúñü0-9,. ]{0,60}$/";
        if (($codigoCarrera > 0) && preg_match($expresion, mb_strtolower($nombreAsignatura))) {
            $condicion = ($pertenece) ? "IN" : "NOT IN";
            $parametros = array("%{$nombreAsignatura}%", $codigoCarrera);
            $query = "SELECT id, nombreCorto, nombreLargo, fechaCreacion "
                . " FROM asignatura WHERE nombreLargo LIKE ? AND id {$condicion} "
                . " (SELECT idAsignatura FROM plan WHERE idCarrera = ?) ORDER BY nombreLargo";
            return $this->select($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Obtener informacion de la asignatura a partir de su identificador.
     * @param int $id Identificador del la asignatura.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorID(Asignatura $asignatura)
    {
        $id = $asignatura->getId();
        if ($id > 0) {
            $query = "SELECT id, nombreCorto, nombreLargo, fechaCreacion FROM asignatura WHERE id = ?";
            $parametros = array($id);
            $resultado =  $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $datos = $resultado->getDatos();
                $asignatura->setear($datos);
                $resultado->setDatos($asignatura);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Obtnener informacion de la asignatura a partir de su nombre largo.
     * @param string $nombreLargo Nombre largo de la asignatura
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorNombreLargo(Asignatura $asignatura)
    {
        $nombreLargo = $asignatura->getNombreLargo();
        if ($nombreLargo) {
            $query = "SELECT id, nombreCorto, nombreLargo, fechaCreacion FROM asignatura WHERE nombreLargo = ?";
            $parametros = array($nombreLargo);
            $resultado =  $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $datos = $resultado->getDatos();
                $asignatura->setear($datos);
                $resultado->setDatos($asignatura);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }
}
