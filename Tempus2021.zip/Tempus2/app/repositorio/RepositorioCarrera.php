<?php


namespace app\repositorio;

use app\modelo\Carrera;
use app\modelo\Constantes;
use app\modelo\Resultado;

/**
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class RepositorioCarrera extends Repositorio
{

    public function borrarCarreras()
    {
        $query = "DELETE FROM carrera WHERE id NOT IN (SELECT DISTINCT idCarrera FROM Plan)";
        return $this->delete($query, array());
    }

    /**
     * Crea una nueva carrera. 
     * @param Carrera $carrera Carrera a crear.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function crear(Carrera $carrera)
    {
        if ($carrera->esValida()) {
            $query = 'INSERT INTO carrera VALUES (NULL, ?, ?, NOW())';
            $parametros = $carrera->getArrayInsert();
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $resultado->setDatos($carrera);
            }
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    public function listarInforme()
    {
        $query = "SELECT * FROM vw_informe WHERE modulo = 'CARRERAS'";
        return $this->select($query, array());
    }


    /**
     * Listar carreras que coincidan por nombre largo. El listado se ordena por ID.
     * @param string $nombreLargo Nombre largo de la carrera (LIKE).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function listarPorNombreLargo($nombreLargo)
    {
        $parametros = array("%{$nombreLargo}%");
        $query = "SELECT id, nombreCorto, nombreLargo, fechaCreacion, asignaturas "
            . " FROM vw_carrera WHERE nombreLargo LIKE ? ORDER BY id";
        return $this->select($query, $parametros);
    }

    /**
     * Listar las carreras que pertenecen a una asignatura. El listado se ordena por anio y nombre.
     * @param int $id Identificador de la asignatura.
     * @return Resultado Objeto de tipo Resultado
     */
    public function listarPorIDAsignatura($id)
    {
        if ($id > 0) {
            $query = "SELECT c.id, c.nombreCorto, c.nombreLargo, c.fechaCreacion, p.anio "
                . "FROM plan p INNER JOIN carrera c ON c.id = p.idCarrera "
                . "WHERE p.idAsignatura = ? ORDER BY p.anio, c.nombreLargo ";
            $parametros = array($id);
            return $this->select($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Obtener informacion de la carrera a partir de su identificador.
     * @param int $id Identificador del la carrera.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorID(Carrera $carrera)
    {
        $id = $carrera->getId();
        if ($id > 0) {
            $query = "SELECT id, nombreCorto, nombreLargo, fechaCreacion FROM carrera WHERE id = ?";
            $parametros = array($id);
            $resultado = $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $datos = $resultado->getDatos();
                $carrera->setear($datos);
                $resultado->setDatos($carrera);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Obtener informacion de la carrera a partir de su identificador o nombre largo.
     * @param Carrera $carrera Carrera a obtener.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorIDoNombre(Carrera $carrera)
    {
        $id = $carrera->getId();
        $nombreLargo = $carrera->getNombreLargo();
        if ($id > 0 && $nombreLargo) {
            $query = "SELECT id, nombreCorto, nombreLargo, fechaCreacion FROM carrera WHERE id = ? OR nombreLargo = ?";
            $parametros = array($id, $nombreLargo);
            return $this->select($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }
}
