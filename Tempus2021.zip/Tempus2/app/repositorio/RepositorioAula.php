<?php

namespace app\repositorio;

use app\modelo\Aula;
use app\modelo\Constantes;
use app\modelo\Resultado;

class RepositorioAula extends Repositorio
{
    public function borrar()
    {
    }

    /**
     * Crea una nueva aula. 
     * @param array Datos del aula (nombre, sector).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function crear(Aula $aula)
    {
        if ($aula->esValida()) {
            $query = "INSERT INTO aula (id, nombre, sector) VALUES (NULL, ?, ?)";
            $parametros = $aula->getArrayInsert();
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $id = $resultado->getDatos();
                $aula->setId($id);
                $resultado->setDatos($aula);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Buscar aulas por sector o nombre. El listado se ordena por sector y nombre.
     * @param string $sector Nombre del sector.
     * @param string $nombre Nombre del aula.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function listarParaBusqueda($sector, $nombre)
    {
        $query = "SELECT id, sector, nombre, clases, llamados FROM vw_aula "
            . " WHERE sector LIKE ? AND nombre LIKE ? "
            . " ORDER BY sector, nombre";
        $parametros = array("%$sector%", "%{$nombre}%");
        return $this->select($query, $parametros);
    }

    /**
     * Listar las aulas que coincidan por nombre. El listado se ordena por nombre y sector.
     * @param string $sector Nombre del sector.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function listarPorNombre($nombre)
    {
        $query = "SELECT id, sector, nombre FROM aula WHERE nombre LIKE ? ORDER BY sector, nombre";
        $parametros = array("%{$nombre}%");
        return $this->select($query, $parametros);
    }

    /**
     * Modificar los datos del aula. 
     * @param array Datos del aula (nombre, sector).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function modificar(Aula $aula)
    {
        if ($aula->esValida()) {
            $query = "UPDATE aula SET nombre=?, sector=? WHERE id=?";
            $parametros = $aula->getArrayUpdate();
            return $this->update($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Obtener informacion del aula a partir de su identificador.
     * @param int $id Identificador del aula (Igual).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorID(Aula $aula)
    {
        $id = $aula->getId();
        if ($id > 0) {
            $query = "SELECT id, nombre, sector FROM aula WHERE id = ?";
            $parametros = array($id);
            $resultado =  $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $datos = $resultado->getDatos();
                $aula->setear($datos);
                $resultado->setDatos($aula);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Obtener informacion del aula a partir de su nombre y sector.
     * @param string $nombre Nombre del aula (Igual).
     * @param string $sector Nombre del sector (Igual).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorNombreSector(Aula $aula)
    {
        $nombre = $aula->getNombre();
        $sector = $aula->getSector();
        if ($nombre && $sector) {
            $query = "SELECT id, nombre, sector FROM aula WHERE id = ?";
            $parametros = array($nombre, $sector);
            $resultado = $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $datos = $resultado->getDatos();
                $aula->setear($datos);
                $resultado->setDatos($aula);
            }
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }
}
