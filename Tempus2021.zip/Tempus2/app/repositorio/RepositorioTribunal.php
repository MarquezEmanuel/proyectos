<?php

namespace app\repositorio;

use app\modelo\Constantes;
use app\modelo\Resultado;
use app\modelo\Tribunal;

/**
 * 
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class RepositorioTribunal extends Repositorio
{

    public function borrar($id)
    {
        $query = "DELETE FROM tribunal WHERE id = ?";
    }

    /**
     * Crea un nuevo tribunal. 
     * @param Tribunal Tribunal a crear.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function crear(Tribunal $tribunal)
    {
        if ($tribunal) {
            $query = "INSERT INTO tribunal (id, idPresidente, idVocal1, idVocal2, idSuplente) VALUES (NULL, ?, ?, ?, ?)";
            $parametros = $tribunal->toArray(true);
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $id = $resultado->getDatos();
                $tribunal->setId($id);
                $resultado->setDatos($tribunal);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Modificar los datos del tribunal. 
     * @param Tribunal Tribunal a modificar.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function modificar(Tribunal $tribunal)
    {
        if ($tribunal) {
            $query = "UPDATE tribunal SET idPresidente=?, idVocal1=?, idVocal2=?, idSuplente=? WHERE id=?";
            $parametros = $tribunal->toArray(false);
            return $this->update($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    public function obtenerPorID(Tribunal $tribunal)
    {
        if ($tribunal) {
            $query = 'SELECT id, idPresidente, idVocal1, idVocal2, idSuplente FROM tribunal WHERE id=?';
            $parametros = array($tribunal->getId());
            $resultado = $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $datos = $resultado->getDatos();
                $tribunal->setear($datos);
                $resultado->setDatos($tribunal);
            }
            return $resultado;
        }
    }
}
