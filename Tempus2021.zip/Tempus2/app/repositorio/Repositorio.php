<?php

namespace app\repositorio;

use PDO;
use PDOException;
use app\modelo\Resultado;
use app\modelo\Constantes;

class Repositorio
{
    private $conexion;
    private $logs;
    private $MYSQL_MENSAJES;
    private $MYSQL_DUPLICATE_CODES;

    public function __construct()
    {
        $this->logs = array();
        $this->conexion = MySQL::getInstancia();
        $this->MYSQL_DUPLICATE_CODES = array(1062, 23000);
        $this->MYSQL_MENSAJES = [
            'DEL_ERR' => 'No se pudo realizar la eliminación solicitada por un error interno',
            'DEL_WAR' => 'No se pudo realizar la eliminación',
            'DEL_SUC' => 'Se realizó la eliminación correctamente',
            'INS_ERR' => 'No se pudo realizar la creación solicitada por un error interno',
            'INS_WAR' => 'No se pudo realizar la creación solicitada porque ya existe',
            'INS_SUC' => 'Se realizó la creación correctamente',
            'GET_ERR' => 'No se pudo realizar la consulta solicitada por un error interno',
            'GET_WAR' => 'No se encontraron resultados',
            'SEL_ERR' => 'No se pudo realizar la consulta solicitada por un error interno',
            'SEL_WAR' => 'No se encontraron resultados',
            'UPD_ERR' => 'No se pudo realizar la modificación solicitada por un error interno',
            'UPD_WAR' => 'No se pudo realizar la modificación solicitada porque ya existe',
            'UPD_SUC' => 'Se realizó la modificación correctamente'
        ];
    }

    public function getLogs()
    {
        $logs = $this->logs;
        $this->logs = array();
        return $logs;
    }

    public function iniciarTransaccion()
    {
        $this->conexion->beginTransaction();
    }

    public function commit()
    {
        $this->conexion->commit();
    }

    public function rollback()
    {
        $this->conexion->rollback();
    }

    private function guardarDatosTransaccion($query, $parametros)
    {
        $contador = 0;
        $this->logs[] = $query;
        foreach ($parametros as $parametro) {
            $this->logs[] = "[{$contador}]: {$parametro}";
            $contador++;
        }
    }

    public function delete($query, $parametros)
    {
        try {
            $stmt = $this->conexion->prepare($query);
            $stmt->execute($parametros);
            return new Resultado(Constantes::COD_SUCCESS, $this->MYSQL_MENSAJES['DEL_SUC']);
        } catch (PDOException $e) {
            $this->guardarDatosTransaccion($query, $parametros);
            $this->logs[] = $e->getCode() . " => " . $e->getMessage();
        }
        return new Resultado(Constantes::COD_ERROR, $this->MYSQL_MENSAJES['DEL_ERR']);
    }

    public function get($query, $parametros)
    {
        try {
            $stmt = $this->conexion->prepare($query);
            $stmt->execute($parametros);
            $listado = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$listado) {
                return new Resultado(Constantes::COD_WARNING, $this->MYSQL_MENSAJES['GET_WAR']);
            }
            return new Resultado(Constantes::COD_SUCCESS, '', $listado);
        } catch (PDOException $e) {
            $this->guardarDatosTransaccion($query, $parametros);
            $this->logs[] = $e->getCode() . " => " . $e->getMessage();
            return new Resultado(Constantes::COD_ERROR, $this->MYSQL_MENSAJES['GET_ERR']);
        }
    }

    public function insert($query, $parametros)
    {
        try {
            $stmt = $this->conexion->prepare($query);
            $stmt->execute($parametros);
            $id = $this->conexion->lastInsertId();
            return new Resultado(Constantes::COD_SUCCESS, $this->MYSQL_MENSAJES['INS_SUC'], $id);
        } catch (PDOException $e) {
            if (in_array($e->getCode(), $this->MYSQL_DUPLICATE_CODES)) {
                return new Resultado(Constantes::COD_WARNING, $this->MYSQL_MENSAJES['INS_WAR']);
            }
            $this->guardarDatosTransaccion($query, $parametros);
            $this->logs[] = $e->getCode() . " => " . $e->getMessage();
        }
        return new Resultado(Constantes::COD_ERROR, $this->MYSQL_MENSAJES['INS_ERR']);
    }

    public function select($query, $parametros)
    {
        try {
            $stmt = $this->conexion->prepare($query);
            $stmt->execute($parametros);
            $listado = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (!$listado) {
                return new Resultado(Constantes::COD_WARNING, $this->MYSQL_MENSAJES['SEL_WAR']);
            }
            return new Resultado(Constantes::COD_SUCCESS, '', $listado);
        } catch (PDOException $e) {
            $this->guardarDatosTransaccion($query, $parametros);
            $this->logs[] = $e->getCode() . " => " . $e->getMessage();
            return new Resultado(Constantes::COD_ERROR, $this->MYSQL_MENSAJES['SEL_ERR']);
        }
    }

    public function update($query, $parametros)
    {
        try {
            $stmt = $this->conexion->prepare($query);
            $stmt->execute($parametros);
            return new Resultado(Constantes::COD_SUCCESS, $this->MYSQL_MENSAJES['UPD_SUC']);
        } catch (PDOException $e) {
            if (in_array($e->getCode(), $this->MYSQL_DUPLICATE_CODES)) {
                return new Resultado(Constantes::COD_WARNING, $this->MYSQL_MENSAJES['UPD_WAR']);
            }
            $this->guardarDatosTransaccion($query, $parametros);
            $this->logs[] = $e->getCode() . " => " . $e->getMessage();
        }
        return new Resultado(Constantes::COD_ERROR, $this->MYSQL_MENSAJES['UPD_ERR']);
    }
}
