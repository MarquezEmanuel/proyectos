<?php

namespace app\modelo;

use app\modelo\Conexion;

/**
 * 
 * @package app\seguridad\modelo
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ColeccionPermisos {

    /**
     * @see vw_informe Consulta cuando modulo es PERMISOS.
     */
    public static function listarInformesPermiso(): array {
        $consulta = "SELECT * FROM vw_informe WHERE modulo = 'PERMISOS'";
        return Conexion::getInstancia()->seleccionar($consulta);
    }

}
