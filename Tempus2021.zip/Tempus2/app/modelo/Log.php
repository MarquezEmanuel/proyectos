<?php

namespace app\modelo;

use Exception;

/**
 * paquete: principal.
 * namespace: modelos;
 */
class Log
{

    public static $instancia;

    private $archivo;

    public function __construct()
    {
        $carpeta = dirname(__FILE__, 3) . '\\logs';
        $this->archivo = "$carpeta\\LOG.txt";
    }

    public static function getInstancia()
    {
        if (!self::$instancia instanceof self) {
            try {
                self::$instancia = new self;
            } catch (Exception $e) {
                return null;
            }
        }
        return self::$instancia;
    }

    public function error($texto)
    {
        $this->guardar(Constantes::COD_ERROR, $texto);
    }

    public function info($texto)
    {
        $this->guardar(Constantes::COD_INFO, $texto);
    }

    public function success($texto)
    {
        $this->guardar(Constantes::COD_SUCCESS, $texto);
    }

    public function warning($texto)
    {
        $this->guardar(Constantes::COD_WARNING, $texto);
    }

    private function guardar($tipo, $texto)
    {
        $date = date("Y-m-d H:i:s");
        $file = file_exists($this->archivo) ? fopen($this->archivo, 'a') : fopen($this->archivo, 'w');
        $ip = isset($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : "DESC";
        $script = explode("/", $_SERVER["SCRIPT_NAME"]);
        $archivo = $script[count($script) - 1];
        $usuario = (isset($_SESSION['user'])) ? unserialize($_SESSION['user']) : NULL;
        $user = ($usuario) ? $usuario->getEmail() : "DESC";
        $data = "[{$date}][{$tipo}][{$user}][{$ip}][{$archivo}][{$texto}]" . PHP_EOL;
        fwrite($file, $data);
    }
}
