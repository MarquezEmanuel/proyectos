<?php

namespace app\modelo;

use app\modelo\Conexion;

/**
 * 
 * @package app\seguridad\modelo
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ColeccionRoles {

    

    /**
     * @see vw_informe Consulta cuando modulo es ROLES.
     */
    public static function listarInformesRol(): array {
        $consulta = "SELECT * FROM vw_informe WHERE modulo = 'ROLES'";
        return Conexion::getInstancia()->seleccionar($consulta);
    }    

}
