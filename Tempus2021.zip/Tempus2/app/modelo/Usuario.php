<?php

namespace app\modelo;

use app\modelo\Conexion;

/**
 * Description of Usuario
 *
 * @author Emanuel
 */
class Usuario
{

    /** @var integer Identificador del usuario en la base de datos */
    private $id;

    /** @var string Correo electronico del usuario */
    private $email;

    /** @var string Nombre del usuario */
    private $nombre;

    /** @var string Metodo de acceso al sistema (Manual o Google) */
    private $metodoLogin;

    /** @var string Estado del usuario (Activo o Inactivo) */
    private $estado;

    /** @var integer Rol que posee el usuario dentro del sistema */
    private $rol;

    public function __construct($parametros)
    {
        $this->setId($parametros[0]);
        $this->setEmail($parametros[1]);
        $this->setNombre($parametros[2]);
        $this->setMetodo($parametros[3]);
        $this->setEstado($parametros[4]);
        $this->setRol($parametros[5]);
    }

    public function getId()
    {
        return $this->id;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function getNombre()
    {
        return $this->nombre;
    }

    public function getMetodo()
    {
        return $this->metodo;
    }

    public function getEstado()
    {
        return $this->estado;
    }

    public function getRol()
    {
        return $this->rol;
    }

    public function setId($id)
    {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    public function setMetodo($metodo)
    {
        $this->metodo = $metodo;
    }

    public function setEstado($estado)
    {
        $this->estado = $estado;
    }

    public function setRol($rol)
    {
        $this->rol = $rol;
    }

    public function borrar()
    {
        if ($this->id) {
            $relacion = $this->borrarRelacionRol();
            if ($relacion == 2) {
                $consulta = "DELETE FROM usuario WHERE id = {$this->id}";
                return Conexion::getInstancia()->borrar($consulta);
            }
            return array($relacion, "No se realizo la eliminación del usuario");
        }
        return array(0, "No se pudo hacer referencia al usuario");
    }

    private function borrarRelacionRol()
    {
        $consulta = "DELETE FROM rol_usuario WHERE usuario_id = {$this->id}";
        $resultado = Conexion::getInstancia()->borrar($consulta);
        return $resultado[0];
    }

    private function obtenerRol($idRol)
    {
        $rol = new Rol($idRol);
        $resultado = $rol->obtenerPorIdentificador();
        $this->rol = ($resultado[0] == 2) ? $rol : NULL;
        return $resultado;
    }
}
