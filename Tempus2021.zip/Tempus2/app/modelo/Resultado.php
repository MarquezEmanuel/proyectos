<?php

namespace app\modelo;

use app\modelo\Constantes;

class Resultado
{

    /** @var int */
    private $codigo;

    /** @var string */
    private $mensaje;

    private $datos;

    public function __construct($codigo = NULL, $mensaje = NULL, $datos = NULL)
    {
        $this->codigo = $codigo;
        $this->mensaje = $mensaje;
        $this->datos = $datos;
    }

    public function isSuccess()
    {
        return ($this->codigo == Constantes::COD_SUCCESS);
    }

    public function getCodigo()
    {
        return $this->codigo;
    }

    public function getMensaje()
    {
        return $this->mensaje;
    }

    public function getDatos()
    {
        return $this->datos;
    }

    public function setCodigo($codigo)
    {
        $this->codigo = $codigo;
    }

    public function setMensaje($mensaje)
    {
        $this->mensaje = $mensaje;
    }

    public function setDatos($datos)
    {
        $this->datos = $datos;
    }

    /**
     * Obtiene la clase correspondiente del alert segun el valor del codigo del resultado.
     * @return String la clase correspondiente segun el codigo.
     */
    public function getClaseAlerta()
    {
        if (!is_null($this->codigo)) {
            switch ($this->codigo) {
                case Constantes::COD_ERROR:
                    return "alert-danger";
                case Constantes::COD_WARNING:
                    return "alert-warning";
                case Constantes::COD_SUCCESS:
                    return "alert-success";
                case Constantes::COD_INFO:
                    return "alert-info";
                default:
                    return "";
            }
        }
        return "";
    }
}
