<?php

namespace app\modelo;

use app\modelo\Conexion;

class Permiso
{

    /** @var integer Identificador del permiso en la base de datos */
    private $id;

    /** @var string Nombre del permiso */
    private $nombre;

    /**
     * Constructor de clase.
     */
    public function __construct($id = NULL, $nombre = NULL)
    {
        $this->setId($id);
        $this->setNombre($nombre);
    }

    /**
     * Retorna el identificador del permiso.
     * @return int Identificador del permiso.
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Retorna el nombre del permiso.
     * @return string Nombre del permiso.
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Modifica el identificador del permiso solo si es mayor que cero.
     * @param int $id Identificador del permiso.
     */
    public function setId($id)
    {
        $this->id = ($id > 0) ? $id : NULL;
    }

    /**
     * Modifica el nombre del permiso solo si cumple con el formato requerido.
     * @param string $nombre Nombre del permiso.
     */
    public function setNombre($nombre)
    {
        if (preg_match("/^[A-Za-z_]{5,15}$/", $nombre)) {
            $this->nombre = strtoupper($nombre);
        }
    }

    public function setear($datos)
    {
        $this->id = isset($datos['id']) ? $datos['id'] : NULL;
        $this->nombre = isset($datos['nombre']) ? $datos['nombre'] : NULL;
    }

    /** 
     * Retorna los datos para hacer un insert a la base de datos.
     * @return array Arreglo con los datos del permiso [nombre].
     */
    public function getArrayInsert()
    {
        return [$this->nombre];
    }

    /** 
     * Retorna los datos para hacer un update a la base de datos.
     * @return array Arreglo con los datos del permiso [nombre, id]. 
     */
    public function getArrayUpdate()
    {
        return [$this->nombre, $this->id];
    }

    public function borrar(): array
    {
        if ($this->id) {
            $consulta = "DELETE FROM permiso WHERE id = {$this->id}";
            $resultado = Conexion::getInstancia()->borrar($consulta);
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al permiso");
    }
}
