<?php

namespace app\modelo;

use app\modelo\Conexion;
use app\modelo\Log;
use app\modelo\Util;

/**
 * 
 * @package app\aula\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Aula
{

    /** @var integer Identificador del aula en la base de datos [INT]. */
    private $id;

    /** @var string Nombre del aula [NVARCHAR(50) NOT NULL]. */
    private $nombre;

    /** @var string Sector donde se ubica el aula [NVARCHAR(5) NOT NULL]. */
    private $sector;

    /** @var array Arreglo de clases asociadas. */
    private $clases;

    /** @var array Arreglo de mesas asociadas. */
    private $mesas;

    public function __construct($id = NULL, $nombre = NULL, $sector = NULL)
    {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setSector($sector);
    }

    /**
     * Retorna el identificador del aula.
     * @return int Identificador del aula.
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Retorna el nombre del aula.
     * @return string Nombre del aula.
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Retorna el nombre del sector donde se encuentra el aula.
     * @return string Nombre del sector.
     */
    public function getSector()
    {
        return $this->sector;
    }

    /** 
     * Retorna el listado de clases asociadas al aula.
     * @return array Arreglo de clases. 
     */
    public function getClases()
    {
        return $this->clases;
    }

    /** 
     * Retorna el listado de mesas asociadas al aula.
     * @return array Arreglo de clases. 
     */
    public function getMesas()
    {
        return $this->mesas;
    }

    /**
     * Modificar el identificador del aula solo si es mayor que cero.
     * @param int $id Identificador del aula.
     */
    public function setId($id)
    {
        $this->id = ($id > 0) ? $id : NULL;
    }

    /**
     * Modificar el nombre del aula solo si cumple el formato. 
     * @param string $nombre Nombre de aula.
     */
    public function setNombre($nombre)
    {
        if (Util::validarAulaNombre($nombre)) {
            $this->nombre = Util::convertirCamelCase($nombre);
        }
    }

    /**
     * Modificar el nombre del sector solo si cumple el formato. 
     * @param string $sector Nombre del sector.
     */
    public function setSector($sector)
    {
        if (Util::validarAulaSector($sector)) {
            $this->sector = Util::convertirCamelCase($sector);
        }
    }

    /** 
     * Modificar el arreglo de clases.
     * @param array $clases Arreglo de clases.
     */
    public function setClases($clases)
    {
        $this->clases = $clases;
    }

    /** 
     * Modificar el arreglo de mesas.
     * @param array $clases Arreglo de mesas.
     */
    public function setMesas($mesas)
    {
        $this->mesas = $mesas;
    }

    public function setear($datos)
    {
        if (!empty($datos)) {
            $this->id = $datos['id'];
            $this->sector = $datos['sector'];
            $this->nombre = $datos['nombre'];
        }
    }

    /** 
     * Retorna los datos para hacer un insert a la base de datos.
     * @return array Arreglo con los datos del aula [nombre].
     */
    public function getArrayInsert()
    {
        return [$this->nombre, $this->sector];
    }

    /** 
     * Retorna los datos para hacer un update a la base de datos.
     * @return array Arreglo con los datos del aula [nombre, sector, id]. 
     */
    public function getArrayUpdate()
    {
        return [$this->nombre, $this->sector, $this->id];
    }

    /** 
     * Indica si el aula posee todos los campos obligatorios. El metodo no chequea que
     * el aula posea identificador.
     * @return boolean True si tiene todos los campos obligatorios o false en caso contrario. 
     */
    public function esValida()
    {
        return ($this->nombre && $this->sector) ? true : false;
    }
}
