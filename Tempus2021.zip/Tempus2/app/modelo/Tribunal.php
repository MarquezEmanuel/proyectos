<?php

namespace app\modelo;


/**
 * 
 * @package app\mesa\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Tribunal
{

    /** @var int Identificador del tribunal */
    private $id;

    /** @var array Docentes que componen el tribunal */
    private $docentes;

    /**
     * Constructor de clase
     */
    public function __construct($id = NULL)
    {
        $this->setId($id);
        $this->docentes = array();
    }

    /**
     * Retorna el identificador del tribunal.
     * @return int Identificador del tribunal.
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Retorna los docentes que componen el tribunal.
     * @return array Docentes del tribunal.
     */
    public function getDocentes()
    {
        return $this->docentes;
    }

    /**
     * Modifica el identificador del tribunal solo si es mayor que cero.
     * @param int $id Identificador del tribunal.
     */
    public function setId($id)
    {
        $this->id = ($id > 0) ? $id : NULL;
    }
}
