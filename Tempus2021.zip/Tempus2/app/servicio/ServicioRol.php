<?php

namespace app\servicio;

use app\modelo\Rol;
use app\repositorio\RepositorioRol;
use app\repositorio\RepositorioLog;

class ServicioRol
{
    private $repoRol;
    private $repoLog;

    public function __construct()
    {
        $this->repoRol = new RepositorioRol();
        $this->repoLog = new RepositorioLog();
    }

    public function crear($nombre, $permisos)
    {
        $this->repoRol->iniciarTransaccion();
        $resultados = array();
        $rol = new Rol(NULL, $nombre, $permisos);
        $resultados[] = $this->repoRol->crear($rol);
        $id = $rol->getId();
        $resultados[] = $this->repoRol->agregarPermisos($id, $permisos);
        foreach ($resultados as $resultado) {
            if (!$resultado->isSuccess()) {
                $this->repoRol->rollback();
                $this->repoLog->guardarErrores($this->repoRol->getLogs());
                return $resultado;
            }
        }
        $this->repoRol->commit();
        return $resultado[0];
    }

    public function modificar($id, $nombre, $permisos)
    {
    }

    public function listar()
    {
        $resultado = $this->repoRol->listar();
        if (!$resultado->isSuccess()) {
            $this->repoLog->guardarErrores($this->repoRol->getLogs());
        }
        return $resultado;
    }

    public function listarParaBusqueda($nombre)
    {
        $resultado = $this->repoRol->listarParaBusqueda($nombre);
        if (!$resultado->isSuccess()) {
            $this->repoLog->guardarErrores($this->repoRol->getLogs());
        }
        return $resultado;
    }

    public function obtenerPorID($id)
    {
        $rol = new Rol($id);
        $resultado = $this->repoRol->obtenerPorID($rol);
        if (!$resultado->isSuccess()) {
            $this->repoLog->guardarErrores($this->repoRol->getLogs());
        }
        return $resultado;
    }

    public function seleccionar($nombre)
    {
        $resultado = $this->repoRol->seleccionar($nombre);
        if (!$resultado->isSuccess()) {
            $this->repoLog->guardarErrores($this->repoRol->getLogs());
        }
        return $resultado;
    }
}
