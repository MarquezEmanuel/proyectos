<?php

namespace app\servicio;

use app\modelo\Permiso;
use app\repositorio\RepositorioPermiso;
use app\repositorio\RepositorioLog;

class ServicioPermiso
{
    private $repoPermiso;
    private $repoLog;

    public function __construct()
    {
        $this->repoPermiso = new repositorioPermiso();
        $this->repoLog = new RepositorioLog();
    }

    public function crear($nombre)
    {
        $permiso = new Permiso(null, $nombre);
        $resultado = $this->repoPermiso->crear($permiso);
        if (!$resultado->isSuccess()) {
            $this->repoLog->guardarErrores($this->repoPermiso->getLogs());
        }
        return $resultado;
    }

    public function listar()
    {
        $resultado = $this->repoPermiso->listar();
        if (!$resultado->isSuccess()) {
            $this->repoLog->guardarErrores($this->repoPermiso->getLogs());
        }
        return $resultado;
    }

    public function listarPorIDRol($id)
    {
        $resultado = $this->repoPermiso->listarPorIDRol($id);
        if (!$resultado->isSuccess()) {
            $this->repoLog->guardarErrores($this->repoPermiso->getLogs());
        }
        return $resultado;
    }

    public function modificar($id, $nombre)
    {
        $permiso = new Permiso($id, $nombre);
        $resultado = $this->repoPermiso->modificar($permiso);
        if (!$resultado->isSuccess()) {
            $this->repoLog->guardarErrores($this->repoPermiso->getLogs());
        }
        return $resultado;
    }

    public function obtenerPorID($id)
    {
        $permiso = new Permiso($id);
        $resultado = $this->repoPermiso->obtenerPorID($permiso);
        if (!$resultado->isSuccess()) {
            $this->repoLog->guardarErrores($this->repoPermiso->getLogs());
        }
        return $resultado;
    }
}
