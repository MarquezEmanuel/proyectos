<?php

namespace app\servicio;

use app\repositorio\RepositorioRol;
use app\repositorio\RepositorioUsuario;

use app\modelo\Usuario;
use app\modelo\Rol;

class ServicioUsuario
{

    private $repoUsuario;
    private $repoRol;

    public function __construct()
    {
        $this->repoUsuario = new RepositorioUsuario();
        $this->repoRol = new RepositorioRol();
    }

    public function login($email)
    {
        $resultado01 = $this->repoUsuario->login($email);
        if ($resultado01->isSuccess()) {
            $datosUsuario = $resultado01->getDatos()[0];
            $usuario = new Usuario($datosUsuario);
            $resultado02 = $this->repoRol->obtenerPorID($usuario->getRol());
            if ($resultado02->isSuccess()) {
                
            }
            $resultado01->setDatos($usuario);
        }
    }
}
