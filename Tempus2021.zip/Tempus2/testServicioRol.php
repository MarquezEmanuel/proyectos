<?php
include_once './app/modelo/Autocargador.php';
include_once './config/inc_config.php';

use app\modelo\Encriptador;
use app\modelo\AutoCargador;
use app\modelo\Log;
use app\modelo\Resultado;
use app\repositorio\MySQL;
use app\repositorio\RepositorioPermiso;
use app\modelo\Permiso;

use app\servicio\ServicioRol;

AutoCargador::cargarModulos();


$servicio = new ServicioRol();

$resultado = $servicio->crear('MIROL', array(1, 9));
var_dump($resultado);
