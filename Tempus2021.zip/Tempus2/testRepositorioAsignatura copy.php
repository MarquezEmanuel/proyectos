<?php
include_once './app/modelo/Autocargador.php';
include_once './config/inc_config.php';

use app\modelo\Encriptador;
use app\modelo\AutoCargador;
use app\modelo\Log;
use app\modelo\Resultado;
use app\repositorio\MySQL;
use app\repositorio\RepositorioAsignatura;

AutoCargador::cargarModulos();

$repositorio = new repositorioAsignatura();

$parametros= array('MP', 'Materia de prueba');
$resultado = $repositorio->crear($parametros);
if ($resultado->isSuccess()) {
    echo '<br>' . $resultado->getMensaje();
    $listado = $resultado->getDatos();
    var_dump($listado);
} else {
    var_dump($repositorio->getLogs());
    echo '<br>' .  $resultado->getMensaje();
}

$resultado = $repositorio->obtenerPorID(190);
if ($resultado->isSuccess()) {
    echo '<br>' . $resultado->getMensaje();
    $listado = $resultado->getDatos();
    var_dump($listado);
} else {
    var_dump($repositorio->getLogs());
    echo '<br>' .  $resultado->getMensaje();
}


$resultado = $repositorio->obtenerPorNombreLargo('MATERIA DE PRUEBA');
if ($resultado->isSuccess()) {
    echo '<br>' . $resultado->getMensaje();
    $listado = $resultado->getDatos();
    var_dump($listado);
} else {
    var_dump($repositorio->getLogs());
    echo '<br>' .  $resultado->getMensaje();
}

$resultado = $repositorio->listarPorNombreLargo('MATERIA');
if ($resultado->isSuccess()) {
    echo '<br>' . $resultado->getMensaje();
    $listado = $resultado->getDatos();
    var_dump($listado);
} else {
    var_dump($repositorio->getLogs());
    echo '<br>' .  $resultado->getMensaje();
}

$resultado = $repositorio->listarPorCodigoCarrera(4);
if ($resultado->isSuccess()) {
    echo '<br>' . $resultado->getMensaje();
    $listado = $resultado->getDatos();
    var_dump($listado);
} else {
    var_dump($repositorio->getLogs());
    echo '<br>' .  $resultado->getMensaje();
}

$resultado = $repositorio->listarPorCondicionCarrera(4, 'geografia', true);
if ($resultado->isSuccess()) {
    echo '<br>' . $resultado->getMensaje();
    $listado = $resultado->getDatos();
    var_dump($listado);
} else {
    var_dump($repositorio->getLogs());
    echo '<br>' .  $resultado->getMensaje();
}