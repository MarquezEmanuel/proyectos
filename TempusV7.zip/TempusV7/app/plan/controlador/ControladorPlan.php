<?php

namespace app\plan\controlador;

use app\plan\modelo\Plan;
use app\cursada\modelo\Cursada;
use app\plan\modelo\ColeccionPlanes as Planes;
use app\principal\modelo\Conexion;

/**
 * 
 * @package app\plan\controlador
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ControladorPlan {

    public function buscarPlanSinCursada($nombreAsignatura) {
        return Planes::buscarPlanSinCursada($nombreAsignatura);
    }

    public function buscarPlanSinMesaExamen($nombreAsignatura) {
        return Planes::buscarPlanSinMesaExamen($nombreAsignatura);
    }

    public function crear($asignatura, $carrera, $cursada, $mesa, $anio) {
        if (Conexion::getInstancia()->iniciarTransaccion()) {
            $plan = new Plan(NULL, $asignatura, $carrera, $cursada, $mesa, $anio);
            $resultado = $plan->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            Conexion::getInstancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function crearCursada(Plan $plan, $clases) {
        if (Conexion::getInstancia()->iniciarTransaccion()) {
            $cursada = new Cursada();
            $agregada = TRUE;
            foreach ($clases as $clase) {
                $cargada = $cursada->agregarClase($clase);
                $agregada = ($cargada) ? $agregada : FALSE;
            }
            if ($agregada) {
                $plan->setCursada($cursada);
                $resultado = $plan->crearCursada();
                $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
                Conexion::getInstancia()->finalizarTransaccion($confirmar);
                return $resultado;
            }
            return array(0, "No se pudieron agregar todas las clases a la cursada");
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

}
