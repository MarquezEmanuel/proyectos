<?php

namespace app\plan\modelo;

use app\principal\modelo\Conexion;
use app\principal\modelo\Log;

/**
 * 
 * @package app\plan\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ColeccionPlanes {

    public static function buscarPlanSinCursada($nombreAsignatura) {
        $expresion = "/^[a-záéíóúñü0-9,. ]{0,60}$/";
        if (preg_match($expresion, mb_strtolower($nombreAsignatura))) {
            $consulta = "SELECT idPlan, nombreLargoAsignatura, nombreLargoCarrera "
                    . "FROM vw_plan WHERE cursada = 'No' COLLATE utf8mb4_unicode_ci AND "
                    . "nombreLargoAsignatura LIKE '%{$nombreAsignatura}%'";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "El nombre no cumple con el formato requerido");
    }

    public static function buscarPlanSinMesaExamen($nombreAsignatura) {
        $expresion = "/^[a-záéíóúñü0-9,. ]{0,60}$/";
        if (preg_match($expresion, mb_strtolower($nombreAsignatura))) {
            $consulta = "SELECT idPlan, nombreLargoAsignatura, nombreLargoCarrera "
                    . "FROM vw_plan WHERE mesaExamen = 'No' COLLATE utf8mb4_unicode_ci AND "
                    . "nombreLargoAsignatura LIKE '%{$nombreAsignatura}%'";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "El nombre no cumple con el formato requerido");
    }

    public static function quitarMesasExamen() {
        Log::guardar("INF", "COLECCION PLANES --> QUITAR MESAS DE EXAMEN");
        $consulta = "UPDATE plan SET idMesaExamen = NULL";
        $resultado = Conexion::getInstancia()->modificar($consulta);
        return $resultado;
    }

}
