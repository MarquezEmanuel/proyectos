<?php

namespace app\plan\modelo;

use app\asignatura\modelo\Asignatura as Asignatura;
use app\carrera\modelo\Carrera as Carrera;
use app\principal\modelo\Conexion as Conexion;
use app\principal\modelo\Log as Log;
use app\util\modelo\Util as Util;

/**
 * 
 * @package app\plan\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Plan {

    private $id;
    private $asignatura;
    private $carrera;
    private $mesa;
    private $anio;
    private $fechaCreacion;
    private $observacion;
    private $clases;

    public function __construct($id = NULL, $asignatura = NULL, $carrera = NULL, $anio = NULL, $fechaCreacion = NULL, $observacion = NULL) {
        $this->setId($id);
        $this->setAsignatura($asignatura);
        $this->setCarrera($carrera);
        $this->setAnio($anio);
        $this->setFechaCreacion($fechaCreacion);
        $this->setObservacion($observacion);
    }

    /**
     * Retorna el identificador de la cursada.
     * @return int Identificador de la cursada.
     */
    public function getId() {
        return $this->id;
    }

    /**
     * Retorna la asignatura de la cursada.
     * @return Asignatura Asignatura de cursada.
     */
    public function getAsignatura() {
        return $this->asignatura;
    }

    /**
     * Retorna la carrera de la cursada.
     * @return Carrera Carrera de la cursada.
     */
    public function getCarrera() {
        return $this->carrera;
    }

    public function getMesa() {
        return $this->mesa;
    }

    /**
     * Retorna el anio de la cursada.
     * @return int Anio de cursada.
     */
    public function getAnio() {
        return $this->anio;
    }

    /**
     * Retorna la fecha de creacion de la cursada.
     * @return string Fecha de creacion.
     */
    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    /**
     * Retorna la observacion de la cursada.
     * @return string Codigo de la carrera.
     */
    public function getObservacion() {
        return $this->observacion;
    }

    public function getClases() {
        return $this->clases;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setAsignatura(Asignatura $asignatura) {
        if ($asignatura instanceof Asignatura) {
            $this->asignatura = $asignatura;
        }
    }

    public function setCarrera(Carrera $carrera) {
        if ($carrera instanceof Carrera) {
            $this->carrera = $carrera;
        }
    }

    public function setMesa($mesa) {
        $this->mesa = $mesa;
    }

    public function setAnio($anio) {
        $this->anio = $anio;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setObservacion($observacion) {
        $this->observacion = $observacion;
    }

    public function setClases($clases) {
        $this->clases = $clases;
    }

    public function crear() {
        if ($this->asignatura && $this->carrera && $this->anio && $this->observacion) {
            $idAsignatura = $this->crearAsignatura();
            $idCarrera = $this->crearCarrera();
            $consulta = "INSERT INTO plan VALUES (NULL, {$idAsignatura}, '{$idCarrera}', {$this->anio}, NOW(),'{$this->observacion}')";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                Log::guardarActividad("PLAN --> NUEVA ({$idAsignatura}, {$idCarrera}, {$this->anio})");
                $this->id = $resultado[2];
            }
            return $resultado;
        }
        return array(0, "Los campos para crear la cursada no cumplen con el formato requerido");
    }

    private function crearAsignatura() {
        if (!$this->asignatura->getId()) {
            $creacion = $this->asignatura->crear();
            return ($creacion[0] == 2) ? $this->asignatura->getId() : NULL;
        }
        return $this->asignatura->getId();
    }

    private function crearCarrera() {
        $creacion = $this->carrera->crear();
        return ($creacion[0] == 2) ? $this->carrera->getId() : NULL;
    }

    public function obtenerPorIdentificador() {
        if ($this->id) {
            $consulta = "SELECT * FROM plan WHERE id = {$this->id}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->id = $fila['id'];
                $this->anio = $fila['anio'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $rasi = $this->obtenerAsignatura($fila['idAsignatura']);
                $rcar = $this->obtenerAsignatura($fila['idCarrera']);
                $exito = array(2, "Se obtuvo la información del plan correctamente");
                return ($rasi == 2 && $rcar == 2) ? $exito : array(1, "No se obtuvo la información del plan");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la cursada");
    }

    private function obtenerAsignatura(int $idAsignatura): int {
        $asignatura = new Asignatura($idAsignatura);
        $resultado = $asignatura->obtenerPorIdentificador();
        $this->asignatura = ($resultado[0] == 2) ? $asignatura : NULL;
        return $resultado[0];
    }

    private function obtenerCarrera(string $idCarrera) {
        $carrera = new Carrera($idCarrera);
        $resultado = $carrera->obtenerPorIdentificador();
        $this->carrera = ($resultado[0] == 2) ? $carrera : NULL;
        return $resultado[0];
    }

}
