<?php

namespace app\plan\modelo;

use app\asignatura\modelo\Asignatura as Asignatura;
use app\carrera\modelo\Carrera as Carrera;
use app\principal\modelo\Conexion as Conexion;
use app\principal\modelo\Log as Log;
use app\mesa\modelo\MesaExamen as MesaExamen;

/**
 * 
 * @package app\plan\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Plan {

    /** @var int Identificador del plan. */
    private $id;

    /** @var Asignatura Asignatura relacionada al plan. */
    private $asignatura;

    /** @var Carrera Carrera a la que pertenece la asignatura. */
    private $carrera;

    /** @var array Listado de clases para la cursada. */
    private $cursada;

    /** @var MesaExamen Mesa para la asignatura dentro de la carrera. */
    private $mesa;

    /** @var int Anio en que se dicta la materia dentro de la carrera. */
    private $anio;

    /** @var string Fecha de creacion del plan. */
    private $fechaCreacion;

    /** @var atring Observacion para el plan. */
    private $observacion;

    public function __construct($id = NULL, $asignatura = NULL, $carrera = NULL, $cursada = NULL, $mesa = NULL, $anio = NULL, $fechaCreacion = NULL, $observacion = NULL) {
        $this->setId($id);
        $this->setAsignatura($asignatura);
        $this->setCarrera($carrera);
        $this->setCursada($cursada);
        $this->setMesa($mesa);
        $this->setAnio($anio);
        $this->setFechaCreacion($fechaCreacion);
        $this->setObservacion($observacion);
    }

    /**
     * Retorna el identificador de la cursada.
     * @return int Identificador de la cursada.
     */
    public function getId() {
        return $this->id;
    }

    /**
     * Retorna la asignatura de la cursada.
     * @return Asignatura Asignatura de cursada.
     */
    public function getAsignatura() {
        return $this->asignatura;
    }

    /**
     * Retorna la carrera de la cursada.
     * @return Carrera Carrera de la cursada.
     */
    public function getCarrera() {
        return $this->carrera;
    }

    public function getMesa() {
        return $this->mesa;
    }

    /**
     * Retorna el anio de la cursada.
     * @return int Anio de cursada.
     */
    public function getAnio() {
        return $this->anio;
    }

    /**
     * Retorna la fecha de creacion de la cursada.
     * @return string Fecha de creacion.
     */
    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    /**
     * Retorna la observacion de la cursada.
     * @return string Codigo de la carrera.
     */
    public function getObservacion() {
        return $this->observacion;
    }

    public function getCursada() {
        return $this->cursada;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setAsignatura(Asignatura $asignatura) {
        if ($asignatura instanceof Asignatura) {
            $this->asignatura = $asignatura;
        }
    }

    public function setCarrera(Carrera $carrera) {
        if ($carrera instanceof Carrera) {
            $this->carrera = $carrera;
        }
    }

    public function setMesa($mesa) {
        if ($mesa instanceof MesaExamen) {
            $this->mesa = $mesa;
        }
    }

    public function setAnio($anio) {
        $this->anio = $anio;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setObservacion($observacion) {
        $this->observacion = $observacion;
    }

    public function setCursada($cursada) {
        $this->cursada = $cursada;
    }

    public function crear() {
        if ($this->asignatura && $this->carrera && $this->anio && $this->observacion) {
            $idAsignatura = $this->crearAsignatura();
            $idCarrera = $this->crearCarrera();
            $idMesaExamen = $this->crearMesaExamen();
            $consulta = "INSERT INTO plan VALUES (NULL, {$idAsignatura}, '{$idCarrera}', {$idMesaExamen}, {$this->anio}, NOW(),'{$this->observacion}')";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                Log::guardarActividad("PLAN --> NUEVO ({$idAsignatura}, {$idCarrera}, {$this->anio})");
                $this->id = $resultado[2];
            }
            return $resultado;
        }
        return array(0, "Los campos para crear la cursada no cumplen con el formato requerido");
    }

    /**
     * Crear asignatura nueva u obtener datos. Crea la asignatura, en caso de no 
     * existir, y retorna el identificador relacionado.
     */
    private function crearAsignatura() {
        if (!$this->asignatura->getId()) {
            $creacion = $this->asignatura->crear();
            return ($creacion[0] == 2) ? $this->asignatura->getId() : NULL;
        }
        return $this->asignatura->getId();
    }

    /**
     * Crear carrera nueva u obtener datos. Crea la carrera, en caso de no existir,
     * y retorna el identificador relacionado.
     */
    private function crearCarrera() {
        $creacion = $this->carrera->crear();
        return ($creacion[0] == 2) ? $this->carrera->getId() : NULL;
    }

    /**
     * Crear mesa de examen u obtener datos. Crear la mesa de examen, en caso de
     * no existir, y retorna el identificador relacionado o NULL.
     */
    private function crearMesaExamen() {
        if ($this->mesa) {
            if (!$this->mesa->getId()) {
                $creacion = $this->mesa->crear();
                return ($creacion[0] == 2) ? $this->mesa->getId() : NULL;
            }
            return $this->mesa->getId();
        }
        return "NULL";
    }

    /**
     * Obtiener datos del plan por su identificador.
     */
    public function obtenerPorIdentificador() {
        if ($this->id) {
            $consulta = "SELECT * FROM plan WHERE id = {$this->id}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->id = $fila['id'];
                $this->anio = $fila['anio'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->mesa = $fila['idMesaExamen'];
                $rasi = $this->obtenerAsignatura($fila['idAsignatura']);
                $rcar = $this->obtenerCarrera($fila['idCarrera']);
                $exito = array(2, "Se obtuvo la información del plan correctamente");
                return ($rasi == 2 && $rcar == 2) ? $exito : array(1, "No se obtuvo la información del plan");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la cursada");
    }

    private function obtenerAsignatura(int $idAsignatura): int {
        $asignatura = new Asignatura($idAsignatura);
        $resultado = $asignatura->obtenerPorIdentificador();
        $this->asignatura = ($resultado[0] == 2) ? $asignatura : NULL;
        return $resultado[0];
    }

    private function obtenerCarrera(string $idCarrera) {
        $carrera = new Carrera($idCarrera);
        $resultado = $carrera->obtenerPorIdentificador();
        $this->carrera = ($resultado[0] == 2) ? $carrera : NULL;
        return $resultado[0];
    }

    public function obtenerMesaExamen() {
        if (gettype($this->mesa) == "int") {
            
        }
        return 1;
    }

}
