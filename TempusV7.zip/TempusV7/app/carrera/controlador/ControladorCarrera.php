<?php

namespace app\carrera\controlador;

class ControladorCarrera {
    
}
