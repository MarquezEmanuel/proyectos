<?php

namespace app\carrera\controlador;

use app\carrera\modelo\ColeccionCarreras as Carreras;

/**
 * 
 * @package app\carrera\controlador
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ControladorCarrera {

    public function buscarPorNombre($nombreCarrera) {
        return Carreras::buscarPorNombre($nombreCarrera);
    }

    public function listarResumenCarreras($limite) {
        return Carreras::listarResumenCarreras($limite);
    }

}
