<?php

/* SE INCLUYE EL ARCHIVO DE CONSTANTES Y EL AUTOLOAD */

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

/* SE REFERENCIAN LOS NAMESPACE */

use app\aula\controlador\ControladorAula;
use app\principal\controlador\ControladorHTML;
use app\principal\modelo\AutoCargador;

AutoCargador::cargarModulos();

$controlador = new ControladorAula();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $campo = $_POST['campo'];
    $valor = $_POST['valor'];
    $datos = ($valor) ? $campo . ", '{$valor}'" : $campo . ", TODAS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscarPorSectorNombre($campo, $valor);
    $_SESSION['BUSAUL'] = array($campo, $valor, $datos);
} else {
    if (isset($_SESSION['BUSAUL'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSAUL'];
        $campo = $parametros[0];
        $valor = $parametros[1];
        $filtro = "Última búsqueda realizada: " . $parametros[2];
        $resultado = $controlador->buscarPorSectorNombre($campo, $valor);
        $_SESSION['BUSAUL'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $limite = 10;
        $resultado = $controlador->listarResumenAulas($limite);
        $filtro = "Resumen de aulas";
        $_SESSION['BUSAUL'] = NULL;
    }
}
$html = "";
if ($resultado[0] == 2) {
    $aulas = $resultado[1];
    $filas = "";
    foreach ($aulas as $aula) {
        if ($aula['clases'] == 0 && $aula['llamados'] == 0) {
            $operaciones = "
                <button class='btn btn-outline-info detalle' 
                        name='{$aula['id']}' 
                        title='Ver detalle'><i class='fas fa-eye'></i>
                </button>
                <button class='btn btn-outline-warning editar' 
                        name='{$aula['id']}' 
                        title='Editar'><i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger borrar' 
                        name='{$aula['id']}' 
                        title='Borrar'><i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-info detalle' 
                        name='{$aula['id']}' 
                        title='Ver detalle'><i class='fas fa-eye'></i>
                </button>
                <button class='btn btn-outline-warning editar' 
                        name='{$aula['id']}' 
                        title='Editar'><i class='far fa-edit'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td class='align-middle'>{$aula['sector']}</td>
                <td class='align-middle'>" . utf8_encode($aula['nombre']) . "</td>
                <td class='align-middle'>{$aula['clases']}</td>
                <td class='align-middle'>{$aula['llamados']}</td>   
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>{$operaciones}</div>
                </td>
            </tr>";
    }
    $html = '
        <div class="table-responsive mt-4">
            <table id="tablaBuscarAulas" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th title="Nombre del sector">Sector</th>
                        <th title="Nombre del aula">Nombre</th>
                        <th title="Cantidad de clases asociadas">Clases</th>
                        <th title="Cantidad de llamados asociados">Llamados</th>
                        <th title="Operaciones disponibles" class="text-center">Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $codigo = $resultado[0];
    $mensaje = $resultado[1];
    $html = ControladorHTML::mostrarAlertaResultadoBusqueda($codigo, $mensaje);
}

echo ControladorHTML::mostrarCardResultadoBusqueda($filtro, $html);
