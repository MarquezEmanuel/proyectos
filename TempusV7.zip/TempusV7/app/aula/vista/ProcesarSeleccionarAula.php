<?php

/* SE INCLUYE EL ARCHIVO DE CONSTANTES Y EL AUTOLOAD */

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

/* SE REFERENCIAN LOS NAMESPACE */

use app\aula\controlador\ControladorAula;
use app\principal\modelo\AutoCargador;

AutoCargador::cargarModulos();

$controlador = new ControladorAula();
$arreglo = array();
if (isset($_POST['nombre'])) {
    $campo = "nombre";
    $nombre = $_POST['nombre'];
    $aulas = $controlador->buscar($campo, $nombre);
} else {
    $aulas = $controlador->listarUltimasCreadas();
}

if (gettype($aulas) == "object") {
    while ($aula = $aulas->fetch_assoc()) {
        $arreglo[] = array('id' => $aula["idaula"], 'text' => $aula["sector"] . " - " . $aula["nombre"]);
    }
} else {
    $arreglo[] = array('id' => "NO", 'text' => "Sin resultados");
}
echo json_encode($arreglo);
