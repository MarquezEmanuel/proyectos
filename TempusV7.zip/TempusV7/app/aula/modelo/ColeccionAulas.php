<?php

namespace modelos;

/**
 * Description of Aulas
 * 
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ColeccionAulas {

    public static function buscar($campo, $valor) {
        if ($campo) {
            $consulta = "SELECT aul.*, (CASE WHEN cla.clases IS NULL THEN 0 ELSE cla.clases END) clases,"
                    . "(CASE WHEN lla.llamados IS NULL THEN 0 ELSE lla.llamados END) llamados "
                    . "FROM aula aul LEFT JOIN (SELECT idaula, COUNT(idclase) clases "
                    . "FROM clase GROUP BY idaula) cla ON cla.idaula = aul.idaula "
                    . "LEFT JOIN (SELECT idaula, COUNT(idllamado) llamados "
                    . "FROM llamado GROUP BY idaula) lla ON lla.idaula = aul.idaula "
                    . "WHERE {$campo} LIKE '%{$valor}%'";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "Los datos recibidos no cumplen con el formato requerido");
    }

    /*
      public static function listar() {
      $consulta = "SELECT * FROM aula";
      return Conexion::getInstancia()->seleccionar($consulta);
      }
     */

    public static function listarAulasDisponibles($dia, $desde, $hasta, $nombre) {
        if ($dia && $desde && $hasta && $nombre) {
            $consulta = "SELECT * FROM aula WHERE nombre LIKE '%{$nombre}%' AND idaula NOT IN "
                    . "(SELECT idaula FROM clase WHERE dia = {$dia} AND "
                    . "((desde >= '{$desde}' AND desde < '{$hasta}') OR "
                    . "(hasta > '{$desde}' AND hasta < '{$hasta}') OR "
                    . "(desde < '{$desde}' AND hasta > '{$desde}') "
                    . ")) OR idaula IN (SELECT idaula FROM clase WHERE dia = {$dia} AND "
                    . "desde = '{$desde}' and hasta='{$hasta}')";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "Los datos recibidos no cumplen con el formato requerido");
    }

    public static function listarHorariosClase($idAula) {
        if ($idAula) {
            $consulta = "SELECT DISTINCT idAsignatura, nombreAsignatura, idClase, "
                    . "numeroDia, nombreDia, desde, hasta, idAula, fechaMod "
                    . "FROM vista_aulascursadas WHERE idAula = {$idAula} "
                    . "ORDER BY numeroDia asc, desde";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se pudo hacer referencia al aula");
    }

    public static function listarInformeCursada($disponible, $dia, $desde, $hasta) {
        if ($dia && $desde && $hasta) {
            $consulta = "SELECT * FROM aula WHERE idaula {$disponible} (SELECT idaula FROM clase WHERE ";
            $consulta .= ($dia != "NO") ? "dia = {$dia} AND" : "";
            $consulta .= "((desde >= '{$desde}' AND desde < '{$hasta}') OR (hasta > '{$desde}' AND hasta < '{$hasta}') "
                    . "OR (desde < '{$desde}' AND hasta > '{$desde}'))) ORDER BY sector, nombre";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "Los datos recibidos no cumplen con el formato requerido");
    }

    public static function listarInformeMesa($disponible, $fecha, $hora) {
        if ($disponible && $fecha && $hora) {
            $consulta = "SELECT * FROM aula WHERE idaula {$disponible} (SELECT idaula "
                    . "FROM llamado WHERE fecha = '{$fecha}' AND hora = '{$hora}') "
                    . "ORDER BY sector, nombre";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "Los datos recibidos no cumplen con el formato requerido");
    }

    public static function listarMesasExamen($id) {
        if ($id > 0) {
            $consulta = "SELECT codigoCarrera, nombreCarrera, nombreAsignatura, "
                    . "fechaPri, horaPri, fechaSeg, horaSeg "
                    . " FROM vista_mesas WHERE idAulaPri = {$id} OR idAulaSeg = {$id}";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se pudo hacer referencia al aula");
    }

    /**
     * Listar resumen limitado de aulas. Selecciona el idaula, sector, nombre,
     * cantidad de clases y cantidad de llamados ordenados por idaula.
     */
    public static function listarResumenAulas($limite) {
        if ($limite > 0) {
            $consulta = "SELECT aul.*, (CASE WHEN cla.clases IS NULL THEN 0 ELSE cla.clases END) clases,"
                    . "(CASE WHEN lla.llamados IS NULL THEN 0 ELSE lla.llamados END) llamados "
                    . "FROM aula aul LEFT JOIN (SELECT idaula, COUNT(idclase) clases "
                    . "FROM clase GROUP BY idaula) cla ON cla.idaula = aul.idaula "
                    . "LEFT JOIN (SELECT idaula, COUNT(idllamado) llamados "
                    . "FROM llamado GROUP BY idaula) lla ON lla.idaula = aul.idaula "
                    . "ORDER BY idaula DESC LIMIT {$limite}";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se estableció un limite válido");
    }

}
