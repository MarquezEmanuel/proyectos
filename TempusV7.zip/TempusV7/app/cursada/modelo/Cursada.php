<?php

namespace app\cursada\modelo;

/**
 * 
 * @package carrera.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Cursada {

    private $cursada;
    private $clases;

    public function __construct($cursada, $clases) {
        $this->setCursada($cursada);
        $this->setClases($clases);
    }

    public function getCursada() {
        return $this->cursada;
    }

    public function getClases() {
        return $this->clases;
    }

    public function setCursada(Cursada $cursada) {
        if ($cursada instanceof Cursada) {
            $this->cursada = $cursada;
        }
    }

    public function setClases(array $clases) {
        if (count($clases) < 8) {
            $this->clases = $clases;
        }
    }

}
