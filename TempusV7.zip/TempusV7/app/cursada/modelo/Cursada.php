<?php

namespace app\cursada\modelo;

/**
 * 
 * @package carrera.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Cursada {

    private $plan;
    private $clases;

    public function __construct($plan, $clases) {
        $this->setPlan($plan);
        $this->setClases($clases);
    }

    public function getPlan() {
        return $this->plan;
    }

    public function getClases() {
        return $this->clases;
    }

    public function setPlan(Plan $plan) {
        if ($plan instanceof Plan) {
            $this->plan = $plan;
        }
    }

    public function setClases(array $clases) {
        if (count($clases) < 8) {
            $this->clases = $clases;
        }
    }

}
