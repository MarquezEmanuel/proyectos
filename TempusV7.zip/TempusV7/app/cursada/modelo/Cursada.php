<?php

namespace app\cursada\modelo;

/**
 * 
 * @package app\cursada\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Cursada {

    private $plan;
    private $clases;

    public function __construct() {
        $this->clases = array();
    }

    public function getPlan() {
        return $this->plan;
    }

    public function getClases() {
        return $this->clases;
    }

    public function setPlan($plan) {
        $this->plan = $plan;
    }

    public function agregarClase(Clase $clase) {
        $cantidad = count($this->clases);
        if ($cantidad < 8) {
            if ($this->verificar($clase->getDiaSemana())) {
                $this->clases[] = $clase;
                return true;
            }
        }
        return false;
    }

    public function crear() {
        if (count($this->clases) > 0) {
            $clases = $this->clases;
            $resultado = TRUE;
            foreach ($clases as $clase) {
                $clase->setPlan($this->plan);
                $creacion = $clase->crear();
                $resultado = ($creacion[0] == 2) ? $resultado : FALSE;
            }
            if ($resultado) {
                return array(2, "Se realizó la creación de la cursada correctamente");
            }
            return array(1, "No se realizó la creación de la cursada porque no se crearon todas las clases");
        }
        return array(0, "Los campos recibidos para crear la cursada no cumplen con el formato requerido");
    }

    private function verificar($dia) {
        $cantidad = count($this->clases);
        $contador = 0;
        while ($contador < $cantidad) {
            $clase = $this->clases[$contador];
            if ($dia == $clase->getDiaSemana()) {
                return false;
            }
            $contador++;
        }
        return true;
    }

}
