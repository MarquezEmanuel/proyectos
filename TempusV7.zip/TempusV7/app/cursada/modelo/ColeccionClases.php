<?php

namespace app\cursada\modelo;

/**
 *
 * @package app\cursada\ColeccionClases.
 *  
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ColeccionClases {

    /**
     * Borrar todas los registros de clases. Luego de eliminar todas las clases 
     * se reinicia el auto incrementador de la clave primaria.
     * @uses Clases::reiniciarAutoIncrementador Reinicia auto incrementador a 1.
     */
    public static function borrarClases() {
        $consulta = "DELETE FROM clase";
        $resultado = Conexion::getInstancia()->borrar($consulta);
        return ($resultado[0] == 2) ? $this->reiniciarAutoIncrementador() : $resultado;
    }

    /**
     * Reiniciar el auto incrementador de la clave primaria.
     */
    private function reiniciarAutoIncrementador() {
        $consulta = "ALTER TABLE clase AUTO_INCREMENT = 1";
        return Conexion::getInstancia()->borrar($consulta);
    }

}
