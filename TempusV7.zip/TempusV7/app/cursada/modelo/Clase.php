<?php

namespace app\cursada\modelo;

use app\aula\modelo\Aula as Aula;

/**
 * 
 * @package cursada.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Clase {

    /** @var string Identificador de la clase en la base de datos. */
    private $id;

    /** @var string Aula en la que se dicta la clase. */
    private $aula;

    /** @var string Identificador del plan al que pertenece la clase. */
    private $plan;

    /** @var int Numero del dia se la semana en que se dicta la clase. */
    private $diaSemana;

    /** @var string Horario de inicio. */
    private $horaInicio;

    /** @var string Horario de fin. */
    private $horaFin;

    /** @var string Fecha de ultima modificacion realizada. */
    private $fechaEdicion;

    /**
     * Constructor de la clase.
     */
    public function __construct($id, $aula, $plan, $diaSemana, $horaInicio, $horaFin, $fechaEdicion) {
        $this->setId($id);
        $this->setAula($aula);
        $this->setPlan($plan);
        $this->setDiaSemana($diaSemana);
        $this->setHoraInicio($horaInicio);
        $this->setHoraFin($horaFin);
        $this->setFechaEdicion($fechaEdicion);
    }

    public function getId() {
        return $this->id;
    }

    public function getAula() {
        return $this->aula;
    }

    public function getPlan() {
        return $this->plan;
    }

    public function getDiaSemana($formato = "NRO") {
        return ($formato == "NRO") ? $this->diaSemana : Util::obtenerNombreDia($this->diaSemana);
    }

    public function getHoraInicio($formato = "HHMMSS") {
        return ($formato == "HHMMSS") ? $this->horaInicio : substr($this->horaInicio, 0, 5);
    }

    public function getHoraFin($formato = "HHMMSS") {
        return ($formato == "HHMMSS") ? $this->horaFin : substr($this->horaFin, 0, 5);
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->idClase = ($id > 0) ? $id : NULL;
    }

    public function setAula($aula) {
        if ($aula instanceof Aula) {
            $this->aula = $aula->getId();
        }
    }

    public function setPlan($plan) {
        $this->plan = $plan;
    }

    public function setDiaSemana($diaSemana) {
        $this->diaSemana = $diaSemana;
    }

    public function setHoraInicio($horaInicio) {
        $this->horaInicio = $horaInicio;
    }

    public function setHoraFin($horaFin) {
        $this->horaFin = $horaFin;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function crear(): array {
        if ($this->diaSemana && $this->horaInicio && $this->horaFin && $this->aula) {
            $existencia = $this->evaluarExistencia();
            if ($existencia == 1) {
                $consulta = "INSERT INTO clase VALUES (NULL, {$this->dia}, '{$this->horaInicio}', '{$this->horaFin}', {$this->aula}, NULL)";
                $creacion = Conexion::getInstancia()->insertar($consulta);
                if ($creacion[0] == 2) {
                    $this->id = $creacion[2];
                }
                return $creacion;
            }
            return $existencia;
        }
        return array(0, "Los campos necesarios para crear la clase no cumplen con el formato requerido");
    }

    public function modificar(): array {
        if ($this->idClase && $this->horaInicio && $this->horaFin && $this->aula) {
            $consulta = "UPDATE clase SET desde='{$this->horaInicio}',"
                    . " hasta='{$this->horaFin}', idaula={$this->aula}, "
                    . " fechaEdicion=NOW() WHERE idclase = {$this->idClase}";
            return Conexion::getInstancia()->modificar($consulta);
        }
        return array(0, "Los campos necesarios para modificar la clase no cumplen con el formato requerido");
    }

    public function obtenerPorIdentificador(): array {
        if ($this->idClase) {
            $consulta = "SELECT * FROM clase WHERE id = {$this->idClase}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->id = $fila['id'];
                $this->diaSemana = $fila['diaSemana'];
                $this->horaInicio = $fila['horaInicio'];
                $this->horaFin = $fila['horaFin'];
                $this->fechaModificacion = $fila['fechaEdicion'];
                return $this->obtenerAula($fila['idAula']);
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la clase");
    }

    private function obtenerPorDatos(): array {
        $consulta = "SELECT idclase FROM clase WHERE dia ={$this->dia} "
                . "AND desde = '{$this->horaInicio}' "
                . "AND hasta = '{$this->horaFin}' "
                . "AND idaula={$this->aula}";
        $fila = Conexion::getInstancia()->obtener($consulta);
        if (gettype($fila) == "array") {
            $this->id = $fila['id'];
            $this->dia = $fila['dia'];
            $this->horaInicio = $fila['desde'];
            $this->horaFin = $fila['hasta'];
            $this->fechaModificacion = $fila['fechamod'];
            return $this->obtenerAula($fila['idaula']);
        }
        $this->descripcion = Conexion::getInstancia()->getDescripcion();
        return $fila;
    }

    private function obtenerAula($idAula): array {
        if ($idAula > 0) {
            $this->aula = NULL;
            $aula = new Aula($idAula);
            $resultado = $aula->obtenerPorIdentificador();
            if ($resultado[0] == 2) {
                $this->aula = $aula;
                $resultado[1] = "Se obtuvo la información de la clase correctamente";
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al aula asignada a la clase");
    }

}
