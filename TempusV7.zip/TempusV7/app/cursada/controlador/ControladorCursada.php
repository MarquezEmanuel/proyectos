<?php

namespace app\cursada\controlador;

class ControladorCursada {

    public function buscar() {
        
    }

    public function crear($plan, $clases) {
        
    }

}
