<?php

/* SE INCLUYE EL ARCHIVO DE CONSTANTES Y EL AUTOLOAD */

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

/* SE REFERENCIAN LOS NAMESPACE */

use app\cursada\controlador\ControladorCursada;
use app\principal\controlador\ControladorHTML;
use app\principal\modelo\AutoCargador;

AutoCargador::cargarModulos();

session_start();

$controlador = new ControladorCursada();
if (isset($_POST['peticion'])) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreCarrera = $_POST['carrera'];
    $nombreAsignatura = $_POST['asignatura'];
    $datos = ($nombreCarrera) ? "Carrera : {$nombreCarrera}," : "Carrera: TODAS, ";
    $datos .= ($nombreAsignatura) ? "Asignatura '{$nombreAsignatura}'" : "Asignatura: TODAS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscarPorCarreraAsignatura($nombreCarrera, $nombreAsignatura);
    $_SESSION['BUSCUR'] = array($nombreCarrera, $nombreAsignatura, $datos);
} else {
    if (isset($_SESSION['BUSCUR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BUSCUR'];
        $nombreCarrera = $parametros[0];
        $nombreAsignatura = $parametros[1];
        $filtro = "Última búsqueda realizada: " . $parametros[2];
        $resultado = $controlador->buscarPorCarreraAsignatura($nombreCarrera, $nombreAsignatura);
        $_SESSION['BUSCUR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $limite = 20;
        $resultado = $controlador->listarResumenCursadas($limite);
        $filtro = "Resumen de horarios de cursada";
        $_SESSION['BUSCUR'] = NULL;
    }
}

$cuerpo = "";
if ($resultado[0] == 2) {
    $cursadas = $resultado[1];
    $filas = "";
    foreach ($cursadas as $cursada) {

        $idPlan = $cursada['idPlan'];
        $codigoCarrera = str_pad($cursada['codigoCarrera'], 3, "0", STR_PAD_LEFT);
        $nombreCortoCarrera = $cursada['nombreCortoCarrera'];
        $nombreLargoCarrera = $cursada['nombreLargoCarrera'];
        $nombreCortoAsignatura = $cursada['nombreCortoAsignatura'];
        $nombreLargoAsignatura = $cursada['nombreLargoAsignatura'];

        /* DATOS DE LA CLASE PARA DIA LUNES */
        $horaInicioLunes = ($cursada['horaInicioLunes']) ? substr($cursada['horaInicioLunes'], 0, 5) : "";
        $horaFinLunes = ($cursada['horaFinLunes']) ? substr($cursada['horaFinLunes'], 0, 5) : "";
        $sectorAulaLunes = $cursada['sectorAulaLunes'];
        $nombreAulaLunes = $cursada['nombreAulaLunes'];

        /* DATOS DE LA CLASE PARA DIA MARTES */
        $horaInicioMartes = ($cursada['horaInicioMartes']) ? substr($cursada['horaInicioMartes'], 0, 5) : "";
        $horaFinMartes = ($cursada['horaFinMartes']) ? substr($cursada['horaFinMartes'], 0, 5) : "";
        $sectorAulaMartes = $cursada['sectorAulaMartes'];
        $nombreAulaMartes = $cursada['nombreAulaMartes'];

        /* DATOS DE LA CLASE PARA DIA MIERCOLES */
        $horaInicioMiercoles = ($cursada['horaInicioMiercoles']) ? substr($cursada['horaInicioMiercoles'], 0, 5) : "";
        $horaFinMiercoles = ($cursada['horaFinMiercoles']) ? substr($cursada['horaFinMiercoles'], 0, 5) : "";
        $sectorAulaMiercoles = $cursada['sectorAulaMiercoles'];
        $nombreAulaMiercoles = $cursada['nombreAulaMiercoles'];

        /* DATOS DE LA CLASE PARA DIA JUEVES */
        $horaInicioJueves = ($cursada['horaInicioJueves']) ? substr($cursada['horaInicioJueves'], 0, 5) : "";
        $horaFinJueves = ($cursada['horaFinJueves']) ? substr($cursada['horaFinJueves'], 0, 5) : "";
        $sectorAulaJueves = $cursada['sectorAulaJueves'];
        $nombreAulaJueves = $cursada['nombreAulaJueves'];

        /* DATOS DE LA CLASE PARA DIA VIERNES */
        $horaInicioViernes = ($cursada['horaInicioViernes']) ? substr($cursada['horaInicioViernes'], 0, 5) : "";
        $horaFinViernes = ($cursada['horaFinViernes']) ? substr($cursada['horaFinViernes'], 0, 5) : "";
        $sectorAulaViernes = $cursada['sectorAulaViernes'];
        $nombreAulaViernes = $cursada['nombreAulaViernes'];

        /* DATOS DE LA CLASE PARA DIA SABADO */
        $horaInicioSabado = ($cursada['horaInicioSabado']) ? substr($cursada['horaInicioSabado'], 0, 5) : "";
        $horaFinSabado = ($cursada['horaFinSabado']) ? substr($cursada['horaFinSabado'], 0, 5) : "";
        $sectorAulaSabado = $cursada['sectorAulaSabado'];
        $nombreAulaSabado = $cursada['nombreAulaSabado'];

        $filas .= "
            <tr>
                <td style='display: none;'>{$codigoCarrera}</td>
                <td style='display: none;'>{$nombreCortoCarrera}</td>
                <td class='align-middle'>{$nombreLargoCarrera}</td>
                <td style='display: none;'>{$nombreCortoAsignatura}</td>
                <td class='align-middle'>{$nombreLargoAsignatura}</td>
                <td class='align-middle'>{$horaInicioLunes}</td>
                <td class='align-middle'>{$horaFinLunes}</td>
                <td class='align-middle'>{$sectorAulaLunes}</td>
                <td class='align-middle'>{$nombreAulaLunes}</td>
                
                <td class='align-middle'>{$horaInicioMartes}</td>
                <td class='align-middle'>{$horaFinMartes}</td>
                <td class='align-middle'>{$sectorAulaMartes}</td>
                <td class='align-middle'>{$nombreAulaMartes}</td>
                    
                <td class='align-middle'>{$horaInicioMiercoles}</td>
                <td class='align-middle'>{$horaFinMiercoles}</td>
                <td class='align-middle'>{$sectorAulaMiercoles}</td>
                <td class='align-middle'>{$nombreAulaMiercoles}</td>
                    
                <td class='align-middle'>{$horaInicioJueves}</td>
                <td class='align-middle'>{$horaFinJueves}</td>
                <td class='align-middle'>{$sectorAulaJueves}</td>
                <td class='align-middle'>{$nombreAulaJueves}</td>
                    
                <td class='align-middle'>{$horaInicioViernes}</td>
                <td class='align-middle'>{$horaFinViernes}</td>
                <td class='align-middle'>{$sectorAulaViernes}</td>
                <td class='align-middle'>{$nombreAulaViernes}</td>
                    
                <td class='align-middle'>{$horaInicioSabado}</td>
                <td class='align-middle'>{$horaFinSabado}</td>
                <td class='align-middle'>{$sectorAulaSabado}</td>
                <td class='align-middle'>{$nombreAulaSabado}</td>

                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info detalle' 
                                title='Ver detalle'><i class='fas fa-eye'></i>
                        </button>
                        <button class='btn btn-outline-warning editar' 
                                name='$idPlan' id='$idPlan' 
                                title='Editar'><i class='far fa-edit'></i>
                        </button>
                        <button class='btn btn-outline-danger borrar' 
                                name='{$idPlan}' id='{$idPlan}' 
                                title='Borrar'><i class='fas fa-trash'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tablaBuscarCursadas" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th style="display: none;">Código de carrera</th>
                        <th style="display: none;">Nombre corto de carrera</th>
                        <th>Carrera</th>
                        <th style="display: none;">Nombre corto de asignatura</th>
                        <th>Asignatura</th>
                        <th title="">Hora inicio</th>
                        <th title="">Hora fin</th>
                        <th title="">Sector</th>
                        <th title="">Aula</th>
                        <th title="">Hora inicio</th>
                        <th title="">Hora fin</th>
                        <th title="">Sector</th>
                        <th title="">Aula</th>
                        <th title="">Hora inicio</th>
                        <th title="">Hora fin</th>
                        <th title="">Sector</th>
                        <th title="">Aula</th>
                        <th title="">Hora inicio</th>
                        <th title="">Hora fin</th>
                        <th title="">Sector</th>
                        <th title="">Aula</th>
                        <th title="">Hora inicio</th>
                        <th title="">Hora fin</th>
                        <th title="">Sector</th>
                        <th title="">Aula</th>
                        <th title="">Hora inicio</th>
                        <th title="">Hora fin</th>
                        <th title="">Sector</th>
                        <th title="">Aula</th>
                        <th title="Operaciones disponibles" class="text-center">Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $codigo = $resultado[0];
    $mensaje = $resultado[0];
    $cuerpo = ControladorHTML::mostrarAlertaResultadoBusqueda($codigo, $mensaje);
}

echo ControladorHTML::mostrarCardResultadoBusqueda($filtro, $cuerpo);
