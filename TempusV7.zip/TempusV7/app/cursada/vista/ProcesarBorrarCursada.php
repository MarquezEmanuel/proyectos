<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

if (isset($_POST['modalIdCarrera']) && isset($_POST['modalIdAsignatura'])) {
    $codigo = $_POST['modalIdCarrera'];
    $idAsignatura = $_POST['modalIdAsignatura'];

    Log::escribirLineaError($codigo . " & " . $idAsignatura);
    $controlador = new ControladorCursada();
    $eliminacion = $controlador->borrar($codigo, $idAsignatura);
    $mensaje = $controlador->getDescripcion();
    $resultado = ControladorHTML::mostrarAlertaResultadoOperacion($eliminacion, $mensaje);
} else {
    $mensaje = "No se recibió la información desde el formulario";
    $resultado = ControladorHTML::mostrarAlertaResultadoOperacion(0, $mensaje);
}

echo $resultado;
