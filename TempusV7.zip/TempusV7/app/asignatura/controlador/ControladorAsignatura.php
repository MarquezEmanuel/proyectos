<?php

namespace app\asignatura\controlador;

use app\asignatura\modelo\Asignatura;
use app\asignatura\modelo\ColeccionAsignaturas as Asignaturas;

class ControladorAsignatura {

    public function buscarPorCarrera($codigoCarrera, $nombreAsignatura, $pertenece) {
        return Asignaturas::buscarPorCarrera($codigoCarrera, $nombreAsignatura, $pertenece);
    }

    public function buscarPorNombre($nombreAsignatura) {
        return Asignaturas::buscarPorNombre($nombreAsignatura);
    }

    public function crear($nombreAsignatura) {
        $asignatura = new Asignatura(NULL, $nombreAsignatura, $nombreAsignatura);
        return $asignatura->crear();
    }

    public function listarResumenAsignaturas($limite) {
        return Asignaturas::listarResumenAsignaturas($limite);
    }

}
