<?php

namespace app\asignatura\controlador;

class ControladorAsignatura {
    
}
