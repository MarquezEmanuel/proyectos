<?php

namespace app\mesa\modelo;

use principal\modelos\Conexion as Conexion;

/**
 * Description of MesasExamen
 *
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class MesasExamen {

    /**
     * Realiza la busqueda de mesas de examen en la vista correspondiente. Se puede
     * aplicar el filtro para el campo carrera o asignatura.
     * @param string $campo Se debe indicar carrera o asignatura.
     * @param string $valor Valor para el campo indicado anteriormente.
     * @return integer 0 cuando falla la consulta, 1 sin resultados o 2 correcta.
     */
    public static function buscar($campo, $valor) {
        if ($campo) {
            $consulta = "SELECT * FROM vista_mesas WHERE {$campo} LIKE '%{$valor}%'";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "El campo es obligatorio");
    }

    public function importar($mesas, $nroLlamados) {
        $resultado = $this->truncarMesasExamen();
        if ($resultado[0] == 2) {
            $errores = ($nroLlamados == 1) ? $this->importarUnLlamado($mesas) : $this->importarDosLlamados($mesas);
            if (count($errores) == count($mesas)) {
                $this->descripcion = "No se crearon mesas de examen";
                return 1;
            }
            $this->descripcion = "Mesas creadas exitosamente: " . (count($mesas) - count($errores)) . " de " . count($mesas);
            return $errores;
        }
        return $resultado;
    }

    public function importarUnLlamado($mesas) {
        $errores = array();
        foreach ($mesas as $datos) {
            $carrera = new Carrera($datos[0], $datos[1]);
            $asignatura = new Asignatura(NULL, $datos[2]);
            $presidente = new Docente(NULL, $datos[3]);
            $vocal1 = new Docente(NULL, $datos[4]);
            $vocal2 = new Docente(NULL, $datos[5]);
            $suplente = new Docente(NULL, $datos[6]);
            $primero = new Llamado(NULL, date('Y-m-d', strtotime(str_replace('/', '-', $datos[7]))), $datos[8], NULL);
            $carrera->crear();
            $asignatura->crear();
            $carrera->agregarAsignatura($asignatura->getIdAsignatura(), 1);
            $presidente->crear();
            $vocal1->crear();
            $vocal2->crear();
            $suplente->crear();
            $tribunal = new Tribunal(NULL, $presidente->getIdDocente(), $vocal1->getIdDocente(), $vocal2->getIdDocente(), $suplente->getIdDocente());
            $tribunal->crear();
            $primero->crear();
            $mesa = new MesaExamen(NULL, $asignatura->getIdAsignatura(), $carrera->getCodigo(), $tribunal->getIdTribunal(), $primero->getIdLlamado());
            if ($mesa->crear() != 2) {
                $mensaje = "Carrera: " . $carrera->getDescripcion() . " / ";
                $mensaje .= "Asignatura: " . $asignatura->getDescripcion() . " / ";
                $mensaje .= "Tribunal: " . $tribunal->getDescripcion() . " / ";
                $mensaje .= "Llamado: " . $primero->getDescripcion() . " / ";
                $mensaje .= "Mesa: " . $mesa->getDescripcion();
                Log::escribirLineaError("[" . $mensaje . "]");
                $errores [] = $datos;
            }
        }
        return $errores;
    }

    public function importarDosLlamados($mesas) {
        $errores = array();
        foreach ($mesas as $datos) {
            $carrera = new Carrera($datos[0], $datos[1]);
            $asignatura = new Asignatura(NULL, $datos[2]);
            $presidente = new Docente(NULL, $datos[3]);
            $vocal1 = new Docente(NULL, $datos[4]);
            $vocal2 = new Docente(NULL, $datos[5]);
            $suplente = new Docente(NULL, $datos[6]);
            $primero = new Llamado(NULL, date('Y-m-d', strtotime(str_replace('/', '-', $datos[7]))), $datos[9], NULL);
            $segundo = new Llamado(NULL, date('Y-m-d', strtotime(str_replace('/', '-', $datos[8]))), $datos[9], NULL);
            $carrera->crear();
            $asignatura->crear();
            $carrera->agregarAsignatura($asignatura->getIdAsignatura(), 1);
            $presidente->crear();
            $vocal1->crear();
            $vocal2->crear();
            $suplente->crear();
            $tribunal = new Tribunal(NULL, $presidente->getIdDocente(), $vocal1->getIdDocente(), $vocal2->getIdDocente(), $suplente->getIdDocente());
            $tribunal->crear();
            $primero->crear();
            $segundo->crear();
            $mesa = new MesaExamen(NULL, $asignatura->getIdAsignatura(), $carrera->getCodigo(), $tribunal->getIdTribunal(), $primero->getIdLlamado(), $segundo->getIdLlamado());
            if ($mesa->crear() != 2) {
                $mensaje = "Carrera: " . $carrera->getDescripcion() . " / ";
                $mensaje .= "Asignatura: " . $asignatura->getDescripcion() . " / ";
                $mensaje .= "Tribunal: " . $tribunal->getDescripcion() . " / ";
                $mensaje .= "Llamado 1: " . $primero->getDescripcion() . " / ";
                $mensaje .= "Llamado 2: " . $segundo->getDescripcion() . " / ";
                $mensaje .= "Mesa: " . $mesa->getDescripcion();
                Log::escribirLineaError("[" . $mensaje . "]");
                $errores [] = $datos;
            }
        }
        return $errores;
    }

    /**
     * Realiza la busqueda de mesas de examen en la vista correspondientes con el
     * objetivo de generar el informe del modulo. Se pueden aplicar filtros para
     * el nombre de carrera, nombre de asignatura, fecha, hora y fecha de edicion
     * de la mesa.
     * @param string $carrera Nombre de la carrera.
     * @param string $asignatura Nombre de la asignatura.
     * @param string $fecha Fecha en la que se dicta la mesa o NO.
     * @param string $hora Hora en la que se dicta la mesa o NO.
     * @param string $docente Nombre del docente a buscar dentro del tribunal.
     * @param string $modificada SI para mesa modificada, NO en caso contrario.
     * @return integer 0 cuando falla la consulta, 1 sin resultados o 2 correcta.
     */
    public function listarInforme($carrera, $asignatura, $fecha, $hora, $docente, $modificada) {
        $consulta = "SELECT * FROM vista_mesas WHERE ";
        $consulta .= ($carrera) ? "nombreCarrera LIKE '%{$carrera}%' AND " : "";
        $consulta .= ($asignatura) ? "nombreAsignatura LIKE '%{$asignatura}%' AND " : "";
        $consulta .= ($fecha != "NO") ? "(fechaPri = '{$fecha}' OR fechaSeg = '{$fecha}') AND " : "";
        $consulta .= ($hora != "NO") ? "(horaPri = '{$hora}' OR horaSeg = '{$hora}') AND " : "";
        $consulta .= ($docente) ? "(nombrePresidente LIKE '%{$docente}%' OR nombreVocalPri LIKE '%{$docente}%' OR nombreVocalSeg LIKE '%{$docente}%' OR nombreSuplente LIKE '%{$docente}%') AND" : "";
        $consulta .= ($modificada == "SI") ? "(fechaModPri IS NOT NULL OR fechaModSeg IS NOT NULL)" : "(fechaModPri IS NULL AND fechaModSeg IS NULL)";
        $resultado = Conexion::getInstancia()->seleccionar($consulta);
        $this->descripcion = Conexion::getInstancia()->getDescripcion();
        return $resultado;
    }

    public static function listarMesasDeAula($idAula) {
        if ($idAula > 0) {
            $consulta = "SELECT me.idmesa, ma.idasignatura, ma.nombre asignatura, ca.codigo, ca.nombre carrera, lp.idllamado idpl, lp.fecha fechapl, "
                    . "lp.hora horapl, lp.fechamod fechamodpl, ls.idllamado idsl, ls.fecha fechasl, ls.hora horasl, ls.fechamod fechamodsl "
                    . "FROM mesa_examen me "
                    . "INNER JOIN asignatura ma ON ma.idasignatura = me.idasignatura "
                    . "INNER JOIN carrera ca ON ca.codigo = me.idcarrera "
                    . "LEFT JOIN llamado lp ON lp.idllamado = me.primero "
                    . "LEFT JOIN llamado ls ON ls.idllamado = me.segundo "
                    . "WHERE lp.idaula = {$this->idAula} OR ls.idaula = {$this->idAula}";
            echo $consulta;
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se pudo hacer referencia al aula");
    }

    public function listarResumenInicial() {
        $consulta = "SELECT 'Total de mesas de examen' nombre, COUNT(*) cantidad FROM vista_mesas UNION "
                . "SELECT 'Total de asignaturas distintas con mesa', COUNT(DISTINCT idasignatura) cantidad FROM vista_mesas UNION "
                . "SELECT 'Total de mesas que se han modificado' nombre, COUNT(*) cantidad FROM vista_mesas WHERE fechaModPri IS NOT NULL OR fechaModSeg IS NOT NULL";
        $resultado = Conexion::getInstancia()->seleccionar($consulta);
        $this->descripcion = Conexion::getInstancia()->getDescripcion();
        return $resultado;
    }

    /**
     * Realiza la busqueda de las ultimas diez mesas de examen que se han creado.
     * El objetivo es brindar resultados previos cuando se hace la busqueda de 
     * mesas de examen.
     * @return integer 0 cuando falla la consulta, 1 sin resultados o 2 correcta.
     */
    public static function listarResumenMesasExamen($limite) {
        if ($limite > 0) {
            $consulta = "SELECT * FROM vista_mesas ORDER BY idmesa LIMIT {$limite}";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se estableció un limite valido");
    }

    public function truncarMesasExamen() {
        Log::guardarActividad("MESAS DE EXAMEN --> TRUNCAR");
        $consulta = "TRUNCATE TABLE mesa_examen";
        $resultado = Conexion::getInstancia()->borrar($consulta);
        if ($resultado[0] == 2) {
            $tborrar = Tribunales::borrarTribunales();
            $lborrar = Llamados::borrarLlamados();
            $error = array(0, "No se pudo realizar la eliminación de mesas");
            return ($tborrar[0] == 2 && $lborrar[0] == 2) ? $resultado : $error;
        }
        return $resultado;
    }

}
