<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of MesaExame
 *
 * @author Emanuel
 */
class MesaExamen {

    private $id;
    private $asignatura;
    private $fechaCreacion;
    private $observacion;

    public function __construct($id, $asignatura, $fechaCreacion, $observacion) {
        $this->id = $id;
        $this->asignatura = $asignatura;
        $this->fechaCreacion = $fechaCreacion;
        $this->observacion = $observacion;
    }
    
    public function getId() {
        return $this->id;
    }

    public function getAsignatura() {
        return $this->asignatura;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getObservacion() {
        return $this->observacion;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setAsignatura($asignatura) {
        $this->asignatura = $asignatura;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setObservacion($observacion) {
        $this->observacion = $observacion;
    }



}
