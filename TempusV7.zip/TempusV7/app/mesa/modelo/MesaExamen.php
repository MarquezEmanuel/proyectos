<?php

namespace app\mesa\modelo;

use app\mesa\modelo\Llamado as Llamado;
use app\mesa\modelo\Tribunal as Tribunal;
use app\principal\modelo\Conexion as Conexion;
use app\principal\modelo\Log as Log;

/**
 * 
 * @package app\mesa\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class MesaExamen {

    private $id;
    private $primerLlamado;
    private $segundoLlamado;
    private $tribunal;
    private $fechaCreacion;
    private $observacion;

    public function __construct($id = NULL, $primerLlamado = NULL, $segundoLlamado = NULL, $tribunal = NULL, $fechaCreacion = NULL, $observacion = NULL) {
        $this->setId($id);
        $this->setPrimerLlamado($primerLlamado);
        $this->setSegundoLlamado($segundoLlamado);
        $this->setTribunal($tribunal);
        $this->setFechaCreacion($fechaCreacion);
        $this->setObservacion($observacion);
    }

    public function getId() {
        return $this->id;
    }

    public function getPrimerLlamado() {
        return $this->primerLlamado;
    }

    public function getSegundoLlamado() {
        return $this->segundoLlamado;
    }

    public function getTribunal() {
        return $this->tribunal;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getObservacion() {
        return $this->observacion;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setPrimerLlamado($primerLlamado) {
        if ($primerLlamado instanceof Llamado) {
            $this->primerLlamado = $primerLlamado;
        }
    }

    public function setSegundoLlamado($segundoLlamado) {
        if ($segundoLlamado instanceof Llamado) {
            $this->segundoLlamado = $segundoLlamado;
        }
    }

    public function setTribunal($tribunal) {
        if ($tribunal instanceof Tribunal) {
            $this->tribunal = $tribunal;
        }
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setObservacion($observacion) {
        $this->observacion = $observacion;
    }

    public function crear() {
        if ($this->plan && $this->tribunal && ($this->primero || $this->segundo)) {
            $primero = ($this->primero) ? $this->primero : "NULL";
            $segundo = ($this->segundo) ? $this->segundo : "NULL";
            $values = "(NULL, {$this->asignatura}, {$this->carrera}, {$this->tribunal}, {$primero}, {$segundo})";
            $creacion = Conexion::getInstancia()->insertar("mesa_examen", $values);
            $this->idasignatura = ($creacion == 2) ? (Int) Conexion::getInstancia()->insert_id : NULL;
            $this->descripcion = Conexion::getInstancia()->getDescripcion();
            return $creacion;
        }
        return array(0, "Los campos necesarios para crear la mesa de examen no cumple el formato requerido");
    }

    public function obtenerPorIdentificador() {
        if ($this->id) {
            $consulta = "SELECT * FROM mesa_examen WHERE id = {$this->id}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->id = $fila['id'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->observacion = $fila['observacion'];
                $rtri = $this->obtenerTribunal($fila['idTribunal']);
                $rpri = $this->obtenerPrimerLlamado($fila['idPrimerLlamado']);
                $rseg = $this->obtenerSegundoLlamado($fila['idSegundoLlamado']);
                $exito = array(2, "Se obtuvo la información de la mesa de examen correctamente");
                $error = array(1, "No se obtuvo la información de la mesa de examen");
                return (($rtri == 2) && ($rpri == 2) && ($rseg == 2)) ? $exito : $error;
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la mesa de examen");
    }

    private function obtenerTribunal($idTribunal) {
        $tribunal = new Tribunal($idTribunal);
        $resultado = $tribunal->obtenerPorIdentificador();
        $this->tribunal = ($resultado[0] == 2) ? $tribunal : NULL;
        return $resultado[0];
    }

    private function obtenerPrimerLlamado($idPrimerLlamado) {
        $llamado = new Llamado($idPrimerLlamado);
        $resultado = $llamado->obtenerPorIdentificador();
        $this->primerLlamado = ($resultado[0] == 2) ? $llamado : NULL;
        return $resultado[0];
    }

    private function obtenerSegundoLlamado($idSegundoLlamado) {
        $llamado = new Llamado($idSegundoLlamado);
        $resultado = $llamado->obtenerPorIdentificador();
        $this->segundoLlamado = ($resultado[0] == 2) ? $llamado : NULL;
        return $resultado[0];
    }

}
