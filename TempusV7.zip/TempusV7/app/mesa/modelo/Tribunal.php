<?php

namespace app\mesa\modelo;

use app\docente\modelo\Docente as Docente;
use app\principal\modelo\Conexion as Conexion;
use app\principal\modelo\Log as Log;
use app\util\modelo\Util as Util;

/**
 * 
 * @package tribunal.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Tribunal {

    /** @var int Identificador del tribunal */
    private $id;
    private $docentes;

    public function __construct($id = NULL, $docentes = NULL) {
        $this->setId($id);
        $this->setDocentes($docentes);
    }

    public function getId() {
        return $this->id;
    }

    public function getDocentes() {
        return $this->docentes;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setDocentes($docentes) {
        $this->docentes = ($docentes) ? $docentes : array();
    }

    private function obtenerDocente($obligatorio, $orden, $idDocente) {
        if ($idDocente > 0) {
            $docente = new Docente($idDocente);
            $resultado = $docente->obtenerPorIdentificador();
            $this->docentes[$orden] = ($resultado[0] == 2) ? $docente : NULL;
            return $resultado[0];
        }
        return ($obligatorio) ? 1 : 2;
    }

    public function agregarDocente(Docente $docente) {
        $cantidad = count($this->docentes);
        if ($cantidad < 4) {
            if ($this->verificar($docente->getNombre())) {
                $this->docentes[] = $docente;
                return true;
            }
        }
        return false;
    }

    private function verificar($nombre) {
        $cantidad = count($this->docentes);
        $contador = 0;
        while ($contador < $cantidad) {
            $docente = $this->docentes[$contador];
            if ($nombre == $docente->getNombre()) {
                return false;
            }
            $contador++;
        }
        return true;
    }

}
