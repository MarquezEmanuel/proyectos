<?php

namespace app\mesa\modelo;

use app\aula\modelo\Aula as Aula;
use app\principal\modelo\Conexion as Conexion;
use app\principal\modelo\Log as Log;

/**
 * 
 * @package app\mesa\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Llamado {

    /** @var integer Identificador del llamado en la base de datos. */
    private $id;

    /** @var Aula Aula en la que se dicta la mesa de examen. */
    private $aula;

    /** @var string Fecha en la que se dicta la mesa de examen. */
    private $fecha;

    /** @var string Fecha de modificacion del llamado. */
    private $fechaEdicion;

    /** @var string Hora en la que se dicta la mesa de examen. */
    private $hora;

    /**
     * Constructor de clase.
     */
    public function __construct($id = NULL, $aula = NULL, $fecha = NULL, $hora = NULL, $fechaEdicion = NULL) {
        $this->id = $id;
        $this->aula = $aula;
        $this->fecha = $fecha;
        $this->fechaEdicion = $fechaEdicion;
        $this->hora = $hora;
    }

    /**
     * Retorna el identificador del llamado.
     * @return int Identificador de llamado.
     */
    public function getId(): int {
        return $this->id;
    }

    public function getAula(): Aula {
        return $this->aula;
    }

    public function getFecha(): string {
        return $this->fecha;
    }

    public function getFechaEdicion(): string {
        return $this->fechaEdicion;
    }

    public function getHora(): string {
        return $this->hora;
    }

    public function setId(int $id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setAula(Aula $aula) {
        if ($aula instanceof Aula) {
            $this->aula = $aula;
        }
    }

    public function setFecha(string $fecha) {
        $this->fecha = $fecha;
    }

    public function setFechaEdicion(string $fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function setHora(string $hora) {
        if (Util::validarLlamadoHora($hora)) {
            $this->hora = $hora;
        }
    }

    public function borrar(): array {
        if ($this->id) {
            $consulta = "DELETE FROM llamado WHERE id = {$this->id}";
            return Conexion::getInstancia()->borrar($consulta);
        }
        return array(0, "No se pudo hacer referencia al llamado");
    }

    public function crear() {
        if ($this->fecha && $this->hora) {
            $idAula = $this->crearAula();
            $consulta = "INSERT INTO llamado VALUES (NULL, {$idAula}, '{$this->fecha}', NULL, '{$this->hora}')";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                $this->id = $resultado[2];
                Log::guardarActividad("LLAMADO --> NUEVO ({$this->id}, {$idAula}, {$this->fecha}, {$this->hora})");
            }
            return $resultado;
        }
        return array(0, "No se indicaron todos los campos obligatorios del llamado");
    }

    private function crearAula() {
        if ($this->aula) {
            if (!$this->aula->getId()) {
                $creacion = $this->aula->crear();
                return ($creacion[0] == 2) ? $this->aula->getId() : NULL;
            }
            return $this->aula->getId();
        }
        return "NULL";
    }

    public function modificar() {
        if ($this->id && $this->fecha && $this->hora) {
            $consulta = "UPDATE llamado SET fecha='{$this->fecha}', hora='{$this->hora}', "
                    . "idaula={$this->aula}, fechamod = NOW() "
                    . "WHERE idllamado = {$this->idLlamado}";
            return Conexion::getInstancia()->modificar($consulta);
        }
        return array(0, "Los campos no cumplen con el formato requerido");
    }

}
