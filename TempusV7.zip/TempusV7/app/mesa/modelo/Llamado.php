<?php


class Llamado {

    private $id;
    private $aula;
    private $mesaExamen;
    private $tribunal;
    private $fecha;
    private $fechaEdicion;
    private $hora;
    
    public function __construct($id, $aula, $mesaExamen, $tribunal, $fecha, $fechaEdicion, $hora) {
        $this->id = $id;
        $this->aula = $aula;
        $this->mesaExamen = $mesaExamen;
        $this->tribunal = $tribunal;
        $this->fecha = $fecha;
        $this->fechaEdicion = $fechaEdicion;
        $this->hora = $hora;
    }
    
    public function getId() {
        return $this->id;
    }

    public function getAula() {
        return $this->aula;
    }

    public function getMesaExamen() {
        return $this->mesaExamen;
    }

    public function getTribunal() {
        return $this->tribunal;
    }

    public function getFecha() {
        return $this->fecha;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function getHora() {
        return $this->hora;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setAula($aula) {
        $this->aula = $aula;
    }

    public function setMesaExamen($mesaExamen) {
        $this->mesaExamen = $mesaExamen;
    }

    public function setTribunal($tribunal) {
        $this->tribunal = $tribunal;
    }

    public function setFecha($fecha) {
        $this->fecha = $fecha;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function setHora($hora) {
        $this->hora = $hora;
    }




}
