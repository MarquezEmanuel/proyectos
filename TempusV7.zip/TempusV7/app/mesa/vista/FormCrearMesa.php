<?php
/* SE INCLUYE EL ARCHIVO DE CONSTANTES Y EL AUTOLOAD */

include_once '../../principal/vista/header.php';
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

/* SE REFERENCIAN LOS NAMESPACE */

use app\mesa\controlador\ControladorMesa;
use app\principal\controlador\ControladorHTML;
use app\principal\modelo\AutoCargador;

AutoCargador::cargarModulos();

/* INICIA EL CODIGO CON LA FUNCIONALIDAD PROPIA */

$controlador = new ControladorMesa();
$cantidad = $controlador->obtenerNumeroDeLlamados();
if ($cantidad > 0) {

    // ESTABLECE COMO VALOR PREDETERMINADO LA FECHA DEL DIA PARA SELECCIONAR

    date_default_timezone_set('America/Argentina/Buenos_Aires');
    $fechaHoy = date("Y-m-d");

    // CARGA EL RANGO DE HORARIO PARA SELECCIONAR

    $opcionesHora = "";
    for ($hora = 10; $hora < 23; ++$hora) {
        $opcionesHora .= "<option value='{$hora}:00'>{$hora}:00 hs</option>";
    }

    $formulario = '
        <input type="hidden" name="cantidadLlamados" id="cantidadLlamados" value="' . $cantidad . '">
        <div class="card border-dark mb-2">
            <div class="card-header bg-dark text-white">Seleccione asignatura</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="plan" class="col-sm-2 col-form-label">* Asignatura:</label>
                    <div class="col">
                        <select class="form-control mb-2" 
                                name="plan" id="plan" required></select>
                    </div>
                </div>
            </div>
        </div>
        <div class="card border-dark mb-2">
            <div class="card-header bg-dark text-white">Seleccione los integrantes del tribunal</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="presidente" class="col-sm-2 col-form-label">* Presidente:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="presidente" id="presidente"></select>
                    </div>
                    <label for="vocal1" class="col-sm-2 col-form-label">* Vocal primero:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="vocal1" id="vocal1" disabled></select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="vocal2" class="col-sm-2 col-form-label">Vocal segundo:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="vocal2" id="vocal2" disabled></select>
                    </div>
                    <label for="suplente" class="col-sm-2 col-form-label">Suplente:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="suplente" id="suplente" disabled></select>
                    </div>
                </div>
            </div>
        </div>
        <div class="card border-dark">
            <div class="card-header bg-dark text-white">Complete los datos del primer llamado</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="fecha1" class="col-sm-2 col-form-label">* Fecha:</label>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               value="' . $fechaHoy . '" min="' . $fechaHoy . '"
                               name="fecha1" id="fecha1" required>
                    </div>
                    <label for="vocal2" class="col-sm-2 col-form-label">* Hora:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="hora1" id="hora1">' . $opcionesHora . '</select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="aula1" class="col-sm-2 col-form-label">Aula:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="aula1" id="aula1"></select>
                    </div>
                     <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>
            </div>
        </div>';
    if ($cantidad == 2) {
        $fechaSegundo = date("Y-m-d", strtotime('+3 days', strtotime($fechaHoy)));
        $formulario .= '<br>
            <div class="card border-dark">
                <div class="card-header bg-dark text-white">Complete los datos del segundo llamado</div>
                <div class="card-body">
                    <div class="form-row">
                        <label for="fecha2" class="col-sm-2 col-form-label">* Fecha y hora:</label>
                        <div class="col">
                            <input type="date" class="form-control mb-2" 
                                   name="fecha2" id="fecha2"
                                   value="' . $fechaSegundo . '" min="' . $fechaSegundo . '" required>
                        </div>
                        <div class="col">
                            <select class="form-control mb-2" name="hora2" id="hora2">' . $opcionesHora . '</select>
                        </div>
                        <div class="col-1 text-right"></div>
                    </div>
                    <div class="form-row">
                        <label for="aula2" class="col-sm-2 col-form-label">Aula:</label>
                        <div class="col">
                            <select class="form-control mb-2" name="aula2" id="aula2"></select>
                        </div>
                         <label class="col-sm-2 col-form-label"></label>
                        <div class="col"></div>
                    </div>
                </div>
            </div>';
    }
    $formulario .= '
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-success" 
                        id="btnCrearMesa" title="Guardar datos">
                    <i class="far fa-save"></i> GUARDAR
                </button>
                <a href="mesa_buscar">
                    <button type="button" class="btn btn-outline-info">
                        <i class="fas fa-search"></i> BUSCAR
                    </button>
                </a>
            </div>
        </div>';
} else {
    $titulo = "Información básica";
    $mensaje = ($cantidad == -1) ? "Ocurrió un error al consultar cantidad de llamados" : "Debe importar mesas de examen antes de crear";
    $contenido = ControladorHTML::mostrarAlertaResultadoOperacion(0, $mensaje);
    $formulario = ControladorHTML::mostrarCard($titulo, $contenido);
}
?>
<div class="container-fluid" id="contenido">
    <div class="container">
        <div class="form-row mt-4 mb-4">
            <div class="col text-left"><h4><i class="far fa-calendar-alt"></i> CREAR MESA DE EXAMEN</h4></div>
            <div class="col text-right">
                <a href="principal_home">
                    <button class="btn btn-sm btn-outline-secondary"> 
                        <i class="fas fa-times"></i> CERRAR
                    </button>
                </a>
            </div>
        </div>
        <div id="seccionResultado"></div>
        <div id="seccionFormulario">
            <form id="formCrearMesa" name="formCrearMesa" method="POST">
                <?= $formulario; ?>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/CrearMesa.js"></script>

