
$(document).ready(function () {

    buscarPermisos();

    $("#formBuscarPermiso").submit(function (evento) {
        evento.preventDefault();
        $("#peticion").val("true");
        buscarPermisos();
    });

    $(".editar").click(function (evento) {
        evento.preventDefault();
        var idPermiso = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./app/usuarios/vistas/FormModificarPermiso.php",
            data: "idPermiso=" + idPermiso,
            success: function (data) {
                $("#contenido").html(data);
            },
            error: function (data) {
                console.log(data);
                $("#contenido").html('<div class="alert alert-danger text-center" role="alert"><strong>No se procesó la petición</strong></div>');
            }
        });
    });

    $(".borrar").click(function (evento) {
        evento.preventDefault();
        $("#modalIdPermiso").val($(this).attr("name"));
        $("#ModalBorrarPermiso").modal({});
    });

    $('#btnBorrarPermiso').click(function () {
        $.ajax({
            type: "POST",
            url: "./app/usuarios/vistas/ProcesarBorrarPermiso.php",
            data: $("#formBorrarPermiso").serialize(),
            success: function (data) {
                $('#cuerpoModal').html(data);
                $('#btnBorrarPermiso').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                $("#cuerpoModal").html('<div class="alert alert-danger text-center" role="alert"><strong>No se procesó la petición</strong></div>');
            }
        });
    });

    $("#btnRefrescarPantalla").click(function () {
        setTimeout(function () {
            location.reload();
        }, 600);
    });

});

function buscarPermisos() {
    $.ajax({
        type: "POST",
        url: "./ProcesarBuscarPermiso.php",
        data: $("#formBuscarPermiso").serialize(),
        success: function (data) {
            $("#seccionInferior").html(data);
            $("table#tablaBuscarPermisos").DataTable({
                dom: 'frtip',
                responsive: true,
                language: {url: "./lib/js/Spanish.json"}
            });
        },
        error: function (data) {
            console.log(data);
            var men = '<strong>No se procesó la petición</strong>';
            var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
            $("#seccionInferior").html(div);
        }
    });
}