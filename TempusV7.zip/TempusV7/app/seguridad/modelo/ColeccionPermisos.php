<?php

namespace app\seguridad\modelo;

use app\principal\modelo\Conexion as Conexion;

/**
 * 
 * @package app\seguridad\modelo
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ColeccionPermisos {

    public static function buscar($nombre): array {
        $consulta = "SELECT PER.*, (CASE WHEN CAN.cantidad IS NULL THEN 0 ELSE CAN.cantidad END) cantidad "
                . "FROM permiso PER LEFT JOIN (SELECT idpermiso, COUNT(*) cantidad FROM rol_permiso GROUP BY idpermiso) CAN "
                . "ON CAN.idpermiso = PER.idpermiso WHERE PER.nombre LIKE '%{$nombre}%'";
        return Conexion::getInstancia()->seleccionar($consulta);
    }

    /**
     * Listar todos los permisos.
     */
    public static function listarPermisos(): array {
        $consulta = "SELECT * FROM permiso ORDER BY nombre";
        return Conexion::getInstancia()->seleccionar($consulta);
    }

    public static function listarResumenPermisos($limite): array {
        if ($limite > 0) {
            $consulta = "SELECT PER.*, (CASE WHEN CAN.cantidad IS NULL THEN 0 ELSE CAN.cantidad END) cantidad "
                    . "FROM permiso PER LEFT JOIN (SELECT idpermiso, COUNT(*) cantidad FROM rol_permiso GROUP BY idpermiso) CAN "
                    . "ON CAN.idpermiso = PER.idpermiso ORDER BY PER.idpermiso DESC LIMIT 10";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se estableció un limite válido");
    }

    /* Devuelve todos los permisos de un determinado rol */

    public static function listarPermisosRol($idRol): array {
        if ($idRol > 0) {
            $consulta = "SELECT pe.* FROM permiso pe INNER JOIN rol_permiso rp "
                    . "ON rp.permiso_id = pe.id AND rp.rol_id = {$idRol}";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se pudo hacer referencia al rol");
    }

    public function listarResumenInicial(): array {
        $consulta = "SELECT 'Total de permisos' nombre, COUNT(*) cantidad FROM permiso";
        $resultado = Conexion::getInstancia()->seleccionar($consulta);
        $this->descripcion = Conexion::getInstancia()->getDescripcion();
        return $resultado;
    }

}
