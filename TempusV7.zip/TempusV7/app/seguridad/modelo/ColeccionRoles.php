<?php

namespace app\seguridad\modelo;

use app\principal\modelo\Conexion as Conexion;

/**
 * 
 * @package app\seguridad\modelo
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ColeccionRoles {

    public static function buscar($nombre): array {
        $consulta = "SELECT ROL.*, (CASE WHEN USU.usuarios IS NULL THEN 0 ELSE USU.usuarios END) usuarios, PER.permisos FROM rol ROL "
                . "LEFT JOIN (SELECT idrol, COUNT(*) permisos FROM rol_permiso GROUP BY idrol) PER ON PER.idrol = ROL.idrol "
                . "LEFT JOIN (SELECT idrol, COUNT(*) usuarios FROM usuario_rol GROUP BY idrol) USU ON USU.idrol = ROL.idrol "
                . "WHERE ROL.nombre LIKE '%{$nombre}%'";
        return Conexion::getInstancia()->seleccionar($consulta);
    }

    /**
     * Listar todos los roles.
     */
    public static function listarRoles(): array {
        $consulta = "SELECT * FROM rol ORDER BY nombre";
        return Conexion::getInstancia()->seleccionar($consulta);
    }

    public static function listarResumenRoles($limite): array {
        if ($limite > 0) {
            $consulta = "SELECT ROL.*, (CASE WHEN USU.usuarios IS NULL THEN 0 ELSE USU.usuarios END) usuarios, PER.permisos FROM rol ROL "
                    . "LEFT JOIN (SELECT idrol, COUNT(*) permisos FROM rol_permiso GROUP BY idrol) PER ON PER.idrol = ROL.idrol "
                    . "LEFT JOIN (SELECT idrol, COUNT(*) usuarios FROM usuario_rol GROUP BY idrol) USU ON USU.idrol = ROL.idrol "
                    . "ORDER BY ROL.idrol DESC LIMIT 10";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se estableció un limite válido");
    }

    public static function listarResumenInicial() {
        $consulta = "SELECT 'Total de roles' nombre, COUNT(*) cantidad FROM rol";
        $resultado = Conexion::getInstancia()->seleccionar($consulta);
        $this->descripcion = Conexion::getInstancia()->getDescripcion();
        return $resultado;
    }

}
