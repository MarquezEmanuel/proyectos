<?php

namespace app\seguridad\modelo;

use app\principal\modelo\Conexion;

/**
 * 
 * @package app\seguridad\modelo
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ColeccionRoles {

    /**
     * Buscar roles por nombre y ordenados por nombre.
     * @param string $nombreRol Nombre o parte del nombre del rol.
     * @return array Arreglo de dos posiciones (codigo, datos).
     */
    public static function buscarPorNombre($nombreRol): array {
        $expresion = "/^[a-z_ ]{0,15}$/";
        if (preg_match($expresion, mb_strtolower($nombreRol))) {
            $consulta = "SELECT * FROM vw_rol WHERE nombre LIKE '%{$nombreRol}%' ORDER BY nombre";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "El nombre no cumple con el formato requerido");
    }

    /**
     * Listar todos los roles ordernados por nombre. Selecciona el id y nombre
     * de cada uno de los roles guardados. 
     * @return array Arreglo de dos posiciones (codigo, datos).
     */
    public static function listarRoles(): array {
        $consulta = "SELECT * FROM rol ORDER BY nombre";
        return Conexion::getInstancia()->seleccionar($consulta);
    }

    /**
     * Listar un resumen limitado de roles. Selecciona el id, nombre, cantidad
     * de usuarios asociados y cantidad de permisos asociados para uno de los roles 
     * segun el limite establecido.
     * @param int $limite Limite maximo de roles a seleccionar (LIMIT).
     * @return array Arreglo de dos posiciones (codigo, datos).
     */
    public static function listarResumenRoles($limite): array {
        if ($limite > 0) {
            $consulta = "SELECT * FROM vw_rol ORDER BY id DESC LIMIT {$limite}";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se estableció un limite válido");
    }

    public static function listarResumenInicial() {
        $consulta = "SELECT 'Total de roles' nombre, COUNT(*) cantidad FROM rol";
        $resultado = Conexion::getInstancia()->seleccionar($consulta);
        $this->descripcion = Conexion::getInstancia()->getDescripcion();
        return $resultado;
    }

}
