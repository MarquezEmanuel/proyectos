<?php

namespace app\seguridad\modelo;

/**
 * Description of Usuario
 *
 * @author Emanuel
 */
class Usuario {
    //put your code here
}
