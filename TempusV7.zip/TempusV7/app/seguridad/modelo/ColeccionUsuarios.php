<?php

namespace app\seguridad\modelo;

use app\principal\modelo\Conexion as Conexion;

/**
 * 
 * @package app\seguridad\modelo
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ColeccionUsuarios {

    public static function buscar($nombre): array {
        $consulta = "SELECT * FROM vista_usuarios WHERE nombreUsuario LIKE '%{$nombre}%'";
        return Conexion::getInstancia()->seleccionar($consulta);
    }

    public static function listarResumenUsuarios($limite): array {
        if ($limite > 0) {
            $consulta = "SELECT * FROM vista_usuarios WHERE estado = 'Activo' ORDER BY idUsuario DESC";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
    }

    public static function listarResumenInicial(): array {
        $consulta = "SELECT 'Total de usuarios' nombre, COUNT(*) cantidad FROM usuario UNION "
                . "SELECT 'Total de usuarios en estado activo' nombre, COUNT(*) cantidad FROM usuario WHERE estado = 'Activo' UNION "
                . "SELECT 'Total de usuarios en estado inactivo' nombre, COUNT(*) cantidad FROM usuario WHERE estado = 'Inactivo'";
        $resultado = Conexion::getInstancia()->seleccionar($consulta);
        $this->descripcion = Conexion::getInstancia()->getDescripcion();
        return $resultado;
    }

}
