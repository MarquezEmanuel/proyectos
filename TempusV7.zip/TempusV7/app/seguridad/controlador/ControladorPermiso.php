<?php

namespace app\seguridad\controlador;

use app\seguridad\modelo\Permiso as Permiso;
use app\seguridad\modelo\ColeccionPermisos as Permisos;

/**
 * 
 * @package app\seguridad\controlador
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ControladorPermiso {

    public function borrar($id) {
        $permiso = new Permiso($id);
        $resultado = $permiso->borrar();
        return $resultado;
    }

    public function buscar($nombre) {
        return Permisos::buscar($nombre);
    }

    public function crear($nombre) {
        $permiso = new Permiso(NULL, $nombre);
        $creacion = $permiso->crear();
        return $creacion;
    }

    public function listarPermisos() {
        return Permisos::listarPermisos();
    }

    public function listarResumenPermisos($limite) {
        return Permisos::listarResumenPermisos($limite);
    }

    public function listarResumenInicial() {
        $permisos = new Permisos();
        $resultado = $permisos->listarResumenInicial();
        $this->descripcion = $permisos->getDescripcion();
        return $resultado;
    }

    public function modificar($id, $nombre) {
        $permiso = new Permiso($id, $nombre);
        $modificacion = $permiso->modificar();
        return $modificacion;
    }

}
