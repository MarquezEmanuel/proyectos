<?php

namespace app\docente\modelo;

use app\principal\modelo\Conexion;

/**
 * 
 * @package app\docente\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ColeccionDocentes {

    /**
     * Seleccionar docente por su nombre.
     * @param string $nombreDocente Nombre del docente o parte del nombre.
     * @return array Arreglo de dos posiciones (codigo, mensaje).
     */
    public static function seleccionar($nombreDocente) {
        $consulta = "SELECT * FROM docente "
                . "WHERE nombre LIKE '%{$nombreDocente}%' ORDER BY nombre";
        return Conexion::getInstancia()->seleccionar($consulta);
    }

}
