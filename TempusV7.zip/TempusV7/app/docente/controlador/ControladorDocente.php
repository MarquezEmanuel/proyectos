<?php

/**
 * Description of ControladorDocente
 *
 * @author Emanuel
 */
class ControladorDocente {
    //put your code here
}
