<?php

/* 
 * 
 * ALTER TABLE clase ADD UNIQUE `unique_plan_dia` (`idPlan`, `diaSemana`)
 * 
 */

