<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$fecha = "26/9/2019";



$date = DateTime::createFromFormat('d/m/Y', $fecha);

echo $date->format('d/m/Y');

echo "<br> " . $_SERVER["SCRIPT_NAME"];

$array = explode("/", $_SERVER["SCRIPT_NAME"]);
var_dump($array);

echo '<br>' . $array[count($array) - 1];


echo "<br>" . str_repeat("=", 10);
