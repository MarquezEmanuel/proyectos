<?php
include_once './app/modelo/Autocargador.php';
include_once './config/inc_config.php';

use app\modelo\Encriptador;
use app\modelo\AutoCargador;
use app\modelo\Log;
use app\modelo\Resultado;
use app\repositorio\MySQL;
use app\repositorio\RepositorioPermiso;
use app\modelo\Permiso;

use app\servicio\ServicioPermiso;

AutoCargador::cargarModulos();


$servicio = new ServicioPermiso();

$resultado = $servicio->crear('PERMISO_EJEMPLO');
var_dump($resultado);

$resultado = $servicio->modificar(9, 'PERMI_PRUEBA');
var_dump($resultado);

$resultado = $servicio->obtenerPorID(1);
var_dump($resultado);

$resultado = $servicio->listar();
var_dump($resultado);

$resultado = $servicio->listarPorIDRol(1);
var_dump($resultado);
