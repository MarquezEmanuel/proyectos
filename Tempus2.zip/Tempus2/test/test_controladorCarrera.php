<?php

include_once '../app/modelo/Autocargador.php';
include_once '../config/inc_config.php';

use app\controlador\ControladorCarrera;
use app\modelo\AutoCargador;

AutoCargador::cargarModulos();

$controlador = new ControladorCarrera();

$codigo = 987;
$nombre = 'Carrera de prueba';
$resultado01 = $controlador->crear($codigo, $nombre);
echo '<br>' . $resultado01->getMensaje() . '<br>';
if ($resultado01->isSuccess()) {
    $carrera = $resultado01->getDatos();
    echo '<br>ID: ' . $carrera->getId() . '<br>';
}
