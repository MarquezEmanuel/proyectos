<?php

include_once '../app/modelo/Autocargador.php';
include_once '../config/inc_config.php';

use app\repositorio\RepositorioTribunal;
use app\modelo\Tribunal;
use app\modelo\AutoCargador;

AutoCargador::cargarModulos();

$repositorio = new RepositorioTribunal();

$tirbunal = new Tribunal(NULL, 1, 2, 3, 4);
$resultado = $repositorio->crear($tirbunal);
echo '<br>Mensaje:' . $resultado->getMensaje() . '<br>';
if ($resultado->isSuccess()) {
    $tirbunal = $resultado->getDatos();
    echo '<br>ID:' . $tirbunal->getId() . '<br>';
}
