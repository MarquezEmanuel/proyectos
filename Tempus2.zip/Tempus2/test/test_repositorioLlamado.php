<?php

include_once '../app/modelo/Autocargador.php';
include_once '../config/inc_config.php';

use app\repositorio\RepositorioLlamado;
use app\modelo\Llamado;
use app\modelo\AutoCargador;

AutoCargador::cargarModulos();


$repositorio = new RepositorioLlamado();

$llamado = new Llamado(NULL, 1, '2021-02-15', '10:30', 'Inactivo');
$resultado = $repositorio->crear($llamado);
echo '<br>Mensaje: ' . $resultado->getMensaje() . '<br>';
if ($resultado->isSuccess()) {
    $llamado = $resultado->getDatos();
    echo '<br>ID:' . $llamado->getId() . '<br>';
}


