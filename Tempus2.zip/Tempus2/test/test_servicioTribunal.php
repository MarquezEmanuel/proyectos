<?php

include_once '../app/modelo/Autocargador.php';
include_once '../config/inc_config.php';

use app\servicio\ServicioTribunal;
use app\modelo\AutoCargador;

AutoCargador::cargarModulos();


$servicio = new ServicioTribunal();

$resultado = $servicio->crear('Zeta Emanuel', 'Zeta Alberto', NULL, NULL);
echo '<br>Mensaje:' . $resultado->getMensaje() . '<br>';
if ($resultado->isSuccess()) {
    $tirbunal = $resultado->getDatos();
    echo '<br>ID:' . $tirbunal->getId() . '<br>';
}
