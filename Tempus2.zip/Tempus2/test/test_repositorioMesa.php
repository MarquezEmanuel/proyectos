<?php


include_once '../app/modelo/Autocargador.php';
include_once '../config/inc_config.php';

use app\repositorio\RepositorioMesa;
use app\modelo\MesaExamen;
use app\modelo\AutoCargador;

AutoCargador::cargarModulos();

$repositorio = new RepositorioMesa();
$mesa = new MesaExamen(NULL, 104, NULL, 52);
$resultado = $repositorio->crear($mesa);
echo '<br>Mensaje: ' . $resultado->getMensaje() . '<br>';
if ($resultado->isSuccess()) {
    $mesa = $resultado->getDatos();
    echo '<br>ID:' . $mesa->getId() . '<br>';
}
