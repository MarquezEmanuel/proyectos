<?php

include_once '../app/modelo/Autocargador.php';
include_once '../config/inc_config.php';

use app\controlador\ControladorAula;
use app\modelo\AutoCargador;

AutoCargador::cargarModulos();

$controlador = new ControladorAula();

$nombre = 'Aula de prueba';
$sector = 'x';
$resultado01 = $controlador->crear($sector, $nombre);
echo '<br>' . $resultado01->getMensaje() . '<br>';
if ($resultado01->isSuccess()) {
    $aula = $resultado01->getDatos();
    echo '<br>ID: ' . $aula->getId() . '<br>';
}
