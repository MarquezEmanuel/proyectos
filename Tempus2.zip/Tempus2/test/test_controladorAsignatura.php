<?php
include_once '../app/modelo/Autocargador.php';
include_once '../config/inc_config.php';

use app\controlador\ControladorAsignatura;
use app\modelo\AutoCargador;

AutoCargador::cargarModulos();

$controlador = new ControladorAsignatura();

$nombre = 'minuto para ganar';
$resultado01 = $controlador->crear($nombre);
echo '<br>Mensaje: ' . $resultado01->getMensaje() . '<br>';
if ($resultado01->isSuccess()) {
    $asignatura = $resultado01->getDatos();
    echo '<br>ID: ' . $asignatura->getId() . '<br>';
}

$nombre = 'minuto para ganar';
$resultado02 = $controlador->crearObtener($nombre);
echo '<br>Mensaje: ' . $resultado02->getMensaje() . '<br>';
if ($resultado02->isSuccess()) {
    $asignatura = $resultado02->getDatos();
    echo '<br>ID: ' . $asignatura->getId() . ' ' . $asignatura->getNombreLargo() . '<br>';
}
