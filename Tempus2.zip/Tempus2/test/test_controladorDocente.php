<?php

include_once '../app/modelo/Autocargador.php';
include_once '../config/inc_config.php';

use app\controlador\ControladorDocente;
use app\modelo\AutoCargador;

AutoCargador::cargarModulos();

$controlador = new ControladorDocente();

$nombre = 'Santiago garcia';
$resultado01 = $controlador->crear($nombre);
echo '<br>' . $resultado01->getMensaje() . '<br>';
if ($resultado01->isSuccess()) {
    $docente = $resultado01->getDatos();
    echo '<br>ID: ' . $docente->getId() . '<br>';
}

$nombre = 'Santiago garcia';
$resultado02 = $controlador->crearObtener($nombre);
echo '<br>' . $resultado02->getMensaje() . '<br>';
if ($resultado02->isSuccess()) {
    $docente = $resultado02->getDatos();
    echo '<br>ID: ' . $docente->getId() . ' ' . $docente->getNombre() . '<br>';
}
