<?php

namespace app\servicio;

use app\modelo\Asignatura;
use app\modelo\Log;
use app\repositorio\RepositorioAsignatura;

class ServicioAsignatura
{

    /** @var Log Instancia para guardar logs. */
    private $log;

    /** @var RepositorioAsignatura Repositorio para operar con la base de datos */
    private $repoAsignatura;

    public function __construct()
    {
        $this->log = Log::getInstancia();
        $this->repoAsignatura = new RepositorioAsignatura();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function crear($nombreLargo)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $asignatura = new Asignatura(NULL, $nombreLargo, $nombreLargo);
        return $this->repoAsignatura->crear($asignatura);
    }

    public function crearObtener($nombreLargo)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $asignatura = new Asignatura(NULL, $nombreLargo, $nombreLargo);
        $resultado = $this->repoAsignatura->crear($asignatura);
        if ($resultado->isWarning()) {
            return $this->repoAsignatura->obtenerPorNombreLargo($asignatura);
        }
        return $resultado;
    }
}
