<?php

namespace app\servicio;

use app\modelo\MesaExamen;
use app\modelo\Log;
use app\repositorio\RepositorioMesa;
use app\servicio\ServicioLlamado;
use app\servicio\ServicioTribunal;

class ServicioMesa
{
    /** @var Log Instancia para guardar logs. */
    private $log;

    /** @var RepositorioMesa Repositorio para operar con la base de datos. */
    private $repoMesa;

    /** @var ServicioLlamado Servicio para operar con las funciones de llamados. */
    private $servicioLlamado;

    /** @var ServicioTribunal Servicio para operar con las funciones de tribunales. */
    private $servicioTribunal;

    public function __construct()
    {
        $this->log = Log::getInstancia();
        $this->repoMesa = new RepositorioMesa();
        $this->servicioLlamado = new ServicioLlamado();
        $this->servicioTribunal = new ServicioTribunal();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function crearUnLlamado($sector, $nombreAula, $fecha, $hora, $estado, $presidente, $vocal1, $vocal2, $suplente, $observacion)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $resultado01 = $this->servicioLlamado->crear($sector, $nombreAula, $fecha, $hora, $estado);
        if (!$resultado01->isSuccess()) {
            return $resultado01;
        }
        $resultado02 = $this->servicioTribunal->crear($presidente, $vocal1, $vocal2, $suplente);
        if (!$resultado02->isSuccess()) {
            return $resultado02;
        }
        $llamado = $resultado01->getDatos();
        $tribunal = $resultado02->getDatos();
        $idPrimerLlamado = $llamado->getId();
        $idTribunal = $tribunal->getId();
        $mesa = new MesaExamen(NULL, $idPrimerLlamado, NULL, $idTribunal, $observacion);
        return $this->repoMesa->crear($mesa);
    }
}
