<?php

namespace app\servicio;

use app\modelo\Aula;
use app\modelo\Log;
use app\repositorio\RepositorioAula;

class ServicioAula
{
    /** @var Log Instancia para guardar logs. */
    private $log;

    /** @var RepositorioAula Repositorio para operar con la base de datos */
    private $repoAula;

    public function __construct()
    {
        $this->log = Log::getInstancia();
        $this->repoAula = new RepositorioAula();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function crear($sector, $nombre)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $aula = new Aula(NULL, $nombre, $sector);
        return $this->repoAula->crear($aula);
    }

    public function crearObtener($sector, $nombre)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $aula = new Aula(NULL, $nombre, $sector);
        $resultado = $this->repoAula->crear($aula);
        if ($resultado->isWarning()) {
            return $this->repoAula->obtenerPorNombreSector($aula);
        }
        return $resultado;
    }
}
