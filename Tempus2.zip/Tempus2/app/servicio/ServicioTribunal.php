<?php

namespace app\servicio;

use app\modelo\Log;
use app\modelo\Tribunal;
use app\servicio\ServicioDocente;
use app\repositorio\RepositorioTribunal;

class ServicioTribunal
{

    private $log;
    private $servicioDocente;
    private $repoTribunal;

    public function __construct()
    {
        $this->log = Log::getInstancia();
        $this->servicioDocente = new ServicioDocente();
        $this->repoTribunal = new RepositorioTribunal();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function crear($nombrePresidente, $nombreVocal1, $nombreVocal2, $nombreSuplente)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $docentes = array($nombrePresidente, $nombreVocal1, $nombreVocal2, $nombreSuplente);
        $identificadores = array();
        foreach ($docentes as $nombreDocente) {
            if ($nombreDocente) {
                $resultado = $this->servicioDocente->crearObtener($nombreDocente);
                if (!$resultado->isSuccess()) {
                    return $resultado;
                }
                $docente = $resultado->getDatos();
                $identificadores[] = $docente->getId();
            } else {
                $identificadores[] = NULL;
            }
        }
        $tribunal = new Tribunal(NULL, $identificadores[0], $identificadores[1], $identificadores[2], $identificadores[3]);
        return $this->repoTribunal->crear($tribunal);
    }
}
