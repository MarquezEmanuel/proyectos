<?php

namespace app\servicio;

use app\modelo\Log;
use app\modelo\Permiso;
use app\repositorio\RepositorioPermiso;

class ServicioPermiso
{
    /** @var Log Instancia para guardar logs. */
    private $log;

    /** @var RepositorioPermiso Repositorio para operar con la base de datos. */
    private $repoPermiso;

    public function __construct()
    {
        $this->log = Log::getInstancia();
        $this->repoPermiso = new repositorioPermiso();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function crear($nombre)
    {
        $permiso = new Permiso(null, $nombre);
        return $this->repoPermiso->crear($permiso);
    }

    public function listar()
    {
        return $this->repoPermiso->listar();
    }

    public function listarParaBusqueda($nombre)
    {
        return $this->repoPermiso->listarParaBusqueda($nombre);
    }

    public function listarInformesPermiso()
    {
        return $this->repoPermiso->listarInformesPermiso();
    }

    public function listarPorIDRol($id)
    {
        return $this->repoPermiso->listarPorIDRol($id);
    }

    public function modificar($id, $nombre)
    {
        $permiso = new Permiso($id, $nombre);
        return $this->repoPermiso->modificar($permiso);
    }

    public function obtenerPorID($id)
    {
        $permiso = new Permiso($id);
        return $this->repoPermiso->obtenerPorID($permiso);
    }
}
