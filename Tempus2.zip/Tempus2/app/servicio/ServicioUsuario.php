<?php

namespace app\servicio;

use app\modelo\Log;
use app\modelo\Usuario;
use app\repositorio\RepositorioUsuario;
use app\servicio\ServicioRol;

class ServicioUsuario
{
    /** @var Log Instancia para guardar logs. */
    private $log;

    /** @var RepositorioUsuario Repositorio para operar con la base de datos. */
    private $repoUsuario;

    /** @var ServicioRol Servicio para operar con roles. */
    private $servicioRol;

    public function __construct()
    {
        $this->log = Log::getInstancia();
        $this->repoUsuario = new RepositorioUsuario();
        $this->servicioRol = new ServicioRol();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function login($email)
    {
        $resultado01 = $this->repoUsuario->login($email);
        if ($resultado01->isSuccess()) {
            $datosUsuario = $resultado01->getDatos()[0];
            $usuario = new Usuario($datosUsuario);
            $resultado02 = $this->repoRol->obtenerPorID($usuario->getRol());
            if ($resultado02->isSuccess()) {
            }
            $resultado01->setDatos($usuario);
        }
    }
}
