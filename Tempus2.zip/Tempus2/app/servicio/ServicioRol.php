<?php

namespace app\servicio;

use app\modelo\Log;
use app\modelo\Rol;
use app\repositorio\RepositorioRol;

class ServicioRol
{
    /** @var Log Instancia para guardar logs. */
    private $log;

    /** @var RepositorioRol Repositorio para operar con la base de datos. */
    private $repoRol;

    /** @var ServicioPermiso Servicio para operar con permisos. */
    private $servicioPermiso;

    public function __construct()
    {
        $this->log = Log::getInstancia();
        $this->repoRol = new RepositorioRol();
        $this->servicioPermiso = new ServicioPermiso();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function crear($nombre, $permisos)
    {
        $this->repoRol->iniciarTransaccion();
        $resultados = array();
        $rol = new Rol(NULL, $nombre, $permisos);
        $resultados[] = $this->repoRol->crear($rol);
        $id = $rol->getId();
        $resultados[] = $this->repoRol->agregarPermisos($id, $permisos);
        foreach ($resultados as $resultado) {
            if (!$resultado->isSuccess()) {
                $this->repoRol->rollback();
                $this->repoLog->guardarErrores($this->repoRol->getLogs());
                return $resultado;
            }
        }
        $this->repoRol->commit();
        return $resultado[0];
    }

    public function modificar($id, $nombre, $permisos)
    {
    }

    public function listar()
    {
        return $this->repoRol->listar();
    }

    public function listarParaBusqueda($nombre)
    {
        return $this->repoRol->listarParaBusqueda($nombre);
    }

    public function obtenerPorID($id)
    {
        $rol = new Rol($id);
        $resultado01 = $this->repoRol->obtenerPorID($id);
        if ($resultado01->isSuccess()) {
            $resultado02 = $this->servicioPermiso->listarPorIDRol($id);
            if (!$resultado02->isSuccess()) {
                return $resultado02;
            }
            $permisos = $resultado02->getDatos();
            $rol->setPermisos($permisos);
            $resultado01->setDatos($rol);
        }
        return $resultado01;
    }

    public function seleccionar($nombre)
    {
        return $this->repoRol->seleccionar($nombre);
    }
}
