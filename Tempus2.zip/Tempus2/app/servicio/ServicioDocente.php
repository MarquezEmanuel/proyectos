<?php

namespace app\servicio;

use app\modelo\Docente;
use app\modelo\Log;
use app\repositorio\RepositorioDocente;

class ServicioDocente
{
    /** @var Log Instancia para guardar logs. */
    private $log;

    /** @var RepositorioDocente Repositorio para operar con la base de datos */
    private $repoDocente;

    public function __construct()
    {
        $this->log = Log::getInstancia();
        $this->repoDocente = new RepositorioDocente();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function crear($nombre)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $docente = new Docente(NULL, $nombre);
        return $this->repoDocente->crear($docente);
    }

    public function crearObtener($nombre)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $docente = new Docente(NULL, $nombre);
        $resultado = $this->repoDocente->crear($docente);
        if ($resultado->isWarning()) {
            return $this->repoDocente->obtenerPorNombre($docente);
        }
        return $resultado;
    }
}
