<?php

namespace app\servicio;

use app\modelo\Llamado;
use app\modelo\Log;
use app\repositorio\RepositorioLlamado;

class ServicioLlamado
{
    /** @var Log Instancia para guardar logs. */
    private $log;

    /** @var RepositorioLlamado Repositorio para operar con la base de datos. */
    private $repoLlamado;

    /** @var ServicioAula Servicio para operar con las funciones de aulas. */
    private $servicioAula;

    public function __construct()
    {
        $this->log = Log::getInstancia();
        $this->repoLlamado = new RepositorioLlamado();
        $this->servicioAula = new ServicioAula();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function crear($sector, $nombre, $fecha, $hora, $estado)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $idAula = NULL;
        if ($nombre && $sector) {
            $resultado = $this->servicioAula->crearObtener($sector, $nombre);
            if (!$resultado->isSuccess()) {
                return $resultado;
            }
            $aula = $resultado->getDatos();
            $idAula = $aula->getId();
        }
        $llamado = new Llamado(NULL, $idAula, $fecha, $hora, $estado);
        return $this->repoLlamado->crear($llamado);
    }
}
