<?php

namespace app\controlador;

use app\modelo\Docente;
use app\modelo\Log;
use app\servicio\ServicioDocente;

class ControladorDocente
{
    private $servicioDocente;
    private $log;

    public function __construct()
    {
        $this->log = Log::getInstancia();
        $this->servicioDocente = new ServicioDocente();
    }

    public function crear($nombre)
    {
        $this->log->info('--> Creación de docente');
        return $this->servicioDocente->crear($nombre);
    }

    public function crearObtener($nombre)
    {
        $this->log->info('--> Creación u obtención de docente');
        return $this->servicioDocente->crearObtener($nombre);
    }
}
