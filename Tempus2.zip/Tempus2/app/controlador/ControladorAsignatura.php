<?php

namespace app\controlador;

use app\modelo\Log;
use app\servicio\ServicioAsignatura;

/**
 * Controlador de Asignatura. Esta clase se comunica con los modelos del modulo
 * de asignaturas para invocar sus metodos y otorgar los resultados a las vistas 
 * que correspondan. Ademas, se encarga de almacenar las actividades que se llevan
 * a cabo en el Log cuando se realiza una operacion que implica actualizar 
 * informacion en la base de datos.
 * 
 * @package app\controlador
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 * 
 * @version 1.0
 */
class ControladorAsignatura
{
    /** @var Log Instancia para guardar logs. */
    private $log;

    /** @var ServicioAsignatura Servicio para operar con asignaturas */
    private $servicioAsignatura;

    public function __construct()
    {
        $this->log = Log::getInstancia();
        $this->servicioAsignatura = new ServicioAsignatura();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function crear($nombreLargo)
    {
        $this->log->info('--> Creacion de asignatura');
        return $this->servicioAsignatura->crear($nombreLargo);
    }

    public function crearObtener($nombreLargo)
    {
        $this->log->info('--> Creacion u obtención de asignatura');
        return $this->servicioAsignatura->crearObtener($nombreLargo);
    }
}
