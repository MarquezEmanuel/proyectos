<?php

namespace app\controlador;

use app\modelo\Aula;
use app\repositorio\RepositorioAula;
use app\repositorio\RepositorioLog;

class ControladorAula
{

    private $repoAula;
    private $repoLog;

    public function __construct()
    {
        $this->repoAula = new RepositorioAula();
        $this->repoLog = new RepositorioLog();
    }

    public function crear($sector, $nombre)
    {
        $aula = new Aula(NULL, $nombre, $sector);
        $resultado = $this->repoAula->crear($aula);
        if (!$resultado->isSuccess()) {
            $this->repoLog->guardarErrores($this->repoAula->getLogs());
        }
        return $resultado;
    }
}
