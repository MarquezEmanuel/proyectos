<?php

namespace app\controlador;

use app\modelo\Carrera;
use app\repositorio\RepositorioCarrera;
use app\repositorio\RepositorioLog;

class ControladorCarrera
{
    private $repoCarrera;
    private $repoLog;

    public function __construct()
    {
        $this->repoCarrera = new RepositorioCarrera();
        $this->repoLog = new RepositorioLog();
    }

    public function crear($codigo, $nombreLargo)
    {
        $carrera = new Carrera($codigo, $nombreLargo, $nombreLargo);
        $resultado = $this->repoCarrera->crear($carrera);
        if (!$resultado->isSuccess()) {
            $this->repoLog->guardarErrores($this->repoCarrera->getLogs());
        }
        return $resultado;
    }
}
