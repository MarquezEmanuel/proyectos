<?php

namespace app\repositorio;

use app\modelo\Constantes;
use app\modelo\Resultado;
use app\modelo\Docente;
use app\modelo\Log;

/**
 * 
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class RepositorioDocente extends Repositorio
{
    private $log;

    public function __construct()
    {
        parent::__construct();
        $this->log = Log::getInstancia();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function borrarDocentes()
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $query = 'DELETE FROM docente';
        return $this->delete($query, array());
    }

    /**
     * Crea un nuevo docente. 
     * @param Docente Docente a crear.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function crear(Docente $docente)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        if ($docente->esValido()) {
            $query = "INSERT INTO docente (id, nombre) VALUES (NULL, ?)";
            $parametros = $docente->getArrayInsert();
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $docente->setId($resultado->getDatos());
                $resultado->setDatos($docente);
            } else {
                $this->log->errorMultiple($this->getLogs());
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_ERROR, Constantes::MJE_MODELO_INVALIDO);
    }

    /**
     * Obtener informacion del docente a partir de su identificador.
     * @param Docente $docente Objeto docente a cargar.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorID(Docente $docente)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        if ($docente) {
            $query = "SELECT id, nombre FROM docente WHERE id = ?";
            $parametros = array($docente->getId());
            $resultado = $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $docente->setear($resultado->getDatos());
                $resultado->setDatos($docente);
            } else {
                $this->log->errorMultiple($this->getLogs());
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_ERROR, Constantes::MJE_MODELO_INVALIDO);
    }

    /**
     * Obtener informacion del docente a partir de su nombre.
     * @param Docente $docente Objeto docente a cargar.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorNombre(Docente $docente)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $nombre = $docente->getNombre();
        if ($nombre) {
            $query = "SELECT id, nombre FROM docente WHERE nombre = ?";
            $parametros = array($docente->getNombre());
            $resultado = $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $docente->setear($resultado->getDatos());
                $resultado->setDatos($docente);
            } else {
                $this->log->errorMultiple($this->getLogs());
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_ERROR, Constantes::MJE_MODELO_INVALIDO);
    }

    public function reiniciarAutoIncrementador()
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $query = 'ALTER TABLE docente AUTO_INCREMENT = 1';
    }

    /**
     * Seleccionar docente por su nombre.
     * @param string $nombre Nombre del docente (LIKE).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function seleccionar($nombre)
    {
        $query = "SELECT id, nombre FROM docente WHERE nombre LIKE ? ORDER BY nombre";
        $parametros = array("%{$nombre}%");
        return $this->select($query, $parametros);
    }
}
