<?php

namespace app\repositorio;

use app\modelo\Clase;
use app\modelo\Constantes;
use app\modelo\Log;
use app\modelo\Resultado;

class RepositorioClase extends Repositorio
{

    private $log;

    public function __construct()
    {
        parent::__construct();
        $this->log = Log::getInstancia();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function borrar($id)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $query = "DELETE FROM clase WHERE id = ?";
        $parametros = array($id);
        return $this->delete($query, $parametros);
    }

    public function borrarPorPlan($idPlan)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $query = "DELETE FROM clase WHERE idPlan = ?";
        $parametros = array($idPlan);
        return $this->delete($query, $parametros);
    }

    public function crear(Clase $clase)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        if ($clase->esValida()) {
            $query = "INSERT INTO clase (id, idAula, idPlan, diaSemana, horaInicio, horaFin, fechaEdicion) VALUES (NULL, ?, ?, ?, ?, ?, NULL)";
            $parametros = $clase->getArrayInsert();
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $clase->setId($resultado->getDatos());
                $resultado->setDatos($clase);
            } else {
                $this->log->errorMultiple($this->getLogs());
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_ERROR, Constantes::MJE_MODELO_INVALIDO);
    }

    public function modificar(Clase $clase)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        if ($clase->esValida()) {
            $query = "UPDATE clase SET idAula = ?, horaInicio = ?, horaFin = ?, fechaEdicion = NOW() WHERE id = ?";
            $parametros = $clase->getArrayUpdate();
            return $this->update($query, $parametros);
        }
        return new Resultado(Constantes::COD_ERROR, Constantes::MJE_MODELO_INVALIDO);
    }

    public function obtenerPorID(Clase $clase)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $id = $clase->getId();
        if ($id > 0) {
            $query = "SELECT id, idAula, idPlan, diaSemana, horaInicio, horaFin, fechaEdicion FROM clase WHERE id = ?";
            $parametros = array($id);
            $resultado =  $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $clase->setear($resultado->getDatos());
                $resultado->setDatos($clase);
            } else {
                $this->log->errorMultiple($this->getLogs());
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_ERROR, Constantes::MJE_MODELO_INVALIDO);
    }
}
