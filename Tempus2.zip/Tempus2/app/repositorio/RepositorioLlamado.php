<?php

namespace app\repositorio;

use app\modelo\Constantes;
use app\modelo\Resultado;
use app\modelo\Llamado;
use app\modelo\Log;

/**
 * 
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class RepositorioLlamado extends Repositorio
{
    private $log;

    public function __construct()
    {
        parent::__construct();
        $this->log = Log::getInstancia();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function borrar($id)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        if ($id > 0) {
            $query = 'DELETE FROM llamado WHERE id = ?';
            return $this->delete($query, array());
        }
        return new Resultado(Constantes::COD_ERROR, Constantes::MJE_MODELO_INVALIDO);
    }

    public function borrarLlamados()
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $query = "DELETE FROM llamado";
        return $this->delete($query, array());
    }

    public function borrarLlamadosSinMesaExamen()
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $query = "DELETE LLA FROM llamado LLA JOIN (SELECT idllamado FROM llamado "
            . "WHERE idllamado NOT IN (SELECT DISTINCT primero idllamado FROM mesa_examen "
            . "WHERE primero IS NOT NULL UNION SELECT DISTINCT segundo idllamado "
            . "FROM mesa_examen WHERE segundo IS NOT NULL)) CAN ON CAN.idllamado = LLA.idllamado";
        return $this->delete($query, array());
    }

    /**
     * Crea un nuevo llamado. 
     * @param Llamado Llamado a crear.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function crear(Llamado $llamado)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        if ($llamado->esValido()) {
            $query = "INSERT INTO llamado (id, idAula, fecha, hora, estado, fechaCreacion, fechaEdicion)"
                . " VALUES (NULL, ?, ?, ?, ?, NOW(), NULL)";
            $parametros = $llamado->getArrayInsert();
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $llamado->setId($resultado->getDatos());
                $resultado->setDatos($llamado);
            } else {
                $this->log->errorMultiple($this->getLogs());
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_ERROR, Constantes::MJE_MODELO_INVALIDO);
    }

    public function listarFechasExamen()
    {
        $query = "SELECT DISTINCT fecha FROM llamado ORDER BY fecha";
        return $this->select($query, array());
    }

    public function modificar(Llamado $llamado)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        if ($llamado->esValido()) {
            $query = "UPDATE llamado SET fecha=?, hora=?, idAula=?, estado=?, fechaEdicion = NOW() WHERE id=?";
            $parametros = $llamado->getArrayUpdate();
            return $this->update($query, $parametros);
        }
        return new Resultado(Constantes::COD_ERROR, Constantes::MJE_MODELO_INVALIDO);
    }

    public function obtenerNumeroDeLlamados()
    {
        $query = "SELECT COUNT(idSegundoLlamado) cantidad FROM mesa_examen WHERE idSegundoLlamado IS NOT NULL";
        return $this->get($query, array());
    }

    public function obtenerPorID(Llamado $llamado)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $id = $llamado->getId();
        if ($id > 0) {
            $query = "SELECT id, idAula, estado, fecha, fechaEdicion, hora FROM llamado WHERE id = ?";
            $parametros = array($id);
            $resultado = $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $llamado->setear($resultado->getDatos());
                $resultado->setDatos($llamado);
            } else {
                $this->log->errorMultiple($this->getLogs());
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_ERROR, Constantes::MJE_MODELO_INVALIDO);
    }

    public function reiniciarAutoIncrementador()
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        $query = "ALTER TABLE llamado AUTO_INCREMENT = 1";
        return $this->update($query, array());
    }
}
