<?php

namespace app\repositorio;

use app\modelo\Constantes;
use app\modelo\Resultado;
use app\modelo\Rol;

/**
 * 
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class RepositorioRol extends Repositorio
{

    public function agregarPermisos($id, $permisos)
    {
        if ($id && !empty($permisos)) {
            $values = "";
            foreach ($permisos as $permiso) {
                $values .= "({$id}, {$permiso}),";
            }
            $query = "INSERT INTO rol_permiso VALUES " . substr($values, 0, -1);
            return $this->insert($query, array());
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los permisos para el rol');
    }

    /**
     * Crea un nuevo rol. 
     * @param array Datos del rol (nombre).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function crear(Rol $rol)
    {
        if ($rol->esValido()) {
            $query = "INSERT INTO aula (id, nombre) VALUES (NULL, ?)";
            $parametros = $rol->getArrayInsert();
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $id = $resultado->getDatos();
                $rol->setId($id);
                $resultado->setDatos($rol);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, Constantes::MJE_MODELO_INVALIDO);
    }

    /**
     * Modificar los datos del rol. 
     * @param array Datos del rol (nombre, id).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function modificar(Rol $rol)
    {
        if ($rol) {
            $query = "UPDATE rol SET nombre=? WHERE id=?";
            $parametros = $rol->toArray(false);
            return $this->update($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Listar todos los roles ordernados por nombre.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function listar()
    {
        $query = "SELECT id, nombre FROM rol ORDER BY nombre";
        return $this->select($query, array());
    }

    public function listarInformesRol()
    {
        $query = "SELECT * FROM vw_informe WHERE modulo = 'ROLES'";
        return $this->select($query, array());
    }

    /**
     * Buscar roles que coincidan por nombre. El listado se ordena por nombre.
     * @param string $nombre Nombre del rol (LIKE).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function listarParaBusqueda($nombre)
    {
        $query = "SELECT id, nombre, permisos, usuarios FROM vw_rol WHERE nombre LIKE ? ORDER BY nombre";
        $parametros = array("%{$nombre}%");
        return $this->select($query, $parametros);
    }

    /**
     * Obtener informacion del rol a partir de su identificador.
     * @param int $id Identificador del rol (Igual).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorID(Rol $rol)
    {
        if ($rol) {
            $query = "SELECT id, nombre FROM rol WHERE id = ?";
            $parametros = array($rol->getId());
            $resultado = $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $datos = $resultado->getDatos();
                $rol->setear($datos);
                $resultado->setDatos($rol);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    public function quitarPermisos()
    {
        $consulta = "DELETE FROM rol_permiso WHERE rol_id = ?";
    }

    /**
     * Seleccionar rol por su nombre.
     * @param string $nombre Nombre del rol (LIKE).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function seleccionar($nombre)
    {
        $query = "SELECT id, nombre FROM rol WHERE nombre LIKE ? ORDER BY nombre";
        $parametros = array("%{$nombre}%");
        return $this->select($query, $parametros);
    }
}
