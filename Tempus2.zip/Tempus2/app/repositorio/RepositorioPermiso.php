<?php

namespace app\repositorio;

use app\modelo\Constantes;
use app\modelo\Permiso;
use app\modelo\Resultado;

/**
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class RepositorioPermiso extends Repositorio
{

    /**
     * Crea un nuevo permiso. 
     * @param array Datos del permiso (nombre).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function crear(Permiso $permiso)
    {
        if ($permiso->esValido()) {
            $query = "INSERT INTO permiso (id, nombre) VALUES (NULL, ?)";
            $parametros = $permiso->getArrayInsert();
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $id = $resultado->getDatos();
                $permiso->setId($id);
                $resultado->setDatos($permiso);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, Constantes::MJE_MODELO_INVALIDO);
    }

    /**
     * Listar todos los permisos. El listado se ordena por nombre
     * @return Resultado Objeto de tipo Resultado.
     */
    public function listar()
    {
        $query = "SELECT id, nombre FROM permiso ORDER BY nombre";
        return $this->select($query, array());
    }

    /**
     * Buscar permisos que coincidan por nombre. El listado se ordena por nombre.
     * @param string $nombre Nombre del permiso.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function listarParaBusqueda($nombre)
    {
        $query = "SELECT id, nombre, roles FROM vw_permiso WHERE nombre LIKE ? ORDER BY nombre";
        $parametros = array("%{$nombre}%");
        return $this->select($query, $parametros);
    }

    public function listarInformesPermiso()
    {
        $query = "SELECT * FROM vw_informe WHERE modulo = 'PERMISOS'";
        return $this->select($query, array());
    }

    /** 
     * Listar permisos que pertenecen a un determinado rol. 
     * @param int $id Identificador del permiso.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function listarPorIDRol($id)
    {
        if ($id > 0) {
            $query = "SELECT pe.id, pe.nombre FROM permiso pe INNER JOIN rol_permiso rp "
                . " ON rp.permiso_id = pe.id AND rp.rol_id = ? "
                . " ORDER BY pe.nombre";
            $parametros = array($id);
            return $this->select($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Modificar los datos del permiso. 
     * @param array Datos del permiso (nombre, id).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function modificar(Permiso $permiso)
    {
        if ($permiso) {
            $query = "UPDATE permiso SET nombre=? WHERE id=?";
            $parametros = $permiso->toArray(false);
            return $this->update($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Obtener informacion del permiso a partir de su identificador.
     * @param int $id Identificador del permiso (Igual).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorID(Permiso $permiso)
    {
        if ($permiso) {
            $query = "SELECT id, nombre FROM permiso WHERE id = ?";
            $parametros = array($permiso->getId());
            $resultado = $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $datos = $resultado->getDatos();
                $permiso->setear($datos);
                $resultado->setDatos($permiso);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }
}
