<?php

namespace app\repositorio;

use app\modelo\Constantes;
use app\modelo\Plan;
use app\modelo\Resultado;


class RepositorioPlan extends Repositorio
{

    public function asociarMesaExamen($idMesaExamen, $idPlan)
    {
        $query = "UPDATE plan SET idMesaExamen = ? WHERE id = ?";
        $parametros = array($idMesaExamen, $idPlan);
        return $this->update($query, $parametros);
    }

    public function crear(Plan $plan)
    {
        if ($plan->esValido()) {
            $query = "INSERT INTO plan VALUES (NULL, ?, ?, ?, ?, NOW())";
            $parametros = $plan->getArrayInsert();
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $resultado->setDatos($plan);
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, Constantes::MJE_MODELO_INVALIDO);
    }

    public function obtenerPorID(Plan $plan)
    {
        $id = $plan->getId();
        if ($id > 0) {
            $query = "SELECT * FROM plan WHERE id = ?";
            $parametros = array($id);
        }
        return new Resultado(Constantes::COD_WARNING, Constantes::MJE_MODELO_INVALIDO);
    }

    public function obtenerPorCarreraAsignatura(Plan $plan)
    {
        $idCarrera = $plan->getCarrera();
        $idAsignatura = $plan->getAsignatura();
        if ($idCarrera && $idAsignatura) {
            $query = "SELECT * FROM plan WHERE idAsignatura = ? AND idCarrera = ?";
        }
        return new Resultado(Constantes::COD_WARNING, Constantes::MJE_MODELO_INVALIDO);
    }

    public function quitarMesaExamen($idPlan)
    {
        if ($idPlan > 0) {
            $query = "UPDATE plan SET idMesaExamen = NULL WHERE id = ?";
            $parametros = array($idPlan);
            return $this->update($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, Constantes::MJE_MODELO_INVALIDO);
    }
}
