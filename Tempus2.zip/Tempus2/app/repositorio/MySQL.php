<?php

namespace app\repositorio;

use PDO;
use Exception;
use app\modelo\Log;
use app\modelo\Encriptador;

/**
 * Esta clase extiende de mysqli. Tiene la logica necesaria para conectarse a 
 * la base de datos del sistema.
 *
 * paquete: principal.
 * namespace: modelos.
 * @author Eder dos Santos <esantos@uarg.unpa.edu.ar>
 *
 */
class MySQL
{
    protected static $instancia;

    public static function getInstancia()
    {
        if (!self::$instancia instanceof self) {
            try {
                global $g_db_hostname, $g_db_basename, $g_db_username, $g_db_password, $g_crypto_key;
                $encriptador = new Encriptador();
                $hostname = $encriptador->desencriptar($g_db_hostname, $g_crypto_key);
                $basename = $encriptador->desencriptar($g_db_basename, $g_crypto_key);
                $username = $encriptador->desencriptar($g_db_username, $g_crypto_key);
                $password = $encriptador->desencriptar($g_db_password, $g_crypto_key);
                $dsn = "mysql:host={$hostname};dbname={$basename};charset=utf8mb4";
                $options = [PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_EMULATE_PREPARES   => false, // turn off emulation mode for "real" prepared statements
                ];
                self::$instancia = new PDO($dsn, $username, $password, $options);
            } catch (Exception $e) {
                Log::getInstancia()->error("INSTANCIA --> {$e->getCode()}: {$e->getMessage()}");
                die("Error de conexion a la base de datos: " . $e->getCode() . ".");
            }
        }
        return self::$instancia;
    }
}
