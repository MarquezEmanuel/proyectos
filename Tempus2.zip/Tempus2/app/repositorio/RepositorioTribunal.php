<?php

namespace app\repositorio;

use app\modelo\Constantes;
use app\modelo\Log;
use app\modelo\Resultado;
use app\modelo\Tribunal;

/**
 * 
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class RepositorioTribunal extends Repositorio
{
    private $log;

    public function __construct()
    {
        parent::__construct();
        $this->log = Log::getInstancia();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function borrar($id)
    {
        $query = "DELETE FROM tribunal WHERE id = ?";
        return $this->delete($query, array());
    }

    public function borrarTribunales()
    {
        $query = "DELETE FROM tribunal";
        return $this->delete($query, array());
    }

    public function borrarTribunalesSinMesaExamen()
    {
        $query = "DELETE TRI FROM tribunal TRI JOIN (SELECT idtribunal FROM tribunal "
            . "WHERE idtribunal NOT IN (SELECT DISTINCT idtribunal FROM mesa_examen)) "
            . "CAN ON CAN.idtribunal = TRI.idtribunal";
        return $this->delete($query, array());
    }

    /**
     * Crea un nuevo tribunal. 
     * @param Tribunal Tribunal a crear.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function crear(Tribunal $tribunal)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        if ($tribunal->esValido()) {
            $query = "INSERT INTO tribunal (id, idPresidente, idVocal1, idVocal2, idSuplente) VALUES (NULL, ?, ?, ?, ?)";
            $parametros = $tribunal->getArrayInsert();
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $id = $resultado->getDatos();
                $tribunal->setId($id);
                $resultado->setDatos($tribunal);
            } else {
                $this->log->errorMultiple($this->getLogs());
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, Constantes::MJE_MODELO_INVALIDO);
    }

    /**
     * Modificar los datos del tribunal. 
     * @param Tribunal Tribunal a modificar.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function modificar(Tribunal $tribunal)
    {
        if ($tribunal) {
            $query = "UPDATE tribunal SET idPresidente=?, idVocal1=?, idVocal2=?, idSuplente=? WHERE id=?";
            $parametros = $tribunal->getArrayUpdate();
            return $this->update($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    public function obtenerPorID(Tribunal $tribunal)
    {
        if ($tribunal) {
            $query = 'SELECT id, idPresidente, idVocal1, idVocal2, idSuplente FROM tribunal WHERE id=?';
            $parametros = array($tribunal->getId());
            $resultado = $this->get($query, $parametros);
            if ($resultado->isSuccess()) {
                $datos = $resultado->getDatos();
                $tribunal->setear($datos);
                $resultado->setDatos($tribunal);
            }
            return $resultado;
        }
    }

    public function reiniciarAutoIncrementador()
    {
        $consulta = "ALTER TABLE tribunal AUTO_INCREMENT = 1";
    }
}
