<?php

namespace app\repositorio;

use app\modelo\Constantes;
use app\modelo\Resultado;

class RepositorioUsuario extends Repositorio
{

    public function asociarRol($parametros)
    {
        if (!empty($parametros)) {
            $query = "INSERT INTO rol_usuario (rol_id, usuario_id) VALUES (?, ?)";
            return $this->insert($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Crea un nuevo usuario. 
     * @param array Datos del usuario (id, email, nombre, metodo, estado).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function crear($parametros)
    {
        if (!empty($parametros)) {
            $query = "INSERT INTO usuario (id, email, nombre, metodoLogin, estado) VALUES (NULL, ?, ?, ?, ?)";
            return $this->insert($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    public function listarParaBusqueda()
    {
        $query = "SELECT * FROM vw_usuario WHERE nombreUsuario LIKE ? ORDER BY nombreUsuario";
        return $this->select($query, array());
    }

    /**
     * @see vw_informe Consulta cuando modulo es USUARIOS.
     */
    public function listarInformesUsuario()
    {
        $query = "SELECT * FROM vw_informe WHERE modulo = 'USUARIOS'";
        return $this->select($query, array());
    }

    /**
     * Obtener informacion del usuario a partir de su email.
     * @param string $email Correo electronico del usuario.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function login($email)
    {
        if ($email) {
            $query = "SELECT usu.id, usu.nombre, usu.email, usu.metodoLogin, usu.estado, rel.rol_id "
                . " FROM usuario usu INNER JOIN rol_usuario rel ON rel.usuario_id = usu.id "
                . " WHERE usu.email = ?";
            $parametros = array($email);
            return $this->select($query, $parametros);
        }
        return new Resultado(Constantes::COD_ERROR, Constantes::MJE_MODELO_INVALIDO);
    }

    /**
     * Modificar los datos del aula. 
     * @param array Datos del aula (nombre, sector).
     * @return Resultado Objeto de tipo Resultado.
     */
    public function modificar($parametros)
    {
        if (!empty($parametros)) {
            $query = "UPDATE usuario SET email=?, nombre=?, metodoLogin=?, estado=? WHERE id=?";
            return $this->update($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }

    /**
     * Obtener informacion del usuario a partir de su identificador.
     * @param int $id Identificador del usuario.
     * @return Resultado Objeto de tipo Resultado.
     */
    public function obtenerPorID($id)
    {
        if ($id > 0) {
            $query = "SELECT usu.id, usu.nombre, usu.email, usu.metodoLogin, usu.estado, rel.rol_id "
                . " FROM usuario usu INNER JOIN rol_usuario rel ON rel.usuario_id = usu.id "
                . " WHERE usu.id = ?";
            $parametros = array($id);
            return $this->select($query, $parametros);
        }
        return new Resultado(Constantes::COD_WARNING, 'No se recibieron los parametros');
    }
}
