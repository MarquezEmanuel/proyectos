<?php

namespace app\repositorio;

use app\modelo\Constantes;
use app\modelo\MesaExamen;
use app\modelo\Log;
use app\modelo\Resultado;

class RepositorioMesa extends Repositorio
{
    private $log;

    public function __construct()
    {
        parent::__construct();
        $this->log = Log::getInstancia();
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
    }

    public function crear(MesaExamen $mesa)
    {
        $this->log->info(__CLASS__ . ':' . __FUNCTION__ . ':' . __LINE__);
        if ($mesa->esValida()) {
            $query = "INSERT INTO mesa_examen (id, idPrimerLlamado, idSegundoLLamado, idTribunal, observacion, fechaCreacion) VALUES (NULL, ?, ?, ?, ?, NOW())";
            $parametros = $mesa->getArrayInsert();
            $resultado = $this->insert($query, $parametros);
            if ($resultado->isSuccess()) {
                $mesa->setId($resultado->getDatos());
                $resultado->setDatos($mesa);
            } else {
                $this->log->errorMultiple($this->getLogs());
            }
            return $resultado;
        }
        return new Resultado(Constantes::COD_WARNING, Constantes::MJE_MODELO_INVALIDO);
    }
}
