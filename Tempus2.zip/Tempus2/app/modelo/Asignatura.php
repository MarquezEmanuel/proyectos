<?php

namespace app\modelo;

use app\modelo\Util;

/**
 * 
 * @package app\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Asignatura
{

    /** @var string Identificador de la asignatura en la base de datos [INT]. */
    private $id;

    /** @var string Nombre abreviado de la asignatura [VARCHAR(10) NOT NULL]. */
    private $nombreCorto;

    /** @var string Nombre largo de la asignatura [VARCHAR(255) NOT NULL]. */
    private $nombreLargo;

    /** @var string Fecha de creacion del registro [DATETIME NOT NULL]. */
    private $fechaCreacion;

    /** @var array Carreras asociadas a la asignatura. */
    private $carreras;

    /**
     * Constructor de clase. 
     */
    public function __construct($id = NULL, $nombreCorto = NULL, $nombreLargo = NULL, $fechaCreacion = NULL)
    {
        $this->setId($id);
        $this->setNombreLargo($nombreLargo);
        $this->setNombreCorto($nombreCorto);
        $this->setFechaCreacion($fechaCreacion);
    }

    /**
     * Retorna el identificador de la asignatura.
     * @return int Identificador de la asignatura.
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Retorna el nombre abreviado de la asignatura.
     * @return string Nombre abreviado de la asignatura.
     */
    public function getNombreCorto()
    {
        return $this->nombreCorto;
    }

    /**
     * Retorna el nombre largo de la asignatura.
     * @return string Nombre largo de la asignatura.
     */
    public function getNombreLargo()
    {
        return $this->nombreLargo;
    }

    /**
     * Retorna la fecha de creacion de la asignatura.
     * @return string Fecha de creacion de la asignatura.
     */
    public function getFechaCreacion()
    {
        return $this->fechaCreacion;
    }

    /**
     * Retorna las carreras asociadas a la asignatura.
     * @return array Arreglo de carreras.
     */
    public function getCarreras()
    {
        return $this->carreras;
    }

    /**
     * Modifica el identificador de la asignatura solo si es mayor a cero.
     * @param int $id Identificador de asignatura.
     */
    public function setId($id)
    {
        $this->id = ($id > 0) ? $id : NULL;
    }

    /**
     * Modifica el nombre corto de la asignatura con la inicial de cada palabra.
     * @param string $nombreCorto Nombre corto de la asignatura.
     */
    public function setNombreCorto($nombreCorto)
    {
        if (Asignatura::validarNombreLargo($nombreCorto)) {
            $this->nombreCorto = Util::obtenerIniciales($nombreCorto);
        }
    }

    /**
     * Modificar el nombre de la asignatura solo si cumple el formato. 
     * @param string $nombreLargo Nombre de asignatura.
     */
    public function setNombreLargo($nombreLargo)
    {
        if (Asignatura::validarNombreLargo($nombreLargo)) {
            $this->nombreLargo = Util::convertirCamelCase($nombreLargo);
        }
    }

    /**
     * Modificar la fecha de creacion de la asignatura. 
     * @param string $fechaCreacion Fecha de creacion de asignatura.
     */
    public function setFechaCreacion($fechaCreacion)
    {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setear($datos)
    {
        if (!empty($datos)) {
            $this->id = $datos['id'];
            $this->nombreCorto = $datos['nombreCorto'];
            $this->nombreLargo = $datos['nombreLargo'];
            $this->fechaCreacion = $datos['fechaCreacion'];
        }
    }

    /** 
     * Retorna los datos para hacer un insert a la base de datos.
     * @return array Arreglo con los datos de la asignatura [nombreCorto, nombreLargo].
     */
    public function getArrayInsert()
    {
        return [$this->nombreCorto, $this->nombreLargo];
    }

    /** 
     * Retorna los datos para hacer un update a la base de datos.
     * @return array Arreglo con los datos de la asignatura [nombreCorto, nombreLargo, id]. 
     */
    public function getArrayUpdate()
    {
        return [$this->nombreCorto, $this->nombreLargo, $this->id];
    }

    /** 
     * Indica si la asignatura posee todos los campos obligatorios. El metodo no chequea que
     * la asignatura posea identificador.
     * @return boolean True si tiene todos los campos obligatorios o false en caso contrario. 
     */
    public function esValida()
    {
        return ($this->nombreCorto && $this->nombreLargo);
    }

    /**
     * Validar el formato para el nombre de una asignatura.
     * @param string $nombre Nombre a validar.
     * @return boolean True cuando cumple el formato y false en caso contrario.
     */
    public static function validarNombreLargo($nombreLargo)
    {
        if (!ctype_digit($nombreLargo)) {
            $expresion = "/^[a-záéíóúñü0-9,. ]{5,60}$/";
            return preg_match($expresion, mb_strtolower($nombreLargo));
        }
        return false;
    }
}
