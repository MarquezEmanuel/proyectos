<?php

namespace app\modelo;

use app\modelo\Asignatura;
use app\modelo\Carrera;
use app\modelo\Cursada;
use app\modelo\MesaExamen;

/**
 * 
 * @package app\plan\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Plan
{

    /** @var int Identificador del plan. */
    private $id;

    /** @var int Asignatura relacionada al plan. */
    private $idAsignatura;

    /** @var int Carrera a la que pertenece la asignatura. */
    private $idCarrera;

    /** @var array Listado de clases para la cursada. */
    private $cursada;

    /** @var int Mesa para la asignatura dentro de la carrera. */
    private $idMesaExamen;

    /** @var int Anio en que se dicta la materia dentro de la carrera. */
    private $anio;

    /** @var string Fecha de creacion del plan. */
    private $fechaCreacion;

    public function __construct($id = NULL, $idAsignatura = NULL, $idCarrera = NULL, $cursada = NULL, $idMesaExamen = NULL, $anio = NULL, $fechaCreacion = NULL)
    {
        $this->setId($id);
        $this->setAsignatura($idAsignatura);
        $this->setCarrera($idCarrera);
        $this->setCursada($cursada);
        $this->setMesa($idMesaExamen);
        $this->setAnio($anio);
        $this->setFechaCreacion($fechaCreacion);
    }

    /**
     * Retorna el identificador de la cursada.
     * @return int Identificador de la cursada.
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Retorna la asignatura de la cursada.
     * @return Asignatura Asignatura de cursada.
     */
    public function getAsignatura()
    {
        return $this->idAsignatura;
    }

    /**
     * Retorna la carrera de la cursada.
     * @return Carrera Carrera de la cursada.
     */
    public function getCarrera()
    {
        return $this->idCarrera;
    }

    public function getMesa()
    {
        return $this->idMesaExamen;
    }

    /**
     * Retorna el anio de la cursada.
     * @return int Anio de cursada.
     */
    public function getAnio()
    {
        return $this->anio;
    }

    /**
     * Retorna la fecha de creacion de la cursada.
     * @return string Fecha de creacion.
     */
    public function getFechaCreacion()
    {
        return $this->fechaCreacion;
    }

    public function getCursada()
    {
        return $this->cursada;
    }

    public function setId($id)
    {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setAsignatura($asignatura)
    {
        $this->idAsignatura = $asignatura;
    }

    public function setCarrera($carrera)
    {
        $this->idCarrera =  $carrera;
    }

    public function setMesa($mesa)
    {
        $this->idMesaExamen = $mesa;
    }

    public function setAnio($anio)
    {
        $this->anio = $anio;
    }

    public function setFechaCreacion($fechaCreacion)
    {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setCursada($cursada)
    {
        $this->cursada = $cursada;
    }

    public function setear(array $datos)
    {
        if (!empty($datos)) {
            $this->id = $datos['id'];
            $this->idAsignatura = $datos['idAsignatura'];
            $this->idCarrera = $datos['idCarrera'];
            $this->idMesaExamen = $datos['idMesa'];
            $this->anio = $datos['anio'];
            $this->fechaCreacion['fechaCreacion'];
        }
    }

    public function getArrayInsert()
    {
        return [$this->idAsignatura, $this->idCarrera, $this->idMesaExamen, $this->anio];
    }

    public function esValido()
    {
        return ($this->idAsignatura && $this->idCarrera && $this->anio);
    }
}
