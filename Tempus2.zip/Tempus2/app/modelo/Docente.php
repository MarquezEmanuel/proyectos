<?php

namespace app\modelo;

use app\modelo\Util;

/**
 * 
 * @package app\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Docente
{

    /** @var integer $id Identidicador del docente en la base de datos */
    private $id;

    /** @var string $nombre Nombre del docente */
    private $nombre;

    /**
     * Constructor de clase.
     */
    public function __construct($id = NULL, $nombre = NULL)
    {
        $this->setId($id);
        $this->setNombre($nombre);
    }

    /**
     * Retorna el identificador del docente.
     * @return int Identificador del docente.
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Retorna el nombre del docente.
     * @return string Nombre del docente.
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Modifica el identificador del docente solo si es mayor a cero.
     * @param int $id Identificador del docente.
     */
    public function setId($id)
    {
        $this->id = ($id > 0) ? $id : NULL;
    }

    /**
     * Modifica el nombre del docente solo si cumple con el formato requerido.
     * @param string $nombre Nombre del docente.
     */
    public function setNombre($nombre)
    {
        if (Docente::validarNombre($nombre)) {
            $this->nombre = Util::convertirCamelCase($nombre);
        }
    }

    public function setear($datos)
    {
        if (!empty($datos)) {
            $this->id = $datos['id'];
            $this->nombre = $datos['nombre'];
        }
    }

    /** 
     * Retorna los datos para hacer un insert a la base de datos.
     * @return array Arreglo con los datos del docente [nombre].
     */
    public function getArrayInsert()
    {
        return [$this->nombre];
    }

    /** 
     * Retorna los datos para hacer un update a la base de datos.
     * @return array Arreglo con los datos del docente [nombre, id]. 
     */
    public function getArrayUpdate()
    {
        return [$this->nombre, $this->id];
    }

    /** 
     * Indica si el docente posee todos los campos obligatorios.
     * @return boolean True si tiene todos los campos obligatorios o false en caso contrario. 
     */
    public function esValido()
    {
        return ($this->nombre);
    }

    /**
     * Validar el formato para el nombre de un docente.
     * @see preg_match
     * @see mb_strtolower
     * @param integer $nombre Nombre de docente a validar.
     * @return boolean True cuando cumple el formato y false en caso contrario.
     */
    public static function validarNombre($nombre): bool
    {
        $expresion = "/^[a-záéíóúñü,. ]{4,60}$/";
        return preg_match($expresion, mb_strtolower($nombre));
    }
}
