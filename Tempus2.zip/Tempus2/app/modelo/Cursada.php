<?php

namespace app\modelo;

use app\modelo\Conexion;

/**
 * 
 * @package app\cursada\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Cursada {

    private $plan;
    private $clases;

    public function __construct($plan = NULL) {
        $this->plan = $plan;
        $this->clases = array();
    }

    public function getPlan() {
        return $this->plan;
    }

    public function getClases() {
        return $this->clases;
    }

    public function setPlan($plan) {
        $this->plan = $plan;
    }

    

    /*
    public function obtenerPorIdentificador() {
        if ($this->plan) {
            $consulta = "SELECT id FROM clase WHERE idPlan = {$this->plan} ORDER BY diaSemana";
            $resultado = Conexion::getInstancia()->seleccionar($consulta);
            if ($resultado[0] != 2) {
                return $resultado;
            }
            $obtenidos = TRUE;
            $this->clases = array();
            $registros = $resultado[1];
            foreach ($registros as $fila) {
                $clase = new Clase($fila['id']);
                $obtener = $clase->obtenerPorIdentificador();
                if ($obtener[0] == 2) {
                    $dia = $clase->getDiaSemana();
                    $this->clases[$dia] = $clase;
                } else {
                    $obtenidos = FALSE;
                }
            }
            return ($obtenidos) ? array(2, "Se obtuvo la información de la cursada") : array(1, "No se obtuvo la cursada");
        }
        return array(0, "No se pudo hacer referencia a la cursada");
    }
    */
}
