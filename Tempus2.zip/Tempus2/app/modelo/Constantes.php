<?php

namespace app\modelo;

/**
 * 
 * @package app\principal\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Constantes
{

    # CODIGOS DE ERROR

    const COD_ERROR = 'ERR';
    const COD_WARNING = 'WAR';
    const COD_SUCCESS = 'SUC';
    const COD_INFO = 'INF';

    # LISTADO DE MENSAJES DEL SISTEMA

    const MJE_MODELO_INVALIDO = 'Los datos son inválidos para efecturar la operación';
}
