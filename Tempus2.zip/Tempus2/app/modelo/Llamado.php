<?php

namespace app\modelo;

use app\modelo\Util;

/**
 * 
 * @package app\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Llamado
{

    /** @var integer Identificador del llamado en la base de datos [INT]. */
    private $id;

    /** @var int Aula en la que se dicta la mesa de examen [INT NULL]. */
    private $idAula;

    /** @var string Fecha en la que se dicta la mesa de examen [DATE NOT NULL]. */
    private $fecha;

    /** @var string Hora en la que se dicta la mesa de examen [TIME NOT NULL]. */
    private $hora;

    /** @var string Estado del llamado [ENUM NOT NULL]. */
    private $estado;

    /** @var string Fecha de creacion del llamado [DATETIME NOT NULL]. */
    private $fechaCreacion;

    /** @var string Fecha de modificacion del llamado [DATETIME NULL]. */
    private $fechaEdicion;

    /**
     * Constructor de clase.
     */
    public function __construct($id = NULL, $aula = NULL,  $fecha = NULL, $hora = NULL, $estado = NULL, $fechaCreacion = NULL, $fechaEdicion = NULL)
    {
        $this->setId($id);
        $this->setAula($aula);
        $this->setFecha($fecha);
        $this->setHora($hora);
        $this->setEstado($estado);
        $this->setFechaCreacion($fechaCreacion);
        $this->setFechaEdicion($fechaEdicion);
    }

    /**
     * Retorna el identificador del llamado.
     * @return int Identificador de llamado.
     */
    public function getId()
    {
        return $this->id;
    }

    public function getAula()
    {
        return $this->idAula;
    }

    public function getEstado()
    {
        return $this->estado;
    }

    public function getFecha()
    {
        return $this->fecha;
    }

    public function getHora()
    {
        return $this->hora;
    }

    public function getFechaCreacion()
    {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion()
    {
        return $this->fechaEdicion;
    }

    public function setId($id)
    {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setAula($aula)
    {
        $this->idAula = $aula;
    }

    public function setFecha($fecha)
    {
        $this->fecha = $fecha;
    }

    public function setEstado($estado)
    {
        $this->estado = $estado;
    }

    public function setFechaCreacion($fechaCreacion)
    {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion)
    {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function setHora($hora)
    {
        if (Util::validarLlamadoHora($hora)) {
            $this->hora = $hora;
        }
    }

    public function setear(array $datos)
    {
        if (!empty($datos)) {
            $this->id = $datos['id'];
            $this->fecha = $datos['fecha'];
            $this->hora = $datos['hora'];
            $this->estado = $datos['estado'];
            $this->fechaCreacion = $datos['fechaCreacion'];
            $this->fechaEdicion = $datos['fechaEdicion'];
        }
    }

    /** 
     * Retorna los datos para hacer un insert a la base de datos.
     * @return array Arreglo con los datos del llamado [idAula, estado, fecha, hora].
     */
    public function getArrayInsert()
    {
        return [$this->idAula, $this->fecha, $this->hora, $this->estado];
    }

    /** 
     * Retorna los datos para hacer un update a la base de datos.
     * @return array Arreglo con los datos del docente [nombre]. 
     */
    public function getArrayUpdate()
    {
        return [$this->idAula, $this->fecha, $this->hora, $this->estado, $this->id];
    }

    /** 
     * Indica si el llamado posee todos los campos obligatorios.
     * @return boolean True si tiene todos los campos obligatorios o false en caso contrario. 
     */
    public function esValido()
    {
        return ($this->estado && $this->fecha && $this->hora) ? true : false;
    }
}
