<?php

namespace app\modelo;

use app\modelo\Util;

/**
 * 
 * @package app\carrera\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Carrera
{

    /** @var string $id Codigo de la carrera [VARCHAR(3) NOT NULL]. */
    private $id;

    /** @var string $nombre Nombre abreviado de la carrera [VARCHAR(10) NOT NULL]. */
    private $nombreCorto;

    /** @var string $nombre Nombre largo de la carrera [VARCHAR(255) NOT NULL]. */
    private $nombreLargo;

    /** @var string Fecha de creacion del registro [DATETIME NOT NULL]. */
    private $fechaCreacion;

    /** @var array $asignaturas Arreglo de las asignaturas de la carrera */
    private $asignaturas;

    /**
     * Constructor de clase.
     */
    public function __construct($id = NULL, $nombreCorto = NULL, $nombreLargo = NULL)
    {
        $this->setId($id);
        $this->setNombreCorto($nombreCorto);
        $this->setNombreLargo($nombreLargo);
    }

    /**
     * Retorna el codigo de la carrera.
     * @return string Codigo de la carrera.
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Retorna el nombre abreviado de la carrera.
     * @return string Nombre de la carrera.
     */
    public function getNombreCorto()
    {
        return $this->nombreCorto;
    }

    /**
     * Retorna el nombre largo de la carrera.
     * @return string Nombre de la carrera.
     */
    public function getNombreLargo()
    {
        return $this->nombreLargo;
    }

    /**
     * Retorna la fecha de creacion.
     * @return string Fecha de creacion de la carrera.
     */
    public function getFechaCreacion()
    {
        return $this->fechaCreacion;
    }

    /**
     * Retorna las asignaturas de la carrera.
     * @return array Arreglo de asignaturas asocidadas a la carrera.
     */
    public function getAsignaturas()
    {
        return $this->asignaturas;
    }

    /**
     * Modifica el identificador de la carrera solo si cumple el formato.
     * @param string Identificador de la carrera.
     */
    public function setId($id)
    {
        if (Carrera::validarCodigo($id)) {

            $this->id = $id;
        }
    }

    /**
     * Modifica el nombre corto de la carrera con la inicial de cada palabra.
     * @param string $nombreCorto Nombre corto de la asignatura.
     */
    public function setNombreCorto($nombreCorto)
    {
        if (Carrera::validarNombreLargo($nombreCorto)) {

            $this->nombreCorto = Util::obtenerIniciales($nombreCorto);
        }
    }

    /**
     * Modificar el nombre de la carrera solo si cumple el formato. 
     * @param string $nombreLargo Nombre de carrera.
     */
    public function setNombreLargo($nombreLargo)
    {
        if (Carrera::validarNombreLargo($nombreLargo)) {
            $this->nombreLargo = Util::convertirCamelCase($nombreLargo);
        }
    }

    /**
     * Modificar la fecha de creacion. 
     * @param string $fechaCreacion Fecha de creacion de carrera.
     */
    public function setFechaCreacion($fechaCreacion)
    {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setear($datos)
    {
        if (!empty($datos)) {
            $this->id = $datos['id'];
            $this->nombreCorto = $datos['nombreCorto'];
            $this->nombreLargo = $datos['nombreLargo'];
            $this->fechaCreacion = $datos['fechaCreacion'];
        }
    }

    /** 
     * Retorna los datos para hacer un insert a la base de datos.
     * @return array Arreglo con los datos de la carrera [id, nombreCorto, nombreLargo].
     */
    public function getArrayInsert()
    {
        return [$this->id, $this->nombreCorto, $this->nombreLargo];
    }

    /** 
     * Retorna los datos para hacer un update a la base de datos.
     * @return array Arreglo con los datos de la carrera [nombreCorto, nombreLargo, id]. 
     */
    public function getArrayUpdate()
    {
        return [$this->nombreCorto, $this->nombreLargo, $this->id];
    }

    /** 
     * Indica si la carrera posee todos los campos obligatorios.
     * @return boolean True si tiene todos los campos obligatorios o false en caso contrario. 
     */
    public function esValida()
    {
        return ($this->id && $this->nombreCorto && $this->nombreLargo);
    }

    /**
     * Validar el formato para el codigo de una carrera.
     * @param integer $codigo Numero a validar.
     * @return boolean True cuando cumple el formato y false en caso contrario.
     */
    public static function validarCodigo($codigo)
    {
        $expresion = "/^[0-9]{1,3}$/";
        return preg_match($expresion, $codigo) ? true : false;
    }

    /**
     * Validar el formato para el nombre de una carrera.
     * @param integer $nombreLargo Cadena de texto a validar.
     * @return boolean True cuando cumple el formato y false en caso contrario.
     */
    public static function validarNombreLargo($nombreLargo)
    {
        $expresion = "/^[a-záéíóúñü,. ]{10,160}$/";
        return preg_match($expresion, mb_strtolower($nombreLargo));
    }
}
