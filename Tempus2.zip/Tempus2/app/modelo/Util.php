<?php

namespace app\modelo;

/**
 * Esta clase contiene metodos de utilidad para diferentes clases. Se puede
 * utilizar para validar cadenas de texto entre otras operaciones.
 * 
 * @author Oyarzo Mariela.
 * @author Quiroga Sandra.
 * @author Marquez Emanuel.
 *  */
class Util {

    /**
     * Realiza la conversion de una cadena de texto a formato Camel Case.
     * @param string $texto Cadena de texto en cualquier formato.
     * @return string Devuelve la cadena en formato Camel Case. 
     * @see mb_strtolower
     * @see ucwords
     * */
    public static function convertirCamelCase($texto) {
        if ($texto) {
            $minuscula = mb_strtolower($texto);
            $texto = ucwords($minuscula);
        }
        return $texto;
    }

    public static function obtenerIniciales($cadena) {
        $acronimo = '';
        foreach (explode(' ', trim($cadena)) as $palabra) {
            $acronimo .= (!isset($palabra[0])) ?: strtoupper($palabra[0]);
        }
        return $acronimo;
    }

    public static function validarAnio($anio) {
        return (preg_match("/^[1-5]$/", $anio)) ? true : false;
    }

    public static function validarLlamadoHora($hora) {
        $expresion = "/^(1[0-9]|2[0-3]):[0-5][0-9]$/";
        return (preg_match($expresion, $hora)) ? true : false;
    }

}
