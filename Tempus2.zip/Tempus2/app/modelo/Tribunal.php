<?php

namespace app\modelo;


/**
 * 
 * @package app\mesa\modelo.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Tribunal
{

    /** @var int Identificador del tribunal */
    private $id;

    /** @var int Identificador del docente Presidente */
    private $idPresidente;

    /** @var int Identificador del docente Vocal primero */
    private $idVocal1;

    /** @var int Identificador del docente Vocal segundo */
    private $idVocal2;

    /** @var int Identificador del docente Suplente */
    private $idSuplente;


    /**
     * Constructor de clase
     */
    public function __construct($id = NULL, $idPresidente = NULL, $idVocal1 = NULL, $idVocal2 = NULL, $idSuplente = NULL)
    {
        $this->setId($id);
        $this->setPresidente($idPresidente);
        $this->setVocal1($idVocal1);
        $this->setVocal2($idVocal2);
        $this->setSuplente($idSuplente);
    }

    /**
     * Retorna el identificador del tribunal.
     * @return int Identificador del tribunal.
     */
    public function getId()
    {
        return $this->id;
    }

    public function getPresidente()
    {
        return $this->idPresidente;
    }

    public function getVocal1()
    {
        return $this->idVocal1;
    }

    public function getVocal2()
    {
        return $this->idVocal2;
    }

    public function getSuplente()
    {
        return $this->idSuplente;
    }

    /**
     * Modifica el identificador del tribunal solo si es mayor que cero.
     * @param int $id Identificador del tribunal.
     */
    public function setId($id)
    {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setPresidente($idPresidente)
    {
        $this->idPresidente = $idPresidente;
    }

    public function setVocal1($idVocal1)
    {
        $this->idVocal1 = $idVocal1;
    }

    public function setVocal2($idVocal2)
    {
        $this->idVocal2 = $idVocal2;
    }

    public function setSuplente($idSuplente)
    {
        $this->idSuplente = $idSuplente;
    }

    public function setear(array $datos)
    {
        if (!empty($datos)) {
            $this->id = $datos['id'];
            $this->idPresidente = $datos['idPresidente'];
            $this->idVocal1 = $datos['idVocal1'];
            $this->idVocal2 = $datos['idVocal2'];
            $this->idSuplente = $datos['idSuplente'];
        }
    }

    public function esValido()
    {
        return ($this->idPresidente && $this->idVocal1);
    }

    public function getArrayInsert()
    {
        return [$this->idPresidente, $this->idVocal1, $this->idVocal2, $this->idSuplente];
    }

    public function getArrayUpdate()
    {
        return [$this->idPresidente, $this->idVocal1, $this->idVocal2, $this->idSuplente, $this->id];
    }
}
