<?php

# CONFIGURACION DE LA BASE DE DATOS
$g_db_hostname = 'Q3Q3aHRCQUtkZm5ncXBwaGpFaFljZz09Ojoc44XdHSXAp7jLdhAzCfCF';
$g_db_basename = 'RkxESzNUTytnMTdFdzVnSGlyRHpSQT09Ojq2opG14idn0w1GZexe3R1Y';
$g_db_username = 'Zldjc2orZVZzaVlycThxb0xYQUZoUT09OjrjoYE81wTY1jQr4lXNmwUe';
$g_db_password = 'QkNKOUdMNFpMaUxDNXp1MW5EU3hiQT09OjrdLZ0qibf+qdcmaUYpDBgG';
$g_crypto_key = 'tempus';
