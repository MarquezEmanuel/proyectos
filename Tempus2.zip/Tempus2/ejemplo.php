<?php
include_once './app/modelo/Autocargador.php';
include_once './config/inc_config.php';

use app\modelo\AutoCargador;
use app\modelo\Carrera;

AutoCargador::cargarModulos();

$expresiones = [
    'ASIGNATURA_NOMBRE' => ['EXPRESION' => '[a-záéíóúñü0-9,. ]{5,60}'],
    'AULA_NOMBRE'       => ['EXPRESION' => '[a-záéíóúñü0-9,. ]{1,40}'],
    'AULA_SECTOR'       => ['EXPRESION' => '[a-zñ]'],
    'CARRERA_CODIGO'    => ['EXPRESION' => '[0-9]{1,3}'],
    'CARRERA_NOMBRE'    => ['EXPRESION' => '[a-záéíóúñü,. ]{10,160}'],
    'CLASE_DIA'         => ['EXPRESION' => '[1-7]{1}'],
    'CLASE_HORA'        => ['EXPRESION' => '(1[0-9]|2[0-4]):[0-5][0-9]'],
    'DOCENTE_NOMBRE'    => ['EXPRESION' => '[a-záéíóúñü,. ]{4,60}'],
    'LLAMADO_HORA'      => ['EXPRESION' => '(1[0-9]|2[0-4]):[0-5][0-9]'],
    'PLAN_ANIO'         => ['EXPRESION' => '[1-5]'],
];


$dias = ['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sábado'];

echo $dias[2];

echo $expresiones['ASIGNATURA_NOMBRE']['EXPRESION'];

$expresion = $expresiones['AULA_NOMBRE']['EXPRESION'];
$expresion_regular = "/^{$expresion}$/";
echo (int) preg_match($expresion_regular, mb_strtolower('999'));
