<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\instalacion\controlador\ControladorInstalacion;

AutoCargador::cargarModulos();
session_start();

if (isset($_POST['mceiAccion'])) {
    $controlador = new ControladorInstalacion();
    $id = $_POST['mceiIdInstalacion'];
    $estado = ($_POST['mceiAccion'] == "ALTA") ? 'Activa' : 'Inactiva';
    $modificacion = $controlador->cambiarEstado($id, $estado);
    $mensaje = $controlador->getMensaje();
    $resultado = ControladorHTML::getAlertaOperacion($modificacion, $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = ControladorHTML::getAlertaOperacion(0, $mensaje);
}

echo $resultado;
