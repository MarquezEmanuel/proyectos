<?php

namespace app\instalacion\modelo;

use app\principal\modelo\SQLServer;

class ColeccionInstalaciones {

    public static function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM vwins_instalacion WHERE inombre LIKE ? AND iestado = ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array('%' . $nombre . '%', &$estado));
        return $resultado;
    }

    public static function consultar($nombre, $gerencia, $empleado, $sitio) {
        $consulta = "SELECT * FROM vwins_instalacion WHERE inombre LIKE ? AND gnombre LIKE ? AND enombre LIKE ? AND snombre LIKE ? AND iestado = 'Activa'";
        $datos = array('%' . utf8_decode($nombre) . '%', '%' . utf8_decode($gerencia) . '%', '%' . utf8_decode($empleado) . '%', '%' . utf8_decode($sitio) . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        return $resultado;
    }

    public static function buscarUltimasCreadas($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM vwins_instalacion "
                    . "WHERE estadoInstalacion = ? ORDER BY fechaCreacionInstalacion DESC";
            $datos = array(&$top, &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar instalaciones");
    }

    public static function seleccionar($nombre) {
        $consulta = "SELECT idInstalacion, nombreInstalacion FROM vwins_instalacion "
                . "WHERE nombreInstalacion LIKE ? AND estadoInstacion = 'Activa'";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombre}%"));
    }

}
