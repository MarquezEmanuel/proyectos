<?php

namespace app\instalacion\modelo;

use app\principal\modelo\SQLServer;
use app\gerencia\modelo\Gerencia;
use app\gerencia\modelo\Empleado;
use app\sitio\modelo\Sitio;

class Instalacion {

    private $id;
    private $nombreCorto;
    private $nombreLargo;
    private $gerencia;
    private $empleado;
    private $sitio;
    private $plataforma;

    /** @var string Riesgo de Tecnologia Informatica [NVARCHAR(5) NOT NULL] */
    private $rti;
    private $descripcion;
    private $estado;
    private $visibilidad;
    private $fechaCreacion;
    private $fechaEdicion;

    public function __construct($id = NULL, $nombreCorto = NULL, $nombreLargo = NULL, $gerencia = NULL, $empleado = NULL, $sitio = NULL, $plataforma = NULL, $rti = NULL, $descripcion = NULL, $estado = NULL, $visibilidad = NULL) {
        $this->setId($id);
        $this->setNombreCorto($nombreCorto);
        $this->setNombreLargo($nombreLargo);
        $this->setGerencia($gerencia);
        $this->setEmpleado($empleado);
        $this->setSitio($sitio);
        $this->setPlataforma($plataforma);
        $this->setRti($rti);
        $this->setDescripcion($descripcion);
        $this->setEstado($estado);
        $this->setVisibilidad($visibilidad);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombreCorto() {
        return utf8_encode($this->nombreCorto);
    }

    public function getNombreLargo() {
        return utf8_encode($this->nombreLargo);
    }

    public function getGerencia() {
        return $this->gerencia;
    }

    public function getEmpleado() {
        return $this->empleado;
    }

    public function getSitio() {
        return $this->sitio;
    }

    public function getPlataforma() {
        return $this->plataforma;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getVisibilidad() {
        return $this->visibilidad;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setNombreCorto($nombreCorto) {
        if ($nombreCorto && (strlen($nombreCorto) <= 20)) {
            $this->nombreCorto = utf8_decode($nombreCorto);
        }
    }

    public function setNombreLargo($nombreLargo) {
        if ($nombreLargo && (strlen($nombreLargo) <= 20)) {
            $this->nombreLargo = utf8_decode($nombreLargo);
        }
    }

    public function setGerencia($gerencia) {
        $this->gerencia = $gerencia;
    }

    public function setEmpleado($empleado) {
        $this->empleado = $empleado;
    }

    public function setSitio($sitio) {
        $this->sitio = $sitio;
    }

    public function setPlataforma($plataforma) {
        $this->plataforma = $plataforma;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setDescripcion($descripcion) {
        if ($descripcion && (strlen($descripcion) <= 300)) {
            $this->descripcion = utf8_decode($descripcion);
        }
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setVisibilidad($visibilidad) {
        $this->visibilidad = ($visibilidad > 0) ? $visibilidad : NULL;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE ins_instalacion SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para cambiar estado de la instalación");
    }

    public function crear() {
        if ($this->nombreCorto && $this->nombreLargo && $this->gerencia && $this->empleado && $this->sitio) {
            $consulta = "INSERT INTO ins_instalacion OUTPUT INSERTED.id VALUES (?, ?, ?, ?, ?, ?, 'Si', ?, 'Activa', 1, GETDATE(), NULL)";
            $datos = array(&$this->nombreCorto, &$this->nombreLargo, &$this->gerencia, &$this->empleado, &$this->sitio, &$this->plataforma, &$this->descripcion);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            $this->id = ($resultado[0]) ? $resultado[2] : NULL;
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear la instalación");
    }

    public function modificar() {
        if ($this->id && $this->nombreCorto && $this->nombreLargo && $this->gerencia && $this->empleado && $this->sitio) {
            $consulta = "UPDATE ins_instalacion SET sigla=?, nombre=?, gerencia=?, "
                    . "empleado=?, sitio=?, plataforma=?, descripcion=?, "
                    . "fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->nombreCorto, &$this->nombreLargo, &$this->gerencia, &$this->empleado, &$this->sitio, &$this->plataforma, &$this->descripcion, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para modificar la instalación");
    }

    /**
     * Realiza la modificacion de los datos del activo que corresponden a la Gerencia
     * de Control de Tecnologia Informatica (GCTI).
     */
    public function modificarGCTI() {
        if ($this->id && $this->rti && $this->visibilidad) {
            $consulta = "UPDATE ins_instalacion SET rti=?, nivelVisibilidad=?, "
                    . " fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->rti, &$this->visibilidad, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para modificar la instalación");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM ins_instalacion WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombreCorto = $fila['nombreCorto'];
                $this->nombreLargo = $fila['nombreLargo'];
                $this->gerencia = $fila['idGerencia'];
                $this->empleado = $fila['idEmpleado'];
                $this->sitio = $fila['idSitio'];
                $this->plataforma = $fila['idPlataforma'];
                $this->rti = $fila['rti'];
                $this->descripcion = $fila['descripcion'];
                $this->estado = $fila['estado'];
                $this->visibilidad = $fila['nivelVisibilidad'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaEdicion'];
                return array(2, "Se obtuvo la información de la instalación correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la instalación para obtener datos");
    }

    public function obtenerPlataforma() {
        $plataforma = new PlataformaSO($this->plataforma);
        $resultado = $plataforma->obtener();
        $this->plataforma = ($resultado[0] == 2) ? $plataforma : NULL;
        return $resultado;
    }

    public function obtenerGerencia() {
        $gerencia = new Gerencia($this->gerencia);
        $resultado = $gerencia->obtener();
        $this->gerencia = ($resultado[0] == 2) ? $gerencia : NULL;
        return $resultado;
    }

    public function obtenerEmpleado() {
        $empleado = new Empleado($this->empleado);
        $resultado = $empleado->obtener();
        $this->empleado = ($resultado[0] == 2) ? $empleado : NULL;
        return $resultado;
    }

    public function obtenerSitio() {
        $sitio = new Sitio($this->sitio);
        $resultado = $sitio->obtener();
        $this->sitio = ($resultado[0] == 2) ? $sitio : NULL;
        return $resultado;
    }

    public function toString() {
        $instalacion = ($this->id) ? "{{$this->id}," : "{0,";
        $instalacion .= ($this->nombreCorto) ? "'{$this->getNombreCorto()}'," : "'',";
        $instalacion .= ($this->nombreLargo) ? "'{$this->getNombreLargo()}'," : "'',";
        $instalacion .= ($this->gerencia && (gettype($this->gerencia) == "integer")) ? "{$this->gerencia}," : "0,";
        $instalacion .= ($this->empleado && (gettype($this->empleado) == "string")) ? "'{$this->empleado}'," : "'',";
        $instalacion .= ($this->sitio && (gettype($this->sitio) == "string")) ? "'{$this->sitio}'," : "'',";
        $instalacion .= ($this->plataforma && (gettype($this->plataforma) == "integer")) ? "{$this->plataforma}," : "0,";
        $instalacion .= ($this->rti) ? "'{$this->getRti()}'," : "'',";
        $instalacion .= ($this->estado) ? "'{$this->getEstado()}'," : "'',";
        $instalacion .= ($this->visibilidad) ? "{$this->visibilidad}}" : "0}";
        return $instalacion;
    }

}
