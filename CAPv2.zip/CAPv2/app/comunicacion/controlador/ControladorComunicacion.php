<?php

namespace app\comunicacion\controlador;

use app\comunicacion\modelo\Comunicacion;
use app\comunicacion\modelo\ColeccionComunicaciones as Comunicaciones;
use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

class ControladorComunicacion {

    public function buscar($nombre, $estado) {
        return Comunicaciones::buscar($nombre, $estado);
    }

    public function buscarUltimasCreadas($top, $estado) {
        return Comunicaciones::listarUltimasCreadas($top, $estado);
    }

    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $comunicacion = new Comunicacion($id);
            $comunicacion->setEstado($estado);
            $resultado = $comunicacion->cambiarEstado();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function crear($nombreCorto, $nombreLargo, $cantidad, $idGerencia, $idEmplegado, $idSitio, $idProveedor, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $comunicacion = new Comunicacion(NULL, $sigla, $nombre, $cantidad, $gerencia, $delegado, $ubicacion, $proveedor, $rti, $descripcion);
            $resultado = $comunicacion->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function consultar($nombre, $gerencia, $empleado, $sitio, $proveedor) {
        $resultado = Comunicaciones::consultar($nombre, $gerencia, $empleado, $sitio, $proveedor);
        return $resultado;
    }

    public function modificar($id, $sigla, $nombre, $cantidad, $gerencia, $delegado, $ubicacion, $proveedor, $rti, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $comunicacion = new Comunicacion($id, $sigla, $nombre, $cantidad, $gerencia, $delegado, $ubicacion, $proveedor, $rti, $descripcion);
            $resultado = $comunicacion->modificar();
            $this->mensaje = $comunicacion->getMensaje();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Comunicacion $comunicacion Vinculo de comunicacion con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $comunicacion) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "COMUNICACIONES";
        $metodo = "ControladorComunicacion::$funcion";
        $detalle = substr($comunicacion->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
