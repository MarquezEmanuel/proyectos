<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\comunicacion\controlador\ControladorComunicacion;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorComunicacion();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $gerencia = $_POST['gerencia'];
    $empleado = $_POST['empleado'];
    $sitio = $_POST['sitio'];
    $proveedor = $_POST['proveedor'];
    $datos = ($nombre) ? "'{$nombre}', " : "TODAS, ";
    $datos .= ($gerencia) ? "'{$gerencia}', " : "TODAS, ";
    $datos .= ($empleado) ? "'{$empleado}', " : "TODOS, ";
    $datos .= ($sitio) ? "'{$sitio}', " : "TODOS, ";
    $datos .= ($proveedor) ? "'{$proveedor}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $comunicaciones = $controlador->consultar($nombre, $gerencia, $empleado, $sitio, $proveedor);
    $_SESSION['CCOMUNICACIONES'] = array($nombre, $gerencia, $empleado, $sitio, $proveedor, $datos);
} else {
    if (isset($_SESSION['CCOMUNICACIONES'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['CCOMUNICACIONES'];
        $nombre = $parametros[0];
        $gerencia = $parametros[1];
        $empleado = $parametros[2];
        $sitio = $parametros[3];
        $proveedor = $parametros[4];
        $filtro = "Ultima búsqueda realizada: " . $parametros[5];
        $comunicaciones = $controlador->consultar($nombre, $gerencia, $empleado, $sitio, $proveedor);
        $_SESSION['CCOMUNICACIONES'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $comunicaciones = $controlador->listarUltimasCreadas();
        $filtro = "Resumen inicial";
        $_SESSION['CCOMUNICACIONES'] = NULL;
    }
}


if (gettype($comunicaciones) == "resource") {
    $filas = "";
    while ($comunicacion = sqlsrv_fetch_array($comunicaciones, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr class='fila' title='Haga doble click para acceder a los detalles del elemento'>
                <td style='display: none;'>" . utf8_encode($comunicacion['csigla']) . "</td>
                <td>" . utf8_encode($comunicacion['cnombre']) . "</td>
                <td>" . utf8_encode($comunicacion['gnombre']) . "</td>
                <td style='display: none;'>" . utf8_encode($comunicacion['eid']) . "</td>
                <td>" . utf8_encode($comunicacion['enombre']) . "</td>
                <td style='display: none;'>" . utf8_encode($comunicacion['sid']) . "</td> 
                <td>" . utf8_encode($comunicacion['snombre']) . "</td> 
                <td>" . utf8_encode($comunicacion['pnombre']) . "</td>
                <td style='display: none;'>" . utf8_encode($comunicacion['ccantidad']) . "</td>
                <td style='display: none;'>" . utf8_encode($comunicacion['cdescripcion']) . "</td>
                <td style='display: none;'>" . utf8_encode($comunicacion['crti']) . "</td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbComunicaciones" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th style="display: none;">Nombre corto</th>
                        <th>Nombre largo</th>
                        <th>Gerencia</th>
                        <th style="display: none;">Legajo delegado</th>
                        <th>Nombre delegado</th>
                        <th style="display: none;">Código sitio</th>
                        <th>Nombre Sitio</th>
                        <th>Proveedor</th>
                        <th style="display: none;">Cantidad</th>
                        <th style="display: none;">Descripción</th>
                        <th style="display: none;">RTI</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($comunicaciones == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($comunicaciones, $mensaje);
}

$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
