<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\comunicacion\controlador\ControladorComunicacion;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if ($_POST['nombre'] && $_POST['gerencia'] && $_POST['delegado'] && $_POST['ubicacion'] && $_POST['proveedor']) {
    $controlador = new ControladorComunicacion();
    $nombreCorto = $_POST['nombreCorto'];
    $nombreLargo = $_POST['nombreLargo'];
    $gerencia = $_POST['gerencia'];
    $delegado = $_POST['delegado'];
    $sitio = $_POST['sitio'];
    $proveedor = $_POST['proveedor'];
    $cantidad = $_POST['cantidad'];
    $rti = $_POST['rti'];
    $descripcion = $_POST['descripcion'];
    $creacion = $controlador->crear($nombreCorto, $nombreLargo, $cantidad, $idGerencia, $idEmplegado, $idSitio, $idProveedor, $descripcion);
    $exito = ($creacion[0] == 2) ? true : false;
    $mensaje = "{$nombreLargo}: {$creacion[0]}";
    $resultado = ControladorHTML::getAlertaOperacion($creacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = ControladorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
