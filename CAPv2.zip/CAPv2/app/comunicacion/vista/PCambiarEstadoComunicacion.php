<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\comunicacion\controlador\ControladorComunicacion;

AutoCargador::cargarModulos();
session_start();

if (isset($_POST['mcecAccion'])) {
    $controlador = new ControladorComunicacion();
    $id = $_POST['mcecIdComunicacion'];
    $estado = ($_POST['mcecAccion'] == "ALTA") ? 'Activa' : 'Inactiva';
    $modificacion = $controlador->cambiarEstado($id, $estado);
    $mensaje = $controlador->getMensaje();
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion, $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

echo $resultado;
