<?php

namespace app\comunicacion\modelo;

use app\principal\modelo\SQLServer;

class ColeccionComunicaciones {

    public static function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM vwcom_comunicacion WHERE cnombre LIKE ? AND cestado = ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array('%' . utf8_decode($nombre) . '%', &$estado));
        return $resultado;
    }

    public static function consultar($nombre, $gerencia, $empleado, $sitio, $proveedor) {
        $consulta = "SELECT * FROM vwcom_comunicacion WHERE cnombre LIKE ? AND gnombre LIKE ? AND enombre LIKE ? AND snombre LIKE ? AND pnombre LIKE ? AND cestado = 'Activa'";
        $datos = array('%' . utf8_decode($nombre) . '%', '%' . utf8_decode($gerencia) . '%', '%' . utf8_decode($empleado) . '%', '%' . utf8_decode($sitio) . '%', '%' . utf8_decode($proveedor) . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        return $resultado;
    }

    public static function listarConTope($tope) {
        $consulta = "SELECT TOP(?) * FROM vwcom_comunicacion WHERE cestado = 'Activa' ORDER BY cid DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array($tope));
        return $resultado;
    }

}
