<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\sitio\controlador\ControladorSitio;
use app\utilidad\modelo\GeneradorHTML;

AutoCargador::cargarModulos();

session_start();

$controlador = new ControladorSitio();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $provincia = $_POST['provincia'];
    $ciudad = $_POST['ciudad'];
    $estado = $_POST['estado'];
    $resultado = $controlador->buscar($nombre, $provincia, $ciudad, $estado);
    $datos = ($nombre) ? "'{$nombre}', " : "";
    $datos .= ($provincia) ? "'{$provincia}', " : "";
    $datos .= ($ciudad) ? "'{$ciudad}', " : "";
    $datos .= ($estado) ? "'{$estado}', " : "";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $_SESSION['BSITIOS'] = array($nombre, $provincia, $ciudad, $estado, $datos);
} else {
    if (isset($_SESSION['BSITIOS'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BSITIOS'];
        $nombre = $parametros[0];
        $provincia = $parametros[1];
        $ciudad = $parametros[2];
        $estado = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[4];
        $resultado = $controlador->buscar($nombre, $provincia, $ciudad, $estado);
        $_SESSION['BSITIOS'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['BSITIOS'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $sitios = $resultado[1];
    $filas = $operaciones = "";
    while ($sitio = sqlsrv_fetch_array($sitios, SQLSRV_FETCH_ASSOC)) {
        $id = $sitio['id'];
        $tipo = $sitio['tipo'];
        $nombre = utf8_encode($sitio['nombre']);
        $provincia = utf8_encode($sitio['provincia']);
        $ciudad = utf8_encode($sitio['ciudad']);
        $codigoPostal = $sitio['codigoPostal'];
        $direccion = utf8_encode($sitio['direccion']);
        $origen = $sitio['origen'];
        $estado = $sitio['estado'];
        $fechaCreacion = isset($sitio['fechaCreacion']) ? date_format($sitio['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($sitio['fechaUltimaEdicion']) ? date_format($sitio['fechaUltimaEdicion'], 'd/m/Y H:i') : "";

        if ($estado == 'Activo') {
            $operaciones = "
                <button class='btn btn-outline-info datos' 
                        name='{$id}' title='Datos básicos: $nombre'>
                    <i class='fas fa-info-circle'></i>
                </button>
                <button class='btn btn-outline-warning editar' 
                        name='{$id}' title='Editar: $nombre'>
                    <i class='far fa-edit'></i>
                </button>

                <button class='btn btn-outline-danger baja' 
                        name='{$id}' title='Dar de baja: $nombre'>
                    <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-info datos' 
                        name='{$id}' title='Datos básicos: $nombre'>
                    <i class='fas fa-info-circle'></i>
                </button>
                <button class='btn btn-outline-success alta' 
                        name='{$id}' title='Dar de alta: $nombre'>
                        <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td class='align-middle'>{$id}</td>
                <td class='align-middle'>{$tipo}</td>
                <td class='align-middle'>{$nombre}</td>
                <td class='align-middle'>{$provincia}</td>
                <td class='align-middle'>{$ciudad}</td>
                <td style='display: none;' class='align-middle'>{$codigoPostal}</td>
                <td style='display: none;' class='align-middle'>{$direccion}</td>
                <td class='align-middle'>{$origen}</td>
                <td style='display: none;' class='align-middle'>{$estado}</td>
                <td style='display: none;' class='align-middle'>{$fechaCreacion}</td>
                <td style='display: none;' class='align-middle'>{$fechaEdicion}</td>
                <td class='text-center align-middle'>
                    <div class='btn-group btn-group-sm'>{$operaciones}</div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbSitios" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Tipo</th>
                        <th>Nombre</th>
                        <th>Provincia</th>
                        <th>Ciudad</th>
                        <th style="display: none;">Código postal</th>
                        <th style="display: none;">Dirección</th>
                        <th>Origen</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">Fecha de creación</th>
                        <th style="display: none;">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
