<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
require_once '../../principal/vistas/header.php';

AutoCargador::cargarModulos();

$controlador = new ControladorSitio();
$sitios = $controlador->listarReporte();
if (gettype($sitios) == "resource") {
    $total = $tsucursal = $tcpd = $tsar = 0;
    $filas = "";
    while ($sitio = sqlsrv_fetch_array($sitios, SQLSRV_FETCH_ASSOC)) {
        $total = $total + 1;
        $tsucursal = ($sitio['stipo'] === "SUC") ? $tsucursal + 1 : $tsucursal;
        $tcpd = ($sitio['stipo'] === "CPD") ? $tcpd + 1 : $tcpd;
        $tsar = ($sitio['stipo'] === "SAR") ? $tsar + 1 : $tsar;
        $filas .= "
            <tr>
                <td>" . utf8_encode($sitio['stipo']) . "</td>
                <td>" . utf8_encode($sitio['snombre']) . "</td>
                <td class='text-center'>{$sitio['comunicaciones']}</td>
                <td class='text-center'>{$sitio['firewalls']}</td>
                <td class='text-center'>{$sitio['hardwares']}</td>
                <td class='text-center'>{$sitio['instalaciones']}</td>
                <td class='text-center'>{$sitio['switchs']}</td>    
            </tr>";
    }
    $cuerpo = '
        <div class="row">
            <div class="col">
                <div class="card border-azul-clasico" title="Total de sitios">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>TOTAL</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $total . '</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card border-azul-clasico" title="Total de sucursales">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>SUCURSAL</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $tsucursal . '</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card border-azul-clasico" title="Total de centros de procesamientos de datos">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>CPD</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $tcpd . '</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card border-azul-clasico" title="Total de sitios de almacenamiento de resguardos">
                    <div class="card-body bg-light">
                        <h4 class="card-title text-center"><b>SAR</b></h4>
                        <p class="card-text text-center h1 font-weight-bold">' . $tsar . '</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-row mt-4">
            <div class="col-5">
                <div class="input-group">
                    <select class="custom-select" id="minimo" name="minimo" title="Cantidad minima de elementos">
                        <option value="1">1 elemento</option>
                        <option value="2">2 elementos</option>
                        <option value="3">3 elementos</option>
                        <option value="4">4 elementos</option>
                        <option value="5">5 elementos</option>
                        <option value="6">6 elementos</option>
                        <option value="7">7 elementos</option>
                        <option value="8">8 elementos</option>
                        <option value="9">9 elementos</option>
                        <option value="10">10 elementos</option>
                    </select>
                    <select class="custom-select" id="elemento" name="elemento">
                        <option value="2">Comunicaciones</option>
                        <option value="3">Firewalls</option>
                        <option value="4">Hardwares</option>
                        <option value="5">Instalaciones</option>
                        <option value="6">Switchs</option>
                    </select>
                    <div class="input-group-append">
                      <button class="btn btn-outline-success" id="btnGraficar" name="btnGraficar"
                              title="Graficar" type="button"><i class="fas fa-chart-pie"></i></button>
                    </div>
                </div>
            </div>
            <div class="col"></div>
        </div>
        <div class="row mt-4">
            <div class="col">
                <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white"><i class="fas fa-table"></i> Información resumida</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="tbReporteSitios" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Tipo</th>
                                        <th>Nombre</th>
                                        <th>Comunicaciones</th>
                                        <th>Firewalls</th>
                                        <th>Hardwares</th>
                                        <th>Instalaciones</th>
                                        <th>Switchs</th>
                                    </tr>
                                </thead>
                                <tbody>' . $filas . '</tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4" id="seccionImagen" style="display: none;">
            <div class="col">
                <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white"><i class="fas fa-chart-pie"></i> Gráfico</div>
                    <div class="card-body">
                        <div class="mt-4 mb-4 text-center" id="imagen"></div>
                    </div>
                </div>
            </div>
        </div>';
} else {
    $filtro = "Información resumida";
    $mensaje = $controlador->getMensaje();
    $alerta = ControladorHTML::getAlertaOperacion($sitios, $mensaje);
    $cuerpo = ControladorHTML::getCardBusqueda($filtro, $alerta);
}
?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="far fa-building"></i> REPORTE DE SITIOS</h4>
                </div>
            </div>
            <div class="mt-3 mb-4"><?= $cuerpo; ?></div>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/ReporteSitio.js"></script>