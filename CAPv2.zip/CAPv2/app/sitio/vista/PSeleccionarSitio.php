<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\principal\modelo\Log;
use app\sitio\controlador\ControladorSitio;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorSitio();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $sitios = $resultado[1];
        while ($sitio = sqlsrv_fetch_array($sitios, SQLSRV_FETCH_ASSOC)) {
            $idSitio = $sitio['id'];
            $tipo = $sitio['tipo'];
            $nombreSitio = utf8_encode($sitio['nombre']);
            $texto = "$tipo : $nombreSitio";
            $arreglo[] = array('id' => $idSitio, 'text' => $texto);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar sitios";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'SITIOS', 'busqueda', 'PSeleccionarSitio', '', $detalle);
}

echo json_encode($arreglo);


