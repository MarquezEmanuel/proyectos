<?php

namespace app\sitio\controlador;

use app\sitio\modelo\Sitio;
use app\sitio\modelo\ColeccionSitios as Sitios;
use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

/**
 * Controla los eventos de los modelos de sitios.
 * 
 * @package app\seguridad\controlador.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ControladorSitio {

    public function buscar($nombre, $provincia, $ciudad, $estado) {
        return Sitios::buscar($nombre, $provincia, $ciudad, $estado);
    }

    public function buscarParaSeleccionar($nombre) {
        return Sitios::buscarParaSeleccionar($nombre);
    }

    public function buscarUltimosCreados($top, $estado) {
        return Sitios::buscarUltimosCreados($top, $estado);
    }

    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $sitio = new Sitio($id, NULL, NULL, NULL, NULL, NULL, NULL, NULL, $estado);
            $resultado = $sitio->cambiarEstado();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "cambiarEstado", $sitio);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    public function crear($codigo, $tipo, $nombre, $provincia, $ciudad, $codigoPostal, $direccion, $origen) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $sitio = new Sitio($codigo, $tipo, $nombre, $provincia, $ciudad, $codigoPostal, $direccion, $origen);
            $resultado = $sitio->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $sitio);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar con el sitio");
    }

    public function listarReporte() {
        $resultado = Sitios::listarReporte();
        return $resultado;
    }

    public function modificar($id, $tipo, $nombre, $provincia, $ciudad, $codigoPostal, $direccion, $origen) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $sitio = new Sitio($id, $tipo, $nombre, $provincia, $ciudad, $codigoPostal, $direccion, $origen);
            $resultado = $sitio->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $sitio);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Sitio $sitio Sitio con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $sitio) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "SITIOS";
        $metodo = "ControladorSitio::$funcion";
        $detalle = substr($sitio->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
