<?php

namespace app\hardware\modelo;

use app\principal\modelo\SQLServer;

/**
 * Mapea con la tabla de hardwares y con la vista asociada.
 * 
 * @package app\hardware\modelo.
 * 
 * @uses vwhar_hardware Vista de activos hardware.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 * 
 * @version 1.1
 */
class ColeccionHardwares {

    public static function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM vwhar_hardware WHERE hnombre LIKE ? AND hestado = ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array('%' . $nombre . '%', $estado));
        return $resultado;
    }

    /**
     * Buscar elementos de hardware en estado activo a partir de su nombre largo. 
     * De la consulta se obtiene el id, tipo y nombre largo. El objetivo del metodo 
     * es obtener los datos necesarios para seleccionar y relacionar.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombreLargo Nombre o parte del nombre del hardware (LIKE).
     * @return array Arreglo de dos posiciones (codigo, datos o mensaje).
     */
    public static function buscarParaSeleccionar($nombreLargo) {
        $consulta = "SELECT id, tipo, nombreLargo FROM har_hardware "
                . "WHERE nombreLargo LIKE ? AND estado = 'Activo'"
                . "ORDER BY tipo, nombreLargo";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombreLargo}%"));
    }

    /**
     * Lista los hardwares (Servidores) asociados a una base de datos cargada de
     * forma manual.
     * @see SQLServer::instancia()->seleccionar
     * @param int $idBaseDatosManual Identificador del proveedor.
     * @return array Arreglo de dos posiciones (codigo, mensaje).
     */
    public static function buscarHardwaresBaseDatosManual($idBaseDatosManual) {
        if ($idBaseDatosManual > 0) {
            $consulta = "SELECT har.*, rel.fechaCreacionBase FROM bas_man_base_hardware rel "
                    . "INNER JOIN har_hardware har ON har.id = rel.idHardware "
                    . "WHERE rel.idBaseDatosManual = ?";
            return SQLServer::instancia()->seleccionar($consulta, array(&$idBaseDatosManual));
        }
        return array(0, "No se pudo hacer referencia a la base de datos");
    }

    public static function consultar($nombre, $tipo, $ambiente, $dominio, $sitio) {
        $tipo = ($tipo == "TODOS") ? "" : $tipo;
        $ambiente = ($ambiente == "TODOS") ? "" : $ambiente;
        $dominio = ($dominio == "TODOS") ? "" : $dominio;
        $consulta = "SELECT * FROM vwhar_hardware WHERE hnombre LIKE ? AND htipo LIKE ? AND hambiente LIKE ? AND hdominio LIKE ? AND snombre LIKE ? AND hestado = 'Activo'";
        $datos = array('%' . utf8_decode($nombre) . '%', '%' . utf8_decode($tipo) . '%', '%' . utf8_decode($ambiente) . '%', '%' . utf8_decode($dominio) . '%', '%' . utf8_decode($sitio) . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        return $resultado;
    }

    public static function listarUltimosCreados() {
        $consulta = "SELECT TOP(10) * FROM vwhar_hardware WHERE hestado = 'Activo' ORDER BY hid DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        return $resultado;
    }

}
