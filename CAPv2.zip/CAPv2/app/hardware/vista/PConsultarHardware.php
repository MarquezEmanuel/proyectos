<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\hardware\controlador\ControladorHardware;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorHardware();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $tipo = $_POST['tipo'];
    $ambiente = $_POST['ambiente'];
    $dominio = $_POST['dominio'];
    $sitio = $_POST['sitio'];
    $datos = ($nombre) ? "'{$nombre}', " : "TODOS, ";
    $datos .= ($tipo) ? "'{$tipo}', " : "TODOS, ";
    $datos .= ($ambiente) ? "'{$ambiente}', " : "TODOS, ";
    $datos .= ($dominio) ? "'{$dominio}', " : "TODOS, ";
    $datos .= ($sitio) ? "'{$sitio}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $hardwares = $controlador->consultar($nombre, $tipo, $ambiente, $dominio, $sitio);
    $_SESSION['CHARDWARES'] = array($nombre, $tipo, $ambiente, $dominio, $sitio, $datos);
} else {
    if (isset($_SESSION['CHARDWARES'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['CHARDWARES'];
        $nombre = $parametros[0];
        $tipo = $parametros[1];
        $ambiente = $parametros[2];
        $dominio = $parametros[3];
        $sitio = $parametros[4];
        $filtro = "Ultima búsqueda realizada: " . $parametros[5];
        $hardwares = $controlador->consultar($nombre, $tipo, $ambiente, $dominio, $sitio);
        $_SESSION['CHARDWARES'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $hardwares = $controlador->listarUltimosCreados();
        $filtro = "Resumen inicial";
        $_SESSION['CHARDWARES'] = NULL;
    }
}


if (gettype($hardwares) == "resource") {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $filas = "";
    while ($hardware = sqlsrv_fetch_array($hardwares, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr class='fila' title='Haga doble click para acceder a los detalles del elemento'>
                <td>{$hardware['htipo']}</td>
                <td>{$hardware['hsigla']}</td>
                <td>{$hardware['hnombre']}</td>
                <td style='display: none;'>{$hardware['hdominio']}</td>
                <td>" . utf8_encode($hardware['hambiente']) . "</td>
                <td style='display: none;'>" . utf8_encode($hardware['hsoftwareBase']) . "</td>
                <td>" . utf8_encode($hardware['snombre']) . "</td>
                <td>" . utf8_encode($hardware['hmarca']) . "</td>
                <td style='display: none;'>" . utf8_encode($hardware['hmodelo']) . "</td>
                <td style='display: none;'>" . utf8_encode($hardware['harquitectura']) . "</td>
                <td style='display: none;'>" . utf8_encode($hardware['hcore']) . "</td>
                <td style='display: none;'>" . utf8_encode($hardware['hprocesador']) . "</td>
                <td style='display: none;'>{$hardware['hmhz']}</td>
                <td style='display: none;'>{$hardware['hmemoria']}</td>
                <td style='display: none;'>" . utf8_encode($hardware['hdisco']) . "</td>
                <td style='display: none;'>" . utf8_encode($hardware['hraid']) . "</td>
                <td style='display: none;'>{$hardware['hred']}</td> 
                <td style='display: none;'>{$hardware['hrti']}</td> 
                <td style='display: none;'>" . utf8_encode($hardware['hfuncion']) . "</td> 
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbHardwares" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Tipo</th>
                        <th>Nombre corto</th>
                        <th>Nombre largo</th>
                        <th style="display: none;">Dominio</th>
                        <th>Ambiente</th>
                        <th style="display: none;">Software base</th>
                        <th>Sitio</th>
                        <th>Marca</th>
                        <th style="display: none;">Modelo</th>
                        <th style="display: none;">Arquitectura</th>
                        <th style="display: none;">Core</th>
                        <th style="display: none;">Procesador</th>
                        <th style="display: none;">Mhz</th>
                        <th style="display: none;">Memoria</th>
                        <th style="display: none;">Disco</th>
                        <th style="display: none;">Raid</th>
                        <th style="display: none;">Red</th>
                        <th style="display: none;">RTI</th>
                        <th style="display: none;">Funcion</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($hardwares == 1) ? $mensaje . " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($hardwares, $mensaje);
}

echo ControladorHTML::getCardBusqueda($filtro, $cuerpo);
