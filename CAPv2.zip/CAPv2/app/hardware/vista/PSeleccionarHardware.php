<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\principal\modelo\Log;
use app\hardware\controlador\ControladorHardware;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorHardware();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $hadwares = $resultado[1];
        while ($hadware = sqlsrv_fetch_array($hadwares, SQLSRV_FETCH_ASSOC)) {
            $idHardware = $hadware["id"];
            $nombreHardware = utf8_encode($hadware["tipo"]) . ' (' . utf8_encode($hadware["nombreLargo"]) . ')';
            $arreglo[] = array('id' => $idHardware, 'text' => $nombreHardware);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar hardware";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'HARDWARES', 'busqueda', 'PSeleccionarHardware', '', $detalle);
}

echo json_encode($arreglo);
