<?php

namespace app\utilidad\modelo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Util {

    /**
     * Realiza la conversion de una cadena de texto a formato Camel Case.
     * @param string $texto Cadena de texto en cualquier formato.
     * @return string Devuelve la cadena en formato Camel Case. 
     * @see mb_strtolower
     * @see ucwords
     * */
    public static function convertirCamelCase($texto) {
        if ($texto) {
            $minuscula = mb_strtolower($texto);
            $texto = ucwords($minuscula);
        }
        return $texto;
    }

}
