<?php
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\proveedor\controlador\ControladorProveedor;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorProveedor();
$resultado = $controlador->buscarEstadoActivo();
$estadoBoton = "disabled";
if ($resultado[0] == 2) {
    $proveedores = $resultado[1];
    $filas = $estadoBoton = "";
    while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
        $idProveedor = $proveedor['id'];
        $nombreProveedor = $proveedor['nombre'];
        $filas .= "
            <tr>
                <td class='text-center'>
                    <input type='checkbox' 
                           id='proveedores' name='proveedores[]' 
                           title='Seleccionar: {$nombreProveedor}'
                           value='{$idProveedor}'>
                </td>
                <td class='align-middle'>{$nombreProveedor}</td>
            </tr>";
    }
    $tablaProveedores = '
        <div class="table-responsive">
            <table id="tbProveedores" class="table table-bordered table-hover" 
                   cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th class="text-center">
                            <input type="checkbox" 
                                   id="cbTodosProveedores" name="cbTodosProveedores"
                                   title="Seleccionar todos los proveedores">
                        </th>
                        <th>Nombre</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $tablaProveedores = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-fire-alt"></i> CREAR FIREWALL</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formCrearFirewall" name="formCrearFirewall" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombre" id="nombre" 
                               placeholder="Nombre" required>
                    </div>
                    <label for="marca" class="col-sm-2 col-form-label">* Marca:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="marca" id="marca"
                               placeholder="Nombre de la marca" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="modelo" class="col-sm-2 col-form-label">* Modelo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="modelo" id="modelo" maxlength="50"
                               placeholder="Modelo" required>
                    </div>
                    <label for="nroSerie" class="col-sm-2 col-form-label">* Nro Serie:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nroSerie" id="nroSerie" maxlength="50"
                               placeholder="Número de serie" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="version" class="col-sm-2 col-form-label">* Versión Firmware:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="version" id="version" maxlength="50"
                               placeholder="Versión" required>
                    </div>
                    <label for="ip" class="col-sm-2 col-form-label">* IP:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="ip" id="ip" maxlength="15"
                               placeholder="IP" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="sucursal" class="col-sm-2 col-form-label">* Sitio:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="sucursal" name="sucursal"></select>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label">* Descripcion:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  id="descripcion" name="descripcion"
                                  maxlength="500"
                                  placeholder="Descripcion" required></textarea>
                    </div>
                </div>
                <div class="form-row">
                    <label for="proveedores" class="col-sm-2 col-form-label">* Proveedores:</label>
                    <div class="col"><?= $tablaProveedores; ?></div>
                </div>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
                <a href="FBuscarFirewall.php">
                    <button type="button" class="btn btn-outline-info">
                        <i class="fas fa-search"></i> BUSCAR
                    </button>
                </a>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="../js/CrearFirewall.js"></script>
