<?php
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\firewall\modelo\Firewall;

AutoCargador::cargarModulos();
session_start();

if ($_POST['idFirewall']) {

    $id = $_POST['idFirewall'];
    $firewall = new Firewall($id);
    $resultado = $firewall->obtener();
    if ($resultado[0] == 2) {

        /* OBTIENE LOS DATOS DEL FIREWALL */

        $nombre = $firewall->getNombre();
        $marca = $firewall->getMarca();
        $modelo = $firewall->getModelo();
        $numeroSerie = $firewall->getNumeroSerie();
        $versionFirmware = $firewall->getVersion();
        $ip = $firewall->getIp();
        $rti = $firewall->getRti();
        $estado = $firewall->getEstado();
        $descripcion = $firewall->getDescripcion();
        $fechaCreacion = $firewall->getFechaCreacion();
        $fechaEdicion = $firewall->getFechaEdicion();
        $fechaCreacionFormateada = isset($fechaCreacion) ? date_format($fechaCreacion, 'd/m/Y H:i') : "";
        $fechaEdicionFormateada = isset($fechaEdicion) ? date_format($fechaEdicion, 'd/m/Y H:i') : "";
        $getSitio = $firewall->obtenerSitio();
        $getProveedores = $firewall->obtenerProveedores();

        /* CARGA LOS DATOS DE LA SUCURSAL ASOCIADA AL FIREWALL */

        if ($getSitio[0] == 2) {
            $sitio = $firewall->getSitio();
            $idSitio = $sitio->getId();
            $tipoSitio = $sitio->getTipo();
            $nombreSitio = $sitio->getNombre();
            $estadoSitio = $sitio->getEstado();
            $filaSucursal = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Código:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $idSitio . '"
                               placeholder="Código del sitio" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Tipo:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $tipoSitio . '"
                               placeholder="Tipo de sitio" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreSitio . '"
                               placeholder="Nombre del sitio" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoSitio . '"
                               placeholder="Estado de sitio" readonly>
                    </div>
                </div>';
        } else {
            $datosSucursal = GeneradorHTML::getAlertaOperacion($getSitio[0], $getSitio[1]);
            $filaSucursal = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosSucursal . '</div>
                </div>';
        }

        /* CARGA LOS DATOS DE LOS PROVEEDORES ASOCIADOS AL FIREWALL */

        if ($getProveedores[0] == 2) {
            $proveedores = $firewall->getProveedores();
            $filas = "";
            foreach ($proveedores as $proveedor) {
                $idProveedor = $proveedor['id'];
                $nombreProveedor = utf8_encode($proveedor['nombre']);
                $telefonoProveedor = $proveedor['telefono'];
                $correoProveedor = $proveedor['correo'];
                $estadoProveedor = $proveedor['estado'];
                $referencia = '#' . str_pad($idProveedor, 6, "0", STR_PAD_LEFT);
                $filas .= "
                    <tr>
                        <td class='align-middle'>{$referencia}</td>
                        <td class='align-middle'>{$nombreProveedor}</td>
                        <td class='align-middle'>{$telefonoProveedor}</td>
                        <td class='align-middle'>{$correoProveedor}</td>
                        <td class='align-middle'>{$estadoProveedor}</td>
                    </tr>";
            }
            $tablaProveedores = '
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" 
                           cellspacing="0" style="width:100%">
                        <thead>
                            <tr>
                                <th>Referencia</th>
                                <th>Nombre</th>
                                <th>Telefono</th>
                                <th>Correo</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>' . $filas . '</tbody>
                    </table>
                </div>';
        } else {
            $tablaProveedores = GeneradorHTML::getAlertaOperacion($getProveedores[0], $getProveedores[1]);
        }

        /* CARGA EL CUERPO DEL FORMULARIO CON LOS DATOS OBTENIDOS */
        $cuerpo = '
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombre . '"
                           placeholder="Nombre" readonly>
                </div>
                <label for="marca" class="col-sm-2 col-form-label">Marca:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $marca . '"
                           placeholder="Nombre de la marca" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Modelo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $modelo . '"
                           placeholder="Modelo" readonly>
                </div>
                <label for="nroSerie" class="col-sm-2 col-form-label">Número de serie:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $numeroSerie . '"
                           placeholder="Número de serie" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Versión del firmware:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $versionFirmware . '"
                           placeholder="Versión" readonly>
                </div>
                <label class="col-sm-2 col-form-label">IP:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $ip . '"
                           placeholder="IP" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">RTI:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $rti . '"
                           placeholder="RTI" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Estado:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $estado . '"
                           placeholder="Estado" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Descripcion:</label>
                <div class="col">
                    <textarea class="form-control mb-2"
                              placeholder="Descripción" readonly>' . $descripcion . '</textarea>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Fecha de creación:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value = "' . $fechaCreacionFormateada . '"
                           placeholder="Fecha de creación" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Fecha de edición:</label>
                <div class="col">
                    <input type="input" class="form-control mb-2" 
                           value="' . $fechaEdicionFormateada . '"
                           placeholder="Fecha de ultima edición" readonly>
                </div>
            </div>
            <div class="form-row mt-4 mb-3">
                <div class="col-2"><strong><p>SITIO</p></strong></div>
                <div class="col-10"><hr></div>
            </div>
            ' . $filaSucursal . '
            <div class="form-row mt-4 mb-3">
                <div class="col-2"><strong><p>PROVEEDORES</p></strong></div>
                <div class="col-10"><hr></div>
            </div>
            <div class="form-row">
                <div class="col">' . $tablaProveedores . '</div>
            </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-fire-alt"></i> DETALLE DE FIREWALL</h4>
        </div>
    </div>
    <div class="card border-azul-clasico mt-3">
        <div class="card-header bg-azul-clasico text-white">Información</div>
        <div class="card-body">
            <?= $cuerpo; ?>
        </div>
    </div>
    <div class="form-row mt-2 mb-4">
        <div class="col text-right">
            <button type="button" class="btn btn-outline-info" 
                    onClick="window.location.reload();" >
                <i class="fas fa-search"></i> REGRESAR
            </button>
        </div>
    </div>
</div>