<?php
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\firewall\modelo\Firewall;
use app\proveedor\controlador\ControladorProveedor;

AutoCargador::cargarModulos();
session_start();

$boton = "";
if ($_POST['idFirewall']) {
    $id = $_POST['idFirewall'];
    $firewall = new Firewall($id);
    $controladorProveedor = new ControladorProveedor();
    $resultado = $firewall->obtener();
    $datosProveedores = $controladorProveedor->buscarEstadoActivo();
    if (($resultado[0] == 2) && ($datosProveedores[0] == 2)) {
        $nombre = $firewall->getNombre();
        $marca = $firewall->getMarca();
        $modelo = $firewall->getModelo();
        $numeroSerie = $firewall->getNumeroSerie();
        $versionFirmware = $firewall->getVersion();
        $ip = $firewall->getIp();
        $descripcion = $firewall->getDescripcion();
        $getSitio = $firewall->obtenerSitio();
        $getProveedores = $firewall->obtenerProveedores();

        /* BOTON QUE HABILITA LA MODIFICACION DEL FIREWALL */

        $boton = '<button type="submit" class="btn btn-success" 
                          id="btnModificarFirewall" name="btnModificarFirewall" disabled>
                          <i class="far fa-save"></i> GUARDAR
                  </button>';

        /* CARGA LOS DATOS DE LA SUCURSAL */

        if ($getSitio[0] == 2) {
            $sitio = $firewall->getSitio();
            $idSitio = $sitio->getId();
            $nombreSitio = $sitio->getNombre();
            $opcionSucursal = "
                <select class='form-control mb-2' 
                        id='sucursal' name='sucursal'>
                        <option value='{$idSitio}'>{$nombreSitio}</option>
                </select>";
        } else {
            $boton = '';
            $opcionSucursal = GeneradorHTML::getAlertaOperacion($getSitio[0], $getSitio[1]);
        }

        /* CARGA LOS PROVEEDORES ACTIVOS QUE ESTAN EN LA BASE DE DATOS */

        $filas = "";
        $proveedoresFirewall = $firewall->getProveedores();
        $idsProveedores = isset($proveedoresFirewall) ? array_column($proveedoresFirewall, "id") : array();
        $proveedores = $datosProveedores[1];
        while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
            $check = (in_array($proveedor['id'], $idsProveedores)) ? "checked" : "";
            $filas .= "
            <tr>
                <td class='text-center'>
                    <input type='checkbox' 
                           id='proveedores' name='proveedores[]' $check value='{$proveedor['id']}'>
                </td>
                <td class='align-middle'>" . utf8_encode($proveedor['nombre']) . "</td>
            </tr>";
        }
        $tablaProveedores = '
            <div class="table-responsive">
                <table id="tbServicios" class="table table-bordered table-hover" 
                       cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th class="text-center">
                                <input type="checkbox" id="cbTodosProveedores" name="cbTodosProveedores">
                            </th>
                            <th>Nombre</th>
                        </tr>
                    </thead>
                    <tbody>' . $filas . '</tbody>
                </table>
            </div>';

        $cuerpo = '
            <input type="hidden" name="idFirewall" id="idFirewall" value="' . $id . '">
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" 
                           value="' . $nombre . '"
                           placeholder="Nombre del firewall" required>
                </div>
                <label for="marca" class="col-sm-2 col-form-label">* Marca:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="marca" id="marca"
                           value="' . $marca . '"
                           placeholder="Nombre de la marca" required>
                </div>
            </div>
            <div class="form-row">
                <label for="modelo" class="col-sm-2 col-form-label">* Modelo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="modelo" id="modelo" maxlength="50"
                           value="' . $modelo . '"
                           placeholder="Modelo" required>
                </div>
                <label for="nroSerie" class="col-sm-2 col-form-label">* Nro Serie:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nroSerie" id="nroSerie" maxlength="50"
                           value="' . $numeroSerie . '"
                           placeholder="Número de serie" required>
                </div>
            </div>
            <div class="form-row">
                <label for="version" class="col-sm-2 col-form-label">* Versión:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="version" id="version" maxlength="50"
                           value="' . $versionFirmware . '"
                           placeholder="Versión" required>
                </div>
                <label for="ip" class="col-sm-2 col-form-label">* IP:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="ip" id="ip" maxlength="15"
                           value="' . $ip . '"
                           placeholder="IP" required>
                </div>
            </div>
            <div class="form-row">
                <label for="sucursal" class="col-sm-2 col-form-label">* Sucursal:</label>
                <div class="col">' . $opcionSucursal . '</div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col"></div>
            </div>
            <div class="form-row">
                <label for="descripcion" class="col-sm-2 col-form-label">* Descripcion:</label>
                <div class="col">
                    <textarea class="form-control mb-2" 
                              id="descripcion" name="descripcion"
                              maxlength="500"
                              placeholder="Descripcion" required>' . $descripcion . '</textarea>
                </div>
            </div>
            <div class="form-row">
                <label for="proveedores" class="col-sm-2 col-form-label">* Proveedores:</label>
                <div class="col">' . $tablaProveedores . '</div>
            </div>';
    } else {
        $codigo = ($resultado[0] == 2) ? $datosProveedores[0] : $resultado[0];
        $mensaje = ($resultado[0] == 2) ? $datosProveedores[1] : $resultado[1];
        $cuerpo = GeneradorHTML::getAlertaOperacion($codigo, $mensaje);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-fire-alt"></i> MODIFICAR FIREWALL</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarFirewall" name="formModificarFirewall" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <a href="FBuscarFirewall.php">
                    <button type="button" class="btn btn-outline-info">
                        <i class="fas fa-search"></i> BUSCAR
                    </button>
                </a>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="../js/ModificarFirewall.js"></script>

