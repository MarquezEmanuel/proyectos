<?php

namespace app\firewall\modelo;

use app\principal\modelo\SQLServer;

/**
 * Mapea con la tabla y vista de firewalls.
 * 
 * @package app\firewall\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ColeccionFirewalls {

    /**
     * Buscar firewalls a partir del nombre, marca, sitio y estado. De la
     * consulta se obtienen todos los campos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombreFirewall Nombre o parte del nombre del firewall (LIKE).
     * @param string $marca Marca del fiwarall (LIKE).
     * @param string $nombreSitio Nombre del sitio (LIKE).
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscar($nombreFirewall, $marca, $nombreSitio, $estado) {
        $consulta = "SELECT * FROM vwfir_firewall WHERE nombreFirewall LIKE ? "
                . "AND marcaFirewall LIKE ? AND nombreSitio LIKE ? "
                . "AND estadoFirewall = ?";
        $datos = array("%{$nombreFirewall}%", "%{$marca}%", "%{$nombreSitio}%", $estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    /**
     * Buscar firewalls ordenadas por fecha de creacion descendente con un tope
     * de registros y un estado. De la consulta se obtienen todos los campos de
     * la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $top Cantidad maxima de registros a seleccionar.
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarUltimosCreados($top, $estado) {
        $consulta = "SELECT TOP(?) * FROM vwfir_firewall "
                . "WHERE estadoFirewall = ? "
                . "ORDER BY fechaCreacionFirewall DESC";
        $datos = array(&$top, &$estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    public static function consultar($nombre, $marca, $ip, $sitio) {
        $consulta = "SELECT * FROM vwfir_firewall WHERE fnombre LIKE ? AND fmarca LIKE ? AND fip LIKE ? AND snombre LIKE ? AND festado = 'Activo'";
        $datos = array('%' . $nombre . '%', '%' . $marca . '%', '%' . $ip . '%', '%' . $sitio . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
