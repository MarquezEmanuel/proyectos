<?php

namespace app\firewall\modelo;

use app\principal\modelo\SQLServer;
use app\sitio\modelo\Sitio;
use app\proveedor\modelo\ColeccionProveedores as Proveedores;

/**
 * 
 * @package app\firewall\modelo.
 * 
 * @uses SQLServer app\principal\modelo\SQLServer.
 * @uses Sitio app\sitio\modelo\Sitio.
 * @uses ColeccionProveedores app\proveedor\modelo\ColeccionProveedores.
 * 
 */
class Firewall {

    private $id;
    private $nombre;
    private $marca;
    private $modelo;
    private $numeroSerie;
    private $version;
    private $sitio;
    private $ip;

    /** @var string Riesgo de TI [NVARCHAR(5) NOT NULL] */
    private $rti;

    /** @var string Estado del registro [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var string Descripcion del elemento auxiliar [NVARCHAR(500) NOT NULL] */
    private $descripcion;

    /** @var int Nivel de visibilidad [INT NOT NULL] */
    private $visibilidad;

    /** @var array Arreglo con identificadores de proveedores */
    private $proveedores;

    /** @var string Fecha de creacion del registro [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de ultima edicion del registro [SMALLDATETIME NOT NULL] */
    private $fechaEdicion;

    /**
     * @param int $id Identificador del registro [PK BIGINT].
     * @param string $nombre Nombre [NVARCHAR(50)].
     * @param string $modelo Modelo [NVARCHAR(50)].
     * @param string $numeroSerie Numero de serie [NVARCHAR(50)].
     * @param string $version Version [NVARCHAR(50)].
     * @param string $ip IP [NVARCHAR(15)].
     * @param string $sitio Sitio o identificador de sitio [FK NVARCHAR(10)].
     * @param string $rti Riesgo de TI [NVARCHAR(5)].
     * @param string $descripcion Descripcion adicional [NVARCHAR(500)].
     * @param string $estado Estado activo o inactivo [NVARCHAR(20)].
     * @param int $visibilidad Nivel de visibilidad del registro [INT].
     * @param array $proveedores Arreglo de proveedores.
     */
    public function __construct($id = NULL, $nombre = NULL, $marca = NULL, $modelo = NULL, $numeroSerie = NULL, $version = NULL, $ip = NULL, $sitio = NULL, $rti = NULL, $descripcion = NULL, $estado = NULL, $visibilidad = NULL, $proveedores = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setMarca($marca);
        $this->setModelo($modelo);
        $this->setNumeroSerie($numeroSerie);
        $this->setVersion($version);
        $this->setSitio($sitio);
        $this->setIp($ip);
        $this->setRti($rti);
        $this->setDescripcion($descripcion);
        $this->setEstado($estado);
        $this->setVisibilidad($visibilidad);
        $this->setProveedores($proveedores);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getMarca() {
        return utf8_encode($this->marca);
    }

    public function getModelo() {
        return utf8_encode($this->modelo);
    }

    public function getNumeroSerie() {
        return utf8_encode($this->numeroSerie);
    }

    public function getVersion() {
        return utf8_encode($this->version);
    }

    public function getSitio() {
        return $this->sitio;
    }

    public function getIp() {
        return $this->ip;
    }

    public function getProveedores() {
        return $this->proveedores;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getVisibilidad() {
        return $this->visibilidad;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = utf8_decode($nombre);
    }

    public function setMarca($marca) {
        $this->marca = utf8_decode($marca);
    }

    public function setModelo($modelo) {
        $this->modelo = utf8_decode($modelo);
    }

    public function setNumeroSerie($numeroSerie) {
        $this->numeroSerie = utf8_decode($numeroSerie);
    }

    public function setVersion($version) {
        $this->version = utf8_decode($version);
    }

    public function setSitio($sitio) {
        $this->sitio = $sitio;
    }

    public function setIp($ip) {
        $this->ip = $ip;
    }

    public function setProveedores($proveedores) {
        $this->proveedores = $proveedores;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setVisibilidad($visibilidad) {
        $this->visibilidad = $visibilidad;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE fir_firewall SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para cambiar estado del firewall");
    }

    public function crear() {
        if ($this->nombre && $this->marca && $this->modelo && $this->nroSerie && $this->version && $this->ip && $this->sitio && $this->descripcion && $this->proveedores) {
            $consulta = "INSERT INTO fir_firewall OUTPUT INSERTED.id VALUES (?, ?, ?, ?, ?, ?, ?, 'Si', ?, 'Activo', 1, GETDATE(), NULL)";
            $datos = array(&$this->nombre, &$this->marca, &$this->modelo, &$this->nroSerie, &$this->version, &$this->ip, &$this->sitio, &$this->descripcion);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            if ($resultado[0] == 2) {
                $this->id = $resultado[2];
                $rfirewall = FirewallProveedor::crear($this->id, $this->proveedores);
                $resultado = ($rfirewall[0] == 2) ? $resultado : $rfirewall;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear el firewall");
    }

    public function modificar() {
        if ($this->nombre && $this->marca && $this->modelo && $this->numeroSerie && $this->version && $this->ip && $this->sitio) {
            $consulta = "UPDATE fir_firewall SET nombre=?, marca=?, modelo=?, "
                    . "numeroSerie=?, version=?, ip=?, idSitio=?, descripcion=?, "
                    . "fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->nombre, &$this->marca, &$this->modelo, &$this->numeroSerie, &$this->version, &$this->ip, &$this->sitio, &$this->descripcion, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            if ($resultado[0] == 2) {
                $actualizar = FirewallProveedor::actualizarProveedoresFirewall($this->id, $this->proveedores);
                $resultado = ($actualizar[0] == 2) ? $resultado : $actualizar;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para modificar el firewall");
    }

    /**
     * Permite modificar los datos del activo que corresponde a Control de Gestion
     * de Tecnologia Informatica (CGTI). Este metodo actualiza los campos
     * rti, nivel de visibilidad y fecha de ultima edicion.
     * @return array Arreglo con dos elementos [codigo, mensaje].
     */
    public function modificarCGTI() {
        if ($this->id && $this->rti && $this->visibilidad) {
            $consulta = "UPDATE fir_firewall SET rti = ?, nivelVisibilidad = ?, "
                    . "fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->rti, &$this->visibilidad, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para modificar el firewall");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM fir_firewall WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->marca = $fila['marca'];
                $this->modelo = $fila['modelo'];
                $this->numeroSerie = $fila['numeroSerie'];
                $this->version = $fila['version'];
                $this->ip = $fila['ip'];
                $this->sitio = $fila['idSitio'];
                $this->rti = $fila['rti'];
                $this->descripcion = $fila['descripcion'];
                $this->estado = $fila['estado'];
                $this->visibilidad = $fila['nivelVisibilidad'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información del firewall correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al firewall");
    }

    public function obtenerSitio() {
        $sitio = new Sitio($this->sitio);
        $resultado = $sitio->obtener();
        $this->sitio = ($resultado[0] == 2) ? $sitio : NULL;
        return $resultado;
    }

    public function obtenerProveedores() {
        $this->proveedores = NULL;
        $resultado = Proveedores::buscarProveedoresFirewall($this->id);
        if ($resultado[0] == 2) {
            $proveedores = $resultado[1];
            while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
                $this->proveedores[] = $proveedor;
            }
            $resultado[1] = ($this->proveedores) ? NULL : $resultado[1];
        }
        return $resultado;
    }

    public function toString() {
        $firewall = ($this->id) ? "{{$this->id}," : "{0,";
        $firewall .= ($this->nombre) ? "'{$this->getNombre()}'," : "'',";
        $firewall .= ($this->marca) ? "'{$this->getMarca()}'," : "'',";
        $firewall .= ($this->modelo) ? "'{$this->getModelo()}'," : "'',";
        $firewall .= ($this->numeroSerie) ? "'{$this->getNumeroSerie()}'," : "'',";
        $firewall .= ($this->version) ? "'{$this->getVersion()}'," : "'',";
        $firewall .= ($this->ip) ? "'{$this->getIp()}'," : "'',";
        $firewall .= ($this->sitio && (gettype($this->sitio) == "string")) ? "'{$this->sitio}'," : "'',";
        $firewall .= ($this->rti) ? "'{$this->getRti()}'," : "'',";
        $firewall .= ($this->estado) ? "'{$this->getEstado()}'," : "'',";
        $firewall .= ($this->visibilidad) ? "{$this->visibilidad}}" : "0}";
        return $firewall;
    }

}
