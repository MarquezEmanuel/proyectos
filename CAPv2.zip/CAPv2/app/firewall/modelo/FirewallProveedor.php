<?php

namespace app\firewall\modelo;

use app\principal\modelo\SQLServer;

/**
 * Mapea con la tabla que relaciona firewalls con proveedores.
 * 
 * @package app\firewall\modelo.
 * 
 * @uses fir_firewall_proveedor Tabla relacion de firewall con proveedor.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 * 
 * @version 1.0
 * 
 */
class FirewallProveedor {

    /**
     * Realiza la eliminacion de los proveedores asociados al activo firewall y luego 
     * la creacion de los nuevos proveedores asociados.
     * @param int $idFirewall Identificador del activo.
     * @param array $proveedores Arreglo con los identificadores de los proveedores.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function actualizarProveedoresFirewall($idFirewall, $proveedores) {
        $resultado = FirewallProveedor::borrar($idFirewall);
        if ($resultado[0] == 2) {
            $resultado = FirewallProveedor::crear($idFirewall, $proveedores);
        }
        return $resultado;
    }

    /**
     * Elimina todos los proveedores asociados al firewall.
     * @see SQLServer::$instancia->borrar
     * @param int $idFirewall Identificador del firewall.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function borrar($idFirewall) {
        if ($idFirewall > 0) {
            $consulta = "DELETE FROM fir_firewall_proveedor WHERE idFirewall = ?";
            return SQLServer::$instancia->borrar($consulta, array(&$idFirewall));
        }
        return array(0, "No se pudo hacer referencia al firewall");
    }

    /**
     * Crea todas las relaciones de un firewall con sus proveedores.
     * @see SQLServer::instancia()->insertar
     * @param int $idFirewall Identificador del firewall.
     * @param array $proveedores Arreglo con los identificadores de los proveedores.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function crear($idFirewall, $proveedores) {
        if (($idFirewall > 0) && !empty($proveedores)) {
            $registros = "";
            for ($index = 0; $index < count($proveedores); $index++) {
                $registros .= "({$idFirewall}, ?),";
            }
            $consulta = "INSERT INTO fir_firewall_proveedor VALUES " . substr($registros, 0, -1);
            return SQLServer::instancia()->insertar($consulta, $proveedores);
        }
        return array(0, "No se recibieron los campos obligatorios para relacionar proveedores");
    }

}
