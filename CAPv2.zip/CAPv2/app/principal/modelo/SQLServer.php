<?php

namespace app\principal\modelo;

use app\principal\modelo\Log;

/**
 * Encripta o desencripta cadenas de texto.
 * 
 * @package app\principal\modelo.
 * 
 * @see Singleton.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class SQLServer {

    /** Instancia de la conexion con la BD */
    public static $instancia;

    /** @var Conexion con la base de datos */
    private $conexion;

    /**
     * Constructor de clase. 
     */
    public function __construct() {
        $configuracion = new ConfiguracionBD();
        $lectura = $configuracion->leerConfiguracion();
        if ($lectura) {
            $host = $configuracion->getHost();
            $usuario = $configuracion->getUsuario();
            $clave = $configuracion->getPassword();
            $baseDatos = $configuracion->getBaseDatos();
            $datosConexion = array("Database" => $baseDatos, "UID" => $usuario, "PWD" => $clave);
            $this->conectar($host, $datosConexion);
        } else {
            Log::escribirLineaError("Error al leer archivo de configuracion __construct() ");
        }
    }

    /**
     * Busca un codigo de error dentro del arreglo de errrores.
     * @param array $errores Arreglo de errores.
     * @param int $codigo Codigo del error.
     * @return bool True si lo encuentra, false caso contrario
     */
    private function buscarError($errores, $codigo) {
        if ($errores != null) {
            return (in_array($codigo, array_column($errores, 'code')));
        }
        return false;
    }

    /**
     * Realiza la conexion con la BD. Cuando se establece la conexion se asigna el
     * recurso al objeto conexion, en caso contrario sera nulo. 
     * @param string $host Nombre del host donde realizar la conexion.
     * @param array $datos Arreglo que contiene el nombre de la BD, usuario y clave.
     */
    private function conectar($host, $datos) {
        $this->conexion = sqlsrv_connect($host, $datos);
        if (!$this->conexion) {
            $this->conexion = NULL;
            Log::escribirLineaError("conectar($host, {$datos['Database']}, {$datos['UID']}, {$datos['PWD']})");
        }
    }

    /**
     * Finaliza la transaccion con la BD. Cuando se indica que el resultado es true
     * se aplica un commit en la BD, cuando se indica que el resultado es false se
     * aplica un rollback en la BD. 
     * @param boolean $resultado Resultado del conjunto de operaciones realizadas.
     */
    public function finalizarTransaccion($resultado = TRUE) {
        ($resultado) ? sqlsrv_commit($this->conexion) : sqlsrv_rollback($this->conexion);
    }

    private function grabarError($metodo, $consulta, $errores) {
        Log::escribirLineaError("$metodo | $consulta");
        foreach ($errores as $error) {
            Log::escribirLineaError("CODE: {$error['code']} --> {$error['message']}");
        }
    }

    /**
     * Inicia el proceso de transaccion. El metodo retorna true cuando la inicializacion
     * es correcta y false en caso contrario.
     * @return boolean True si se inicializa, false en caso contrario.
     */
    public function iniciarTransaccion() {
        if (sqlsrv_begin_transaction($this->conexion) === false) {
            Log::escribirLineaError("Error al inicializar transaccion con la BD");
            return false;
        }
        return true;
    }

    /**
     * Realiza la creacion de una nueva instancia de la conexion a la BD o devuelve
     * la instancia existente.
     */
    public static function instancia() {
        if (!self::$instancia instanceof self) {
            try {
                self::$instancia = new self;
            } catch (Exception $e) {
                Log::escribirError("Error al obtener instancia de la conexion a la BD - {$e->getCode()} - {$e->getMessage()}", "instancia()");
            }
        }
        return self::$instancia;
    }

    public function borrar($consulta, $parametros) {
        $resultado = sqlsrv_prepare($this->conexion, $consulta, $parametros);
        if ($resultado && sqlsrv_execute($resultado)) {
            if (sqlsrv_rows_affected($resultado) > 0) {
                return array(2, "Se eliminó el registro correctamente");
            }
            return array(1, "No se eliminó el registro");
        }
        $this->grabarError("borrar", $consulta, sqlsrv_errors());
        return array(0, "No se creó el registro por un error interno (comunicar al administrador)");
    }

    public function ejecutar($consulta) {
        $resultado = sqlsrv_query($this->conexion, $consulta);
        if ($resultado) {
            return array(2, "Se ejecutó la operación correctamente");
        }
        if ($this->buscarError(sqlsrv_errors(), 2627)) {
            return array(1, "No se creó el registro solicitado porque ya existe");
        }
        $this->grabarError("ejecutar", $consulta, sqlsrv_errors());
        return array(0, "No se ejecutó la operación por un error interno (comunicar al administrador)");
    }

    public function insertar($consulta, $parametros) {
        $resultado = sqlsrv_prepare($this->conexion, $consulta, $parametros);
        if ($resultado && sqlsrv_execute($resultado)) {
            $row = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC);
            return array(2, "Se creó el registro correctamente", $row["id"]);
        }
        if ($this->buscarError(sqlsrv_errors(), 2627)) {
            return array(1, "No se creó el registro solicitado porque ya existe");
        }
        $this->grabarError("insertar", $consulta, sqlsrv_errors());
        return array(0, "No se creó el registro por un error interno (comunicar al administrador)");
    }

    public function modificar($consulta, $parametros) {
        $resultado = sqlsrv_prepare($this->conexion, $consulta, $parametros);
        if ($resultado && sqlsrv_execute($resultado)) {
            return array(2, "Se modificó el registro correctamente");
        }
        if ($this->buscarError(sqlsrv_errors(), 2627)) {
            return array(1, "No se modificó el registro solicitado porque ya existe");
        }
        $this->grabarError("modificar", $consulta, sqlsrv_errors());
        return array(0, "No se modificó el registro por un error interno (comunicar al administrador)");
    }

    public function obtener($consulta, $parametros) {
        $resultado = sqlsrv_query($this->conexion, $consulta, $parametros);
        if ($resultado) {
            if (sqlsrv_has_rows($resultado)) {
                return array(2, sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC));
            }
            return array(1, "No se pudo obtener la información solicitada");
        }
        $this->grabarError("obtener", $consulta, sqlsrv_errors());
        return array(0, "Ocurrio un error al obtener registro (informe al administrador)");
    }

    /**
     * Este metodo permite realizar un SELECT sobre la base de datos. Esta 
     * configurado para ser SCROLLABLE con SQLSRV_CURSOR_KEYSET. Como resultado
     * brinda un codigo numerico y una cadena descriptiva sobre la consulta.
     * @param string $consulta Consulta SQL efectuar.
     * @param array $parametros Arreglo con los parametros a consultar.
     * @return array Arreglo con dos posiciones. Un codigo numerico o resource y un texto.
     */
    public function seleccionar($consulta, $parametros) {
        $opciones = array('Scrollable' => SQLSRV_CURSOR_KEYSET);
        $resultado = sqlsrv_query($this->conexion, $consulta, $parametros, $opciones);
        if ($resultado) {
            if (sqlsrv_has_rows($resultado)) {
                return array(2, $resultado);
            }
            return array(1, "No se encontraron resultados para mostrar");
        }
        $this->grabarError("seleccionar", $consulta, sqlsrv_errors());
        return array(0, "Ocurrio un error al realizar la consulta (informe al administrador)");
    }

}
