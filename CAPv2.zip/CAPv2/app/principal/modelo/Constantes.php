<?php

namespace app\principal\modelo;

/**
 * Lee el XML de configuracion para establecer la conexion a la base de datos.
 * 
 * @package app\principal\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Constantes {

    const ROOT = "C:\\xampp\\htdocs\\CAPv2";
    const APP = Constantes::ROOT . "\\app";
    const LOG = Constantes::ROOT . "\\logs";
    const PRI = Constantes::APP . "\\principal";
    const LDAP_HOST = "ldap://192.168.250.150";
    const LDAP_PORT = 389;
    const LDAP_DOMI = "desarrollo\\";

}
