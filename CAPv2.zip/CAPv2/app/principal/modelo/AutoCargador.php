<?php

namespace app\principal\modelo;


/**
 * Realiza la inclusion de los archivos PHP que se utilizan.
 * 
 * @package app\principal\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class AutoCargador {

    /**
     * Incluye los archivos PHP usando SPL_AUTOLOAD_REGISTER. Este metodo requiere
     * que se defina el nombre de espacios desde el ROOT del proyecto.
     * @see Constantes ROOT.
     */
    public static function cargarModulos() {
        spl_autoload_register(function($clase) {
            $ruta = Constantes::ROOT . "\\{$clase}.php";
            if (file_exists($ruta)) {
                require_once $ruta;
            }
        });
    }

}
