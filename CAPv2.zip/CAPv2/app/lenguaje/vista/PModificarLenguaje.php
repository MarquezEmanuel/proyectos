<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\lenguaje\controlador\ControladorLenguaje;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if ($_POST['idLenguaje']) {
    $id = $_POST['idLenguaje'];
    $nombre = $_POST['nombre'];
    $version = $_POST['version'];
    $descripcion = $_POST['descripcion'];
    $controlador = new ControladorLenguaje();
    $modificacion = $controlador->modificar($id, $nombre, $version, $descripcion);
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $modificacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);

