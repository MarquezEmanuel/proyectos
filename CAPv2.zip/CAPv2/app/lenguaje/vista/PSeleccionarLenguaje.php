<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\principal\modelo\Log;
use app\lenguaje\controlador\ControladorLenguaje;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorLenguaje();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $lenguajes = $resultado[1];
        while ($lenguaje = sqlsrv_fetch_array($lenguajes, SQLSRV_FETCH_ASSOC)) {
            $idLenguaje = $lenguaje["id"];
            $nombreLenguaje = utf8_encode($lenguaje["nombre"]) . ' (' . utf8_encode($lenguaje["version"]) . ')';
            $arreglo[] = array('id' => $idLenguaje, 'text' => $nombreLenguaje);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar lenguaje de programacion";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'LENGUAJES', 'busqueda', 'PSeleccionarLenguaje', '', $detalle);
}

echo json_encode($arreglo);
