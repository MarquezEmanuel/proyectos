<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\lenguaje\controlador\ControladorLenguaje;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorLenguaje();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $version = $_POST['version'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " : "";
    $datos .= ($version) ? "'{$version}', " : "";
    $datos .= ($descripcion) ? "'{$descripcion}', " : "";
    $datos .= ($estado) ? "'{$estado}'" : "";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombre, $version, $descripcion, $estado);
    $_SESSION['BLENGUAJES'] = array($nombre, $version, $descripcion, $estado, $datos);
} else {
    if (isset($_SESSION['BLENGUAJES'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BLENGUAJES'];
        $nombre = $parametros[0];
        $version = $parametros[1];
        $descripcion = $parametros[2];
        $estado = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[4];
        $resultado = $controlador->buscar($nombre, $estado);
        $_SESSION['BLENGUAJES'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['BLENGUAJES'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $lenguajes = $resultado[1];
    $filas = "";
    while ($lenguaje = sqlsrv_fetch_array($lenguajes, SQLSRV_FETCH_ASSOC)) {

        $id = $lenguaje['estado'];
        $nombre = utf8_encode($lenguaje['nombre']);
        $version = utf8_encode($lenguaje['version']);
        $descripcion = utf8_encode($lenguaje['descripcion']);
        $estado = $lenguaje['estado'];
        $fechaCreacion = isset($lenguaje['fechaCreacion']) ? date_format($lenguaje['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($lenguaje['fechaUltimaEdicion']) ? date_format($lenguaje['fechaUltimaEdicion'], 'd/m/Y H:i') : "";

        if ($estado == 'Activo') {
            $operaciones = "
                <button class='btn btn-outline-warning editar' 
                        name='{$id}' title='Editar: $nombre'>
                    <i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger baja' 
                        name='{$id}' title='Dar de baja: $nombre'>
                    <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-success alta' 
                        name='{$id}' title='Dar de alta: $nombre'>
                    <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td class='align-middle'>{$nombre}</td>
                <td class='align-middle'>{$version}</td>
                <td style='display: none;'>{$descripcion}</td>
                <td class='align-middle'>{$fechaCreacion}</td>
                <td class='align-middle'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>{$operaciones}</div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbLenguajes" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Versión</th>
                        <th style="display: none;">Descripción</th>
                        <th>Fecha de creación</th>
                        <th>Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}


echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
