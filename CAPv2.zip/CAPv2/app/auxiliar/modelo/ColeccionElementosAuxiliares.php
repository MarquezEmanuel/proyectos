<?php

namespace app\auxiliar\modelo;

use app\principal\modelo\SQLServer;

class ColeccionElementosAuxiliares {

    public static function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM vwaux_auxiliar WHERE anombre LIKE ? AND aestado = ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array('%' . $nombre . '%', &$estado));
        return $resultado;
    }

    public static function consultar($nombre, $gerencia, $empleado, $sitio) {
        $consulta = "SELECT * FROM vwaux_auxiliar WHERE anombre LIKE ? AND gnombre LIKE ? AND enombre LIKE ? AND snombre LIKE ? AND aestado = 'Activo'";
        $datos = array('%' . $nombre . '%', '%' . $gerencia . '%', '%' . $empleado . '%', '%' . $sitio . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        return $resultado;
    }

    public static function listarConTope($tope) {
        $consulta = "SELECT TOP(?) * FROM vwaux_auxiliar WHERE aestado = 'Activo' ORDER BY aid DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array($tope));
        return $resultado;
    }

}
