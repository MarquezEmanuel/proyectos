<?php

namespace app\auxiliar\modelo;

use app\principal\modelo\SQLServer;

class ColeccionElementosAuxiliares {

    public static function buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $estado) {
        $consulta = "SELECT * FROM vwaux_auxiliar WHERE nombreLargoAuxiliar LIKE ? "
                . " AND nombreGerencia LIKE ? AND nombreEmpleado LIKE ? AND nombreSitio LIKE ? "
                . " AND estadoAuxiliar = ?";
        $datos = array("%{$nombreLargo}%", "%{$nombreGerencia}%", "%{$nombreEmpleado}%", "%{$nombreSitio}%", &$estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    public static function buscarUltimosCreados($top, $estado) {
        $consulta = "SELECT TOP(?) * FROM vwaux_auxiliar "
                . " WHERE estadoAuxiliar = ? "
                . " ORDER BY fechaCreacionAuxiliar DESC";
        return SQLServer::instancia()->seleccionar($consulta, array(&$top, &$estado));
    }

    public static function consultar($nombre, $gerencia, $empleado, $sitio) {
        $consulta = "SELECT * FROM vwaux_auxiliar WHERE anombre LIKE ? AND gnombre LIKE ? AND enombre LIKE ? AND snombre LIKE ? AND aestado = 'Activo'";
        $datos = array('%' . $nombre . '%', '%' . $gerencia . '%', '%' . $empleado . '%', '%' . $sitio . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        return $resultado;
    }

}
