<?php

namespace app\auxiliar\modelo;

use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

/**
 * Mapea con la tabla de elementos auxiliares.
 * 
 * @package app\auxiliar\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 * 
 * @version 1.1
 */
class ElementoAuxiliar {

    /** @var int Identificador del elemento auxiliar [BIGINT NOT NULL] */
    private $id;

    /** @var string Nombre corto del servicio [NVARCHAR(20) NOT NULL] */
    private $nombreCorto;

    /** @var string Nombre largo del servicio [NVARCHAR(50) NOT NULL] */
    private $nombreLargo;

    /** @var int Cantidad de elementos [INT NOT NULL] */
    private $cantidad;

    /** @var int Identificador de la gerencia [BIGINT NOT NULL] */
    private $gerencia;

    /** @var string Identificador del empleado [NVARCHAR(10) NOT NULL] */
    private $empleado;

    /** @var int Identificador del sitio [BIGINT NOT NULL] */
    private $sitio;

    /** @var string Descripcion del elemento auxiliar [NVARCHAR(500) NOT NULL] */
    private $descripcion;

    /** @var string Riesgo de TI [NVARCHAR(5) NOT NULL] */
    private $rti;

    /** @var string Estado del registro [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var int Nivel de visibilidad [INT NOT NULL] */
    private $visibilidad;

    /** @var string Fecha de creacion del registro [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de ultima edicion del registro [SMALLDATETIME NOT NULL] */
    private $fechaEdicion;

    public function __construct($id = NULL, $nombreCorto = NULL, $nombreLargo = NULL, $cantidad = NULL, $gerencia = NULL, $empleado = NULL, $sitio = NULL, $descripcion = NULL, $rti = NULL, $estado = NULL, $visibilidad = NULL) {
        $this->setId($id);
        $this->setNombreCorto($nombreCorto);
        $this->setNombreLargo($nombreLargo);
        $this->setCantidad($cantidad);
        $this->setGerencia($gerencia);
        $this->setEmpleado($empleado);
        $this->setSitio($sitio);
        $this->setDescripcion($descripcion);
        $this->setRti($rti);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombreCorto() {
        return utf8_encode($this->nombreCorto);
    }

    public function getNombreLargo() {
        return utf8_encode($this->nombreLargo);
    }

    public function getGerencia() {
        return $this->gerencia;
    }

    public function getEmpleado() {
        return $this->empleado;
    }

    public function getSitio() {
        return $this->sitio;
    }

    public function getCantidad() {
        return $this->cantidad;
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getVisibilidad() {
        return $this->visibilidad;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setNombreCorto($nombreCorto) {
        if ($nombreCorto && strlen($nombreCorto) <= 20) {
            $this->nombreCorto = utf8_decode($nombreCorto);
        }
    }

    public function setNombreLargo($nombreLargo) {
        if ($nombreLargo && strlen($nombreLargo) <= 50) {
            $this->nombre = utf8_decode($nombreLargo);
        }
    }

    public function setCantidad($cantidad) {
        $this->cantidad = ($cantidad > 0) ? $cantidad : NULL;
    }

    public function setGerencia($gerencia) {
        $this->gerencia = $gerencia;
    }

    public function setEmpleado($empleado) {
        $this->empleado = $empleado;
    }

    public function setSitio($sitio) {
        $this->sitio = $sitio;
    }

    public function setDescripcion($descripcion) {
        if ($descripcion && strlen($descripcion) <= 500) {
            $this->descripcion = utf8_decode($descripcion);
        }
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE aux_auxiliar SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        Log::guardarActividad("WARNING", "AUXILIARES", "modificacion", "ElementoAuxiliar::cambiarEstado", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para cambiar estado del elemento auxiliar");
    }

    public function crear() {
        if ($this->nombreCorto && $this->nombreLargo && $this->cantidad && $this->gerencia && $this->empleado && $this->sitio && $this->descripcion) {
            $consulta = "INSERT INTO aux_auxiliar OUTPUT INSERTED.id "
                    . "VALUES (? ,?, ?, ?, ?, ?, ?, 'Si', 'Activo', 1, GETDATE(), NULL)";
            $datos = array(&$this->sigla, &$this->nombre, &$this->cantidad, &$this->gerencia, &$this->empleado, &$this->sitio, &$this->descripcion);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            $this->id = ($resultado[0] == 2) ? $resultado[2] : NULL;
            return $resultado;
        }
        Log::guardarActividad("WARNING", "AUXILIARES", "creacion", "ElementoAuxiliar::crear", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para crear el elemento auxiliar");
    }

    public function modificar() {
        if ($this->nombreCorto && $this->nombreLargo && $this->cantidad && $this->gerencia && $this->empleado && $this->sitio && $this->descripcion && $this->rti) {
            $consulta = "UPDATE aux_auxiliar SET nombreCorto=?, nombreLargo=?, "
                    . "cantidad=?, idGerencia=?,  idEmpleado=?, idSitio=?, descripcion=?, "
                    . "rti=?, nivelVisibilidad=?, fechaUltimaEdicion = GETDATE() "
                    . "WHERE id=?";
            $datos = array(&$this->sigla, &$this->nombre, &$this->gerencia, &$this->empleado, &$this->cantidad, &$this->sitio, &$this->descripcion, &$this->rti, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        Log::guardarActividad("WARNING", "AUXILIARES", "modificacion", "ElementoAuxiliar::modificar", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para modificar el elemento auxiliar");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM aux_auxiliar WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombreCorto = $fila['nombreCorto'];
                $this->nombreLargo = $fila['nombreLargo'];
                $this->cantidad = $fila['cantidad'];
                $this->gerencia = $fila['idGerencia'];
                $this->empleado = $fila['idEmpleado'];
                $this->sitio = $fila['idSitio'];
                $this->descripcion = $fila['descripcion'];
                $this->rti = $fila['rti'];
                $this->estado = $fila['estado'];
                $this->visibilidad = $fila['nivelVisibilidad'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información del elemento auxiliar correctamente");
            }
            return $resultado;
        }
        Log::guardarActividad("WARNING", "AUXILIARES", "busqueda", "ElementoAuxiliar::obtener", 1, $this->toString());
        return array(0, "No se pudo hacer referencia al elemento auxiliar");
    }

    public function obtenerGerencia() {
        $gerencia = new Gerencia($this->gerencia);
        $resultado = $gerencia->obtener();
        $this->gerencia = ($resultado[0] == 2) ? $gerencia : NULL;
        return $resultado;
    }

    public function obtenerSitio() {
        $sitio = new Sitio($this->sitio);
        $resultado = $sitio->obtener();
        $this->sitio = ($resultado[0] == 2) ? $sitio : NULL;
        return $resultado;
    }

    public function obtenerEmpleado() {
        $empleado = new Empleado($this->empleado);
        $resultado = $empleado->obtener(TRUE);
        $this->empleado = ($resultado[0] == 2) ? $empleado : NULL;
        return $resultado;
    }

    /**
     * Genera una cadena de texto con los datos del elemento auxiliar. Se omiten
     * los campos descripcion, fecha de creacion y fecha de ultima edicion.
     * @return string Datos del elemento auxiliar.
     */
    public function toString() {
        $auxiliar = ($this->id) ? "{{$this->id}," : "{0,";
        $auxiliar .= ($this->nombreCorto) ? "'{$this->getNombreCorto()}'," : "'',";
        $auxiliar .= ($this->nombreLargo) ? "'{$this->getNombreLargo()}'," : "'',";
        $auxiliar .= ($this->cantidad) ? "{$this->cantidad}," : "0,";
        $auxiliar .= ($this->gerencia && gettype($this->gerencia) == "integer") ? "{$this->gerencia}," : "0,";
        $auxiliar .= ($this->empleado && gettype($this->empleado) == "string") ? "'{$this->empleado}'," : "'',";
        $auxiliar .= ($this->sitio && gettype($this->sitio) == "string") ? "'{$this->sitio}'," : "'',";
        $auxiliar .= ($this->rti) ? "'{$this->getRti()}'," : "'',";
        $auxiliar .= ($this->estado) ? "'{$this->getEstado()}'," : "'',";
        $auxiliar .= ($this->visibilidad) ? "{$this->visibilidad}}" : "0}";
        return $auxiliar;
    }

}
