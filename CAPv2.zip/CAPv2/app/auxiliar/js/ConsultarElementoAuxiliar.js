/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    /* CARGA LA FECHA DEL DIA ACTUAL PARA USAR EN LOS NOMBRES DE ARCHIVOS */

    var hoy = new Date();
    var fecha = hoy.getDate() + "_" + (hoy.getMonth() + 1) + "_" + hoy.getFullYear();

    /* EJECUTA LA FUNCION QUE REALIZA LA BUSQUEDA */

    realizarBusqueda();

    /* ENVIA EL FORMULARIO DE BUSQUEDA INDICANDO QUE SE PETICIONO POR EL USUARIO */

    $('#formConsultarAuxiliar').submit(function (event) {
        event.preventDefault();
        $("#peticion").val("true");
        realizarBusqueda();
    });

    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('#seccionInferior').on('dblclick', '.fila', function () {
        $("#mdaSigla").val($(this).find('td:eq(0)').text());
        $("#mdaNombre").val($(this).find('td:eq(1)').text());
        $("#mdaGerencia").val($(this).find('td:eq(2)').text());
        $("#mdaLegajo").val($(this).find('td:eq(3)').text());
        $("#mdaDelegado").val($(this).find('td:eq(4)').text());
        $("#mdaCodigoSitio").val($(this).find('td:eq(5)').text());
        $("#mdaNombreSitio").val($(this).find('td:eq(6)').text());
        $("#mdaCantidad").val($(this).find('td:eq(7)').text());
        $("#mdaRTI").val($(this).find('td:eq(9)').text());
        $("#mdaDescripcion").val($(this).find('td:eq(8)').text());
        $("#ModalDatosAuxiliar").modal();
    });

    /* ENVIA LA PETICION AJAX PARA CARGAR EL RESULTADO PREVIO DE UNA BUSQUEDA */

    function realizarBusqueda() {
        $.ajax({
            type: "POST",
            url: "./PConsultarElementoAuxiliar.php",
            data: $("#formConsultarAuxiliar").serialize(),
            beforeSend: function () {
                $('#ModalCargando').modal({show: true, backdrop: 'static'});
            },
            success: function (data) {
                $('#seccionInferior').html(data);
                $('#tbAuxiliares').dataTable({
                    dom: 'Bfrtip',
                    lengthChange: false,
                    buttons: [{
                            extend: 'excelHtml5',
                            title: fecha + '_APLICACIONES'
                        }
                    ],
                    language: {url: "../../../lib/JQuery/Spanish.json"}
                });
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                setTimeout(function () {
                    $('#ModalCargando').modal('hide');
                }, 1000);
                $('html,body').animate({scrollTop: $("#seccionInferior").offset().top}, '1250');
            }
        });
    }

});

