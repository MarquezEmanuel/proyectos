<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\gerencia\controlador\ControladorGerencia;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['nombre'])) {
    $nombre = $_POST['nombre'];
    $jefe = ($_POST['jefe'] == 'NO') ? NULL : $_POST['jefe'];
    $controlador = new ControladorGerencia();
    $creacion = $controlador->crear($nombre, $jefe);
    $exito = ($creacion[0] == 2) ? TRUE : FALSE;
    $resultado = GeneradorHTML::getAlertaOperacion($creacion[0], $creacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);

