<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\gerencia\controlador\ControladorEmpleado;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['idEmpleado'])) {
    $id = $_POST['idEmpleado'];
    $legajo = $_POST['legajo'];
    $nombre = $_POST['nombre'];
    $departamento = (!isset($_POST['departamento']) || $_POST['departamento'] == 'NO') ? NULL : $_POST['departamento'];
    $controlador = new ControladorEmpleado();
    $modificacion = $controlador->modificar($id, $nombre, $departamento, $legajo);
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $modificacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
