<?php

namespace app\gerencia\modelo;

use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

/**
 * Mapea con la tabla de gerencias.
 * 
 * @package app\gerencia\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Gerencia {

    /** @var int Identificador de la gerencia [BIGINT] */
    private $id;

    /** @var string Nombre [NVARCHAR(100) NOT NULL] */
    private $nombre;

    /** @var int Identificador del empleado gerente [BIGINT NOT NULL] */
    private $jefe;

    /** @var string Estado [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var string Fecha de creacion [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de edicion [SMALLDATETIME NULL] */
    private $fechaEdicion;

    public function __construct($id = NULL, $nombre = NULL, $jefe = NULL, $estado = NULL) {
        $this->id = $id;
        $this->nombre = utf8_decode($nombre);
        $this->jefe = $jefe;
        $this->estado = $estado;
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getJefe() {
        return $this->jefe;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        if ($nombre && (strlen($nombre) <= 100)) {
            $this->nombre = utf8_decode(Util::convertirCamelCase($nombre));
        }
    }

    public function setJefe($jefe) {
        $this->jefe = $jefe;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE ger_gerencia SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        Log::guardarActividad("WARNING", "GERENCIAS", "modificacion", "Gerencia::cambiarEstado", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para cambiar estado de la gerencia");
    }

    public function crear() {
        if ($this->nombre) {
            $consulta = "INSERT INTO ger_gerencia OUTPUT INSERTED.id VALUES (?, ?, 'Activa', GETDATE(), NULL)";
            $datos = array(&$this->nombre, &$this->jefe);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            $this->id = ($resultado[0] == 2) ? $resultado[2] : NULL;
            return $resultado;
        }
        Log::guardarActividad("WARNING", "GERENCIAS", "creacion", "Gerencia::crear", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para crear la gerencia");
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->jefe) {
            $consulta = "UPDATE ger_gerencia SET nombre=?, idEmpleado=?, fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->nombre, &$this->jefe, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        Log::guardarActividad("WARNING", "GERENCIAS", "modificacion", "Gerencia::modificar", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para modificar la gerencia");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM ger_gerencia WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->jefe = $fila['idEmpleado'];
                $this->estado = $fila['estado'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return $resultado;
            }
            return $resultado;
        }
        Log::guardarActividad("WARNING", "GERENCIAS", "busqueda", "Gerencia::obtener", 1, $this->toString());
        return array(0, "No se pudo hacer referencia a la gerencia");
    }

    public function obtenerEmpleado() {
        $jefe = new Empleado($this->jefe);
        $resultado = $jefe->obtener();
        $this->jefe = ($resultado[0] == 2) ? $jefe : NULL;
        return $resultado;
    }

}
