<?php

namespace app\gerencia\modelo;

use app\principal\modelo\SQLServer;

/**
 * Mapea con la tabla y vista de empleados.
 * 
 * @package app\gerencia\modelo.
 * 
 * @uses vwger_empleado Vista de departamentos.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ColeccionEmpleados {

    /**
     * Buscar empleados a partir del legajo, nombre, nombre departamento y estado. 
     * De la consulta se obtienen todos los campos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param string $legajo Numero de legajo del empleado (LIKE).
     * @param string $nombreEmpleado Nombre o parte del nombre del empleado (LIKE).
     * @param string $nombreDepartamento Nombre o parte del nombre del departamento (LIKE).
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscar($legajo, $nombreEmpleado, $nombreDepartamento, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM vwger_empleado WHERE estadoEmpleado = ?";
            $consulta .= ($legajo) ? " AND idEmpleado LIKE ? " : "";
            $consulta .= ($nombreEmpleado) ? " AND nombreEmpleado LIKE ? " : "";
            $consulta .= ($nombreDepartamento) ? " AND nombreDepartamento LIKE ?" : "";
            $datos = array(&$estado, "%{$legajo}%", "%{$nombreEmpleado}%", "%$nombreDepartamento%");
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar empleados");
    }

    /**
     * Buscar empleado en estado activo a partir de su nombre. De la consulta se 
     * obtiene el id, nombre. El objetivo del metodo es obtener los datos necesarios 
     * para seleccionar y relacionar.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre o parte del nombre de la herramienta (LIKE).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarParaSeleccionarDelegado($nombre) {
        $consulta = "SELECT id, nombre FROM ger_empleado "
                . "WHERE nombre LIKE ? AND estado = 'Activo' "
                . "ORDER BY nombre";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombre}%"));
    }

    /**
     * Buscar empleado en estado activo, sin departamento asociados y que no es
     * gerente a partir de su nombre. De la consulta se obtiene el id, nombre. 
     * El objetivo del metodo es obtener los datos necesarios para seleccionar y
     * relacionar.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre o parte del nombre de la herramienta (LIKE).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarParaSeleccionarJefe($nombre) {
        $consulta = "SELECT idEmpleado, nombreEmpleado FROM vwger_empleado "
                . "WHERE nombreEmpleado LIKE ? AND estadoEmpleado = 'Activo' "
                . "AND idDepartamento IS NULL AND gerente = 'No' "
                . "ORDER BY nombreEmpleado";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombre}%"));
    }

    /**
     * Buscar empleados ordenados por fecha de creacion descendente con un tope
     * de registros y un estado. De la consulta se obtienen todos los campos de
     * la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $top Cantidad maxima de registros a seleccionar.
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarUltimosCreados($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM vwger_empleado "
                    . "WHERE estadoEmpleado = ? "
                    . "ORDER BY fechaCreacionEmpleado DESC";
            $datos = array(&$top, &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar departamentos");
    }

}
