<?php

namespace app\gerencia\modelo;

use app\principal\modelo\SQLServer;

/**
 * Mapea con la tabla y vista de gerencias.
 * 
 * @package app\gerencia\modelo.
 * 
 * @uses vwger_gerencia Vista de gerencias.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ColeccionGerencias {

    /**
     * Buscar gerencias a partir del nombre, nombre de empleado y estado. 
     * De la consulta se obtienen todos los campos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombreGerencia Nombre o parte del nombre de la gerencia (LIKE).
     * @param string $nombreEmpleado Nombre o parte del nombre del empleado (LIKE).
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscar($nombreGerencia, $nombreEmpleado, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM vwger_gerencia WHERE estadoGerencia = ?";
            $consulta .= ($nombreGerencia) ? " AND nombreGerencia LIKE ? " : "";
            $consulta .= ($nombreEmpleado) ? " AND nombreEmpleado LIKE ? " : "";
            $datos = array(&$estado, "%{$nombreGerencia}%", "%{$nombreEmpleado}%");
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar gerencias");
    }

    /**
     * Buscar gerencia en estado activa a partir de su nombre. De la consulta se 
     * obtiene el id, nombre. El objetivo del metodo es obtener los datos necesarios 
     * para seleccionar y relacionar.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre o parte del nombre del departamento (LIKE).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarParaSeleccionar($nombre) {
        $consulta = "SELECT id, nombre FROM ger_gerencia "
                . "WHERE nombre LIKE ? AND estado = 'Activa' "
                . "ORDER BY nombre";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombre}%"));
    }

    /**
     * Buscar gerencias ordenados por fecha de creacion descendente con un tope
     * de registros y un estado. De la consulta se obtienen todos los campos de
     * la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $top Cantidad maxima de registros a seleccionar.
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarUltimasCreadas($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM vwger_gerencia "
                    . "WHERE estadoGerencia = ? "
                    . "ORDER BY fechaCreacionGerencia DESC";
            $datos = array(&$top, &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar gerencias");
    }

    public static function listarReporte() {
        $consulta = "SELECT gnombre, aplicaciones, auxiliares, comunicaciones, departamentos, instalaciones FROM vwger_gerencia WHERE gestado = 'Activa'";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        return $resultado;
    }

}
