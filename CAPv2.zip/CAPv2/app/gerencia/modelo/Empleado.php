<?php

namespace app\gerencia\modelo;

use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;
use app\utilidad\modelo\Util;

/**
 * Mapea con la tabla de empleados.
 * 
 * @package app\gerencia\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Empleado {

    /** @var int Identificador del empleado [BIGINT] */
    private $id;

    /** @var string Nombre [NVARCHAR(150) NOT NULL] */
    private $nombre;

    /** @var int Identificador del departamento [BIGINT NULL] */
    private $departamento;

    /** @var string Estado [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var string Fecha de creacion [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de edicion [SMALLDATETIME NULL] */
    private $fechaEdicion;

    public function __construct($id = NULL, $nombre = NULL, $departamento = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setDepartamento($departamento);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getDepartamento() {
        return $this->departamento;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        if ($id && (strlen($id) <= 10)) {
            $this->id = $id;
        }
    }

    public function setNombre($nombre) {
        if ($nombre && (strlen($nombre) <= 150)) {
            $this->nombre = utf8_decode(Util::convertirCamelCase($nombre));
        }
    }

    public function setDepartamento($departamento) {
        $this->departamento = $departamento;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE ger_empleado SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        Log::guardarActividad("WARNING", "GERENCIAS", "modificacion", "Empleado::cambiarEstado", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios");
    }

    public function crear() {
        if ($this->id && $this->nombre) {
            $consulta = "INSERT INTO ger_empleado VALUES (?, ?, ?, 'Activo', GETDATE(), NULL)";
            $datos = array(&$this->id, &$this->nombre, &$this->departamento);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            $this->id = ($resultado[0] == 2) ? $resultado[2] : NULL;
            return $resultado;
        }
        Log::guardarActividad("WARNING", "GERENCIAS", "creacion", "Empleado::crear", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para crear el empleado");
    }

    public function modificar($legajo) {
        if ($this->id && $this->nombre && $legajo) {
            $consulta = "UPDATE ger_empleado SET id=?, nombre=?, idDepartamento=?, "
                    . "fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$legajo, &$this->nombre, &$this->departamento, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        Log::guardarActividad("WARNING", "GERENCIAS", "modificacion", "Empleado::modificar", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para modificar el empleado");
    }

    public function obtener() {
        if (!$this->id) {
            $consulta = "SELECT * FROM ger_empleado WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->departamento = $fila['idDepartamento'];
                $this->estado = $fila['estado'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información del empleado correctamente");
            }
            return $resultado;
        }
        Log::guardarActividad("WARNING", "GERENCIAS", "busqueda", "Empleado::obtener", 1, $this->toString());
        return array(0, "No se pudo hacer referencia al empleado");
    }

    public function obtenerDepartamento() {
        $departamento = new Departamento($this->id);
        $resultado = $departamento->obtener();
        $this->departamento = ($resultado[0] == 2) ? $departamento : NULL;
        return $resultado;
    }

    public function toString() {
        $empleado = ($this->id) ? "{{$this->getId()}," : "{0,";
        $empleado .= ($this->nombre) ? "'{$this->getNombre()}'," : "'',";
        $empleado .= ($this->departamento && (gettype($this->departamento) == "integer")) ? "{$this->getDepartamento()}," : "0,";
        $empleado .= ($this->estado) ? "'{$this->getEstado()}'}" : "''}";
        return $empleado;
    }

}
