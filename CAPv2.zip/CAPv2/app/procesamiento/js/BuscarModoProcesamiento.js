/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    realizarBusqueda();

    $('#formBuscarModo').submit(function (event) {
        event.preventDefault();
        $("#peticion").val("true");
        realizarBusqueda();
    });
    
    /* CARGA EL FORMULARIO DE CREACION CUANDO SE PRESIONA EL BOTON EN PANTALLA */

    $('#btnCrearModo').click(function () {
        $.ajax({
            type: "POST",
            url: "./FCrearModoProcesamiento.php",
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html, body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });

    $('#seccionInferior').on('click', '.editar', function () {
        var idModo = $(this).attr("name");
        event.preventDefault();
        $.ajax({
            type: "POST",
            url: "./FModificarModoProcesamiento.php",
            data: "idModo=" + idModo,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<strong>No se procesó la petición (Informe al administrador)</strong>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('#seccionInferior').on('click', '.baja', function () {
        $("#mcemTitulo").html("<i class='fas fa-trash'></i> CONFIRME LA BAJA DEL MODO");
        $("#mcemAccion").val("BAJA");
        $("#mcemIdModo").val($(this).attr("name"));
        $("#mcemNombre").text($(this).parents("tr").find("td").eq(0).html() + ": ");
        $("#ModalCambioEstadoModo").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('#seccionInferior').on('click', '.alta', function () {
        $("#mcemTitulo").html("<i class='fas fa-plus-circle'></i> CONFIRME EL ALTA DEL MODO");
        $("#mcemAccion").val("ALTA");
        $("#mcemIdModo").val($(this).attr("name"));
        $("#mcemNombre").val($(this).parents("tr").find("td").eq(0).html());
        $("#ModalCambioEstadoModo").modal({backdrop: 'static', keyboard: false});
    });

    /* ENVIA LA OPERACION Y MUESTRA EL RESULTADO EN EL MODAL */

    $('#btnCambiarEstadoModo').click(function () {
        $.ajax({
            type: "POST",
            url: "./PCambiarEstadoModoProcesamiento.php",
            data: $("#formCambiarEstadoModo").serialize(),
            success: function (data) {
                $('#mcemCuerpo').html(data);
                $('#btnCambiarEstadoModo').hide();
                $('#btnCancelarCambiarEstado').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                var men = '<strong>No se procesó la petición (Informe al administrador)</strong>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#mcemCuerpo").html(div);
            }
        });
    });

    /* ACTUALIZA LA PANTALLA LUEGO DE HACER EL ALTA O BAJA */

    $('#btnRefrescarPantalla').click(function () {
        location.reload();
    });

    function realizarBusqueda() {
        $.ajax({
            type: "POST",
            url: "./PBuscarModoProcesamiento.php",
            data: $("#formBuscarModo").serialize(),
            success: function (data) {
                $('#seccionInferior').html(data);
                $('#tbModos').dataTable({
                    lengthChange: false,
                    language: {url: "../../../lib/JQuery/Spanish.json"}
                });
            },
            error: function (data) {
                console.log(data);
                var men = '<strong>No se procesó la petición (Informe al administrador)</strong>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#seccionInferior").offset().top}, '1250');
            }
        });
    }

});

