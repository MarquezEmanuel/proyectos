<?php

namespace app\procesamiento\modelo;

use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

/**
 * Mapea con la tabla de modos de procesamientos.
 * 
 * @package app\procesamiento\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ModoProcesamiento {

    /** @var int Identificador del servicio [BIGINT] */
    private $id;

    /** @var string Nombre [NVARCHAR(50) NOT NULL] */
    private $nombre;

    /** @var string Estado [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var string Fecha de creacion [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de edicion [SMALLDATETIME NULL] */
    private $fechaEdicion;

    public function __construct($id = NULL, $nombre = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function setId($id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setNombre($nombre) {
        if ($nombre && strlen($nombre) <= 50) {
            $this->nombre = utf8_decode($nombre);
        }
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE psa_modo SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        Log::guardarActividad("WARNING", "PROCESAMIENTOS", "modificacion", "ModoProcesamiento::cambiarEstado", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para cambiar estado del modo de procesamiento");
    }

    public function crear() {
        if ($this->nombre) {
            $consulta = "INSERT INTO psa_modo OUTPUT INSERTED.id VALUES (?, 'Activo', GETDATE(), NULL)";
            $resultado = SQLServer::instancia()->insertar($consulta, array(&$this->nombre));
            $this->id = ($resultado[0] == 2) ? $resultado[2] : NULL;
            return $resultado;
        }
        Log::guardarActividad("WARNING", "PROCESAMIENTOS", "creacion", "ModoProcesamiento::crear", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios");
    }

    public function modificar() {
        if ($this->id && $this->nombre) {
            $consulta = "UPDATE psa_modo SET nombre=?, fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->nombre, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        Log::guardarActividad("WARNING", "PROCESAMIENTOS", "modificacion", "ModoProcesamiento::modificar", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM psa_modo WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->estado = $fila['estado'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información correctamente");
            }
            Log::guardarActividad("WARNING", "PROCESAMIENTOS", "busqueda", "ModoProcesamiento::obtener", 1, $this->toString());
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al modo de procesamiento");
    }

    public function toString() {
        $modo = ($this->id) ? "{{$this->getId()}," : "{0,";
        $modo .= ($this->nombre) ? "{$this->getNombre()}," : "'',";
        $modo .= ($this->estado) ? "{$this->getEstado()}}" : "''}";
        return $modo;
    }

}
