<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\procesamiento\controlador\ControladorLugarProcesamiento;
use app\utilidad\modelo\GeneradorHTML;

AutoCargador::cargarModulos();
session_start();

if ($_POST['mcelAccion'] && isset($_POST['mcelIdLugar'])) {
    $controlador = new ControladorLugarProcesamiento();
    $id = $_POST['mcelIdLugar'];
    $estado = ($_POST['mcelAccion'] == "ALTA") ? 'Activo' : 'Inactivo';
    $modificacion = $controlador->cambiarEstado($id, $estado);
    $mensaje = $modificacion[1];
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

echo $resultado;

