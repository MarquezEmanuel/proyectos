<?php

namespace app\plataforma\modelo;

use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

/**
 * Mapea con la tabla de plataformas.
 * 
 * @package app\plataforma\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class PlataformaSO {

    /** @var int Identificador de la plataforma [BIGINT] */
    private $id;

    /** @var string Nombre [NVARCHAR(50) NOT NULL] */
    private $nombre;

    /** @var string Estado [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var string Fecha de creacion [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de edicion [SMALLDATETIME NULL] */
    private $fechaEdicion;

    public function __construct($id = NULL, $nombre = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setNombre($nombre) {
        if ($nombre && (strlen($nombre) <= 50)) {
            $this->nombre = utf8_decode($nombre);
        }
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE pla_plataformaSO SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        Log::guardarActividad("WARNING", "PLATAFORMAS", "modificacion", "PlataformaSO::cambiarEstado", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para cambiar estado de la plataforma");
    }

    public function crear() {
        if ($this->nombre) {
            $consulta = "INSERT INTO pla_plataformaSO OUTPUT INSERTED.id VALUES (?, 'Activa', GETDATE(), NULL)";
            $resultado = SQLServer::instancia()->insertar($consulta, array(&$this->nombre));
            $this->id = ($resultado[0] == 2) ? $resultado[2] : NULL;
            return $resultado;
        }
        Log::guardarActividad("WARNING", "PLATAFORMAS", "creacion", "PlataformaSO::crear", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para crear la plataforma");
    }

    public function modificar() {
        if ($this->id && $this->nombre) {
            $consulta = "UPDATE pla_plataformaSO SET nombre=?, fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->nombre, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        Log::guardarActividad("WARNING", "PLATAFORMAS", "modificacion", "PlataformaSO::modificar", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para modificar la plataforma");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM pla_plataformaSO WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->estado = $fila['estado'];
                return array(2, "Se obtuvo la información de la plataforma correctamente");
            }
            return $resultado;
        }
        Log::guardarActividad("WARNING", "PLATAFORMAS", "busqueda", "PlataformaSO::obtener", 1, $this->toString());
        return array(0, "No se pudo hacer referencia a la plataforma");
    }

    public function toString() {
        $plataforma = ($this->id) ? "{{$this->getId()}," : "{0,";
        $plataforma .= ($this->nombre) ? "'{$this->getNombre()}'," : "'',";
        $plataforma .= ($this->estado) ? "'{$this->getEstado()}'}" : "''}";
        return $plataforma;
    }

}
