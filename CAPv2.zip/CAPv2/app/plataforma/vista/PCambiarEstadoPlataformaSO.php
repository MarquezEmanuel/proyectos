<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\plataforma\controlador\ControladorPlataformaSO;
use app\utilidad\modelo\GeneradorHTML;

AutoCargador::cargarModulos();
session_start();

if (isset($_POST['mcepAccion'])) {
    $controlador = new ControladorPlataformaSO();
    $id = $_POST['mcepIdPlataforma'];
    $estado = ($_POST['mcepAccion'] == "ALTA") ? 'Activa' : 'Inactiva';
    $modificacion = $controlador->cambiarEstado($id, $estado);
    $codigo = $modificacion[0];
    $mensaje = $modificacion[1];
    $resultado = GeneradorHTML::getAlertaOperacion($codigo, $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

echo $resultado;

