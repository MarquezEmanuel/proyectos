<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\plataforma\controlador\ControladorPlataformaSO;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorPlataformaSO();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->seleccionar($nombre);
    if ($resultado[0] == 2) {
        $plataformas = $resultado[1];
        while ($plataforma = sqlsrv_fetch_array($plataformas, SQLSRV_FETCH_ASSOC)) {
            $arreglo[] = array('id' => $plataforma["id"], 'text' => utf8_encode($plataforma["nombre"]));
        }
    }
} else {
    $arreglo[] = array('id' => "NO", 'text' => "Sin parametros");
}

echo json_encode($arreglo);
