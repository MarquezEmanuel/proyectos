<?php

namespace app\actividad\controlador;

use app\actividad\modelo\ColeccionActividades as Actividades;

class ControladorActividad {

    public function buscar($modulo, $operacion, $usuario, $fecha) {
        $resultado = Actividades::buscar($modulo, $operacion, $usuario, $fecha);
        return $resultado;
    }

    public function buscarParaSeleccionarModulo($modulo) {
        return Actividades::buscarParaSeleccionarModulo($modulo);
    }

    public function buscarParaSeleccionarOperacion($operacion) {
        return Actividades::buscarParaSeleccionarOperacion($operacion);
    }

    public function buscarParaSeleccionarTipo($tipo) {
        return Actividades::buscarParaSeleccionarTipo($tipo);
    }

    public function listarResumenHistoricoUsuario($legajo) {
        $resultado = Actividades::listarResumenHistoricoUsuario($legajo);
        return $resultado;
    }

    public function listarResumenHoyUsuario($legajo) {
        $resultado = Actividades::listarResumenHoyUsuario($legajo);
        return $resultado;
    }

    public function listarUltimasCreadas() {
        $resultado = Actividades::listarUltimasCreadas();
        return $resultado;
    }

}
