<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\principal\modelo\Log;
use app\actividad\controlador\ControladorActividad;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['operacion'])) {
    $controlador = new ControladorActividad();
    $operacion = $_POST['operacion'];
    $resultado = $controlador->buscarParaSeleccionarOperacion($operacion);
    if ($resultado[0] == 2) {
        $registros = $resultado[1];
        while ($registro = sqlsrv_fetch_array($registros, SQLSRV_FETCH_ASSOC)) {
            $operacionActividad = utf8_encode($registro["operacion"]);
            $arreglo[] = array('id' => $operacionActividad, 'text' => $operacionActividad);
        }
    }
} else {
    $detalle = "No se recibio operacion para seleccionar";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'ACTIVIDAD', 'busqueda', 'PSeleccionarOperacion', '', $detalle);
}
echo json_encode($arreglo);
