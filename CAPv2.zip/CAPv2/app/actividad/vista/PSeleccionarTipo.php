<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\principal\modelo\Log;
use app\actividad\controlador\ControladorActividad;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['tipo'])) {
    $controlador = new ControladorActividad();
    $tipo = $_POST['tipo'];
    $resultado = $controlador->buscarParaSeleccionarTipo($tipo);
    if ($resultado[0] == 2) {
        $registros = $resultado[1];
        while ($registro = sqlsrv_fetch_array($registros, SQLSRV_FETCH_ASSOC)) {
            $tipoActividad = utf8_encode($registro["tipo"]);
            $arreglo[] = array('id' => $tipoActividad, 'text' => $tipoActividad);
        }
    }
} else {
    $detalle = "No se recibio tipo para seleccionar";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'ACTIVIDAD', 'busqueda', 'PSeleccionarTipo', '', $detalle);
}
echo json_encode($arreglo);
