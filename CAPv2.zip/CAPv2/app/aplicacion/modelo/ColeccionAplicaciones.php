<?php

namespace app\aplicacion\modelo;

use app\principal\modelo\SQLServer; 

class ColecccionAplicaciones {

    public static function buscarPP($nombre, $estado) {
        $consulta = "SELECT * FROM vwapl_aplicacion WHERE anombre LIKE ? AND aestado = ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array('%' . $nombre . '%', $estado));
        return $resultado;
    }

    public static function buscarSP($sigla, $nombre, $tipo) {
        $consulta = "SELECT * FROM vwapl_aplicacion WHERE asigla LIKE ? AND anombre LIKE ? AND atipo = ? AND aestado = 'Activa'";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array('%' . $sigla . '%', '%' . $nombre . '%', utf8_decode($tipo)));
        return $resultado;
    }

    public static function buscarTP($sigla, $nombre) {
        $consulta = "SELECT * FROM vwapl_aplicacion WHERE asigla LIKE ? AND anombre LIKE ? AND aestado = 'Activa'";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array('%' . $sigla . '%', '%' . $nombre . '%'));
        return $resultado;
    }

    public static function consultar($nombre, $tipo, $seguridad, $tecnologia) {
        $tipo = ($tipo == "TODOS") ? "" : $tipo;
        $seguridad = ($seguridad == "TODOS") ? "" : $seguridad;
        $tecnologia = ($tecnologia == "TODOS") ? "" : $tecnologia;
        $consulta = "SELECT * FROM vwapl_aplicacion WHERE anombre LIKE ? AND atipo LIKE ? AND aseguridad LIKE ? AND atecnologia LIKE ? AND aestado = 'Activa'";
        $datos = array('%' . $nombre . '%', '%' . $tipo . '%', '%' . $seguridad . '%', '%' . $tecnologia . '%');
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    public static function listarConTope($tope) {
        $consulta = "SELECT * FROM vwapl_aplicacion WHERE aestado = 'Activa' ORDER BY aid DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array($tope));
        return $resultado;
    }

}
