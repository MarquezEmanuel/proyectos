<?php

namespace app\aplicacion\controlador;

use app\aplicacion\modelo\Aplicacion;
use app\aplicacion\modelo\ColeccionAplicaciones as Aplicaciones;
use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

class ControladorAplicacion {

    public function buscarPP($nombre, $estado) {
        $resultado = Aplicaciones::buscarPP($nombre, $estado);
        return $resultado;
    }

    public function buscarSP($sigla, $nombre, $tipo) {
        $resultado = Aplicaciones::buscarSP($sigla, $nombre, $tipo);
        return $resultado;
    }

    public function buscarTP($sigla, $nombre) {
        $resultado = Aplicaciones::buscarTP($sigla, $nombre);
        return $resultado;
    }

    public function buscarUltimasCreadas($top, $estado) {
        return Aplicaciones::buscarUltimasCreadas($top, $estado);
    }

    public function consultar($nombre, $tipo, $seguridad, $tecnologia) {
        $resultado = Aplicaciones::consultar($nombre, $tipo, $seguridad, $tecnologia);
        return $resultado;
    }

    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $aplicacion = new Aplicacion($id);
            $aplicacion->setEstado($estado);
            $resultado = $aplicacion->cambiarEstado();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * @param string $nombreCorto Nombre corto de la aplicacion.
     * @param string $nombreLargo Nombre largo de la aplicacion.
     * @param string $tipo Tipo de aplicacion.
     * @param string $seguridad Tipo de seguridad.
     * @param string $tecnologia Tipo de tecnologia.
     * @param int $idLenguaje Identificador del lenguaje de progracion.
     * @param int $idHerramienta Identificador de la herramienta de desarrollo.
     * @param int $idBaseDatos Identificador de la base de datos manual.
     * @param int $idModo Identificador modo de procesamiento.
     * @param int $idLugar Identificador del lugar de procesamiento.
     * @param int $idPlataforma Identificador de la plataforma SO.
     * @param int $idGerencia Identificador de la gerencia.
     * @param string $idEmpleado Identificador del empleado delegado.
     * @param string $fechaCaducidad Fecha de caducidad de la licencia.
     * @param string $codigoSAS Codigo de aplicacion SAS.
     * @param string $descripcion Descripcion de la aplicacion.
     * @param array $proveedores Arreglo de proveedores.
     */
    public function crear($nombreCorto, $nombreLargo, $tipo, $seguridad, $tecnologia, $idLenguaje, $idHerramienta, $idBaseDatos, $idModo, $idLugar, $idPlataforma, $idGerencia, $idEmpleado, $fechaCaducidad, $codigoSAS, $descripcion, $proveedores) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $aplicacion = new Aplicacion(NULL, $nombreCorto, $nombreLargo, $tipo, $seguridad, $tecnologia, $idLenguaje, $idHerramienta, $idBaseDatos, $idModo, $idLugar, $idPlataforma, $idGerencia, $idEmpleado, $codigoSAS, $fechaCaducidad, NULL, NULL, NULL, NULL, NULL, $descripcion, NULL, NULL, $proveedores);
            $resultado = $aplicacion->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarPP($id, $sigla, $nombre, $tipo, $seguridad, $tecnologia, $proveedor, $lenguaje, $herramienta, $base, $modo, $lugar, $plataforma, $empleado, $sDesarrollo, $pDesarrollo, $rti, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $aplicacion = new Aplicacion($id, $sigla, $nombre, $tipo, $seguridad, $tecnologia, $proveedor, $lenguaje, $herramienta, $base, $modo, $lugar, $plataforma, NULL, $empleado, NULL, NULL, $sDesarrollo, NULL, NULL, $pDesarrollo, NULL, NULL, NULL, NULL, $rti, $descripcion);
            $resultado = $aplicacion->modificarPP();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarSP($id, $nombre, $sproduccion, $pproduccion, $stest, $ptest) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $aplicacion = new Aplicacion($id, NULL, $nombre, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, $sproduccion, $stest, NULL, $pproduccion, $ptest);
            $resultado = $aplicacion->modificarSP();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarTP($id, $nombre, $confidencialidad, $integridad, $disponibilidad, $criticidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $aplicacion = new Aplicacion($id, NULL, $nombre, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, $confidencialidad, $integridad, $disponibilidad, $criticidad);
            $resultado = $aplicacion->modificarTP();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Aplicacion $aplicacion Aplicacion con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $aplicacion) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "APLICACIONES";
        $metodo = "ControladorAplicacion::$funcion";
        $detalle = substr($aplicacion->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
