<?php
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\proveedor\controlador\ControladorProveedor;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorProveedor();
$resultado = $controlador->buscarEstadoActivo();
$estadoBoton = "disabled";
if ($resultado[0] == 2) {
    $proveedores = $resultado[1];
    $filas = $estadoBoton = "";
    while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
        $idProveedor = $proveedor['id'];
        $nombreProveedor = $proveedor['nombre'];
        $filas .= "
            <tr>
                <td class='text-center'>
                    <input type='checkbox' 
                           id='proveedores' name='proveedores[]' 
                           title='Seleccionar: {$nombreProveedor}'
                           value='{$idProveedor}'>
                </td>
                <td class='align-middle'>{$nombreProveedor}</td>
            </tr>";
    }
    $tablaProveedores = '
        <div class="table-responsive">
            <table id="tbProveedores" class="table table-bordered table-hover" 
                   cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th class="text-center">
                            <input type="checkbox" 
                                   id="cbTodosProveedores" name="cbTodosProveedores"
                                   title="Seleccionar todos los proveedores">
                        </th>
                        <th>Nombre</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $tablaProveedores = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-desktop"></i> CREAR APLICACIÓN</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formCrearAplicacion" name="formCrearAplicacion" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="nombreCorto" class="col-sm-2 col-form-label"
                           title="Nombre corto: campo obligatorio">* Nombre corto:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreCorto" id="nombreCorto"
                               minlength="3" maxlength="20"
                               placeholder="Nombre corto" required>
                    </div>
                    <label for="nombreLargo" class="col-sm-2 col-form-label"
                           title="Nombre largo: campo obligatorio">* Nombre largo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreLargo" id="nombreLargo"
                               minlength="3" maxlength="50"
                               placeholder="Nombre largo" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="tipo" class="col-sm-2 col-form-label"
                           title="Tipo de software: campo obligatorio">* Tipo de software:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="tipo" name="tipo">
                            <option value="Aplicación">Aplicación</option>
                            <option value="Técnico">Técnico</option>
                        </select>
                    </div>
                    <label for="tecnologia" class="col-sm-2 col-form-label"
                           title="Teconologia: campo obligatorio">* Técnologia:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="tecnologia" name="tecnologia">
                            <option value="No aplica">No aplica</option>
                            <option value="Cliente-Servidor">Cliente-Servidor</option>
                            <option value="Stand Alone">Stand Alone</option>
                            <option value="Web">Web</option>
                            <option value="Web Service">Web Service</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="seguridad" class="col-sm-2 col-form-label"
                           title="Seguridad: campo obligatorio">* Seguridad:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="seguridad" name="seguridad">
                            <option value="Active Directory">Active Directory</option>
                            <option value="Integrada">Integrada</option>
                            <option value="Propia">Propia</option>
                        </select>
                    </div>
                    <label for="codigoSAS" class="col-sm-2 col-form-label"
                           title="Código SAS: campo no obligatorio">Código SAS:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="codigoSAS" id="codigoSAS"
                               minlength="3" maxlength="50"
                               placeholder="Código SAS">
                    </div>
                </div>
                <div class="form-row">
                    <label for="codigoSAS" class="col-sm-2 col-form-label"
                           title="Fecha de caducidad de licencia: campo no obligatorio">Fecha caducidad:</label>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCaducidad" id="fechaCaducidad"
                               minlength="3" maxlength="50"
                               placeholder="Fecha de caducidad">
                    </div>
                    <label for="delegado" class="col-sm-2 col-form-label"
                           title="Delegado: campo no obligatorio">Delegado:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="delegado" name="delegado"></select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="herramienta" class="col-sm-2 col-form-label"
                           title="Herramienta de desarrollo: campo no obligatorio">Herramienta:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="herramienta" name="herramienta"></select>
                    </div>
                    <label for="lenguaje" class="col-sm-2 col-form-label"
                           title="Lenguaje de programación: campo no obligatorio">Lenguaje:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="lenguaje" name="lenguaje"></select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="base" class="col-sm-2 col-form-label"
                           title="Base de datos: campo no obligatorio">Base de datos:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="base" name="base"></select>
                    </div>
                    <label for="plataforma" class="col-sm-2 col-form-label"
                           title="Plataforma de sistema operativo: campo obligatorio">* Plataforma SO:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="plataforma" name="plataforma" required></select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="modo" class="col-sm-2 col-form-label"
                           title="Modo de procesamiento: campo obligatorio">* Modo:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="modo" name="modo" required></select>
                    </div>
                    <label for="lugar" class="col-sm-2 col-form-label"
                           title="Lugar de procesamiento: campo obligatorio">* Lugar:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="lugar" name="lugar"></select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label"
                           title="Descripción: campo obligatorio">* Descripción:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  name="descripcion" id="descripcion"
                                  rows="5" minlength="10" maxlength="500"
                                  placeholder="Descripción de la aplicación" required></textarea>
                    </div>
                </div>
                <div class="form-row">
                    <label for="proveedor" class="col-sm-2 col-form-label">Proveedores:</label>
                    <div class="col"><?= $tablaProveedores; ?></div>
                </div>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-success">
                    <i class="far fa-save"></i> GUARDAR
                </button>
                <button type="button" class="btn btn-outline-info" onclick="window.location.reload()">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="../js/CrearAplicacion.js"></script>