<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="fas fa-desktop"></i> BUSCAR APLICACIÓN</h4>
                </div>
            </div>
            <div class="mt-3 mb-4">
                <form method="POST" id="formBuscarAplicacion" name="formBuscarAplicacion">
                    <input type="hidden" name="peticion" value="peticion">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="sigla" class="col-2 col-form-label text-left">Nombre corto:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="sigla" id="sigla" 
                                           maxlength="9" pattern="[A-Za-z0-9]{1,9}"
                                           title="Nombre corto de la aplicación: campo no obligatorio"
                                           placeholder="Nombre corto">
                                </div>
                                <label for="nombre" class="col-2 col-form-label text-left">Nombre largo:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombre" id="nombre" 
                                           maxlength="9" pattern="[A-Za-z0-9]{1,9}"
                                           title="Nombre largo de la aplicación: campo no obligatorio"
                                           placeholder="Nombre largo">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="tipo" class="col-2 col-form-label text-left">* Tipo de software:</label>
                                <div class="col">
                                    <select id="tipo" name="tipo" class="form-control mb-2" required>
                                        <option value="Aplicación">Aplicación</option>
                                        <option value="Técnico">Técnico</option>
                                    </select>
                                </div>
                                <label class="col-2 col-form-label text-left"></label>
                                <div class="col"></div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success" name="btnBuscarAplicacion">
                                <i class="fas fa-search"></i>  BUSCAR</button>
                        </div>
                    </div>
                </form>
            </div>
            <br>
            <div id="seccionInferior" class="mt-4 mb-2"></div>
        </div>
        <div class="modal fade bg-dark" style="opacity: 80%" id="ModalCargando" tabindex="0" aria-labelledby="myModalLabel" data-backdrop="static" aria-hidden="false">
            <div class="modal-dialog modal-lg p-4">
                <div class="container p-4">
                    <div class="container mt-4 mb-4">
                        <div class="row mt-4 mb-4">
                            <div class="col text-center" style="font-size: 1.8rem;">
                                <i class="fas fa-spinner fa-3x fa-spin text-white"></i>
                            </div>
                        </div>
                        <div class="row mt-4 mb-4">
                            <div class="col text-center text-white" style="font-size: 1.4rem;">
                                <p> <strong>CARGANDO RESULTADOS</strong></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/BuscarSPAplicacion.js"></script>
