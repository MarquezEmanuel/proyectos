<?php
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\herramienta\modelo\HerramientaDesarrollo;

AutoCargador::cargarModulos();
session_start();

if ($_POST['idHerramienta']) {
    $id = $_POST['idHerramienta'];
    $herramienta = new HerramientaDesarrollo($id);
    $resultado = $herramienta->obtener();
    if ($resultado[0] == 2) {
        $nombre = $herramienta->getNombre();
        $version = $herramienta->getVersion();
        $fabricante = $herramienta->getFabricante();
        $fechaCaducidad = $herramienta->getFechaCaducidad();
        $descripcion = $herramienta->getDescripcion();
        $fechaCreacion = $herramienta->getFechaCreacion();
        $fechaEdicion = $herramienta->getFechaEdicion();
        $fechaCaducidadFormateada = isset($fechaCaducidad) ? date_format($fechaCaducidad, 'Y-m-d') : "";
        $fechaCreacionFormateada = isset($fechaCreacion) ? date_format($fechaCreacion, 'Y-m-d H:i') : "";
        $fechaEdicionFormateada = isset($fechaEdicion) ? date_format($fechaEdicion, 'Y-m-d H:i') : "";
        $datosProveedor = $herramienta->obtenerProveedores();

        if ($datosProveedor[0] == 2) {
            $proveedores = $herramienta->getProveedores();
            $filas = "";
            foreach ($proveedores as $proveedor) {
                $idProveedor = $proveedor['id'];
                $nombreProveedor = $proveedor['nombre'];
                $telefonoProveedor = $proveedor['telefono'];
                $correoProveedor = $proveedor['correo'];
                $referencia = '#' . str_pad($idProveedor, 10, "0", STR_PAD_LEFT);
                $filas .= "
                    <tr>
                        <td class='align-middle'>{$referencia}</td>
                        <td class='align-middle'>{$nombreProveedor}</td>
                        <td class='align-middle'>{$telefonoProveedor}</td>
                        <td class='align-middle'>{$correoProveedor}</td>
                    </tr>";
            }
            $tablaProveedores = '
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" 
                           cellspacing="0" style="width:100%">
                        <thead>
                            <tr>
                                <th>Referencia</th>
                                <th>Nombre</th>
                                <th>Telefono</th>
                                <th>Correo</th>
                            </tr>
                        </thead>
                        <tbody>' . $filas . '</tbody>
                    </table>
                </div>';
        } else {
            $tablaProveedores = GeneradorHTML::getAlertaOperacion($datosProveedor[0], $datosProveedor[1]);
        }

        $cuerpo = '
                <div class="form-row">
                    <label for="nombre" class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               value = "' . $nombre . '"
                               placeholder="Nombre" readonly>
                    </div>
                    <label for="version" class="col-sm-2 col-form-label">Versión:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               value = "' . $version . '"
                               placeholder="Versión" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label for="fabricante" class="col-sm-2 col-form-label">Fabricante:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               value = "' . $fabricante . '"
                               placeholder="Nombre del fabricante" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Fecha caducidad:</label>
                    <div class="col">
                        <input type="input" class="form-control mb-2" 
                               value="' . $fechaCaducidadFormateada . '"
                               placeholder="Fecha de caducidad" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Fecha de creación:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               value = "' . $fechaCreacionFormateada . '"
                               placeholder="Fecha de creación" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Fecha de edición:</label>
                    <div class="col">
                        <input type="input" class="form-control mb-2" 
                               value="' . $fechaEdicionFormateada . '"
                               placeholder="Fecha de ultima edición" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label">Descripción:</label>
                    <div class="col">
                        <textarea class="form-control mb-2"
                                  placeholder="Descripción adicional" readonly>' . $descripcion . '</textarea>
                    </div>
                </div>
                <div class="form-row">
                    <label for="proveedores" class="col-sm-2 col-form-label">Proveedores:</label>
                    <div class="col">' . $tablaProveedores . '</div>
                </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-laptop-code"></i> DETALLE DE HERRAMIENTA</h4>
        </div>
    </div>
    <div class="card border-azul-clasico mt-3">
        <div class="card-header bg-azul-clasico text-white">Información</div>
        <div class="card-body">
            <?= $cuerpo; ?>
        </div>
    </div>
    <div class="form-row mt-2 mb-4">
        <div class="col text-right">
            <button type="button" class="btn btn-outline-info" 
                    onClick="window.location.reload();" >
                <i class="fas fa-search"></i> REGRESAR
            </button>
        </div>
    </div>
</div>
