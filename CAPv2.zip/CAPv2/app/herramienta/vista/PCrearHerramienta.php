<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\herramienta\controlador\ControladorHerramientaDesarrollo;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if ($_POST['nombre'] && $_POST['version'] && $_POST['fabricante'] && $_POST['descripcion']) {
    $controlador = new ControladorHerramientaDesarrollo();
    $nombre = $_POST['nombre'];
    $version = $_POST['version'];
    $fabricante = $_POST['fabricante'];
    $fechaCaducidad = $_POST['fechaCaducidad'];
    $descripcion = $_POST['descripcion'];
    $proveedores = $_POST['proveedores'];
    $creacion = $controlador->crear($nombre, $version, $fabricante, $fechaCaducidad, $descripcion, $proveedores);
    $exito = ($creacion[0] == 2) ? TRUE : FALSE;
    $resultado = GeneradorHTML::getAlertaOperacion($creacion[0], $creacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
