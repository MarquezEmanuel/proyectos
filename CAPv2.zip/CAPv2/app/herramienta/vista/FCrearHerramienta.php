<?php
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\proveedor\controlador\ControladorProveedor;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorProveedor();
$resultado = $controlador->buscarEstadoActivo();
$estadoBoton = "disabled";
if ($resultado[0] == 2) {
    $proveedores = $resultado[1];
    $filas = $estadoBoton = "";
    while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
        $idProveedor = $proveedor['id'];
        $nombreProveedor = $proveedor['nombre'];
        $filas .= "
            <tr>
                <td class='text-center'>
                    <input type='checkbox' 
                           id='proveedores' name='proveedores[]' 
                           title='Seleccionar: {$nombreProveedor}'
                           value='{$idProveedor}'>
                </td>
                <td class='align-middle'>{$nombreProveedor}</td>
            </tr>";
    }
    $tablaProveedores = '
        <div class="table-responsive">
            <table id="tbProveedores" class="table table-bordered table-hover" 
                   cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th class="text-center">
                            <input type="checkbox" 
                                   id="cbTodosProveedores" name="cbTodosProveedores"
                                   title="Seleccionar todos los proveedores">
                        </th>
                        <th>Nombre</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $tablaProveedores = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-laptop-code"></i> CREAR HERRAMIENTA</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formCrearHerramienta" name="formCrearHerramienta" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombre" id="nombre" maxlength="50"
                               placeholder="Nombre" required>
                    </div>
                    <label for="version" class="col-sm-2 col-form-label">* Versión:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="version" id="version" maxlength="20" 
                               placeholder="Versión" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="fabricante" class="col-sm-2 col-form-label">* Fabricante:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="fabricante" id="fabricante" maxlength="50"
                               placeholder="Nombre del fabricante" required>
                    </div>
                    <label class="col-sm-2 col-form-label">Fecha caducidad:</label>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCaducidad" id="fechaCaducidad"
                               placeholder="Fecha de caducidad">
                    </div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label">* Descripción:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  name="descripcion" id="descripcion" 
                                  maxlength="300"
                                  placeholder="Descripción adicional" required></textarea>
                    </div>
                </div>
                <div class="form-row">
                    <label for="proveedores" class="col-sm-2 col-form-label">* Proveedores:</label>
                    <div class="col"><?= $tablaProveedores; ?></div>
                </div>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-success" <?= $estadoBoton; ?> >
                    <i class="far fa-save"></i> GUARDAR
                </button>
                <a href="FBuscarHerramienta.php">
                    <button type="button" class="btn btn-outline-info">
                        <i class="fas fa-search"></i> BUSCAR
                    </button>
                </a>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="../js/CrearHerramientaDesarrollo.js"></script>
