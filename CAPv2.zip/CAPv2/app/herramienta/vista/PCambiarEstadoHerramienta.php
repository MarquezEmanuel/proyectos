<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\herramienta\controlador\ControladorHerramientaDesarrollo;

AutoCargador::cargarModulos();
session_start();

if ($_POST['mcehAccion'] && isset($_POST['mcehIdHerramienta'])) {
    $controlador = new ControladorHerramientaDesarrollo();
    $id = $_POST['mcehIdHerramienta'];
    $estado = ($_POST['mcehAccion'] == "ALTA") ? 'Activa' : 'Inactiva';
    $modificacion = $controlador->cambiarEstado($id, $estado);
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $modificacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

echo $resultado;
