<?php

namespace app\seguridad\controlador;

use app\seguridad\modelo\Perfil;
use app\seguridad\modelo\ConjuntoPerfiles as Perfiles;
use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

/**
 * Controla los eventos de los modelos de perfiles.
 * 
 * @package app\seguridad\controlador.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ControladorPerfil {

    /**
     * Devuelve todos los datos de uno o mas perfiles obtenidos a partir de su 
     * nombre y/o estado. Este metodo consulta la vista de perfiles (vwseg_perfil)
     * para obtener los datos.
     * @param string $nombre Nombre o parte del nombre del permiso.
     * @param string $estado Estado actual del perfil a consultar.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function buscar($nombre, $estado) {
        $resultado = Perfiles::buscar($nombre, $estado);
        return $resultado;
    }

    /**
     * Realiza la creacion de un nuevo perfil. El resultado de esta operacion se
     * guarda en el log de actividades del sistema.
     * @param string $nombre Nombre del nuevo perfil.
     * @param string $descripcion Descripcion del perfil.
     * @param array $permisos Arreglo con los identificadores de permisos.
     * @return array Arreglo con un resultado numerico y un texto descriptivo.
     */
    public function crear($nombre, $descripcion, $permisos) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $perfil = new Perfil(NULL, $nombre, $descripcion, NULL, $permisos);
            $creacion = $perfil->crear();
            $confirmar = ($creacion == 2) ? TRUE : FALSE;
            $this->registrar($creacion, "creacion", "crear", "", $nombre);
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Realiza el cambio de estado de un determinado perfil. El resultado de esta
     * operacion se guarda en el log de actividades del sistema.
     * @param integer $id Identificador del perfil.
     * @param string $estado Nombre del estado.
     * @return array Arreglo con un resultado numerico y un texto descriptivo.
     */
    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $perfil = new Perfil($id, NULL, NULL, $estado);
            $edicion = $perfil->cambiarEstado();
            $confirmar = ($edicion[0] == 2) ? TRUE : FALSE;
            $this->registrar($edicion, "modificacion", "cambiarEstado", $id, $estado);
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $edicion;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Devuelve un listado de perfiles segun la cantidad especificada en el tope
     * y ordernados por identificador en forma descendente. Este metodo consula la 
     * vista de perfiles (vwseg_perfil) y esta diseñado para ser utilizado como 
     * una vista previa durante una busqueda.
     * @param integer $tope Numero de cantidad maxima a mostrar (TOP SQL).
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function listarConTope($tope) {
        $resultado = Perfiles::listarConTope($tope);
        return $resultado;
    }

    /**
     * Realiza la modificacion de un determinado perfil. El resultado de esta 
     * operacion se registra en el log de actividades del sistema.
     * @param integer $id Identificador del perfil.
     * @param string $nombre Nombre del perfil.
     * @param string $descripcion Descripcion del perfil.
     * @param array $permisos Arreglo con identificadores de permisos asociados.
     * @return array Arreglo con un resultado numerico y un texto descriptivo.
     */
    public function modificar($id, $nombre, $descripcion, $permisos) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $perfil = new Perfil($id, $nombre, $descripcion, NULL, $permisos);
            $edicion = $perfil->modificar();
            $confirmar = ($edicion[0] == 2) ? TRUE : FALSE;
            $this->registrar($edicion, "modificacion", "modificar", $id, $nombre);
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $edicion;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Devuelve el identificador y nombre de uno o mas perfiles. Este metodo 
     * consulta la vista de perfiles (vwseg_perfil) y esta diseñado para ser 
     * utilizado durante la seleccion de perfiles por pantalla.
     * @param string $nombre Nombre o parte del nombre del perfil.
     * @param string $estado Nombre del estado del perfil (Activo o Inactivo). 
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function seleccionar($nombre, $estado) {
        $resultado = Perfiles::seleccionar($nombre, $estado);
        return $resultado;
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param string $referencia Referencia al usuario.
     * @param string $datos Datos adicionales.
     */
    private function registrar($resultado, $operacion, $funcion, $referencia, $datos) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "PERFILES";
        $metodo = "ControladorPerfil::$funcion";
        $detalle = "$codigo : $datos";
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $referencia, $detalle);
    }

}
