<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

modelos\AutoCargador::cargarModulos();

$arreglo = array();
if (isset($_POST['nombre']) && isset($_POST['nivel'])) {
    $controlador = new controladores\ControladorPermiso();
    $nombre = $_POST['nombre'];
    $nivel = $_POST['nivel'];
    $permisos = $controlador->seleccionar($nombre, $nivel);
    if (gettype($permisos[0]) == "resource") {
        $resource = $permisos[0];
        while ($permiso = sqlsrv_fetch_array($resource, SQLSRV_FETCH_ASSOC)) {
            $arreglo[] = array('id' => $permiso["id"], 'text' => utf8_encode($permiso["titulo"]));
        }
    }
}
echo json_encode($arreglo);
