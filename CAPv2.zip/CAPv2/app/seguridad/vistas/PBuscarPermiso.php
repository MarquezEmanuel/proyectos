<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\seguridad\controlador\ControladorPermiso;
use app\principal\controlador\ControladorHTML;
use app\principal\modelo\AutoCargador;

AutoCargador::cargarModulos();

$controlador = new ControladorPermiso();

if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $nivel = $_POST['nivel'];
    $permisos = $controlador->buscar($nombre, $nivel);
    $filtro = "Resultado de la búsqueda: ";
    $filtro .= ($nombre) ? $nombre . ", " . $nivel : "TODOS, " . $nivel;
    $_SESSION['BPERMISOS'] = array($nombre, $nivel);
} else {
    if (isset($_SESSION['BPERMISOS'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BPERMISOS'];
        $nombre = $parametros[0];
        $nivel = $parametros[1];
        $permisos = $controlador->buscar($nombre, $nivel);
        $filtro = "Ultima búsqueda realizada: ";
        $filtro .= ($nombre) ? $nombre . ", " . $nivel : $nivel;
        $_SESSION['BPERMISOS'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $permisos = $controlador->listarConTope(20);
        $filtro = "Resumen inicial de permisos";
        $_SESSION['BPERMISOS'] = NULL;
    }
}

if (gettype($permisos[0]) == "resource") {
    $filas = "";
    $resource = $permisos[0];
    while ($permiso = sqlsrv_fetch_array($resource, SQLSRV_FETCH_ASSOC)) {
        if (($permiso['perfiles'] == 0) && ($permiso['hijos'] == 0)) {
            $operaciones = "
                <button class='btn btn-outline-warning editar' 
                    name='{$permiso['id']}' title='Editar'>
                    <i class='far fa-edit'></i></button>
                <button class='btn btn-outline-danger baja'
                    name='{$permiso['id']}' title='Borrar'>
                    <i class='fas fa-trash'></i></button>";
        } else {
            $operaciones = "<button class='btn btn-outline-warning editar' "
                    . "name='{$permiso['id']}' title='Editar'>"
                    . "<i class='far fa-edit'></i></button>";
        }
        $filas .= "
            <tr>
                <td>" . utf8_encode($permiso['titulo']) . "</td>
                <td>" . utf8_encode($permiso['padre']) . "</td>
                <td>{$permiso['descripcion']}</td>
                <td>{$permiso['perfiles']}</td>
                <td>{$permiso['hijos']}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>{$operaciones}</div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbPermisos" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Titulo</th>
                        <th>Padre</th>
                        <th>Descripción</th>
                        <th titke="Cantidad de roles asociados">Roles</th>
                        <th title="Cantidad de permisos asociados">Permisos</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $permisos[1];
    $mensaje .= ($permisos[0] == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($permisos, $mensaje);
}

$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
