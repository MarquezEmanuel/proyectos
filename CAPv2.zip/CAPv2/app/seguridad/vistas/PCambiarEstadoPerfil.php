<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

modelos\AutoCargador::cargarModulos();
session_start();

if (isset($_POST['mcepAccion'])) {
    $controlador = new controladores\ControladorPerfil();
    $id = $_POST['mcepIdPerfil'];
    $estado = ($_POST['mcepAccion'] == "ALTA") ? 'Activo' : 'Inactivo';
    $modificacion = $controlador->cambiarEstado($id, $estado);
    $resultado = controladores\ControladorHTML::getAlertaOperacion($modificacion[0], $modificacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = controladores\ControladorHTML::getAlertaOperacion(0, $mensaje);
}

echo $resultado;
