<?php

namespace modelos;

use app\principal\modelo\SQLServer;

class PerfilPermiso {

    /**
     * Realiza la eliminacion de la relacion que tiene un perfil con todos los
     * permisos asociados. Esto implica que el perfil indicado ya no poseera mas
     * permisos asociados. Este metodo hace la eliminacion de registros en 
     * seg_perfil_permiso.
     * @param integer $idPerfil Identificador del perfil.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function borrar($idPerfil) {
        if ($idPerfil) {
            $consulta = "DELETE FROM seg_perfil_permiso WHERE idPerfil = ?";
            return SQLServer::$instancia->borrar($consulta, array(&$idPerfil));
        }
        return array(0, "No se pudo hacer referencia al perfil");
    }

    /**
     * Crea una nueva relacion entre un perfil y multiple permisos. Permite que
     * a un determinado perfil se le asignen uno o mas permisos. Este metodo hace
     * la insercion de registros en seg_perfil_permiso.
     * @param integer $idPerfil Identificador del perfil.
     * @param array $permisos Arreglo con los identificadores de permisos.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function crear($idPerfil, $permisos) {
        if ($idPerfil && !empty($permisos)) {
            $registros = "";
            foreach ($permisos as $idPermiso) {
                $registros .= "({$idPerfil}, {$idPermiso}),";
            }
            $consulta = "INSERT INTO seg_perfil_permiso VALUES " . substr($registros, 0, -1);
            return SQLServer::instancia()->ejecutar($consulta);
        }
        return array(0, "No se recibieron los campos obligatorios");
    }

}
