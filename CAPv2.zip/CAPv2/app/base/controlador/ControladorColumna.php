<?php

namespace app\base\controlador;

use app\base\modelo\ColeccionColumnas as Columnas;

class ControladorColumna {

    /**
     * 
     * @param string $nombreBase Nombre de la base de datos.
     * @param string $nombreTabla Nombre de la tabla.
     * @param string $nombreCampo Nombre del campo.
     * @param string $nulos Si permite nulos o no.
     * @param string $tipo Tipo de dato.
     * @param string $maximo Cantidad maxima de caracteres.
     * @param string $descripcion Descripcion del campo.
     */
    public function buscar($nombreBase, $nombreTabla, $nombreCampo, $nulos, $tipo, $maximo, $descripcion) {
        $resultado = Columnas::buscar($base, $tabla, $nombre, $descripcion);
        $this->mensaje = Columnas::getMensaje();
        return $resultado;
    }

    public function modificar($id, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $base = new Columna($id, NULL, NULL, NULL, NULL, NULL, $descripcion);
            $modificacion = $base->modificar();
            $this->mensaje = $base->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar con la columna";
        return 1;
    }

    public function listarPorTabla($idTabla) {
        $resultado = Columnas::listarPorTabla($idTabla);
        $this->mensaje = Columnas::getMensaje();
        return $resultado;
    }

    public function listarUltimosActualizados() {
        $resultado = Columnas::listarUltimosActualizados();
        $this->mensaje = Columnas::getMensaje();
        return $resultado;
    }

}
