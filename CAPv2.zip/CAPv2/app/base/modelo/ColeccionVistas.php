<?php

namespace app\base\modelo;

use app\principal\modelo\SQLServer;

class ColeccionVistas {

    public static function buscar($base, $nombre, $tipo, $descripcion) {
        $top = (!$base && (!$nombre || strlen($nombre) <= 2) && !$tipo && !$descripcion) ? "TOP(5000)" : "";
        $consulta = "SELECT {$top} * FROM vwbas_vista WHERE bnombre LIKE ? AND vnombre LIKE ? AND vdescripcion LIKE ? AND vtipoConsulta = ?";
        $datos = array('%' . $base . '%', '%' . $nombre . '%', '%' . $descripcion . '%', &$tipo);
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        return $resultado;
    }

    public static function listarPorBase($idBase) {
        $consulta = "SELECT * FROM vwbas_vista WHERE bid = ?";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$idBase));
        return $resultado;
    }

    public static function listarConTope($tope) {
        $consulta = "SELECT TOP(?) * FROM vwbas_vista ORDER BY vfechaProceso DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array($tope));
        return $resultado;
    }

}
