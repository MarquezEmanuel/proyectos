<?php

namespace app\base\modelo;

use app\principal\modelo\SQLServer;

class ColeccionBasesDatosManual {

    public static function buscar($nombre, $collation, $estado) {
        $consulta = "SELECT * FROM vwbas_man_base WHERE nombre LIKE ? AND collation LIKE ? AND estado = ?";
        $datos = array("%{$nombre}%", "%{$collation}%", $estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    public static function buscarParaSeleccionar($nombre) {
        $consulta = "SELECT id, nombre FROM bas_man_base WHERE nombre LIKE ? AND estado = 'Activa' ORDER BY nombre";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombre}%"));
    }

    public static function buscarUltimasCreadas($top, $estado) {
        $consulta = "SELECT TOP(?) * FROM vwbas_man_base WHERE estado = ? ORDER BY fechaCreacion DESC";
        $datos = array(&$top, &$estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

}
