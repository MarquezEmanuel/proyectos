<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-database"></i> CREAR BASE DE DATOS</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formCrearBase" name="formCrearBase" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombre" id="nombre" 
                               placeholder="Nombre" required>
                    </div>
                    <label for="marca" class="col-sm-2 col-form-label">* Collation:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="marca" id="marca"
                               placeholder="Nombre de la marca" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="modelo" class="col-sm-2 col-form-label">* Estado:</label>
                    <div class="col">
                        <select class="form-control mb-2">
                            <option value="ONLINE">ONLINE</option>
                            <option value="OFFLINE">OFFLINE</option>
                        </select>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>
                <div class="form-row mt-4 mb-3">
                    <div class="col-2"><strong><p>DATOS DE SERVIDORES</p></strong></div>
                    <div class="col-10"><hr></div>
                </div>
                <div class="form-row">
                    <label for="servidor1" class="col-sm-2 col-form-label">* Servidor N° 1:</label>
                    <div class="col">
                        <select class="form-control mb-2" required></select>
                    </div>
                    <label class="col-sm-2 col-form-label">Fecha creación</label>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCreacion1" id="fechaCreacion1"
                               placeholder="Fecha de creación" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="servidor1" class="col-sm-2 col-form-label">Servidor N° 2:</label>
                    <div class="col">
                        <select class="form-control mb-2"></select>
                    </div>
                    <label class="col-sm-2 col-form-label">Fecha creación</label>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCreacion1" id="fechaCreacion1"
                               placeholder="Fecha de creación" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="servidor1" class="col-sm-2 col-form-label">Servidor N° 3:</label>
                    <div class="col">
                        <select class="form-control mb-2"></select>
                    </div>
                    <label class="col-sm-2 col-form-label">Fecha creación:</label>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCreacion1" id="fechaCreacion1"
                               placeholder="Fecha de creación" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="servidor1" class="col-sm-2 col-form-label">Servidor N° 4:</label>
                    <div class="col">
                        <select class="form-control mb-2"></select>
                    </div>
                    <label class="col-sm-2 col-form-label">Fecha creación:</label>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCreacion1" id="fechaCreacion1"
                               placeholder="Fecha de creación" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="servidor1" class="col-sm-2 col-form-label">Servidor N° 5:</label>
                    <div class="col">
                        <select class="form-control mb-2"></select>
                    </div>
                    <label class="col-sm-2 col-form-label">Fecha creación:</label>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCreacion1" id="fechaCreacion1"
                               placeholder="Fecha de creación" required>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-success"><i class="far fa-save"></i> GUARDAR</button>
                <a href="FBuscarFirewall.php">
                    <button type="button" class="btn btn-outline-info">
                        <i class="fas fa-search"></i> BUSCAR
                    </button>
                </a>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="../js/CrearFirewall.js"></script>