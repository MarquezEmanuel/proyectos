/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {

    realizarBusqueda();

    $('#formBuscarBase').submit(function (event) {
        event.preventDefault();
        $("#peticion").val("true");
        realizarBusqueda();
    });

    /* CARGA EL FORMULARIO DE CREACION CUANDO SE PRESIONA EL BOTON EN PANTALLA */

    $('#btnCrearBase').click(function () {
        $.ajax({
            type: "POST",
            url: "./FCrearBaseManual.php",
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html, body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });

    $('#seccionInferior').on('click', '.editar', function () {
        var id = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./FModificarBaseManual.php",
            data: "idBase=" + id,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });

    $('#seccionInferior').on('click', '.datos', function () {
        var id = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./FDetalleBaseManual.php",
            data: "idBase=" + id,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('#seccionInferior').on('click', '.baja', function () {
        var nombre = $(this).parents("tr").find("td").eq(0).html();
        $("#mcebTitulo").html("<i class='fas fa-trash'></i> CONFIRME LA BAJA DE LA BASE DE DATOS");
        $("#mcebEstado").val("Inactiva");
        $("#mcebIdBase").val($(this).attr("name"));
        $("#mcebNombre").val(nombre);
        $("#mcebTituloNombre").text(nombre + ": ");
        $("#ModalCambioEstadoBase").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('#seccionInferior').on('click', '.alta', function () {
        var nombre = $(this).parents("tr").find("td").eq(0).html();
        $("#mcebTitulo").html("<i class='fas fa-plus-circle'></i> CONFIRME LA BAJA DE LA BASE DE DATOS");
        $("#mcebEstado").val("Activa");
        $("#mcebIdBase").val($(this).attr("name"));
        $("#mcebNombre").val(nombre);
        $("#mcebTituloNombre").text(nombre + ": ");
        $("#ModalCambioEstadoBase").modal({backdrop: 'static', keyboard: false});
    });

    /* ENVIA LA OPERACION Y MUESTRA EL RESULTADO EN EL MODAL */

    $('#btnCambiarEstadoBase').click(function () {
        $.ajax({
            type: "POST",
            url: "./PCambiarEstadoBaseManual.php",
            data: $("#formCambiarEstadoBase").serialize(),
            success: function (data) {
                $('#mcebCuerpo').html(data);
                $('#btnCambiarEstadoBase').hide();
                $('#btnCancelarCambiarEstado').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#mcebCuerpo").html(div);
            }
        });
    });


});

function realizarBusqueda() {
    $.ajax({
        type: "POST",
        url: "./PBuscarBaseDatosManual.php",
        data: $("#formBuscarBase").serialize(),
        beforeSend: function () {
            $('#ModalCargando').modal({show: true, backdrop: 'static'});
        },
        success: function (data) {
            $('#seccionInferior').html(data);
            $('#tbBasesManual').dataTable({
                dom: 'Bfrtip',
                lengthChange: false,
                buttons: [{
                        extend: 'excelHtml5',
                        title: 'Bases de datos'
                    }
                ],
                language: {url: "../../../lib/JQuery/Spanish.json"}
            });
        },
        error: function (data) {
            console.log(data);
            var men = '<b>No se procesó la petición (Informe al administrador)</b>';
            var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
            $("#seccionInferior").html(div);
        },
        complete: function () {
            setTimeout(function () {
                $('#ModalCargando').modal('hide');
            }, 1000);
            $('html,body').animate({scrollTop: $("#seccionInferior").offset().top}, '1250');
        }
    });
}