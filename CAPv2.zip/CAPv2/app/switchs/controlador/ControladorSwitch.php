<?php

namespace app\switchs\controlador;

use app\switchs\modelos\Switchs;
use app\switchs\modelos\ColeccionSwitchs as Switches;
use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

class ControladorSwitch {

    public function buscar($nombre, $estado) {
        return Switches::buscar($nombre, $estado);
    }

    public function buscarUltimosCreados($top, $estado) {
        return Switches::buscarUltimosCreados($top, $estado);
    }

    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $switch = new Switchs($id, NULL, NULL, NULL, NULL, NULL, NULL, $estado);
            $resultado = $switch->cambiarEstado();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function crear($nombre, $modelo, $version, $sitio, $instalacion, $rti) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $switch = new Switchs(NULL, $nombre, $modelo, $version, $sitio, $instalacion, $rti);
            $resultado = $switch->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function consultar($nombre, $modelo, $instalacion, $sitio) {
        $resultado = Switches::consultar($nombre, $modelo, $instalacion, $sitio);
        return $resultado;
    }

    public function modificar($id, $nombre, $modelo, $version, $sitio, $instalacion, $rti) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $switch = new Switchs($id, $nombre, $modelo, $version, $sitio, $instalacion, $rti);
            $resultado = $switch->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Personal $personal Plataforma con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $personal) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "SWITCHS";
        $metodo = "ControladorSwitch::$funcion";
        $detalle = substr($personal->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
