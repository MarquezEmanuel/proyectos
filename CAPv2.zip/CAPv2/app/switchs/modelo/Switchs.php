<?php

namespace app\switchs\modelo;

use app\principal\modelo\SQLServer;
use app\instalacion\modelo\Instalacion;
use app\sitio\modelo\Sitio;
use app\proveedor\modelo\ColeccionProveedores as Proveedores;

class Switchs {

    private $id;
    private $nombre;
    private $modelo;
    private $version;
    private $instalacion;
    private $sitio;
    private $rti;
    private $descripcion;
    private $estado;
    private $visibilidad;
    private $fechaCreacion;
    private $fechaEdicion;
    private $proveedores;

    public function __construct($id = NULL, $nombre = NULL, $modelo = NULL, $version = NULL, $sitio = NULL, $instalacion = NULL, $rti = NULL, $descripcion = NULL, $estado = NULL, $visibilidad = NULL, $proveedores = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setModelo($modelo);
        $this->setVersion($version);
        $this->setInstalacion($instalacion);
        $this->setSitio($sitio);
        $this->setRti($rti);
        $this->setDescripcion($descripcion);
        $this->setEstado($estado);
        $this->setVisibilidad($visibilidad);
        $this->setProveedores($proveedores);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getModelo() {
        return utf8_encode($this->modelo);
    }

    public function getVersion() {
        return utf8_encode($this->version);
    }

    public function getInstalacion() {
        return $this->instalacion;
    }

    public function getSitio() {
        return $this->sitio;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getVisibilidad() {
        return $this->visibilidad;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function getProveedores() {
        return $this->proveedores;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = utf8_decode($nombre);
    }

    public function setModelo($modelo) {
        $this->modelo = utf8_decode($modelo);
    }

    public function setVersion($version) {
        $this->version = utf8_decode($version);
    }

    public function setInstalacion($instalacion) {
        $this->instalacion = $instalacion;
    }

    public function setSitio($sitio) {
        $this->sitio = $sitio;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = utf8_decode($descripcion);
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setVisibilidad($visibilidad) {
        $this->visibilidad = $visibilidad;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function setProveedores($proveedores) {
        $this->proveedores = $proveedores;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE swi_switch SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id=?";
            return SQLServer::instancia()->modificar($consulta, array(&$this->estado, &$this->id));
        }
        return array(0, "No se recibieron los campos obligatorios para cambiar estado de switch");
    }

    public function crear() {
        if ($this->nombre && $this->modelo && $this->version && $this->instalacion && $this->sitio && $this->descripcion) {
            $consulta = "INSERT INTO swi_switch OUTPUT INSERTED.id VALUES (?, ?, ?, ?, ?, 'Si', ?, 'Activo', 1, GETDATE(), NULL)";
            $datos = array(&$this->nombre, &$this->modelo, &$this->version, &$this->instalacion, &$this->sitio, &$this->descripcion);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            if ($resultado[0] == 2) {
                $this->id = $resultado[2];
                $rswitch = SwitchProveedor::crear($this->id, $this->proveedores);
                $resultado = ($rswitch[0] == 2) ? $resultado : $rswitch;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear switch");
    }

    public function modificar() {
        if ($this->nombre && $this->modelo && $this->version && $this->sitio && $this->instalacion && $this->rti) {
            $consulta = "UPDATE swi_switch SET nombre = ?, modelo = ?, version = ?, "
                    . " idInstalacion = ?, idSitio = ?, descripcion = ?, "
                    . " fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->nombre, &$this->modelo, &$this->version, &$this->instalacion, $this->sitio, &$this->descripcion, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            if ($resultado[0] == 2) {
                $actualizar = SwitchProveedor::actualizarProveedoresSwitch($this->id, $this->proveedores);
                $resultado = ($actualizar[0] == 2) ? $resultado : $actualizar;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para modificar switch");
    }

    public function modificarCGTI() {
        if ($this->id && $this->rti && $this->visibilidad) {
            $consulta = "UPDATE swi_switch SET rti = ?, nivelVisibilidad = ?, "
                    . "fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->rti, &$this->visibilidad, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para modificar switch");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM swi_switch WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->modelo = $fila['modelo'];
                $this->version = $fila['version'];
                $this->instalacion = $fila['idInstalacion'];
                $this->sitio = $fila['idSitio'];
                $this->rti = $fila['rti'];
                $this->descripcion = $fila['descripcion'];
                $this->estado = $fila['estado'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al switch para obtener datos");
    }

    public function obtenerInstalacion() {
        $instalacion = new Instalacion($this->instalacion);
        $resultado = $instalacion->obtener();
        $this->instalacion = ($resultado[0] == 2) ? $instalacion : NULL;
        return $resultado;
    }

    public function obtenerSitio() {
        $sitio = new Sitio($this->sitio);
        $resultado = $sitio->obtener();
        $this->sitio = ($resultado[0] == 2) ? $sitio : NULL;
        return $resultado;
    }

    public function obtenerProveedores() {
        $this->proveedores = NULL;
        $resultado = Proveedores::buscarProveedoresSwitch($this->id);
        if ($resultado[0] == 2) {
            $proveedores = $resultado[1];
            while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
                $this->proveedores[] = $proveedor;
            }
            $resultado[1] = ($this->proveedores) ? NULL : $resultado[1];
        }
        return $resultado;
    }

    public function toString() {
        $switch = ($this->id) ? "{{$this->id}," : "{0,";
        $switch .= ($this->nombre) ? "'{$this->getNombre()}'," : "'',";
        $switch .= ($this->modelo) ? "'{$this->getModelo()}'," : "'',";
        $switch .= ($this->version) ? "'{$this->getVersion()}'," : "'',";
        $switch .= ($this->instalacion && (gettype($this->instalacion) == "integer")) ? "{$this->instalacion}," : "0,";
        $switch .= ($this->sitio && (gettype($this->sitio) == "string")) ? "'{$this->sitio}'," : "'',";
        $switch .= ($this->rti) ? "'{$this->getRti()}'," : "'',";
        $switch .= ($this->estado) ? "'{$this->getEstado()}'," : "'',";
        $switch .= ($this->visibilidad) ? "{$this->visibilidad}}" : "0}";
        return $switch;
    }

}
