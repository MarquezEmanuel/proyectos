<?php

namespace app\servicio\controlador;

use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;
use app\servicio\modelo\Servicio;
use app\servicio\modelo\ColeccionServicios as Servicios;

class ControladorServicio {

    public function buscar($nombreCorto, $nombreLargo, $descripcion, $estado) {
        return Servicios::buscar($nombreCorto, $nombreLargo, $descripcion, $estado);
    }

    public function buscarEstadoActivo() {
        return Servicios::buscarEstadoActivo();
    }

    public function buscarUltimosCreados($top, $estado) {
        return Servicios::buscarUltimosCreados($top, $estado);
    }

    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $servicio = new Servicio($id, NULL, NULL, NULL, $estado);
            $resultado = $servicio->cambiarEstado();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "cambiarEstado", $servicio);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function crear($nombreCorto, $nombreLargo, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $servicio = new Servicio(NULL, $nombreCorto, $nombreLargo, $descripcion);
            $resultado = $servicio->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $servicio);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificar($id, $nombreCorto, $nombreLargo, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $servicio = new Servicio($id, $nombreCorto, $nombreLargo, $descripcion);
            $resultado = $servicio->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $servicio);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Servicio $servicio Servicio con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $servicio) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "SERVICIOS";
        $metodo = "ControladorServicio::$funcion";
        $detalle = substr($servicio->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
