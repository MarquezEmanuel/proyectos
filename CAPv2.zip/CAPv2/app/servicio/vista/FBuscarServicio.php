<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="fab fa-connectdevelop"></i> BUSCAR SERVICIO</h4>
                </div>
            </div>
            <div id="seccionCentral" class="mt-3 mb-4">
                <form id="formBuscarServicio" name="formBuscarServicio" method="POST">
                    <input type="hidden" name="peticion" id="peticion">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="nombreCorto" 
                                       title="Campo no obligatorio" 
                                       class="col-2 col-form-label">Nombre corto:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreCorto" id="nombreCorto" 
                                           title="Nombre corto del servicio"
                                           maxlength="20"
                                           placeholder="Nombre corto">
                                </div>
                                <label for="nombreLargo" 
                                       title="Campo no obligatorio" 
                                       class="col-2 col-form-label">Nombre largo:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreLargo" id="nombreLargo" 
                                           title="Nombre largo del servicio"
                                           maxlength="50"
                                           placeholder="Nombre largo">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="descripcion" 
                                       title="Campo no obligatorio" 
                                       class="col-2 col-form-label">Descripción:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="descripcion" id="descripcion" 
                                           title="Descripción del servicio"
                                           maxlength="30"
                                           placeholder="Decripción">
                                </div>
                                <label for="estado" class="col-2 col-form-label">* Estado:</label>
                                <div class="col">
                                    <select id="estado" name="estado" class="form-control mb-2" required>
                                        <option value="Activo">Activo</option>
                                        <option value="Inactivo">Inactivo</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success" 
                                    id="btnBuscarServicio" name="btnBuscarServicio">
                                <i class="fas fa-search"></i>  BUSCAR
                            </button>
                            <button type="button" class="btn btn-outline-info" 
                                    id="btnCrearServicio" name="btnCrearServicio">
                                <i class="fas fa-plus"></i> CREAR
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <br>
            <div id="seccionInferior" class="mt-4 mb-3"></div>
        </div>
        <div class="modal fade" id="ModalCambioEstadoServicio" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg border-azul-clasico">
                <div class="modal-content">
                    <div class="modal-header bg-azul-clasico text-white">
                        <h4 class="modal-title text-center" id="mcesTitulo"></h4>
                    </div>
                    <div class="modal-body" id="mcesCuerpo">
                        <form id="formCambiarEstadoServicio" name="formCambiarEstadoServicio" method="POST">
                            <input type="hidden" name="mcesAccion" id="mcesAccion">
                            <input type="hidden" name="mcesIdServicio" id="mcesIdServicio">
                            <div class="form-row">
                                <b><p id="mcesNombre" name="mcesNombre"></p></b>
                                <p>&nbsp;Presione <b>GUARDAR</b> para efectuar la operación.</p>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success"
                                name="btnCambiarEstadoServicio" id="btnCambiarEstadoServicio">
                            <i class="far fa-save"></i> GUARDAR</button>
                        <button type="button" class="btn btn-outline-secondary" 
                                name="btnCancelarCambiarEstado" id="btnCancelarCambiarEstado"
                                data-dismiss="modal">Cancelar</button>
                        <input type='submit' class='btn btn-outline-secondary' 
                               style="display: none;"
                               name="btnRefrescarPantalla" id="btnRefrescarPantalla" value='Aceptar'>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="ModalDatosServicio" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg border-azul-clasico">
                <div class="modal-content">
                    <div class="modal-header bg-azul-clasico text-white">
                        <h4 class="modal-title text-center"><i class='fas fa-info-circle'></i> INFORMACIÓN BÁSICA</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-row">
                            <label for="mdsNombreCorto" 
                                   class="col-sm-3 col-form-label">Nombre corto:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       id="mdsNombreCorto" name="mdsNombreCorto" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <label for="mdsNombreLargo" 
                                   class="col-sm-3 col-form-label">Nombre largo:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       id="mdsNombreLargo" name="mdsNombreLargo" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <label for="mdsDescripcion" 
                                   class="col-sm-3 col-form-label">Descripción:</label>
                            <div class="col">
                                <textarea class="form-control mb-2" rows="5"
                                          id="mdsDescripcion" name="mdsDescripcion" readonly></textarea>
                            </div>
                        </div>
                        <div class="form-row">
                            <label for="mdsFechaCreacion" 
                                   class="col-sm-3 col-form-label">Fecha creación:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       id="mdsFechaCreacion" name="mdsFechaCreacion" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <label for="mdsFechaEdicion" 
                                   class="col-sm-3 col-form-label">Fecha edición:</label>
                            <div class="col">
                                <input type="text" class="form-control mb-2" 
                                       id="mdsFechaEdicion" name="mdsFechaEdicion" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type='submit' class='btn btn-outline-secondary' data-dismiss="modal" value='Aceptar'>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/BuscarServicio.js"></script>
