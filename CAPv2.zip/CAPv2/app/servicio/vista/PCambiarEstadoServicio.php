<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\servicio\controlador\ControladorServicio;
use app\utilidad\modelo\GeneradorHTML;

AutoCargador::cargarModulos();

session_start();

if (isset($_POST['mcesAccion'])) {
    $controlador = new ControladorServicio();
    $id = $_POST['mcesIdServicio'];
    $estado = ($_POST['mcesAccion'] == "ALTA") ? 'Activo' : 'Inactivo';
    $modificacion = $controlador->cambiarEstado($id, $estado);
    $mensaje = $modificacion[1];
    $exito = ($modificacion[0] == 2) ? TRUE : FALSE;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

echo $resultado;
