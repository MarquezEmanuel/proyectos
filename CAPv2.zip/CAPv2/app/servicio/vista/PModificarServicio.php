<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\servicio\controlador\ControladorServicio;
use app\utilidad\modelo\GeneradorHTML;

AutoCargador::cargarModulos();

session_start();

$exito = FALSE;
if ($_POST['idServicio'] && $_POST['sigla'] && $_POST['nombre']) {
    $controlador = new ControladorServicio();
    $id = $_POST['idServicio'];
    $sigla = $_POST['sigla'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $modificacion = $controlador->modificar($id, $sigla, $nombre, $descripcion);
    $mensaje = $modificacion[1];
    $exito = ($modificacion[0] == 2) ? TRUE : FALSE;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
