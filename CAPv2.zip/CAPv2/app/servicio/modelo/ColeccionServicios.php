<?php

namespace app\servicio\modelo;

use app\principal\modelo\SQLServer;

/**
 * Mapea con la tabla de servicios.
 * 
 * @package app\servicio\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ColeccionServicios {

    /**
     * Buscar servicios a partir del nombre corto, nombre largo, descripcion y 
     * estado. De la consulta se obtienen todos los datos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombreCorto Nombre corto o parte del nombre (LIKE).
     * @param string $nombreLargo Nombre largo o parte del nombre (LIKE).
     * @param string $descripcion Descripcion del servicio (LIKE).
     * @param string $estado Estado del servicio (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscar($nombreCorto, $nombreLargo, $descripcion, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM srv_servicio WHERE nombreCorto LIKE ? AND "
                    . "nombreLargo LIKE ? AND descripcion LIKE ? AND estado = ?";
            $datos = array("%{$nombreCorto}%", "%{$nombreLargo}%", "%{$descripcion}%", &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar servicios");
    }

    /**
     * Buscar servicios en estado activo ordenados por nombre. De la consulta se 
     * obtienen el identificador y nombre. El objetivo del metodo es obtener la
     * informacion necesaria para seleccionar y relacionar multiples registros.
     * @see SQLServer::instancia()->seleccionar
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarEstadoActivo() {
        $consulta = "SELECT id, nombre FROM srv_servicio "
                . "WHERE estado = 'Activo' ORDER BY nombre ASC";
        return SQLServer::instancia()->seleccionar($consulta, array());
    }

    /**
     * Buscar los servicios de un determinado proveedor. De la consulta se obtienen 
     * todos los datos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $idProveedor Identificador del proveedor (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarServiciosProveedor($idProveedor) {
        if ($idProveedor > 0) {
            $consulta = "SELECT ser.* FROM pro_proveedor_servicio rel "
                    . "INNER JOIN srv_servicio ser ON ser.id = rel.idServicio "
                    . "WHERE rel.idProveedor = ?";
            $datos = array(&$idProveedor);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se pudo hacer referencia al proveedor de servicios");
    }

    /**
     * Buscar servicios ordenados por fecha de creacion descendente con un tope
     * de registros y un estado. De la consulta se obtienen todos los datos de 
     * la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $top Cantidad maxima de registros a seleccionar.
     * @param string $estado Estado del servicio (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarUltimosCreados($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM srv_servicio WHERE estado = ? ORDER BY fechaCreacion DESC";
            $datos = array(&$top, &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar servicios");
    }

}
