<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\proveedor\controlador\ControladorResponsable;

AutoCargador::cargarModulos();
session_start();

if (isset($_POST['mcerAccion'])) {
    $controlador = new ControladorResponsable();
    $id = $_POST['mcerIdResponsable'];
    $estado = ($_POST['mcerAccion'] == "ALTA") ? "Activo" : "Inactivo";
    $modificacion = $controlador->cambiarEstado($id, $estado);
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $modificacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

echo $resultado;
