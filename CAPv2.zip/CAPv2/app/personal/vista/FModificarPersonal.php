<?php
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\personal\modelo\Personal;

AutoCargador::cargarModulos();
session_start();

$boton = "";
if ($_POST['idPersonal']) {
    $id = $_POST['idPersonal'];
    $personal = new Personal($id);
    $resultado = $personal->obtener();
    if ($resultado[0] == 2) {

        $nombreCorto = $personal->getNombreCorto();
        $nombreLargo = $personal->getNombreLargo();
        $descripcion = $personal->getDescripcion();
        $getDepartamento = $personal->obtenerDepartamento();

        /* BOTON QUE HABILITA LA MODIFICACION DEL PERSONAL */

        $boton = '<button type="submit" class="btn btn-success" 
                          id="btnModificarPersonal" name="btnModificarPersonal" disabled>
                          <i class="far fa-save"></i> GUARDAR
                  </button>';

        /* CARGA LOS DATOS DEL DEPARTAMENTO */

        if ($getDepartamento[0] == 2) {
            $departamento = $personal->getDepartamento();
            $idDepartamento = $departamento->getId();
            $nombreDepartamento = $departamento->getNombre();
            $opcionDepartamento = "
                <select class='form-control mb-2' 
                        id='departamento' name='departamento'>
                        <option value='{$idDepartamento}'>{$nombreDepartamento}</option>
                </select>";
        } else {
            $boton = '';
            $opcionSucursal = GeneradorHTML::getAlertaOperacion($getDepartamento[0], $getDepartamento[1]);
        }

        $cuerpo = '
            <input type="hidden" name="idPersonal" id="idPersonal" value="' . $personal->getId() . '">
            <div class="form-row">
                <label for="sigla" class="col-sm-2 col-form-label">* Nombre corto:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombreCorto" id="nombreCorto" maxlength="20"
                           value="' . $nombreCorto . '"
                           placeholder="Nombre corto" required>
                </div>
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre largo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombreLargo" id="nombreLargo" maxlength="50"
                           value="' . $nombreLargo . '"
                           placeholder="Nombre largo" required>
                </div>
            </div>
            <div class="form-row">
                <label for="departamento" class="col-sm-2 col-form-label">* Departamento:</label>
                <div class="col">' . $opcionDepartamento . '</div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col"></div>
            </div>
            <div class="form-row">
                <label for="descripcion" class="col-sm-2 col-form-label">* Descripcion:</label>
                <div class="col">
                    <textarea class="form-control mb-2" 
                              id="descripcion" name="descripcion"
                              maxlength="500"
                              placeholder="Descripcion" required>' . $descripcion . '</textarea>
                </div>
            </div>';
    } else {
        $mensaje = $personal->getId();
        $cuerpo = ControladorHTML::getAlertaOperacion($resultado, $mensaje);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = ControladorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-users"></i> MODIFICAR PERSONAL</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarPersonal" name="formModificarPersonal" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <a href="FBuscarPersonal.php">
                    <button type="button" class="btn btn-outline-info">
                        <i class="fas fa-search"></i> BUSCAR
                    </button>
                </a>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="../js/ModificarPersonal.js"></script>
