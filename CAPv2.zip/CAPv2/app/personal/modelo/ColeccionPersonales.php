<?php

namespace app\personal\modelo;

use app\principal\modelo\SQLServer;

class ColeccionPersonales {

    public static function buscar($nombrePersonal, $nombreDepartamento, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM vwper_personal WHERE nombreLargoPersonal LIKE ? AND "
                    . "nombreDepartamento LIKE ? AND estadoPersonal = ?";
            $datos = array("%{$nombrePersonal}%", "%{$nombreDepartamento}%", $estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar personales");
    }

    public static function buscarUltimosCreados($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM vwper_personal "
                    . "WHERE estadoPersonal = ? "
                    . "ORDER BY fechaCreacionPersonal DESC";
            return SQLServer::instancia()->seleccionar($consulta, array(&$top, &$estado));
        }
        return array(0, "No se recibieron los campos obligatorios para consultar personales");
    }

}
