<?php

namespace app\mapper;

interface Mapper {

    public function borrar($objeto);

    public function buscarPorIdentificador($id);

    public function crear();

    public function modificar();
}
