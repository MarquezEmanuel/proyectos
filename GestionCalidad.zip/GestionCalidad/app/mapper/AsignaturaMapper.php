<?php

namespace app\mapper;

use app\dominio\Asignatura as Asignatura;
use app\principal\modelos\Conexion as Conexion;

class AsignaturaMapper implements Mapper {

    public function borrar($objeto) {
        if ($objeto instanceof Asignatura) {
            $id = $objeto->getId();
            $consulta = "DELETE FROM asignatura WHERE id = {$id}";
            $resultado = Conexion::getInstancia()->borrar($consulta);
            return $resultado;
        }
        return array(0, "No se recibió una asignatura");
    }

    public function buscarPorIdentificador($objeto) {
        if ($objeto instanceof Asignatura) {
            if (!isset($objeto->getId())) {
                return array(1, "No se pudo hacer referencia a la asignatura");
            }
            $id = $objeto->getId();
            $consulta = "SELECT * FROM asignatura WHERE id = {$id}";
            $resultado = Conexion::getInstancia()->borrar($consulta);
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $objeto->setNombre($fila['nombre']);
                return array(2, "Se obtuvo la información de la asignatura");
            }
            return $resultado;
        }
        return array(0, "No se recibió una asignatura");
    }

    public function crear($objeto) {
        if ($objeto instanceof Asignatura) {
            if (!isset($objeto->getNombre())) {
                return array(1, "El nombre de asignatura es un campo obligatorio");
            }
            $nombre = $objeto->getNombre();
            $consulta = "INSERT INTO asignatura VALUES (NULL, {$nombre})";
            $resultado = Conexion::getInstancia()->borrar($consulta);
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $objeto->setNombre($fila['nombre']);
                return array(2, "Se obtuvo la información de la asignatura");
            }
            return $resultado;
        }
        return array(0, "No se recibió una asignatura");
    }

    public function modificar($objeto) {
        if ($objeto instanceof Asignatura) {
            
        }
        return array(0, "No se recibió una asignatura");
    }

}
