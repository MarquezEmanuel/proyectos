<?php

namespace app\principal\modelos;

class AutoCargador {

    public static function cargarModulos() {
        spl_autoload_register(function($clase) {
            $ruta = Constantes::APP . "\\$clase.php";
            if (file_exists($ruta)) {
                require_once $ruta;
            }
        });
    }

}
