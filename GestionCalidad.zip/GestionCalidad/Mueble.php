<?php

/* Inicio código fuente de la clase */

class Mueble {

// Todos los atributos son numéricos que admiten decimales
    private $medida;
    private $largo;
    private $ancho;

    public function __construct() {
        ;
    }

    function setMedida() {
        $this->medida = $this->largo * $this->ancho;
        echo "<br>".$this->medida;
    }

    function setLargo($largo_) {
        $this->largo = $largo_;
    }

    function setAncho($ancho_) {
        $this->ancho = $ancho_;
    }

}

/* Fin código fuente de la clase */

