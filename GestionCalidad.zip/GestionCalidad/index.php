<?php

include_once './Mueble.php';

/* Ejecuciones */

/* Escenario 1 */
$Mesa = new Mueble();
$Mesa->setMedida();

/* Escenario 2 */
$Silla = new Mueble();
$Silla->setLargo(2);
$Silla->setAncho("2 metros");
$Silla->setMedida();

/* Escenario 3 */
$Alacena = new Mueble();
$Alacena->setLargo("0.9");
$Alacena->setAncho("2.4");
$Alacena->setMedida();
/* Fin pruebas */