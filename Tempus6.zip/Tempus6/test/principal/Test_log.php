<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\Log as Log;
use modelos\AutoCargador as Cargador;

Cargador::cargarModulos();

Log::guardarError("PRUEBA GUARDAR UN ERROR");

