<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\Configuracion as Configuracion;
use modelos\AutoCargador as Cargador;

Cargador::cargarModulos();

$configuracion = new Configuracion();
$leido = $configuracion->leerConfiguracion();
if ($leido) {
    echo "<br>HOST: " . $configuracion->getHost();
    echo "<br>BASE: " . $configuracion->getBaseDatos();
    echo "<br>USER: " . $configuracion->getUsuario();
    echo "<br>PASS: " . $configuracion->getPassword();
} else {
    echo "Configuracion no leida";
}

