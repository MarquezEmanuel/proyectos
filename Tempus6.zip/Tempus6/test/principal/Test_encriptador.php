<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\Encriptador as Encriptador;
use modelos\AutoCargador as Cargador;

Cargador::cargarModulos();

$encriptador = new Encriptador();

$clave = "tempus";
$host = $encriptador->encriptar("localhost", $clave);
$base = $encriptador->encriptar("tempus", $clave);
$user = $encriptador->encriptar("root", $clave);
$pass = $encriptador->encriptar("", $clave);

$dhost = $encriptador->desencriptar("Q0hRZ2lNN3VGc0ZhY29yOVlKT3poUT09OjrK+vkGtCTocWvcplomDv/e", $clave);
$dbase = $encriptador->desencriptar("N1BCcndTa0EyQ1FobmpDS256M2syUT09OjpvTJqCBLUd00w/RPDfedDs", $clave);
$duser = $encriptador->desencriptar("cHRIemd5UWFSSmVwZURzZ0RNMnFHQT09OjpOPYi2sd4DTDfCSqLQPs1c", $clave);
$dpass = $encriptador->desencriptar("REJoSk9FdW5OR00rdW93OVl3UTlxQT09OjoQa9Qt1oy5iDouuK5ZVp+t", $clave);

echo "<br> HOST: " . $host . " " . $dhost;
echo "<br> BASE: " . $base . " " . $dbase;
echo "<br> USER: " . $user . " " . $duser;
echo "<br> PASS: " . $pass . " " . $dpass;
