<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\Conexion as MYSQL;
use modelos\AutoCargador as Cargador;

Cargador::cargarModulos();

$nombre = "In the sky";
$consulta = "INSERT INTO docente (iddocente, nombre) VALUES (NULL, '$nombre')";
$resultado = MYSQL::getInstancia()->insertar($consulta);
echo "<br>RESULTADO : " . $resultado[0] . " " . $resultado[1] . " " . $resultado[2];
