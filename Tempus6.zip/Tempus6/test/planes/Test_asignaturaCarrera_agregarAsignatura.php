<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use principal\modelos\AutoCargador as Cargador;
use planes\modelos\AsignaturaCarrera as AsignaturaCarrera;
use asignaturas\modelos\Asignatura as Asignatura;

Cargador::cargarModulos();

$asignatura1 = new Asignatura(182);
$asignatura2 = new Asignatura(178);
$asignatura3 = new Asignatura(177);

$ac1 = new AsignaturaCarrera(99, $asignatura1, 1);
$ac2 = new AsignaturaCarrera(99, $asignatura2, 2);
$ac3 = new AsignaturaCarrera(99, $asignatura3, 3);

$res1 = $ac1->agregarAsignatura();
$res2 = $ac2->agregarAsignatura();
$res3 = $ac3->agregarAsignatura();

var_dump($res1);
var_dump($res2);
var_dump($res3);
