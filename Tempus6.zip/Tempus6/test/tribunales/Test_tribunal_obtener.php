<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\AutoCargador as Cargador;
use modelos\Tribunal as Tribunal;

Cargador::cargarModulos();

$id = 8;
$tribunal = new Tribunal($id);
$resultado = $tribunal->obtener();

if ($resultado[0] == 2) {
    $presidente = $tribunal->getPresidente();
    $vocal1 = $tribunal->getVocalPrimero();
    $vocal2 = $tribunal->getVocalSegundo();
    $suplente = $tribunal->getSuplente();

    echo "<br>" . $resultado[1];
    echo "<br> Identificador: " . $tribunal->getIdTribunal();
    echo "<br> Presidente: " . $presidente->getIdDocente() . " " . $presidente->getNombre();
    echo "<br> Vocal 1: " . $vocal1->getIdDocente() . " " . $vocal1->getNombre();
    if ($vocal2) {
        echo "<br> Vocal 2: " . $vocal2->getIdDocente() . " " . $vocal2->getNombre();
        if ($suplente) {
            echo "<br> Suplente: " . $suplente->getIdDocente() . " " . $suplente->getNombre();
        }
    }
} else {
    echo "<br>" . $resultado[1];
}
