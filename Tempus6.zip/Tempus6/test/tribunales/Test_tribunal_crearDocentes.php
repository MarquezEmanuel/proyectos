<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use principal\modelos\AutoCargador as Cargador;
use docentes\modelos\Docente as Docente;
use mesas\modelos\Tribunal as Tribunal;

Cargador::cargarModulos();


$presidente = new Docente(NULL, 'Emanuel Benjamin');
$vocal1 = new Docente(NULL, 'Benjamin emanuel');
$vocal2 = new Docente(NULL, 'Marcos Carlos');
$suplente = new Docente(NULL, 'Carlos Marcos');

$tribunal = new Tribunal(NULL, $presidente, $vocal1, $vocal2, $suplente);

$resultado = $tribunal->crearDocentes();
if ($resultado) {
    echo "<br> SE CREARON LOS DOCENTES";
    echo "<br>" . $presidente->getIdDocente();
    echo "<br>" . $vocal1->getIdDocente();

}