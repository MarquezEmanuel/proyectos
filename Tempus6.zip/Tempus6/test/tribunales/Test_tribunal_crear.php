<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use principal\modelos\AutoCargador as Cargador;
use docentes\modelos\Docente as Docente;
use mesas\modelos\Tribunal as Tribunal;

Cargador::cargarModulos();

$puesto1 = new Docente(NULL, 'Emanuel Marquez PR');
$puesto2 = new Docente(NULL, 'Emanuel Marquez VP');
$puesto3 = NULL;
$puesto4 = new Docente(NULL, 'Emanuel Marquez SU');

$tribunal = new Tribunal(NULL, $puesto1, $puesto2, $puesto3, $puesto4);
$resultado = $tribunal->crear();

echo '<br> [' . (int) $resultado[0] . "] " . $resultado[1] . "<br>";
