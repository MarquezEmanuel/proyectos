<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use principal\modelos\AutoCargador as Cargador;
use mesas\modelos\MesasExamen as MesasExamen;

Cargador::cargarModulos();
