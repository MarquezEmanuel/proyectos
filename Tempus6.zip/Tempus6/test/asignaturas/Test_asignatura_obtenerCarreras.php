<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use principal\modelos\AutoCargador as Cargador;
use asignaturas\modelos\Asignatura as Asignatura;

Cargador::cargarModulos();

$id = 163;
$asignatura = new Asignatura($id);
$resultado = $asignatura->obtenerCarreras();

echo '<br> [' . (int) $resultado[0] . "] " . $resultado[1] . "<br>";

echo "Cantidad de carreras: " . count($asignatura->getCarreras());
