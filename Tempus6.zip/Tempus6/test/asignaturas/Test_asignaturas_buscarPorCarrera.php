<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\AutoCargador as Cargador;
use modelos\Asignaturas as Asignaturas;

Cargador::cargarModulos();

$codigo01 = -12;
$nombre01 = "A";
$pertenece01 = true;

$codigo02 = 16;
$nombre02 = "A";
$pertenece02 = true;

$codigo03 = 72;
$nombre03 = "De";
$pertenece03 = false;

$resultado01 = Asignaturas::buscarPorCarrera($codigo01, $nombre01, $pertenece01);
echo "<br><br> RESULTADO [{$codigo01}, {$nombre01}, {$pertenece01}] -- {$resultado01[0]} " . gettype($resultado01[1]);
if ($resultado01[0] == 2) {
    foreach ($resultado01[1] as $fila) {
        echo "<br>{$fila["idasignatura"]} : {$fila["nombre"]}";
    }
} else {
    echo "<br>{$resultado01[1]}";
}

$resultado02 = Asignaturas::buscarPorCarrera($codigo02, $nombre02, $pertenece02);
echo "<br><br> RESULTADO [{$codigo02}, {$nombre02}, {$pertenece02}] -- {$resultado02[0]} " . gettype($resultado02[1]);
if ($resultado02[0] == 2) {
    foreach ($resultado02[1] as $fila) {
        echo "<br>{$fila["idasignatura"]} : {$fila["nombre"]}";
    }
} else {
    echo "<br>{$resultado02[1]}";
}

$resultado03 = Asignaturas::buscarPorCarrera($codigo03, $nombre03, $pertenece03);
echo "<br><br> RESULTADO [{$codigo03}, {$nombre03}, {$pertenece03}] -- {$resultado03[0]} " . gettype($resultado03[1]);
if ($resultado03[0] == 2) {
    foreach ($resultado03[1] as $fila) {
        echo "<br>{$fila["idasignatura"]} : {$fila["nombre"]}";
    }
} else {
    echo "<br>{$resultado03[1]}";
}