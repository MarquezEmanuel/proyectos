<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use principal\modelos\AutoCargador as Cargador;
use asignaturas\modelos\Asignatura as Asignatura;

Cargador::cargarModulos();

$id = NULL;
$nombre = 'Programación logica 9';
$asignatura = new Asignatura($id, $nombre);
$resultado = $asignatura->crear();

echo '<br> [' . (int) $resultado[0] . "] " . $resultado[1] . "<br>";
if ($resultado[0] > 0) {
    echo '<br>Identificador: ' . $asignatura->getIdAsignatura();
    echo '<br>Nombre: ' . $asignatura->getNombre();
}

