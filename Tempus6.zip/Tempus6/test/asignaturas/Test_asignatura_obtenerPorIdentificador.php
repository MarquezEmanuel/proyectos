<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use principal\modelos\AutoCargador as Cargador;
use asignaturas\modelos\Asignatura as Asignatura;

Cargador::cargarModulos();

$id = 178;
$asignatura = new Asignatura($id);
$resultado = $asignatura->obtenerPorIdentificador();

echo '<br> [' . (int) $resultado[0] . "] " . $resultado[1] . "<br>";
if ($resultado[0] == 2) {
    echo '<br>Identificador: ' . $asignatura->getIdAsignatura();
    echo '<br>Nombre: ' . $asignatura->getNombre();
}
