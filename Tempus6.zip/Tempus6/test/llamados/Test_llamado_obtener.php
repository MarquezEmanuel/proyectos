<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\AutoCargador as Cargador;
use modelos\Llamado as Llamado;

Cargador::cargarModulos();

$id = 9;
$llamado = new Llamado($id);
$resultado = $llamado->obtener();

if ($resultado[0] == 2) {
    $aula = $llamado->getAula();
    echo "<br>" . $resultado[1];
    echo "<br> Identificador: " . $llamado->getIdLlamado();
    echo "<br> Fecha: " . $llamado->getFecha();
    echo "<br> Hora: " . $llamado->getHora();
    if ($aula) {
        echo "<br> Aula Identificador: " . $aula->getIdAula();
        echo "<br> Aula Sector: " . $aula->getSector();
        echo "<br> Aula Nombre: " . $aula->getNombre();
    }
    echo "<br> Fecha edicion: " . $llamado->getFechaEdicion();
} else {
    echo "<br>" . $resultado[1];
}
