<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use aulas\modelos\Aula as Aula;
use principal\modelos\AutoCargador as Cargador;
use mesas\modelos\Llamado as Llamado;

Cargador::cargarModulos();

$id = NULL;
$fecha = '2020-03-06';
$hora = '10:46';
$aula = new Aula(NULL, 'C', 'Cadib');
$llamado = new Llamado($id, $fecha, $hora, $aula);
$resultado = $llamado->crear();

echo "<br>" . $resultado[1] . "<br>";
if ($resultado[0] == 2) {
    echo "<br>Identificador: " . $llamado->getIdLlamado();
    echo "<br>Fecha: " . $llamado->getFecha() . " " . $llamado->getFecha("DDMMAAAA");
    echo "<br>Hora: " . $llamado->getHora();
    if ($llamado->getAula()) {
        $aula = $llamado->getAula();
        echo "<br>Aula Identificador: " . $aula->getIdAula();
        echo "<br>Aula Sector: " . $aula->getSector();
        echo "<br>Aula Nombre: " . $aula->getNombre();
    }
}

