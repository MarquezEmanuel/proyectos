<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use principal\modelos\AutoCargador as Cargador;
use aulas\modelos\Aula as Aula;

Cargador::cargarModulos();

$id = NULL;
$sector = 'B';
$nombre = 'CADIV';
$aula = new Aula($id, $sector, $nombre);
$resultado = $aula->crear();

echo '<br> [' . (int) $resultado[0] . "] " . $resultado[1] . "<br>";
if ($resultado[0] > 0) {
    echo '<br>Identificador: ' . $aula->getIdAula();
    echo '<br>Sector: ' . $aula->getSector();
    echo '<br>Nombre: ' . $aula->getNombre();
}