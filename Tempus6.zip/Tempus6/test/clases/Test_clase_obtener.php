<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\AutoCargador as Cargador;
use modelos\Clase as Clase;

Cargador::cargarModulos();

$id = 27;
$clase = new Clase($id);
$resultado = $clase->obtenerPorIdentificador();

if ($resultado[0] == 2) {
    $aula = $clase->getAula();
    echo "<br>" . $resultado[1];
    echo "<br> Identificador: " . $clase->getId();
    echo "<br> Dia: " . $clase->getDia("NUMERO") . " " . $clase->getDia("NOMBRE");
    echo "<br> Inicio: " . $clase->getHoraInicio("HHMMSS") . " " . $clase->getHoraInicio("HHMM");
    echo "<br> Fin: " . $clase->getHoraFin("HHMMSS") . " " . $clase->getHoraFin("HHMM");
    if ($aula) {
        echo "<br> Aula Identificador: " . $aula->getIdAula();
        echo "<br> Aula Sector: " . $aula->getSector();
        echo "<br> Aula Nombre: " . $aula->getNombre();
    }
    echo "<br> Edicion: " . $clase->getFechaEdicion();
} else {
    echo "<br>" . $resultado[1];
}



