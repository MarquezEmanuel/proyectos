<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$expresion = "/^[a-záéíóúñ0-9,. ]{0,60}$/";

$caso01 = "";
$caso02 = "GESTIÓN";
$caso03 = "Análisis Matemático 2";
$caso04 = "'Análisis'";
$caso05 = "%gestion%";

echo mb_strtolower($caso02);
echo preg_match($expresion, $caso01) ? "<br>SI CUMPLE -- [$caso01]" : "<br>NO CUMPLE -- [$caso01]";
echo preg_match($expresion, mb_strtolower($caso02)) ? "<br>SI CUMPLE -- [$caso02]" : "<br>NO CUMPLE -- [$caso02]";
echo preg_match($expresion, mb_strtolower($caso03)) ? "<br>SI CUMPLE -- [$caso03]" : "<br>NO CUMPLE -- [$caso03]";
echo preg_match($expresion, mb_strtolower($caso04)) ? "<br>SI CUMPLE -- [$caso04]" : "<br>NO CUMPLE -- [$caso04]";
echo preg_match($expresion, mb_strtolower($caso05)) ? "<br>SI CUMPLE -- [$caso05]" : "<br>NO CUMPLE -- [$caso05]";
