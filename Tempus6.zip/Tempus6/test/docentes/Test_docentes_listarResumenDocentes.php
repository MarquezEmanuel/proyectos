<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\AutoCargador as Cargador;
use modelos\Docentes as Docentes;

Cargador::cargarModulos();

$caso01 = -10;
$caso02 = 23;

$resultado01 = Docentes::listarResumenDocentes($caso01);
$resultado02 = Docentes::listarResumenDocentes($caso02);

echo "<br><br> RESULTADO [{$caso01}] -- {$resultado01[0]} " . gettype($resultado01[1]);
if ($resultado01[0] == 2) {
    foreach ($resultado01[1] as $fila) {
        echo "<br>{$fila["iddocente"]} : {$fila["nombre"]}";
    }
} else {
    echo "<br>{$resultado01[1]}";
}

echo "<br><br> RESULTADO [{$caso02}] -- {$resultado02[0]} " . gettype($resultado02[1]);
if ($resultado02[0] == 2) {
    foreach ($resultado02[1] as $fila) {
        echo "<br>{$fila["iddocente"]} : {$fila["nombre"]}";
    }
} else {
    echo "<br>{$resultado02[1]}";
}

