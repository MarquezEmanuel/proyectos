<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\AutoCargador as Cargador;
use modelos\Docentes as Docentes;

Cargador::cargarModulos();

$caso01 = "";
$caso02 = "Osi";
$caso03 = "'a'";

$resultado01 = Docentes::buscar($caso01);
$resultado02 = Docentes::buscar($caso02);
$resultado03 = Docentes::buscar($caso03);

echo "<br><br> RESULTADO [{$caso01}] -- {$resultado01[0]} " . gettype($resultado01[1]);
if ($resultado01[0] == 2) {
    foreach ($resultado01[1] as $fila) {
        echo "<br>{$fila["iddocente"]} : {$fila["nombre"]}";
    }
} else {
    echo "<br>{$resultado01[1]}";
}

echo "<br><br> RESULTADO [{$caso02}] -- {$resultado02[0]} " . gettype($resultado02[1]);
if ($resultado02[0] == 2) {
    foreach ($resultado02[1] as $fila) {
        echo "<br>{$fila["iddocente"]} : {$fila["nombre"]}";
    }
} else {
    echo "<br>{$resultado02[1]}";
}

echo "<br><br> RESULTADO [{$caso03}] -- {$resultado03[0]} " . gettype($resultado03[1]);
if ($resultado03[0] == 2) {
    foreach ($resultado03[1] as $fila) {
        echo "<br>{$fila["iddocente"]} : {$fila["nombre"]}";
    }
} else {
    echo "<br>{$resultado03[1]}";
}

