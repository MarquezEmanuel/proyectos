<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\AutoCargador as Cargador;
use modelos\Docente as Docente;

Cargador::cargarModulos();

$docente01 = new Docente(25);
$docente02 = new Docente(NULL);
$docente03 = new Docente(-65);

$resultado01 = $docente01->obtenerPorIdentificador();
$resultado02 = $docente02->obtenerPorIdentificador();
$resultado03 = $docente03->obtenerPorIdentificador();

var_dump($resultado01);
echo "<br>";
var_dump($resultado02);
echo "<br>";
var_dump($resultado03);

