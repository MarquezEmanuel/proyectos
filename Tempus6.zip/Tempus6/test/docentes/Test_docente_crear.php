<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\AutoCargador as Cargador;
use modelos\Docente as Docente;

Cargador::cargarModulos();

$docente01 = new Docente(NULL, "Moyano Natalia");
$docente02 = new Docente(NULL, "Maria D'amico");
$docente03 = new Docente(NULL, NULL);

$resultado01 = $docente01->crear();
$resultado02 = $docente02->crear();
$resultado03 = $docente03->crear();


ECHO $docente02->getNombre();


echo "<br><br> RESULTADO [DOCENTE01] -- {$resultado01[0]}";
if ($resultado01[0] == 2) {
    echo "<br>{$resultado01[1]}";
    echo "<br>{$docente01->getIdDocente()} : {$docente01->getNombre()}";
} else {
    echo "<br>{$resultado01[1]}";
}

echo "<br><br> RESULTADO [DOCENTE02] -- {$resultado02[0]}";
if ($resultado02[0] == 2) {
    echo "<br>{$resultado02[1]}";
    echo "<br>{$docente02->getIdDocente()} : {$docente02->getNombre()}";
} else {
    echo "<br>{$resultado02[1]}";
}

echo "<br><br> RESULTADO [DOCENTE03] -- {$resultado03[0]}";
if ($resultado03[0] == 2) {
     echo "<br>{$resultado03[1]}";
    echo "<br>{$docente03->getIdDocente()} : {$docente03->getNombre()}";
} else {
    echo "<br>{$resultado03[1]}";
}