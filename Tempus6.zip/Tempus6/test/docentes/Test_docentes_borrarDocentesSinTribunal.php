<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\AutoCargador as Cargador;
use modelos\Docentes as Docentes;

Cargador::cargarModulos();

$resultado = Docentes::borrarDocentesSinTribunal();
echo "<pre>";
var_dump($resultado);
echo "</pre>";
