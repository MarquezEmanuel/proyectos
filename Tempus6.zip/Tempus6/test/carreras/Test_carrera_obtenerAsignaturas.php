<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use carreras\modelos\Carrera as Carrera;
use principal\modelos\AutoCargador as Cargador;

Cargador::cargarModulos();

$codigo = 16;
$carrera = new Carrera($codigo);
$resultado = $carrera->obtenerAsignaturas();

echo '<br> [' . (int) $resultado[0] . "] " . $resultado[1] . "<br>";
if ($resultado[0] == 2) {
    $asignaturas = $carrera->getAsignaturas();
    foreach ($asignaturas as $asignatura) {
        echo "<br>" . $asignatura['idasignatura'] . " " . $asignatura['nombre'] . " " . $asignatura['anio'];
    }
}
