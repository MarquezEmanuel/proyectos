<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\AutoCargador as Cargador;
use modelos\Carreras as Carreras;

Cargador::cargarModulos();

$nombre01 = "";
$nombre02 = "Lice";

$resultado01 = Carreras::listarCarrerasSinMesa($nombre01);
echo "<br><br> RESULTADO [{$nombre01}] -- {$resultado01[0]} " . gettype($resultado01[1]);
if ($resultado01[0] == 2) {
    foreach ($resultado01[1] as $fila) {
        echo "<br>{$fila["codigo"]} : {$fila["nombre"]}";
    }
} else {
    echo "<br>{$resultado01[1]}";
}

$resultado02 = Carreras::listarCarrerasSinMesa($nombre02);
echo "<br><br> RESULTADO [{$nombre02}] -- {$resultado02[0]} " . gettype($resultado02[1]);
if ($resultado02[0] == 2) {
    foreach ($resultado02[1] as $fila) {
        echo "<br>{$fila["codigo"]} : {$fila["nombre"]}";
    }
} else {
    echo "<br>{$resultado02[1]}";
}
