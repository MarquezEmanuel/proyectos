<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use asignaturas\modelos\Asignatura as Asignatura;
use carreras\modelos\Carrera as Carrera;
use planes\modelos\AsignaturaCarrera as AsignaturaCarrera;
use principal\modelos\AutoCargador as Cargador;

Cargador::cargarModulos();

$asignatura1 = new Asignatura(NULL, "LABORATORIO DE PRUEBA 1");
$asignatura2 = new Asignatura(NULL, "LABORATORIO DE PRUEBA 2");
$asignatura3 = new Asignatura(NULL, "LABORATORIO DE PRUEBA 3");
$asignatura4 = new Asignatura(NULL, "LABORATORIO DE PRUEBA 3");

$asignaturas = array();
$asignaturas[] = new AsignaturaCarrera(94, $asignatura1, 1);
$asignaturas[] = new AsignaturaCarrera(94, $asignatura2, 1);
$asignaturas[] = new AsignaturaCarrera(94, $asignatura3, 1);
$asignaturas[] = new AsignaturaCarrera(94, $asignatura4, 1);

$carrera = new Carrera(92, "Carrera de pruueeba", NULL);
$resultado = $carrera->crear();

echo '<br> [' . (int) $resultado[0] . "] " . $resultado[1] . "<br>";
if ($resultado[0] > 0) {
    echo '<br>Identificador: ' . $carrera->getCodigo();
    echo '<br>Nombre: ' . $carrera->getNombre();
}
