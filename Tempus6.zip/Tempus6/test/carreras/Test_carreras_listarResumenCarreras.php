<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use modelos\AutoCargador as Cargador;
use modelos\Carreras as Carreras;

Cargador::cargarModulos();

$limite01 = -10;
$limite02 = 12;

$resultado01 = Carreras::listarResumenCarreras($limite01);
echo "<br><br> RESULTADO [{$limite01}] -- {$resultado01[0]} " . gettype($resultado01[1]);
if ($resultado01[0] == 2) {
    foreach ($resultado01[1] as $fila) {
        echo "<br>{$fila["codigo"]} : {$fila["nombre"]}";
    }
} else {
    echo "<br>{$resultado01[1]}";
}

$resultado02 = Carreras::listarResumenCarreras($limite02);
echo "<br><br> RESULTADO [{$limite02}] -- {$resultado02[0]}  -- " . gettype($resultado02[1]) . " -- " . count($resultado02[1]);
if ($resultado02[0] == 2) {
    foreach ($resultado02[1] as $fila) {
        echo "<br>{$fila["codigo"]} : {$fila["nombre"]}";
    }
} else {
    echo "<br>{$resultado02[1]}";
}

