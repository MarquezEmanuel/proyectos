<?php

include_once '../../app/principal/modelos/Constantes.php';
include_once '../../app/principal/modelos/AutoCargador.php';

use principal\modelos\AutoCargador as Cargador;
use planes\modelos\AsignaturaCarrera as AsignaturaCarrera;
use asignaturas\modelos\Asignatura as Asignatura;

Cargador::cargarModulos();


$plan = new AsignaturaCarrera();

$resultado = $plan->obtener(11, 16);
echo '<br> [' . (int) $resultado[0] . "] " . $resultado[1] . "<br>";
echo $plan->getAnio();



$asignatura = new Asignatura();


echo gettype(10);

if ($asignatura instanceof  Asignatura) {
    echo "ES UNA ASIGNATURA";
}

if ($plan instanceof  Asignatura) {
    echo "ES UNA ASIGNATURA";
}