<?php

namespace principal\modelos;

/**
 * 
 * paquete: principal;
 * namespace: modelos;
 */
class Constantes {

    const ROOT = "C:\\xampp\\htdocs\\Tempus6";
    const APP = Constantes::ROOT . "\\app";
    const LIB = Constantes::ROOT . "\\lib";
    const LOG = Constantes::ROOT . "\\logs";

}
