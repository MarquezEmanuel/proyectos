<?php

namespace modelos;

class AutoCargador {

    public static function cargarModulos() {
        spl_autoload_register(function($clase) {
            $directorio = opendir(Constantes::APP);
            while ($elemento = readdir($directorio)) {
                if ($elemento == "." || $elemento == "..") {
                    continue;
                }
                $ruta = Constantes::APP."\\".$elemento."\\{$clase}.php";
                if(file_exists($ruta)) {
                    require_once $ruta;
                    return;
                }
            }
        });
    }

}
