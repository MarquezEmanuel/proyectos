<?php

namespace modelos;

/**
 * Description of AsignaturaCarrera
 *
 * @author Emanuel
 */
class AsignaturaCarrera_ {

    private $asignatura;
    private $anio;

    public function __construct($asignatura = NULL, $carrera = NULL, $anio = NULL, $cursada = NULL, $mesa = NULL) {
        $this->setAsignatura($asignatura);
        $this->setCarrera($carrera);
        $this->setAnio($anio);
        $this->setCursada($cursada);
        $this->setMesa($mesa);
    }

    public function getAsignatura() {
        return $this->asignatura;
    }

    public function getCarrera() {
        return $this->carrera;
    }

    public function getAnio() {
        return $this->anio;
    }

    public function getCursada() {
        return $this->cursada;
    }

    public function getMesa() {
        return $this->mesa;
    }

    public function setAsignatura($asignatura) {
        $this->asignatura = $asignatura;
    }

    public function setCarrera($carrera) {
        $this->carrera = $carrera;
    }

    public function setAnio($anio) {
        $this->anio = $anio;
    }

    public function setCursada($cursada) {
        $this->cursada = $cursada;
    }

    public function setMesa($mesa) {
        $this->mesa = $mesa;
    }

    public function obtener() {
        if ($this->asignatura && $this->carrera) {
            $consulta = "SELECT * FROM plan WHERE idasignatura = {$this->asignatura} AND idcarrera = {$this->carrera}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->anio = $fila['anio'];
                $rasi = $this->obtenerAsignatura($fila['idasignatura']);
                $rcar = $this->obtenerCarrera($fila['idcarrera']);
                $exito = array(2, "Se obtuvieron los datos correctamente");
                return (($rasi == 2) && ($rcar == 2)) ? $exito : array(1, "No se obtuvieron los datos");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al plan");
    }

    private function obtenerAsignatura($idAsignatura) {
        $asignatura = new Asignatura($idAsignatura);
        $resultado = $asignatura->obtenerPorIdentificador();
        $this->asignatura = ($resultado[0] == 2) ? $asignatura : NULL;
        return $resultado[0];
    }

    private function obtenerCarrera($idCarrera) {
        $carrera = new Carrera($idCarrera);
        $resultado = $carrera->obtenerPorIdentificador();
        $this->carrera = ($resultado[0] == 2) ? $carrera : NULL;
        return $resultado[0];
    }


}
