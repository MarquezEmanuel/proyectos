<?php

namespace planes\modelos;

use asignaturas\modelos\Asignatura as Asignatura;
use principal\modelos\Conexion as Conexion;
use principal\modelos\Log as Log;

/**
 * 
 * @package planes.
 * 
 * @uses Asignatura Description.
 * @uses Conexion Conexion a la base de datos.
 * @uses Log Para registrar las operaciones.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class AsignaturaCarrera {

    private $carrera;
    private $asignatura;
    private $anio;

    /**
     * Constructor de la clase.
     */
    public function __construct($carrera = NULL, $asignatura = NULL, $anio = NULL) {
        $this->setCarrera($carrera);
        $this->setAsignatura($asignatura);
        $this->setAnio($anio);
    }

    public function getCarrera() {
        return $this->carrera;
    }

    public function getAsignatura() {
        return $this->asignatura;
    }

    public function getAnio() {
        return $this->anio;
    }

    public function setCarrera($carrera) {
        $this->carrera = $carrera;
    }

    public function setAsignatura($asignatura) {
        $this->asignatura = $asignatura;
    }

    public function setAnio($anio) {
        $this->anio = $anio;
    }

    public function agregarAsignatura() {
        if ($this->carrera && $this->asignatura && $this->anio) {
            $id = ($this->asignatura instanceof Asignatura) ? $this->asignatura->getIdAsignatura() : $this->asignatura;
            $consulta = "INSERT INTO asignatura_carrera VALUES ({$id}, {$this->carrera}, {$this->anio})";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                Log::guardarActividad("Se creo la relacion ({$id}, {$this->carrera}, {$this->anio})");
                return $resultado;
            }
            return ($resultado[0] == 1) ? $this->obtener() : $resultado;
        }
        return array(0, "Los campos no cumplen con el formato requerido");
    }

    public function obtener() {
        $id = ($this->asignatura instanceof Asignatura) ? $this->asignatura->getIdAsignatura() : $this->asignatura;
        $consulta = "SELECT anio FROM asignatura_carrera WHERE "
                . "idasignatura = {$id} AND idcarrera = {$this->carrera}";
        $resultado = Conexion::getInstancia()->obtener($consulta);
        if (gettype($resultado[0]) == "array") {
            $fila = $resultado[0];
            $this->anio = $fila['anio'];
            return array(2, "Se obtuvo la información correctamente");
        }
        return $resultado;
    }

}
