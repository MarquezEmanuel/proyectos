<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Planes {

    /** @var string Descripcion sobre el resultado de alguna operacion. */
    private $descripcion;

    /**
     * Retorna la descripcion de la ultima operacion que se haya realizado.
     * @return string Descripcion de la operacion realizada.
     */
    public function getDescripcion() {
        return $this->descripcion;
    }

    /**
     * Elimina las relaciones que no tienen cursada ni mesas.
     */
    public function borrar() {
        $consulta = "DELETE FROM asignatura_carrera WHERE "
                . "CONCAT(CAST(idcarrera AS CHAR), '', CAST(idasignatura AS CHAR)) NOT IN "
                . "(SELECT DISTINCT CONCAT(CAST(idcarrera AS CHAR),'', CAST(idasignatura AS CHAR)) FROM cursada) AND "
                . "CONCAT(CAST(idcarrera AS CHAR), '', CAST(idasignatura AS CHAR)) NOT IN "
                . "(SELECT DISTINCT CONCAT(CAST(idcarrera AS CHAR),'', CAST(idasignatura AS CHAR)) FROM mesa_examen)";
        $eliminacion = Conexion::getInstancia()->borrarConSubconsulta($consulta);
        if ($eliminacion == 2) {
            $asignaturas = new Asignaturas();
            $carreras = new Carreras();
            $borraAsignatura = $asignaturas->borrar();
            $borraCarrera = $carreras->borrar();
            return (($borraAsignatura == 2) && ($borraCarrera == 2)) ? 2 : 1;
        }
        $this->descripcion = Conexion::getInstancia()->getDescripcion();
        return $eliminacion;
    }

}
