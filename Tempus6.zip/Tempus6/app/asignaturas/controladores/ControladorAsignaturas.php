<?php

namespace controladores;

/**
 * 
 * namespace: controladores.
 * paquete: asignaturas.
 */
class ControladorAsignaturas {

    private $asignatura;
    private $asignaturas;
    private $descripcion;

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function agregarCarrera($id, $codigo, $anio) {
        $this->asignatura = new Asignatura();
        $this->asignatura->setIdAsignatura($id);
        $resultado = $this->asignatura->agregarCarrera($codigo, $anio);
        $this->descripcion = $this->asignatura->getDescripcion();
        return $resultado;
    }

    public function buscarPorNombre($nombre) {
        $this->asignaturas = new Asignaturas();
        $resultado = $this->asignaturas->buscarPorNombre($nombre);
        $this->descripcion = $this->asignaturas->getDescripcion();
        return $resultado;
    }

    public function buscarPorCarrera($codigo, $nombre, $pertenece) {
        $this->asignaturas = new Asignaturas();
        $resultado = $this->asignaturas->buscarPorCarrera($codigo, $nombre, $pertenece);
        $this->descripcion = $this->asignaturas->getDescripcion();
        return $resultado;
    }

    public function crear($nombre) {
        
    }

    public function listar() {
        $this->asignaturas = new Asignaturas();
        $resultado = $this->asignaturas->listar();
        $this->descripcion = $this->asignaturas->getDescripcion();
        return $resultado;
    }

    public function listarUltimasCreadas() {
        $this->asignaturas = new Asignaturas();
        $resultado = $this->asignaturas->listarUltimasCreadas();
        $this->descripcion = $this->asignaturas->getDescripcion();
        return $resultado;
    }

    public function listarCarrerasAsignatura($id) {
        $asignaturas = new Asignaturas();
        $resultado = $asignaturas->listarCarrerasAsignatura($id);
        $this->descripcion = $asignaturas->getDescripcion();
        return $resultado;
    }

    public function listarSinCursada($codigo, $nombre) {
        $asignaturas = new Asignaturas();
        $resultado = $asignaturas->listarSinCursada($codigo, $nombre);
        $this->descripcion = $asignaturas->getDescripcion();
        return $resultado;
    }

    public function listarSinMesa($codigo, $nombre) {
        $asignaturas = new Asignaturas();
        $resultado = $asignaturas->listarSinMesa($codigo, $nombre);
        $this->descripcion = $asignaturas->getDescripcion();
        return $resultado;
    }

}
