<?php

namespace asignaturas\controladores;

use asignaturas\modelos\Asignatura as Asignatura;
use asignaturas\modelos\Asignaturas as Asignaturas;

/**
 * 
 * paquete: asignaturas.
 * namespace: asignaturas\controladores.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 * 
 */
class ControladorAsignaturas {
    /*
      public function agregarCarrera($idAsignatura, $codigoCarrera, $anio) {
      $this->asignatura = new Asignatura($idAsignatura);
      $resultado = $this->asignatura->agregarCarrera($codigoCarrera, $anio);
      $this->descripcion = $this->asignatura->getDescripcion();
      return $resultado;
      } */

    public function buscarPorNombre(string $nombreAsignatura): array {
        $resultado = Asignaturas::buscarPorNombre($nombreAsignatura);
        return $resultado;
    }

    public function buscarPorCarrera(int $codigoCarrera, string $nombreAsignatura, bool $pertenece): array {
        $resultado = Asignaturas::buscarPorCarrera($codigoCarrera, $nombreAsignatura, $pertenece);
        return $resultado;
    }

    /*
      public function listar() {
      $this->asignaturas = new Asignaturas();
      $resultado = $this->asignaturas->listar();
      $this->descripcion = $this->asignaturas->getDescripcion();
      return $resultado;
      } */

    public function listarResumenAsignaturas(int $limite): array {
        $resultado = Asignaturas::listarResumenAsignaturas($limite);
        return $resultado;
    }

    public function listarAsignaturasSinCursada(int $codigoCarrera, string $nombreAsignatura): array {
        $resultado = Asignaturas::listarAsignaturasSinCursada($codigoCarrera, $nombreAsignatura);
        return $resultado;
    }

    public function listarAsignaturasSinMesa(int $codigoCarrera, string $nombreAsignatura): array {
        $resultado = Asignaturas::listarAsignaturasSinMesa($codigoCarrera, $nombreAsignatura);
        return $resultado;
    }

}
