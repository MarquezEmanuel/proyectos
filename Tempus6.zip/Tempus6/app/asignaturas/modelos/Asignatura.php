<?php

namespace modelos;

/**
 * paquete: asignaturas.
 * namespace: modelos.
 */
class Asignatura {

    /** @var string Identificador de la asignatura en la base de datos */
    private $idAsignatura;

    /** @var string Nombre de la asignatura */
    private $nombre;

    public function __construct($id = NULL, $nombre = NULL) {
        $this->setIdAsignatura($id);
        $this->setNombre($nombre);
    }

    /**
     * @return type Description
     */
    public function getIdAsignatura() {
        return $this->idAsignatura;
    }

    /**
     * @return type Description
     */
    public function getNombre() {
        return $this->nombre;
    }

    public function setIdAsignatura($idAsignatura) {
        $this->idAsignatura = ($idAsignatura > 0) ? $idAsignatura : NULL;
    }

    public function setNombre($nombre) {
        if (Util::validarAsignaturaNombre($nombre)) {
            $this->nombre = Util::convertirCamelCase($nombre);
        }
    }

    /**
     * @return type Description
     */
    public function crear() {
        if ($this->nombre) {
            $consulta = "INSERT INTO asignatura VALUES (NULL, {$this->nombre})";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                $this->idAsignatura = $resultado[2];
                return $resultado;
            }
            if ($resultado[1] == 1) {
                return $this->obtenerPorNombre();
            }
            return $resultado;
        }
        return array(1, "El nombre no cumple el formato requerido");
    }

    /**
     * @return type Description
     */
    public function obtener() {
        if ($this->idAsignatura) {
            $consulta = "SELECT * FROM asignatura WHERE idasignatura = {$this->idAsignatura}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            $fila = $resultado[0];
            if (gettype($fila) == "array") {
                $this->idAsignatura = $fila['idasignatura'];
                $this->nombre = $fila['nombre'];
                return array(2, "Se obtuvieron los datos de la asignatura");
            }
            return $resultado;
        }
        return array(1, "No se pudo hacer referencia a la asignatura");
    }

    /**
     * @return type Description
     */
    private function obtenerPorNombre() {
        if ($this->nombre) {
            $consulta = "SELECT * FROM asignatura WHERE nombre = '{$this->nombre}'";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            $fila = $resultado[0];
            if (gettype($fila) == "array") {
                $this->idAsignatura = $fila['idasignatura'];
                $this->nombre = $fila['nombre'];
                return array(2, "Se obtuvieron los datos de la asignatura");
            }
            return $resultado;
        }
        return array(1, "No se pudo hacer referencia a la asignatura");
    }

}
