<?php

namespace asignaturas\modelos;

use carreras\modelos\Carreras as Carreras;
use principal\modelos\Conexion as Conexion;
use principal\modelos\Log as Log;
use util\modelos\Util as Util;

/**
 * namespace: asignaturas\modelos.
 * 
 * @package asignaturas.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Asignatura {

    /** @var string Identificador de la asignatura en la base de datos. */
    private $idAsignatura;

    /** @var string Nombre de la asignatura. */
    private $nombre;

    /** @var array Arreglo de carreras asociadas a la asignatura. */
    private $carreras;

    /**
     * Constructor de clase. 
     */
    public function __construct($id = NULL, $nombre = NULL, $carreras = NULL) {
        $this->setIdAsignatura($id);
        $this->setNombre($nombre);
        $this->setCarreras($carreras);
    }

    /**
     * Retorna el identificador de la asignatura.
     * @return int Identificador de la asignatura.
     */
    public function getIdAsignatura() {
        return $this->idAsignatura;
    }

    /**
     * Retorna el nombre de la asignatura.
     * @return string Nombre de la asignatura.
     */
    public function getNombre() {
        return $this->nombre;
    }

    /**
     * Retorna el arreglo de carreras de la asignatura.
     * @return array Carreras asociadas a la asignatura.
     */
    public function getCarreras() {
        return $this->carreras;
    }

    /**
     * Modifica el identificador de la asignatura solo si es mayor a cero.
     * @param int $idAsignatura Identificador de asignatura.
     */
    public function setIdAsignatura($idAsignatura) {
        $this->idAsignatura = ($idAsignatura > 0) ? $idAsignatura : NULL;
    }

    /**
     * Modificar el nombre de la asignatura solo si cumple el formato. 
     * @param string $nombre Nombre de asignatura.
     */
    public function setNombre($nombre) {
        if (Util::validarAsignaturaNombre($nombre)) {
            $this->nombre = Util::convertirCamelCase($nombre);
        }
    }

    /**
     * Modificar el arreglo de carreras asociadas a la asignatura.
     * @param array $carreras Arreglo de carreras.
     */
    public function setCarreras($carreras) {
        $this->carreras = $carreras;
    }

    /**
     * Crear nueva asignatura. Realiza la creacion de la nueva asignatura o se
     * obtienen los datos en caso que ya exista una con el mismo nombre.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    public function crear() {
        if ($this->nombre) {
            $consulta = "INSERT INTO asignatura VALUES (NULL, '{$this->nombre}')";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                Log::guardarActividad("Se creo la asignatura {$this->nombre}");
                $this->idAsignatura = $resultado[2];
                return $resultado;
            }
            return ($resultado[0] == 1) ? $this->obtenerPorNombre() : $resultado;
        }
        return array(1, "El nombre no cumple el formato requerido");
    }

    /**
     * Obtener informacion de la asignatura a partir de su identificador. Obtiene
     * los datos de la asignatura y se los asigna a los atributos de clase.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    public function obtenerPorIdentificador() {
        if ($this->idAsignatura) {
            $consulta = "SELECT * FROM asignatura WHERE idasignatura = {$this->idAsignatura}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idAsignatura = $fila['idasignatura'];
                $this->nombre = $fila['nombre'];
                return array(2, "Se obtuvo la información de la asignatura");
            }
            return $resultado;
        }
        return array(1, "No se pudo hacer referencia a la asignatura");
    }

    /**
     * Obtnener informacion de la asignatura a partir de su nombre. Obtiene  los
     * datos de la asignatura y se los asigna a los atributos de clase.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    private function obtenerPorNombre() {
        if ($this->nombre) {
            $consulta = "SELECT * FROM asignatura WHERE nombre = '{$this->nombre}'";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idAsignatura = $fila['idasignatura'];
                $this->nombre = $fila['nombre'];
                return array(2, "Se obtuvo la información de la asignatura");
            }
            return $resultado;
        }
        return array(1, "No se pudo hacer referencia a la asignatura");
    }

    /**
     * Obtener las carreras asociadas a la asignatura. Obtiene los datos de la
     * carrera junto con el anio en que se dicta la asignatura y se asigna al 
     * atributo carreras.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    public function obtenerCarreras() {
        $resultado = Carreras::listarCarrerasDeAsignatura($this->idAsignatura);
        if ($resultado[0] == 2) {
            $this->carreras = $resultado[1];
            return array(2, "Se obtuvieron las carreras para la asignatura");
        }
        return $resultado;
    }

}
