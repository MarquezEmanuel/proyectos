<?php

namespace asignaturas\modelos;

use principal\modelos\Conexion as Conexion;

/**
 * Description of Asignaturas
 * 
 * paquete: asignaturas.
 * namespace: asignaturas\modelos.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Asignaturas {

    public static function borrar() {
        $consulta = "DELETE FROM asignatura WHERE idasignatura NOT IN "
                . "(SELECT DISTINCT idasignatura FROM asignatura_carrera)";
        return Conexion::getInstancia()->borrar($consulta);
    }

    /**
     * Buscar asignaturas por su nombre ordenadas por nombre.
     */
    public static function buscarPorNombre(string $nombreAsignatura) {
        $expresion = "/^[a-záéíóúñü0-9,. ]{0,60}$/";
        if (preg_match($expresion, mb_strtolower($nombreAsignatura))) {
            $consulta = "SELECT ma.*, ca.cantidad FROM asignatura ma "
                    . "LEFT JOIN (SELECT idasignatura, COUNT(idasignatura) cantidad "
                    . "FROM asignatura_carrera "
                    . "GROUP BY idasignatura) ca on ma.idasignatura = ca.idasignatura "
                    . "WHERE ma.nombre LIKE '%{$nombreAsignatura}%' ORDER BY ma.nombre ASC";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "El nombre no cumple con el formato requerido");
    }

    /**
     * Buscar asignaturas por su nombre y carrera ordernadas por nombre.
     */
    public static function buscarPorCarrera($codigoCarrera, $nombreAsignatura, $pertenece) {
        $expresion = "/^[a-záéíóúñü0-9,. ]{0,60}$/";
        if (($codigoCarrera > 0) && preg_match($expresion, mb_strtolower($nombreAsignatura))) {
            $condicion = ($pertenece) ? "IN" : "NOT IN";
            $consulta = "SELECT ma.* FROM asignatura ma "
                    . "WHERE ma.idasignatura {$condicion} "
                    . "(SELECT idasignatura FROM asignatura_carrera WHERE idcarrera = {$codigoCarrera}) "
                    . "AND ma.nombre LIKE '%{$nombreAsignatura}%' ORDER BY ma.nombre ASC";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "Los datos recibidos no cumplen con el formato requerido");
    }

    /*
      public static function listar() {
      $consulta = "SELECT * FROM asignatura ORDER BY nombre ASC";
      return Conexion::getInstancia()->seleccionar($consulta);
      } */

    /**
     * Listar las asignaturas sin horarios de cursada.
     */
    public static function listarAsignaturasSinCursada($codigoCarrera, $nombreAsignatura){
        $expresion = "/^[a-záéíóúñü0-9,. ]{0,60}$/";
        if (($codigoCarrera > 0) && preg_match($expresion, mb_strtolower($nombreAsignatura))) {
            $consulta = "SELECT DISTINCT REL.idasignatura idAsignatura, ASI.nombre nombre "
                    . "FROM asignatura_carrera REL "
                    . "INNER JOIN asignatura ASI ON ASI.idasignatura = REL.idasignatura "
                    . "INNER JOIN carrera CAR ON CAR.codigo = REL.idcarrera "
                    . "LEFT JOIN cursada CUR ON CUR.idasignatura = REL.idasignatura AND CUR.idcarrera = REL.idcarrera "
                    . "WHERE CUR.idclase IS NULL AND REL.idcarrera = {$codigoCarrera} AND ASI.nombre LIKE '%{$nombreAsignatura}%'";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "Los datos recibidos no cumplen con el formato requerido");
    }

    /**
     * Listar las asignaturas que no tienen mesa de examen.
     */
    public static function listarAsignaturasSinMesa($codigoCarrera, $nombre) {
        $expresion = "/^[a-záéíóúñü0-9,. ]{0,60}$/";
        if (($codigoCarrera > 0) && preg_match($expresion, mb_strtolower($nombre))) {
            $consulta = "SELECT REL.idasignatura idAsignatura, ASI.nombre nombre FROM asignatura_carrera REL "
                    . "INNER JOIN asignatura ASI ON ASI.idasignatura = REL.idasignatura "
                    . "LEFT JOIN mesa_examen MES ON MES.idasignatura = REL.idasignatura "
                    . "WHERE MES.idmesa IS NULL AND REL.idcarrera = {$codigoCarrera} AND ASI.nombre LIKE '%{$nombre}%'";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "Los datos recibidos no cumplen con el formato requerido");
    }

    /**
     * Listar las asignaturas de una carrera ordenadas por anio y nombre.
     */
    public static function listarAsignaturasDeCarrera($codigoCarrera) {
        if ($codigoCarrera > 0) {
            $consulta = "SELECT ac.idasignatura, asi.nombre, ac.anio "
                    . "FROM asignatura_carrera ac "
                    . "LEFT JOIN asignatura asi ON asi.idasignatura = ac.idasignatura "
                    . "WHERE ac.idcarrera = {$codigoCarrera} ORDER BY ac.anio, asi.nombre";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "El código de carrera no cumple con el formato requerido");
    }

    /**
     * Listar resumen limitado de asignaturas. Selecciona el identificador, nombre
     * y cantidad de carreras para cada una de las asignaturas segun el limite.
     */
    public static function listarResumenAsignaturas($limite){
        if ($limite > 0) {
            $consulta = "SELECT ma.*, (CASE WHEN ca.cantidad IS NULL THEN 0 ELSE ca.cantidad END) cantidad "
                    . "FROM asignatura ma "
                    . "LEFT JOIN (SELECT idasignatura, COUNT(idasignatura) cantidad "
                    . "FROM asignatura_carrera GROUP BY idasignatura) ca on ma.idasignatura = ca.idasignatura "
                    . "ORDER BY ma.idasignatura DESC LIMIT {$limite}";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se estableció un limite válido");
    }

}
