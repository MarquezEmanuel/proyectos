<?php

namespace modelos;

/**
 * Description of Cursada
 *
 * @author Emanuel
 */
class Cursada {

    private $clases;

    public function __construct($clases = NULL) {
        $this->setClases($clases);
    }

    public function getClases() {
        return $this->clases;
    }

    public function setClases(array $clases) {
        $this->clases = ($clases && count($clases) < 7) ? $clases : NULL;
    }

    /**
     * Borra la cursada de una asignatura y carrera.
     */
    public function borrarCursada($idAsignatura, $idCarrera): array {
        if ($idAsignatura && $idCarrera) {
            $consulta = "DELETE FROM cursada WHERE idasignatura = {$this->asignatura} AND idcarrera = {$this->carrera}";
            $resultado = Conexion::getInstancia()->borrar($consulta);
            return ($resultado[1] == 2) ? Clases::borrarClasesSinCursada() : $resultado;
        }
        return array(0, "Los campos obligatorios no cumplen con el formato requerido");
    }

    public function crearCursada($idAsignatura, $idCarrera): array {
        if ($idAsignatura && $idCarrera && $this->clases) {
            $resultado = $this->crearClases();
            if ($resultado[0] != 2) {
                return $resultado;
            }
            $values = "";
            $claves = $resultado[1];
            foreach ($claves as $idclase) {
                $values .= "({$this->asignatura}, {$this->carrera}, {$idclase}),";
            }
            $consulta = "INSERT INTO cursada VALUES " . substr($values, 0, -1);
            return Conexion::getInstancia()->insertar($consulta);
        }
        return array(0, "Los campos obligatorios no cumplen con el formato requerido");
    }

    private function crearClases(): array {
        $claves = array();
        $error = FALSE;
        foreach ($this->clases as $clase) {
            $resultado = $clase->crear();
            if ($resultado[0] == 2) {
                $claves[] = $clase->getId();
            } else {
                $error = FALSE;
            }
        }
        return ($error) ? array(0, "No se crearon las clases") : array(2, $claves);
    }

    /**
     * Obtiene todas las clases para la cursada de una asignatura y carrera.
     */
    public function obtenerCursada($idAsignatura, $idCarrera) {
        if (($idAsignatura > 0) && ($idCarrera > 0)) {
            $consulta = "SELECT * FROM cursada WHERE idasignatura = {$idAsignatura} AND idcarrera = {$idCarrera}";
            $resultado = Conexion::getInstancia()->seleccionar($consulta);
            return ($resultado[0] == 2) ? $this->obtenerClases($resultado[1]) : $resultado;
        }
        return array(0, "No se pudo hacer referencia a la cursada");
    }

    private function obtenerClases($identificadoresClases) {
        $this->clases = array();
        $error = FALSE;
        foreach ($identificadoresClases as $fila) {
            $clase = new Clase($fila['idclase']);
            $obtener = $clase->obtenerPorIdentificador();
            if ($obtener[0] == 2) {
                $this->clases[] = $clase;
            } else {
                $error = TRUE;
            }
        }
        return ($error) ? array(0, "No se obtuvieron las clases") : array(2, "Se obtuvieron las clases");
    }

}
