<?php

namespace modelos;

class Clase {

    private $idClase;
    private $dia;
    private $horaInicio;
    private $horaFin;
    private $aula;
    private $fechaEdicion;

    public function __construct($idClase = NULL, $dia = NULL, $horaInicio = NULL, $horaFin = NULL, $aula = NULL, $fechaEdicion = NULL) {
        $this->setId($idClase);
        $this->setDia($dia);
        $this->setHoraInicio($horaInicio);
        $this->setHoraFin($horaFin);
        $this->setAula($aula);
        $this->setFechaEdicion($fechaEdicion);
    }

    public function getId() {
        return $this->idClase;
    }

    public function getDia($formato = "NUMERO") {
        return ($formato == "NUMERO") ? $this->dia : Util::obtenerNombreDia($this->dia);
    }

    public function getHoraInicio($formato = "HHMMSS") {
        return ($formato == "HHMMSS") ? $this->horaInicio : substr($this->horaInicio, 0, 5);
    }

    public function getHoraFin($formato = "HHMMSS") {
        return ($formato == "HHMMSS") ? $this->horaFin : substr($this->horaFin, 0, 5);
    }

    public function getAula() {
        return $this->aula;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($idClase) {
        $this->idClase = ($idClase > 0) ? $idClase : NULL;
    }

    public function setDia($dia) {
        if (Util::validarClaseDia($dia)) {
            $this->dia = $dia;
        }
    }

    public function setHoraInicio($horaInicio) {
        if (Util::validarClaseHora($horaInicio)) {
            $this->horaInicio = $horaInicio;
        }
    }

    public function setHoraFin($horaFin) {
        if (Util::validarClaseHora($horaFin)) {
            $this->horaFin = $horaFin;
        }
    }

    public function setAula($aula) {
        $this->aula = ($aula) ? $aula : NULL;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }
    
    public function crear(): array {
        if ($this->dia && $this->horaInicio && $this->horaFin && $this->aula) {
            $existencia = $this->evaluarExistencia();
            if ($existencia == 1) {
                $consulta = "INSERT INTO clase VALUES (NULL, {$this->dia}, '{$this->horaInicio}', '{$this->horaFin}', {$this->aula}, NULL)";
                $creacion = Conexion::getInstancia()->insertar($consulta);
                $this->idClase = ($creacion == 2) ? (Int) Conexion::getInstancia()->insert_id : NULL;
                $this->descripcion = Conexion::getInstancia()->getDescripcion();
                return $creacion;
            }
            return $existencia;
        }
        return array(0, "Los campos no cumplen con el formato requerido");
    }

    public function modificar(): array {
        if ($this->idClase && $this->horaInicio && $this->horaFin && $this->aula) {
            $consulta = "UPDATE clase SET desde='{$this->horaInicio}',"
                    . " hasta='{$this->horaFin}', idaula={$this->aula}, "
                    . " fechamod=NOW() WHERE idclase = {$this->idClase}";
            return Conexion::getInstancia()->modificar($consulta);
        }
        return array(0, "Los campos no cumplen con el formato requerido");
    }

    public function obtenerPorIdentificador(): array {
        if ($this->idClase) {
            $consulta = "SELECT * FROM clase WHERE idclase = {$this->idClase}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idClase = $fila['idclase'];
                $this->dia = $fila['dia'];
                $this->horaInicio = $fila['desde'];
                $this->horaFin = $fila['hasta'];
                $this->fechaModificacion = $fila['fechamod'];
                return $this->obtenerAula($fila['idaula']);
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la clase");
    }

    private function obtenerPorDatos(): array {
        $consulta = "SELECT idclase FROM clase WHERE dia ={$this->dia} "
                . "AND desde = '{$this->horaInicio}' "
                . "AND hasta = '{$this->horaFin}' "
                . "AND idaula={$this->aula}";
        $fila = Conexion::getInstancia()->obtener($consulta);
        if (gettype($fila) == "array") {
            $this->idClase = $fila['idclase'];
            $this->dia = $fila['dia'];
            $this->horaInicio = $fila['desde'];
            $this->horaFin = $fila['hasta'];
            $this->fechaModificacion = $fila['fechamod'];
            return $this->obtenerAula($fila['idaula']);
        }
        $this->descripcion = Conexion::getInstancia()->getDescripcion();
        return $fila;
    }

    private function obtenerAula($idAula): array {
        if ($idAula > 0) {
            $aula = new Aula($idAula);
            $resultado = $aula->obtenerPorIdentificador();
            $this->aula = ($resultado[0] == 2) ? $aula : NULL;
            $resultado[1] = ($resultado[0] == 2) ? "Se obtuvo la información de la clase correctamente" : $resultado[1];
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al aula");
    }

}
