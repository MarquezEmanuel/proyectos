<?php

namespace modelos;

/**
 * Description of Clases
 *
 * paquete: cursadas.
 * namespace: modelos.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Clases {

    /**
     * Borrar todas los registros de clases. Luego de eliminar todas las clases 
     * se reinicia el auto incrementador de la clave primaria.
     * @uses Clases::reiniciarAutoIncrementador Reinicia auto incrementador a 1.
     */
    public static function borrarClases() {
        $consulta = "DELETE FROM clase";
        $resultado = Conexion::getInstancia()->borrar($consulta);
        return ($resultado[0] == 2) ? $this->reiniciarAutoIncrementador() : $resultado;
    }

    /**
     * Borrar las clases que no esten asociadas a ninguna asignatura-carrera.
     */
    public static function borrarClasesSinCursada() {
        $consulta = "DELETE cla FROM clase cla JOIN (SELECT idclase FROM clase "
                . "WHERE idclase NOT IN (SELECT DISTINCT idclase FROM cursada)) "
                . "can ON can.idclase = cla.idclase";
        return Conexion::getInstancia()->borrar($consulta);
    }

    /**
     * Reiniciar el auto incrementador de la clave primaria.
     */
    private function reiniciarAutoIncrementador() {
        $consulta = "ALTER TABLE clase AUTO_INCREMENT = 1";
        return Conexion::getInstancia()->borrar($consulta);
    }

}
