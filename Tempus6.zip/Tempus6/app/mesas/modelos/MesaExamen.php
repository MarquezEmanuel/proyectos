<?php

namespace modelos;

/**
 */
class MesaExamen {

    private $idMesa;
    private $carrera;
    private $asignatura;
    private $tribunal;
    private $primerLlamado;
    private $segundoLlamado;

    public function __construct($id = NULL, $asignatura = NULL, $carrera = NULL, $tribunal = NULL, $primero = NULL, $segundo = NULL) {
        $this->setIdMesa($id);
        $this->setCarrera($carrera);
        $this->setAsignatura($asignatura);
        $this->setTribunal($tribunal);
        $this->setPrimerLlamado($primero);
        $this->setSegundoLlamado($segundo);
    }

    public function getIdMesa() {
        return $this->idMesa;
    }

    public function getCarrera() {
        return $this->carrera;
    }

    public function getAsignatura() {
        return $this->asignatura;
    }

    public function getTribunal() {
        return $this->tribunal;
    }

    public function getPrimerLlamado() {
        return ($this->primerLlamado == "NULL") ? NULL : $this->primerLlamado;
    }

    public function getSegundoLlamado() {
        return ($this->segundoLlamado == "NULL") ? NULL : $this->segundoLlamado;
    }

    public function setIdMesa($idMesa) {
        $this->idMesa = ($idMesa > 0) ? $idMesa : NULL;
    }

    public function setCarrera($carrera) {
        $this->carrera = $carrera;
    }

    public function setAsignatura($asignatura) {
        $this->asignatura = $asignatura;
    }

    public function setTribunal($tribunal) {
        $this->tribunal = $tribunal;
    }

    public function setPrimerLlamado($primerLlamado) {
        $this->primerLlamado = ($primerLlamado) ? $primerLlamado : "NULL";
    }

    public function setSegundoLlamado($segundoLlamado) {
        $this->segundoLlamado = ($segundoLlamado) ? $segundoLlamado : "NULL";
    }

    public function borrar() {
        if ($this->idMesa) {
            $condicion = "idmesa=" . $this->idMesa;
            $eliminacion = Conexion::getInstancia()->borrar("mesa_examen", $condicion);
            $this->descripcion = Conexion::getInstancia()->getDescripcion();
            if ($eliminacion == 2) {
                $borrarTribunal = $this->borrarTribunal();
                $borrarLlamados = $this->borrarLlamados();
                return ($borrarTribunal == 2 && $borrarLlamados == 2) ? 2 : 0;
            }
            return $eliminacion;
        }
        $this->descripcion = "No se pudo hacer referencia a la mesa de examen";
        return 0;
    }

    private function borrarTribunal() {
        $tribunal = new Tribunal($this->tribunal);
        $eliminacion = $tribunal->borrar();
        if ($eliminacion != 2) {
            $this->descripcion = $tribunal->getDescripcion();
        }
        return $eliminacion;
    }

    private function borrarLlamados() {
        $llamados = new Llamados();
        $eliminacion = $llamados->borrarSinMesa();
        if ($eliminacion != 2) {
            $this->descripcion = "No se realizó la eliminación del/los llamado/s asociados a la mesa de examen";
        }
        return $eliminacion;
    }

    public function crear() {
        if ($this->carrera && $this->asignatura && $this->tribunal && ($this->primero || $this->segundo)) {
            $primero = ($this->primero) ? $this->primero : "NULL";
            $segundo = ($this->segundo) ? $this->segundo : "NULL";
            $values = "(NULL, {$this->asignatura}, {$this->carrera}, {$this->tribunal}, {$primero}, {$segundo})";
            $creacion = Conexion::getInstancia()->insertar("mesa_examen", $values);
            $this->idasignatura = ($creacion == 2) ? (Int) Conexion::getInstancia()->insert_id : NULL;
            $this->descripcion = Conexion::getInstancia()->getDescripcion();
            return $creacion;
        }
        $this->descripcion = "No se indicaron todos los campos obligatorios";
        return 0;
    }

    public function obtener() {
        if ($this->idMesa) {
            $consulta = "SELECT * FROM mesa_examen WHERE idmesa = {$this->idMesa}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idMesa = $fila['idmesa'];
                $rtri = $this->obtenerTribunal($fila['idtribunal']);
                $rpri = $this->obtenerPrimerLlamado($fila['idprimerllamado']);
                $rseg = $this->obtenerSegundoLlamado($fila['idsegundollamado']);
                $error = array(1, "No se obtuvo la información del tribunal");
                $exito = array(2, "Se obtuvo la información del tribunal correctamente");
                return (($rtri == 2) && ($rpri == 2) && ($rseg == 2)) ? $exito : $error;
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la mesa de examen");
    }

    private function obtenerTribunal($idTribunal) {
        if ($idTribunal > 0) {
            $tribunal = new Tribunal($idTribunal);
            $resultado = $tribunal->obtener();
            $this->tribunal = ($resultado[0] == 2) ? $tribunal : NULL;
            return $resultado[0];
        }
        return 1;
    }

    private function obtenerPrimerLlamado($idLlamado) {
        if ($idLlamado > 0) {
            $primerLlamado = new Llamado($idLlamado);
            $resultado = $primerLlamado->obtener();
            $this->primerLlamado = ($resultado[0] == 2) ? $primerLlamado : NULL;
            return $resultado[0];
        }
        return 2;
    }

    private function obtenerSegundoLlamado($idLlamado) {
        if ($idLlamado > 0) {
            $segundoLlamado = new Llamado($idLlamado);
            $resultado = $segundoLlamado->obtener();
            $this->segundoLlamado = ($resultado[0] == 2) ? $segundoLlamado : NULL;
            return $resultado[0];
        }
        return 2;
    }

}
