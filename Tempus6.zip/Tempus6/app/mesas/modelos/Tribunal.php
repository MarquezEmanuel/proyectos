<?php

namespace modelos;

/**
 * 
 * paquete: mesas.
 * namespace: modelos.
 * 
 */
class Tribunal {

    private $idTribunal;
    private $presidente;
    private $vocalPrimero;
    private $vocalSegundo;
    private $suplente;

    public function __construct($id = NULL, $presidente = NULL, $vocal1 = NULL, $vocal2 = NULL, $suplente = NULL) {
        $this->setIdTribunal($id);
        $this->setPresidente($presidente);
        $this->setVocalPrimero($vocal1);
        $this->setVocalSegundo($vocal2);
        $this->setSuplente($suplente);
    }

    public function getIdTribunal() {
        return $this->idTribunal;
    }

    public function getPresidente() {
        return $this->presidente;
    }

    public function getVocalPrimero() {
        return $this->vocalPrimero;
    }

    public function getVocalSegundo() {
        return ($this->vocalSegundo == "NULL") ? NULL : $this->vocalSegundo;
    }

    public function getSuplente() {
        return ($this->suplente == "NULL") ? NULL : $this->suplente;
    }

    public function setIdTribunal($idTribunal) {
        $this->idTribunal = $idTribunal;
    }

    public function setPresidente($presidente) {
        $this->presidente = ($presidente) ? $presidente : NULL;
    }

    public function setVocalPrimero($vocalPrimero) {
        $this->vocalPrimero = ($vocalPrimero) ? $vocalPrimero : NULL;
    }

    public function setVocalSegundo($vocalSegundo) {
        $this->vocalSegundo = ($vocalSegundo) ? $vocalSegundo : "NULL";
    }

    public function setSuplente($suplente) {
        $this->suplente = ($this->vocalSegundo && $suplente) ? $suplente : "NULL";
    }

    /**
     * Realiza la eliminacion del tribunal y de los docentes no asociados a ningun
     * tribunal. Cuando se elimina el tribunal, se eliminan los docentes asociados
     * solo si no forman parte de otro tribunal.
     */
    public function borrar() {
        $resultado = Tribunales::borrarTribunalesSinMesaExamen();
        if ($resultado[0] == 2) {
            $resultado = Docentes::borrarDocentesSinTribunal();
            $resultado[1] = ($resultado[1] == 2) ?: "No se realizó la eliminación del tribunal";
            return $resultado;
        }
        $resultado[1] = "No se realizó la eliminación del tribunal";
        return $resultado;
    }

    /**
     * Realiza la creacion del tribunal en la base de datos.
     * @return integer 0 si falla, 1 si no se crea o 2 si es correcta.
     */
    public function crear() {
        if ($this->presidente && $this->vocalPrimero) {
            $consulta = "INSERT INTO tribunal VALUES "
                    . "(NULL, {$this->presidente}, {$this->vocalPrimero}, "
                    . "{$this->vocalSegundo}, {$this->suplente})";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                $this->idTribunal = $resultado[2];
                return $resultado;
            }
            return ($resultado[0] == 1) ? $this->obtener() : $resultado;
        }
        return array(0, "Los campos obligatorios no cumplen con el formato requerido");
    }

    /**
     * Realiza la modificacion en la base de datos de un tribunal.
     * @return integer 0 si falla, 1 si no afecta filas o 2 si es correcta.
     */
    public function modificar() {
        if ($this->idTribunal && $this->presidente && $this->vocalPrimero) {
            $consulta = "UPDATE tribunal SET presidente = {$this->presidente}, "
                    . "vocal1 = {$this->vocalPrimero}, vocal2={$this->vocalSegundo}, "
                    . "suplente={$this->suplente} WHERE idtribunal = {$this->idTribunal}";
            $resultado = Conexion::getInstancia()->modificar($consulta);
            return $resultado;
        }
        return array(0, "Los campos obligatorios no cumplen con el formato requerido");
    }

    public function obtener() {
        if ($this->presidente && $this->vocalPrimero) {
            $consulta = "SELECT * FROM tribunal WHERE presidente = {$this->presidente} "
                    . "AND vocal1 = {$this->vocalPrimero} "
                    . "AND vocal2 = {$this->vocalSegundo} "
                    . "AND suplente = {$this->suplente}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idTribunal = $fila['idtribunal'];
                $rpre = $this->obtenerPresidente($fila['presidente']);
                $rvop = $this->obtenerVocalPrimero($fila['vocal1']);
                $rvos = $this->obtenerVocalSegundo($fila['vocal2']);
                $rsup = $this->obtenerSuplente($fila['suplente']);
                $error = array(1, "No se obtuvo la información del tribunal");
                $exito = array(2, "Se obtuvo la información del tribunal correctamente");
                return (($rpre == 2) && ($rvop == 2) && ($rvos == 2) && ($rsup == 2)) ? $exito : $error;
            }
            return $resultado;
        }
        return array(0, "Los campos obligatorios no cumplen con el formato requerido");
    }

    private function obtenerPresidente($idPresidente) {
        if ($idPresidente > 0) {
            $presidente = new Docente($idPresidente);
            $resultado = $presidente->obtenerPorIdentificador();
            $this->presidente = ($resultado[0] == 2) ? $presidente : NULL;
            return $resultado[0];
        }
        return 0;
    }

    private function obtenerVocalPrimero($idVocalPrimero) {
        if ($idVocalPrimero > 0) {
            $vocal1 = new Docente($idVocalPrimero);
            $resultado = $vocal1->obtenerPorIdentificador();
            $this->vocalPrimero = ($resultado[0] == 2) ? $vocal1 : NULL;
            return $resultado[0];
        }
        return 0;
    }

    private function obtenerVocalSegundo($idVocalSegundo) {
        if ($idVocalSegundo > 0) {
            $vocal2 = new Docente($idVocalSegundo);
            $resultado = $vocal2->obtenerPorIdentificador();
            $this->vocalSegundo = ($resultado[0] == 2) ? $vocal2 : NULL;
            return $resultado[0];
        }
        return 2;
    }

    private function obtenerSuplente($idSuplente) {
        if ($this->vocalSegundo && ($idSuplente > 0)) {
            $suplente = new Docente($idSuplente);
            $resultado = $suplente->obtenerPorIdentificador();
            $this->vocalSegundo = ($resultado[0] == 2) ? $suplente : NULL;
            return $resultado[0];
        }
        return 2;
    }

}
