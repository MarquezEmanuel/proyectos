<?php

namespace modelos;

/**
 * 
 * paquete: mesas.
 * namespace: modelos.
 */
class Tribunales {

    /**
     * @uses element Description
     */
    public static function borrarTribunales() {
        Log::guardarActividad("TRIBUNALES --> BORRAR TRIBUNALES");
        $consulta = "DELETE FROM tribunal";
        $resultado = Conexion::getInstancia()->borrar($consulta);
        if ($resultado[0] == 2) {
            $alter = $this->reiniciarAutoIncrementador();
            return ($alter[0] == 2) ? Docentes::borrarDocentes() : $alter;
        }
        return $resultado;
    }

    public static function borrarTribunalesSinMesaExamen() {
        $consulta = "DELETE TRI FROM tribunal TRI JOIN (SELECT idtribunal FROM tribunal "
                . "WHERE idtribunal NOT IN (SELECT DISTINCT idtribunal FROM mesa_examen)) "
                . "CAN ON CAN.idtribunal = TRI.idtribunal";
        return Conexion::getInstancia()->borrar($consulta);
    }

    private function reiniciarAutoIncrementador() {
        Log::guardarActividad("TRIBUNALES --> REINICIAR AUTO INCREMENTADOR");
        $consulta = "ALTER TABLE tribunal AUTO_INCREMENT = 1";
        return Conexion::getInstancia()->borrar($consulta);
    }

}
