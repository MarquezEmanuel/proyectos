<?php

namespace mesas\modelos;

use aulas\modelos\Aula as Aula;
use principal\modelos\Conexion as Conexion;
use principal\modelos\Log as Log;
use util\modelos\Util as Util;

/**
 * Description of Llamado
 *
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Llamado {

    /** @var integer Identificador del llamado en la base de datos. */
    private $idLlamado;

    /** @var string Fecha en la que se dicta la mesa de examen. */
    private $fecha;

    /** @var string Hora en la que se dicta la mesa de examen. */
    private $hora;

    /** @var Aula Aula en la que se dicta la mesa de examen. */
    private $aula;

    /** @var string Fecha de modificacion del llamado. */
    private $fechaEdicion;

    public function __construct($id = NULL, $fecha = NULL, $hora = NULL, $aula = NULL, $fechaEdicion = NULL) {
        $this->setIdLlamado($id);
        $this->setFecha($fecha);
        $this->setHora($hora);
        $this->setAula($aula);
        $this->setFechaEdicion($fechaEdicion);
    }

    /**
     * Retorna el identificador del llamado.
     * @return int Identificador del llamado.
     */
    public function getIdLlamado() {
        return $this->idLlamado;
    }

    /**
     * Retorna la fecha del llamado.
     * @return string Fecha del llamado.
     */
    public function getFecha($formato = "DDMMAAAA") {
        return ($formato == "DDMMAAAA") ? date_format($this->fecha, 'd/m/Y') : $this->fecha;
    }

    /**
     * Retorna la hora del llamado.
     * @param string $formato Formato HHMMSS o HHMM.
     * @return string Hora del llamado.
     */
    public function getHora($formato = "HHMMSS") {
        return ($formato == "HHMMSS") ? $this->hora : substr($this->hora, 0, 5);
    }

    /**
     * Retorna el aula asignada al llamado.
     * @return int Aula del llamado.
     */
    public function getAula() {
        return ($this->aula == "NULL") ? NULL : $this->aula;
    }

    /**
     * Retorna la fecha de la ultima modificacion para el llamado.
     * @return string Fecha de la ultima modificacion.
     */
    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setIdLlamado($idLlamado) {
        $this->idLlamado = ($idLlamado > 0) ? $idLlamado : NULL;
    }

    public function setFecha($fecha) {
        $this->fecha = $fecha;
    }

    public function setHora($hora) {
        if (Util::validarLlamadoHora($hora)) {
            $this->hora = $hora;
        }
    }

    public function setAula($aula) {
        $this->aula = $aula;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function borrar() {
        if ($this->idLlamado) {
            $consulta = "DELETE FROM llamado WHERE idllamado = {$this->idLlamado}";
            return Conexion::getInstancia()->borrar($consulta);
        }
        return array(0, "No se pudo hacer referencia al llamado");
    }

    public function crear() {
        if ($this->fecha && $this->hora) {
            if (!$this->crearAula()) {
                return array(0, "No se pudo crear el aula para el llamado");
            }
            $aula = ($this->aula instanceof Aula) ? $this->aula->getIdAula() : $this->aula;
            $consulta = "INSERT INTO llamado VALUES (NULL, '{$this->fecha}', '{$this->hora}', {$aula}, NULL)";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                $this->idLlamado = $resultado[2];
                Log::guardarActividad("Se creo el llamado ({$this->idLlamado}, '{$this->fecha}', '{$this->hora}', {$aula}, NULL)");
            }
            return $resultado;
        }
        return array(0, "No se indicaron todos los campos obligatorios del llamado");
    }

    /**
     * Crear aula nueva. Creacion del aula asignada al llamado en caso de tener
     * o asignacion de la variable como nula.
     * @return bool True cuando se crea o se coloca en nulo, false caso contrario.
     */
    private function crearAula() {
        if ($this->aula && ($this->aula instanceof Aula)) {
            $resultado = $this->aula->crear();
            return ($resultado[0] == 2) ? true : false;
        }
        $this->aula = "NULL";
        return true;
    }

    /**
     * Modificar informacion del llamado. Se modifican los datos del llamado en 
     * la base de datos y se asigna la fecha actual al campo fecha modificacion.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    public function modificar() {
        if ($this->idLlamado && $this->fecha && $this->hora) {
            $consulta = "UPDATE llamado SET fecha='{$this->fecha}', "
                    . "hora='{$this->hora}', "
                    . "idaula={$this->aula}, "
                    . "fechamod = NOW() "
                    . "WHERE idllamado = {$this->idLlamado}";
            return Conexion::getInstancia()->modificar($consulta);
        }
        return array(0, "Los campos no cumplen con el formato requerido");
    }

    /**
     * Obtener informacion del llamado a partir de su identificador. Obtiene los
     * datos del llamado y se los asigna a los atributos de clase.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    public function obtenerPorIdentificador() {
        if ($this->idLlamado) {
            $consulta = "SELECT * FROM llamado WHERE idllamado = {$this->idLlamado}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idLlamado = $fila['idllamado'];
                $this->fecha = $fila['fecha'];
                $this->hora = $fila['hora'];
                $this->fechaEdicion = $fila['fechamod'];
                return $this->obtenerAula($fila['idaula']);
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al llamado");
    }

    /**
     * Obtener aula asociada al llamado. Obtiene los datos del aula, si posee, 
     * y se asigna el objeto al atributo aula.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    private function obtenerAula($idAula) {
        if ($idAula > 0) {
            $aula = new Aula($idAula);
            $resultado = $aula->obtenerPorIdentificador();
            $this->aula = ($resultado[0] == 2) ? $aula : NULL;
            return $resultado;
        }
        return array(2, "Se obtuvo la informacion del llamado correctamente");
    }

}
