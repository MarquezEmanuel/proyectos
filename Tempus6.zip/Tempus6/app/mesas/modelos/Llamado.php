<?php

namespace modelos;

/**
 * Description of Llamado
 *
 * @author Emanuel
 */
class Llamado {

    /** @var integer Identificador del llamado en la base de datos. */
    private $idLlamado;

    /** @var string Fecha en la que se dicta la mesa de examen. */
    private $fecha;

    /** @var string Hora en la que se dicta la mesa de examen. */
    private $hora;

    /** @var Aula Aula en la que se dicta la mesa de examen. */
    private $aula;

    /** @var string Fecha de modificacion del llamado. */
    private $fechaEdicion;

    public function __construct($id = NULL, $fecha = NULL, $hora = NULL, $aula = NULL, $fechaEdicion = NULL) {
        $this->setIdLlamado($id);
        $this->setFecha($fecha);
        $this->setHora($hora);
        $this->setAula($aula);
        $this->setFechaEdicion($fechaEdicion);
    }

    public function getIdLlamado() {
        return $this->idLlamado;
    }

    public function getFecha() {
        return $this->fecha;
    }

    public function getHora() {
        return $this->hora;
    }

    public function getAula() {
        return ($this->aula == "NULL") ? NULL : $this->aula;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setIdLlamado($idLlamado) {
        $this->idLlamado = ($idLlamado > 0) ? $idLlamado : NULL;
    }

    public function setFecha($fecha) {
        $this->fecha = $fecha;
    }

    public function setHora($hora) {
        if (Util::validarLlamadoHora($hora)) {
            $this->hora = $hora;
        }
    }

    public function setAula($aula) {
        $this->aula = ($aula) ? $aula : "NULL";
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function borrar() {
        if ($this->idLlamado) {
            $consulta = "DELETE FROM llamado WHERE idllamado = {$this->idLlamado}";
            return Conexion::getInstancia()->borrar($consulta);
        }
        return array(0, "No se pudo hacer referencia al llamado");
    }

    public function crear() {
        if ($this->fecha && $this->hora) {
            $consulta = "INSERT INTO llamado VALUES (NULL, '{$this->fecha}', '{$this->hora}', {$this->aula}, NULL)";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            $this->idLlamado = ($resultado[0] == 2) ? $resultado[2] : NULL;
            return $resultado;
        }
        return array(0, "No se indicaron todos los campos obligatorios del llamado");
    }

    public function modificar() {
        if ($this->idLlamado && $this->fecha && $this->hora) {
            $consulta = "UPDATE llamado SET fecha='{$this->fecha}', hora='{$this->hora}', "
                    . "idaula={$this->aula}, fechamod = NOW() "
                    . "WHERE idllamado = {$this->idLlamado}";
            return Conexion::getInstancia()->modificar($consulta);
        }
        return array(0, "Los campos no cumplen con el formato requerido");
    }

}
