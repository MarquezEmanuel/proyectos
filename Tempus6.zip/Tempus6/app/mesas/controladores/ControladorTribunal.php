<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ControladorTribunal {

    private $descripcion;

    function getDescripcion() {
        return $this->descripcion;
    }

    public function modificar($id, $presidente, $vocal1, $vocal2, $suplente) {
        $tribunal = new Tribunal($id, $presidente, $vocal1, $vocal2, $suplente);
        $modificacion = $tribunal->modificar();
        $this->descripcion = $tribunal->getDescripcion();
        return $modificacion;
    }

}
