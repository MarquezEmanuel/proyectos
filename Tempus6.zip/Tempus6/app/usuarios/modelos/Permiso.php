<?php

/**
 * Description of Permiso
 *
 * @author Emanuel
 */
class Permiso {

    /** @var integer Identificador del permiso en la base de datos */
    private $idPermiso;

    /** @var string Nombre del permiso */
    private $nombre;

    public function __construct($id = NULL, $nombre = NULL) {
        $this->setIdPermiso($id);
        $this->setNombre($nombre);
    }

    public function getIdPermiso() {
        return $this->idPermiso;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function setIdPermiso($idPermiso) {
        $this->idPermiso = ($idPermiso > 0) ? $idPermiso : NULL;
    }

    public function setNombre($nombre) {
        if (preg_match("/^[A-Za-z_]{5,15}$/", $nombre)) {
            $this->nombre = strtoupper($nombre);
        }
    }

    public function borrar() {
        if ($this->idPermiso) {
            $consulta = "DELETE permiso WHERE idpermiso = {$this->idPermiso}";
            $resultado = Conexion::getInstancia()->borrar($consulta);
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al permiso");
    }

    public function crear() {
        if ($this->nombre) {
            $consulta = "INSERT INTO permiso VALUES (NULL, '$this->nombre')";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                $this->idPermiso = $resultado[2];
            }
            return $resultado;
        }
        return array(0, "No se recibieron todos los campos obligatorios");
    }

    public function modificar() {
        if ($this->idPermiso && $this->nombre) {
            $consulta = "UPDATE permiso SET nombre = '{$this->nombre}' WHERE idpermiso = {$this->idPermiso}";
            $modificacion = Conexion::getInstancia()->modificar($consulta);
            return $modificacion;
        }
        return array(0, "No se recibieron todos los campos obligatorios");
    }

    public function obtener() {
        if ($this->idPermiso) {
            $consulta = "SELECT * FROM permiso WHERE idpermiso = {$this->idPermiso}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->nombre = $fila['nombre'];
                return array(2, "Se obtuvo la información del permiso correctamente");
            }
            return array(1, "No se obtuvo la información del permiso");
        }
        return array(0, "No se pudo hacer referencia al permiso");
    }

}
