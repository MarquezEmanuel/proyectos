<?php

namespace usuarios\modelos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Rol {

    /** @var integer Identificador del rol en la base de datos */
    private $idRol;

    /** @var string Nombre del rol */
    private $nombre;

    /** @var array() Permisos asociados al rol */
    private $permisos;

    public function __construct($id = NULL, $nombre = NULL, $permisos = NULL) {
        $this->setIdRol($id);
        $this->setNombre($nombre);
        $this->setPermisos($permisos);
    }

    public function getIdRol() {
        return $this->idRol;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getPermisos() {
        return $this->permisos;
    }

    public function setIdRol($idRol) {
        $this->idRol = $idRol;
    }

    public function setNombre($nombre) {
        if (preg_match("/^[A-Za-z ]{5,30}$/", $nombre)) {
            $this->nombre = $nombre;
        }
    }

    public function setPermisos($permisos) {
        $this->permisos = $permisos;
    }

    private function agregarPermiso() {
        if (!empty($this->permisos)) {
            $values = "";
            foreach ($this->permisos as $permiso) {
                $values = "({$this->idRol}, {$permiso}),";
            }
            $consulta = "INSERT INTO rol_permiso VALUES " . substr($values, 0, -1);
            $resultado = Conexion::getInstancia()->insertar($consulta);
            return $resultado[0];
        }
        return array(0, "Se debe indicar al menos un permiso para crear el rol");
    }

    public function borrar() {
        if ($this->idRol) {
            $resultado = $this->quitarPermisos();
            if ($resultado[0] == 2) {
                $consulta = "DELETE FROM rol WHERE idrol = {$this->idRol}";
                $resultado = Conexion::getInstancia()->borrar($consulta);
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al rol");
    }

    public function crear() {
        if ($this->nombre) {
            $consulta = "INSERT INTO rol VALUES (NULL, '$this->nombre')";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                $this->idRol = $resultado[2];
                $resultado = $this->agregarPermiso();
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios");
    }

    public function modificar() {
        if ($this->idRol && $this->nombre) {
            $consulta = "UPDATE rol SET nombre = '{$this->nombre}' WHERE idrol = {$this->idRol}";
            $resultado = Conexion::getInstancia()->modificar($consulta);
            if ($resultado[0] == 2) {
                $borrar = $this->quitarPermisos();
                $anadir = $this->agregarPermiso();
                $exito = array(2, "Se modificó el rol correctamente");
                $error = array(1, "No se modificó el rol");
                $resultado = ($borrar == 2 && $anadir == 2) ? $exito : $error;
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al rol");
    }

    public function obtener() {
        if ($this->idRol) {
            $consulta = "SELECT * FROM rol WHERE idrol = {$this->idRol}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->nombre = $fila['nombre'];
                return $this->obtenerPermisos();
            }
            return array(1, "No se pudo obtener la información del rol");
        }
        return array(0, "No se pudo hacer referencia al rol");
    }

    private function obtenerPermisos() {
        $resultado = Permisos::listarPorRol($this->idRol);
        if (gettype($resultado[0]) == 2) {
            $this->permisos = $resultado[1];
            return array(2, "Se obtuvieron los permisos del rol");
        }
        return $resultado;
    }

    private function quitarPermisos() {
        $consulta = "DELETE FROM rol_permiso WHERE idrol = {$this->idRol}";
        $resultado = Conexion::getInstancia()->borrar($consulta);
        return $resultado[0];
    }

}
