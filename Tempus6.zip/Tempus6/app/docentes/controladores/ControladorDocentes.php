<?php

namespace controladores;

use modelos\Docentes as Docentes;

/**
 * Description of ControladorDocentes
 *
 * @author Emanuel
 */
class ControladorDocentes {

    public function crear() {
        
    }

    public function buscar($nombre) {
        return Docentes::buscar($nombre);
    }

    public function listarUltimosCreados() {
        $limite = 20;
        return Docentes::listarResumenDocente($limite);
    }

}
