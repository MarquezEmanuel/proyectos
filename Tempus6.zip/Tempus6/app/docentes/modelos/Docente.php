<?php

namespace modelos;

/**
 * 
 * paquete: docentes.
 * namespace: modelos.
 * 
 */
class Docente {

    /** @var integer $iddocente */
    private $idDocente;

    /** @var string $nombre */
    private $nombre;

    public function __construct($id = NULL, $nombre = NULL) {
        $this->setIdDocente($id);
        $this->setNombre($nombre);
    }

    public function getIdDocente() {
        return $this->idDocente;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function setIdDocente($idDocente) {
        $this->idDocente = ($idDocente > 0) ? $idDocente : NULL;
    }

    public function setNombre($nombre) {
        if (Util::validarDocenteNombre($nombre)) {
            $this->nombre = Util::convertirCamelCase($nombre);
        }
    }

    public function crear() {
        if ($this->nombre) {
            $consulta = "INSERT INTO docente VALUES (NULL, '{$this->nombre}')";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                $this->idDocente = $resultado[2];
                return $resultado;
            }
            return ($resultado[0] == 1) ? $this->obtenerPorNombre() : $resultado;
        }
        return array(0, "El nombre del docente no cumple con el formato requerido");
    }

    public function obtenerPorIdentificador() {
        if ($this->idDocente) {
            $consulta = "SELECT * FROM docente WHERE iddocente = {$this->idDocente}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idDocente = $fila['iddocente'];
                $this->nombre = $fila['nombre'];
                return array(2, "Se obtuvo la informacion del docente correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al docente");
    }

    private function obtenerPorNombre() {
        if ($this->nombre) {
            $consulta = "SELECT * FROM docente WHERE nombre = '{$this->nombre}'";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idDocente = $fila['iddocente'];
                $this->nombre = $fila['nombre'];
                return array(2, "Se obtuvo la informacion del docente correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al docente");
    }

}
