<?php

namespace docentes\modelos;

use principal\modelos\Conexion as Conexion;
use principal\modelos\Log as Log;
use util\modelos\Util as Util;

/**
 * 
 * @package docentes.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Docente {

    /** @var integer $iddocente */
    private $idDocente;

    /** @var string $nombre */
    private $nombre;

    /**
     * Constructor de clase.
     * @param int $id Identificador del docente.
     * @param string $nombre Nombre del docente.
     */
    public function __construct($id = NULL, $nombre = NULL) {
        $this->setIdDocente($id);
        $this->setNombre($nombre);
    }

    /**
     * Retorna el identificador del docente.
     * @return int Identificador del docente.
     */
    public function getIdDocente() {
        return $this->idDocente;
    }

    /**
     * Retorna el nombre del docente.
     * @return string Nombre del docente.
     */
    public function getNombre() {
        return $this->nombre;
    }

    /**
     * Modifica el identificador del docente solo si es mayor a cero.
     * @param int $idDocente Identificador del docente.
     */
    public function setIdDocente($idDocente) {
        $this->idDocente = ($idDocente > 0) ? $idDocente : NULL;
    }

    /**
     * Modifica el nombre del docente solo si cumple con el formato requerido.
     * @param string $nombre Nombre del docente.
     */
    public function setNombre($nombre) {
        if (Util::validarDocenteNombre($nombre)) {
            $this->nombre = Util::convertirCamelCase($nombre);
        }
    }

    /**
     * Crear nuevo docente. Realiza la creacion del nuevo docente o se obtienen 
     * los datos en caso que ya exista una con el mismo nombre.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    public function crear() {
        if ($this->nombre) {
            $consulta = "INSERT INTO docente VALUES (NULL, '{$this->nombre}')";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                Log::guardarActividad("Se creo el docente {$this->nombre}");
                $this->idDocente = $resultado[2];
                return $resultado;
            }
            return ($resultado[0] == 1) ? $this->obtenerPorNombre() : $resultado;
        }
        return array(0, "El nombre del docente no cumple con el formato requerido");
    }

    /**
     * Obtener informacion del docente a partir de su identificador. Obtiene
     * los datos del docente y se los asigna a los atributos de clase.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    public function obtenerPorIdentificador() {
        if ($this->idDocente) {
            $consulta = "SELECT * FROM docente WHERE iddocente = {$this->idDocente}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idDocente = $fila['iddocente'];
                $this->nombre = $fila['nombre'];
                return array(2, "Se obtuvo la informacion del docente correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al docente");
    }

    /**
     * Obtnener informacion del docente a partir de su nombre. Obtiene los datos 
     * del docente y se los asigna a los atributos de clase.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    private function obtenerPorNombre() {
        if ($this->nombre) {
            $consulta = "SELECT * FROM docente WHERE nombre = '{$this->nombre}'";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idDocente = $fila['iddocente'];
                $this->nombre = $fila['nombre'];
                return array(2, "Se obtuvo la informacion del docente correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al docente");
    }

}
