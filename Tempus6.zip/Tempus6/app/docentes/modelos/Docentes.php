<?php

namespace modelos;

/**
 * 
 * paquete: docentes.
 * namespace: modelos.
 */
class Docentes {

    public static function borrarDocentes() {
        Log::guardarActividad("DOCENTES --> BORRAR DOCENTES");
        $consulta = "DELETE FROM docente";
        $resultado = Conexion::getInstancia()->borrar($consulta);
        return ($resultado[0] == 2) ? $this->reiniciarAutoIncrementador() : $resultado;
    }

    public static function borrarDocentesSinTribunal() {
        $consulta = "DELETE DOC FROM docente DOC JOIN (SELECT iddocente FROM docente "
                . "WHERE iddocente NOT IN (SELECT DISTINCT presidente iddocente "
                . "FROM tribunal UNION SELECT DISTINCT vocal1 iddocente FROM tribunal "
                . "UNION SELECT DISTINCT vocal2 iddocente FROM tribunal "
                . "UNION SELECT DISTINCT suplente iddocente FROM tribunal)) "
                . "CAN ON CAN.iddocente = DOC.iddocente";
        return Conexion::getInstancia()->borrar($consulta);
    }

    public static function buscar($nombre) {
        $expresion = "/^[a-záéíóúñü,. ]{0,60}$/";
        if (preg_match($expresion, mb_strtolower($nombre))) {
            $consulta = "SELECT * FROM docente WHERE nombre LIKE '%{$nombre}%' ORDER BY nombre";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "El nombre de docente no cuple con el formato requerido");
    }

    public static function listarResumenDocentes($limite) {
        if ($limite > 0) {
            $consulta = "SELECT * FROM docente ORDER BY iddocente DESC LIMIT {$limite}";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se estableció un limite válido");
    }

    private function reiniciarAutoIncrementador() {
        Log::guardarActividad("DOCENTES --> REINICIAR AUTO INCREMENTADOR");
        $consulta = "ALTER TABLE docente AUTO_INCREMENT = 1";
        return Conexion::getInstancia()->borrar($consulta);
    }

}
