<?php

namespace modelos;

/**
 * 
 */
class Aula {

    /** @var integer Identificador del aula en la base de datos. */
    private $idAula;

    /** @var string Nombre del aula. */
    private $nombre;

    /** @var string Sector donde se ubica el aula. */
    private $sector;
    private $clases;
    private $mesas;

    public function __construct($id = NULL, $sector = NULL, $nombre = NULL) {
        $this->setIdAula($id);
        $this->setSector($sector);
        $this->setNombre($nombre);
    }

    public function getIdAula() {
        return $this->idAula;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getSector() {
        return $this->sector;
    }

    public function getClases() {
        return $this->clases;
    }

    public function getMesas() {
        return $this->mesas;
    }

    public function setIdAula($idAula) {
        $this->idAula = ($idAula > 0) ? $idAula : NULL;
    }

    public function setNombre($nombre) {
        if (Util::validarAulaNombre($nombre)) {
            $this->nombre = Util::convertirCamelCase($nombre);
        }
    }

    public function setSector($sector) {
        if (Util::validarAulaSector($sector)) {
            $this->sector = Util::convertirCamelCase($sector);
        }
    }

    public function borrar() {
        if ($this->idAula) {
            $consulta = "DELETE FROM aula WHERE idaula = {$this->idAula}";
            return Conexion::getInstancia()->borrar($consulta);
        }
        return array(1, "No se pudo hacer referencia al aula");
    }

    public function crear() {
        if ($this->nombre && $this->sector) {
            $consulta = "INSERT INTO aula VALUES (NULL,'{$this->nombre}', '{$this->sector}')";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                $this->idaula = $resultado[2];
                return $resultado;
            }
            if ($resultado[0] == 1) {
                return $this->obtenerPorNombreSector();
            }
            return $resultado;
        }
        return array(1, "No se recibieron los campos obligatorios o no cumplen el formato requerido");
    }

    public function modificar() {
        if ($this->idAula && $this->nombre && $this->sector) {
            $consulta = "UPDATE aula SET nombre = '{$this->nombre}', sector = '{$this->sector}' "
                    . "WHERE idaula = {$this->idAula}";
            return Conexion::getInstancia()->modificar($consulta);
        }
        return array(1, "No se recibieron los campos obligatorios o no cumplen el formato requerido");
    }

    public function obtener() {
        if ($this->idAula) {
            $consulta = "SELECT * FROM aula WHERE idaula = {$this->idAula}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0] == "array")) {
                $fila = $resultado[0];
                $this->nombre = $fila['nombre'];
                $this->sector = $fila['sector'];
                return array(2, NULL);
            }
            return $resultado;
        }
        return array(1, "No se pudo hacer referencia al aula");
    }

    public function obtenerClases() {
        if ($this->idAula) {
            $consulta = "SELECT ca.codigo, ca.nombre carrera, ma.idasignatura, "
                    . "ma.nombre asignatura, cl.* FROM cursada cu "
                    . "INNER JOIN asignatura ma ON ma.idasignatura = cu.idasignatura "
                    . "INNER JOIN carrera ca ON ca.codigo = cu.idcarrera "
                    . "INNER JOIN clase cl ON cl.idclase = cu.idclase "
                    . "WHERE cl.idaula = {$this->idAula} ORDER BY cl.dia, cl.desde";
            $this->clases = Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(1, "No se pudo hacer referencia al aula");
    }

    public function obtenerMesas() {
        if ($this->idAula) {
            $consulta = "SELECT me.idmesa, ma.idasignatura, ma.nombre asignatura, ca.codigo, ca.nombre carrera, lp.idllamado idpl, lp.fecha fechapl, "
                    . "lp.hora horapl, lp.fechamod fechamodpl, ls.idllamado idsl, ls.fecha fechasl, ls.hora horasl, ls.fechamod fechamodsl "
                    . "FROM mesa_examen me "
                    . "INNER JOIN asignatura ma ON ma.idasignatura = me.idasignatura "
                    . "INNER JOIN carrera ca ON ca.codigo = me.idcarrera "
                    . "LEFT JOIN llamado lp ON lp.idllamado = me.primero "
                    . "LEFT JOIN llamado ls ON ls.idllamado = me.segundo "
                    . "WHERE lp.idaula = {$this->idAula} OR ls.idaula = {$this->idAula}";
            $this->mesas = Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(1, "No se pudo hacer referencia al aula");
    }

    private function obtenerPorNombreSector() {
        if ($this->nombre && $this->sector) {
            $consulta = "SELECT * FROM aula WHERE nombre = '{$this->nombre}' AND sector = '{$this->sector}'";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idAula = $fila['idaula'];
                $this->nombre = $fila['nombre'];
                $this->sector = $fila['sector'];
                return array(2, "Se obtuvieron los datos correctamente");
            }
            return $resultado;
        }
        return array(1, "No se recibieron los campos obligatorios o no cumplen el formato requerido");
    }

}
