<?php

namespace aulas\modelos;

use principal\modelos\Conexion as Conexion;
use principal\modelos\Log as Log;
use util\modelos\Util as Util;

/**
 * 
 * @package aulas.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Aula {

    /** @var integer Identificador del aula en la base de datos. */
    private $idAula;

    /** @var string Nombre del aula. */
    private $nombre;

    /** @var string Sector donde se ubica el aula. */
    private $sector;

    /** @var array Horarios de clase asociados al aula */
    private $clases;

    /** @var array Mesas de examen asociadas al aula */
    private $mesas;

    public function __construct($id = NULL, $sector = NULL, $nombre = NULL) {
        $this->setIdAula($id);
        $this->setSector($sector);
        $this->setNombre($nombre);
    }

    public function getIdAula() {
        return $this->idAula;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getSector() {
        return $this->sector;
    }

    public function getClases() {
        return $this->clases;
    }

    public function getMesas() {
        return $this->mesas;
    }

    public function setIdAula($idAula) {
        $this->idAula = ($idAula > 0) ? $idAula : NULL;
    }

    public function setNombre($nombre) {
        if (Util::validarAulaNombre($nombre)) {
            $this->nombre = Util::convertirCamelCase($nombre);
        }
    }

    public function setSector($sector) {
        if (Util::validarAulaSector($sector)) {
            $this->sector = Util::convertirCamelCase($sector);
        }
    }

    public function setClases($clases) {
        $this->clases = $clases;
    }

    public function setMesas($mesas) {
        $this->mesas = $mesas;
    }

    public function borrar() {
        if ($this->idAula) {
            $consulta = "DELETE FROM aula WHERE idaula = {$this->idAula}";
            return Conexion::getInstancia()->borrar($consulta);
        }
        return array(1, "No se pudo hacer referencia al aula");
    }

    public function crear() {
        if ($this->nombre && $this->sector) {
            $consulta = "INSERT INTO aula VALUES (NULL, '{$this->nombre}', '{$this->sector}')";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                Log::guardarActividad("Se creo el aula ({$this->nombre}, {$this->sector})");
                $this->idAula = $resultado[2];
                return $resultado;
            }
            return ($resultado[0] == 1) ? $this->obtenerPorDatos() : $resultado;
        }
        return array(0, "Los campos no cumplen el formato requerido");
    }

    public function modificar() {
        if ($this->idAula && $this->nombre && $this->sector) {
            $consulta = "UPDATE aula SET nombre = '{$this->nombre}', sector = '{$this->sector}' "
                    . "WHERE idaula = {$this->idAula}";
            return Conexion::getInstancia()->modificar($consulta);
        }
        return array(0, "No se recibieron los campos obligatorios o no cumplen el formato requerido");
    }

    public function obtenerClases() {
        if ($this->idAula) {
            $consulta = "SELECT ca.codigo, ca.nombre carrera, ma.idasignatura, "
                    . "ma.nombre asignatura, cl.* FROM cursada cu "
                    . "INNER JOIN asignatura ma ON ma.idasignatura = cu.idasignatura "
                    . "INNER JOIN carrera ca ON ca.codigo = cu.idcarrera "
                    . "INNER JOIN clase cl ON cl.idclase = cu.idclase "
                    . "WHERE cl.idaula = {$this->idAula} ORDER BY cl.dia, cl.desde";
            $this->clases = Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(1, "No se pudo hacer referencia al aula");
    }

    public function obtenerMesasExamen() {
        $resultado = MesasExamen::listarMesasDeAula($this->idAula);
        if ($resultado[0] == 2) {
            $this->mesas = $resultado[1];
            return array(2, "Se obtuvieron las mesas de examen para el aula");
        }
        return $resultado;
    }

    public function obtenerPorIdentificador() {
        if ($this->idAula) {
            $consulta = "SELECT * FROM aula WHERE idaula = {$this->idAula}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idAula = $fila['idaula'];
                $this->nombre = $fila['nombre'];
                $this->sector = $fila['sector'];
                return array(2, "Se obtuvo la informacion del aula correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al aula");
    }

    private function obtenerPorDatos() {
        if ($this->nombre && $this->sector) {
            $consulta = "SELECT * FROM aula WHERE nombre = '{$this->nombre}' AND sector = '{$this->sector}'";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->idAula = $fila['idaula'];
                $this->nombre = $fila['nombre'];
                $this->sector = $fila['sector'];
                return array(2, "Se obtuvieron los datos correctamente");
            }
            return $resultado;
        }
        return array(0, "Los campos no cumplen el formato requerido");
    }

}
