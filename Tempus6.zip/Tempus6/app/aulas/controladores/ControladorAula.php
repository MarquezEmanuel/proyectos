<?php

namespace controladores;

/**
 * paquete: aulas.
 * namespace: controladores.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga017@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ControladorAula {

    public function borrar($idAula) {
        $aula = new Aula($idAula);
        $resultado = $aula->borrar();
        $this->descripcion = $aula->getDescripcion();
        return $resultado;
    }

    public function buscar($campo, $valor) {
        $aulas = new Aulas();
        $resultado = $aulas->buscar($campo, $valor);
        $this->descripcion = $aulas->getDescripcion();
        return $resultado;
    }

    public function crear($sector, $nombre) {
        $aula = new Aula(NULL, $sector, $nombre);
        $creacion = $aula->crear();
        $this->descripcion = $aula->getDescripcion();
        return $creacion;
    }

    public function listar() {
        return $this->aulas->listar();
    }

    public function listarUltimasCreadas() {
        $aulas = new Aulas();
        $resultado = $aulas->listarUltimasCreadas();
        $this->descripcion = $aulas->getDescripcion();
        return $resultado;
    }

    public function listarAulasDisponibles($dia, $desde, $hasta, $nombre) {
        $aulas = new Aulas();
        $resultado = $aulas->listarAulasDisponibles($dia, $desde, $hasta, $nombre);
        $this->descripcion = $aulas->getDescripcion();
        return $resultado;
    }

    public function listarHorariosClase($id) {
        $aulas = new Aulas();
        $resultado = $aulas->listarHorariosClase($id);
        $this->descripcion = $aulas->getDescripcion();
        return $resultado;
    }

    public function listarInforme($modulo, $disponibleCursada, $dia, $desde, $hasta, $disponibleMesa, $fecha, $hora) {
        $aulas = new Aulas();
        if ($modulo == "CUR") {
            $resultado = $aulas->listarInformeCursada($disponibleCursada, $dia, $desde, $hasta);
        } else {
            $resultado = $aulas->listarInformeMesa($disponibleMesa, $fecha, $hora);
        }
        $this->descripcion = $aulas->getDescripcion();
        return $resultado;
    }

    public function listarMesasExamen($id) {
        $aulas = new Aulas();
        $resultado = $aulas->listarMesasExamen($id);
        $this->descripcion = $aulas->getDescripcion();
        return $resultado;
    }

    public function modificar($id, $sector, $nombre) {
        $aula = new Aula($id, $sector, $nombre);
        $modificacion = $aula->modificar();
        $this->descripcion = $aula->getDescripcion();
        return $modificacion;
    }

}
