<?php

require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';

AutoCargador::cargarModulos();

if (isset($_POST['modulo'])) {
    $controlador = new ControladorAula();
    $modulo = $_POST['modulo'];
    if ($modulo == "CUR") {
        $disponibleCursada = $_POST['disponibleCursada'];
        $dia = $_POST['dia'];
        $desde = $_POST['desde'];
        $hasta = $_POST['hasta'];
        $disponibleMesa = $hora = $fecha = NULL;
    } else {
        $disponibleCursada = $dia = $desde = $hasta = NULL;
        $disponibleMesa = $_POST['disponibleMesa'];
        $fecha = $_POST['fecha'];
        $hora = $_POST['horaMesa'];
    }
    $aulas = $controlador->listarInforme($modulo, $disponibleCursada, $dia, $desde, $hasta, $disponibleMesa, $fecha, $hora);
    if (gettype($aulas) == "object") {
        $filas = "";
        while ($aula = $aulas->fetch_assoc()) {
            $filas .= "
            <tr>
                <td class='align-middle'>{$aula['sector']}</td>
                <td class='align-middle'>" . utf8_encode($aula['nombre']) . "</td>
            </tr>";
        }
        $cuerpo = '
            <div class="table-responsive mt-4">
                <table id="tablaInformeAulas" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th title="Nombre del sector">Sector</th>
                            <th title="Nombre del aula">Nombre</th>
                        </tr>
                    </thead>
                    <tbody>' . $filas . '</tbody>
                </table>
            </div>';
    } else {
        $cuerpo = ControladorHTML::mostrarAlertaResultadoOperacion($aulas, $controlador->getDescripcion());
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = ControladorHTML::mostrarAlertaResultadoOperacion(0, $mensaje);
}

$titulo = "Resultado de la búsqueda";
$resultado = ControladorHTML::mostrarCardResultadoBusqueda($titulo, $cuerpo);
echo $resultado;

