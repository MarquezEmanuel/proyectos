<?php

namespace carreras\modelos;

use principal\modelos\Conexion as Conexion;

/**
 * paquete: carreras.
 * namespace: modelos.
 * 
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Carreras {

    /**
     */
    public function borrar() {
        $consulta = "DELETE FROM carrera WHERE codigo NOT IN "
                . "(SELECT DISTINCT idcarrera FROM asignatura_carrera)";
        return Conexion::getInstancia()->borrar($consulta);
    }

    /**
     * Realiza la busqueda de carreras a partir del nombre. Se puede indicar el
     * nombre completo o parte del nombre de la carrera a buscar.
     * @param string $nombre Nombre de la carrera a buscar.
     * @return integer 0 si falla la consulta, 1 si no hay resultado o resource.
     */
    public static function buscar(string $nombre) {
        $expresion = "/^[a-záéíóúñü,. ]{0,60}$/";
        if (preg_match($expresion, mb_strtolower($nombre))) {
            $consulta = "SELECT ca.*, (CASE WHEN ma.cantidad IS NULL THEN 0 ELSE ma.cantidad END) cantidad "
                    . "FROM carrera ca "
                    . "LEFT JOIN (SELECT idcarrera, COUNT(idasignatura) cantidad "
                    . "FROM asignatura_carrera GROUP BY idcarrera) ma ON ca.codigo = ma.idcarrera "
                    . "WHERE ca.nombre LIKE '%{$nombre}%'";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "El nombre de la carrera no cumple con el formato requerido");
    }

    /**
     * Listar las carreras de una asignatura ordenadas por anio y nombre.
     */
    public static function listarCarrerasDeAsignatura($idAsignatura) {
        if ($idAsignatura > 0) {
            $consulta = "SELECT ac.anio, ac.idcarrera codigo, ca.nombre "
                    . "FROM asignatura_carrera ac "
                    . "LEFT JOIN carrera ca ON ca.codigo = ac.idcarrera "
                    . "WHERE ac.idasignatura = {$idAsignatura} ORDER BY ac.anio, ca.nombre";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se pudo hacer referencia a la asignatura");
    }

    /**
     * Realiza la busqueda de todas las carreras que tengan al menos una asignatura
     * sin cursada. El objetivo es que se seleccionen solo las carreras que
     * puedan tener asignaturas sin cursada al momento de crear o modificar un
     * horario de cursada.
     * @param string $nombreCarrera Nombre de la carrera.
     * @return integer 0 si la consulta falla, 1 si no hay resultados o resource.
     */
    public static function listarCarrerasSinCursada($nombreCarrera) {
        $expresion = "/^[a-záéíóúñü,. ]{0,60}$/";
        if (preg_match($expresion, mb_strtolower($nombreCarrera))) {
            $consulta = "SELECT ca.* FROM carrera ca LEFT JOIN "
                    . "(SELECT COUNT(idasignatura) asignaturas, idcarrera FROM asignatura_carrera GROUP BY idcarrera) asi "
                    . "ON asi.idcarrera = ca.codigo LEFT JOIN "
                    . "(SELECT COUNT(DISTINCT idasignatura) cursadas, idcarrera FROM cursada GROUP BY idcarrera) cur "
                    . "ON cur.idcarrera = ca.codigo "
                    . "WHERE asi.asignaturas > 0 AND (cur.cursadas < asi.asignaturas OR cur.cursadas IS NULL) AND "
                    . "ca.nombre LIKE '%{$nombreCarrera}%'";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "El nombre de la carrera no cumple con el formato requerido");
    }

    /**
     * Realiza la busqueda de todas las carreras que no tengan al menos una 
     * asignatura sin mesa. El objetivo es mostrar solo las carreras que cumplan
     * esta condicion al momento de realizar la creacion o modificacion de una
     * mesa de examen.
     * @param string $nombreCarrera Nombre de la carrera.
     * @return integer 0 si la consulta falla, 1 si no hay resultados o resource.
     */
    public static function listarCarrerasSinMesa($nombreCarrera) {
        $expresion = "/^[a-záéíóúñü,. ]{0,60}$/";
        if (preg_match($expresion, mb_strtolower($nombreCarrera))) {
            $consulta = "SELECT ca.* FROM carrera ca LEFT JOIN "
                    . "(SELECT COUNT(idasignatura) asignaturas, idcarrera "
                    . "FROM asignatura_carrera GROUP BY idcarrera) asi "
                    . "ON asi.idcarrera = ca.codigo LEFT JOIN "
                    . "(SELECT COUNT(idasignatura) mesas, idcarrera FROM mesa_examen "
                    . "GROUP BY idcarrera) mes ON mes.idcarrera = ca.codigo "
                    . "WHERE asi.asignaturas > 0 AND (mes.mesas < asi.asignaturas OR mes.mesas IS NULL) "
                    . "AND ca.nombre LIKE '%{$nombreCarrera}%'";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "El nombre de la carrera no cumple con el formato requerido");
    }

    /**
     * 
     */
    public static function listarResumenCarreras($limite) {
        if ($limite > 0) {
            $consulta = "SELECT ca.*, (CASE WHEN ma.cantidad IS NULL THEN 0 ELSE ma.cantidad END) cantidad "
                    . "FROM carrera ca LEFT JOIN (SELECT idcarrera, COUNT(idasignatura) cantidad "
                    . "FROM asignatura_carrera GROUP BY idcarrera) ma ON ca.codigo = ma.idcarrera "
                    . "ORDER BY ca.codigo LIMIT {$limite}";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        return array(0, "No se estableció un limite válido");
    }

}
