<?php

namespace modelos;

/**
 * 
 * paquete: carreras.
 * namespace: modelos;
 */
class Carrera {

    /** @var integer $codigo Codigo de la carrera. */
    private $codigo;

    /** @var string $nombre Nombre de la carrera. */
    private $nombre;

    /** @var array $asignaturas Arreglo de las asignaturas de la carrera */
    private $asignaturas;

    public function __construct($codigo = NULL, $nombre = NULL) {
        $this->setCodigo($codigo);
        $this->setNombre($nombre);
    }

    public function getCodigo() {
        return $this->codigo;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getAsignaturas() {
        return $this->asignaturas;
    }

    public function setCodigo($codigo) {
        if (Util::validarCarreraCodigo($codigo)) {
            $this->codigo = $codigo;
        }
    }

    public function setNombre($nombre) {
        if (Util::validarCarreraNombre($nombre)) {
            $this->nombre = Util::convertirCamelCase($nombre);
        }
    }

    public function setAsignaturas($asignaturas) {
        $this->asignaturas = $asignaturas;
    }

    public function agregarAsignatura($idAsignatura, $anio) {
        if ($this->codigo && $idAsignatura && $anio) {
            $existe = $this->verificarRelacion($idAsignatura);
            if ($existe == 1) {
                $values = "({$idAsignatura}, {$this->codigo}, {$anio})";
                $creacion = Conexion::getInstancia()->insertar("asignatura_carrera", $values);
                $this->descripcion = Conexion::getInstancia()->getDescripcion();
                return $creacion;
            }
            return $existe;
        }
        $this->descripcion = "No se recibieron los campos obligatorios o no cumplen el formato requerido";
        return 1;
    }

    public function crear() {
        if ($this->codigo && $this->nombre) {
            $existe = $this->verificarExistencia();
            if ($existe == 1) {
                $values = "($this->codigo, '$this->nombre')";
                $creacion = Conexion::getInstancia()->insertar("carrera", $values);
                $this->descripcion = Conexion::getInstancia()->getDescripcion();
                return $creacion;
            }
            return $existe;
        }
        $this->descripcion = "No se recibieron los campos obligatorios o no cumplen el formato requerido";
        return 1;
    }

    public function obtener() {
        if ($this->codigo) {
            $consulta = "SELECT * FROM carrera WHERE codigo = {$this->codigo}";
            $fila = Conexion::getInstancia()->obtener($consulta);
            if (!is_null($fila)) {
                $this->nombre = $fila['nombre'];
                $this->asignaturas = $this->obtenerAsignaturas();
                return 2;
            }
            $this->descripcion = Conexion::getInstancia()->getDescripcion();
            return 1;
        }
        $this->descripcion = "No se pudo hacer referencia a la carrera";
        return 1;
    }

    public function obtenerAsignaturas() {
        if ($this->codigo) {
            $consulta = "SELECT ma.*, ac.anio "
                    . "FROM asignatura_carrera ac "
                    . "INNER JOIN asignatura ma ON ma.idasignatura = ac.idasignatura "
                    . "WHERE idcarrera = {$this->codigo} ORDER BY ac.anio ASC, ma.nombre ASC";
            return Conexion::getInstancia()->seleccionar($consulta);
        }
        $this->descripcion = "No se pudo hacer referencia a la carrera";
        return 1;
    }

    private function verificarExistencia() {
        $consulta = "SELECT codigo FROM carrera WHERE codigo = {$this->codigo} OR nombre = '{$this->nombre}'";
        $resultado = Conexion::getInstancia()->obtener($consulta);
        $this->descripcion = Conexion::getInstancia()->getDescripcion();
        if (gettype($resultado) == "array") {
            $this->descripcion = "Se verificó la existencia de la carrera";
            $this->idAsignatura = $resultado['codigo'];
            return 2;
        }
        return $resultado;
    }

    private function verificarRelacion($idAsignatura) {
        $consulta = "SELECT idcarrera FROM asignatura_carrera WHERE idcarrera = {$this->codigo} AND idasignatura = {$idAsignatura}";
        $resultado = Conexion::getInstancia()->obtener($consulta);
        $this->descripcion = Conexion::getInstancia()->getDescripcion();
        if (gettype($resultado) == "array") {
            $this->descripcion = "Se verificó la existencia de la relación entre carrera y asignatura";
            return 2;
        }
        return $resultado;
    }

}
