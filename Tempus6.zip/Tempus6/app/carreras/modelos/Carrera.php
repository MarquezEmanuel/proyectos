<?php

namespace carreras\modelos;

use asignaturas\modelos\Asignaturas as Asignaturas;
use principal\modelos\Conexion as Conexion;
use principal\modelos\Log as Log;
use util\modelos\Util as Util;

/**
 * @package carreras.
 *
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class Carrera {

    /** @var integer $codigo Codigo de la carrera. */
    private $codigo;

    /** @var string $nombre Nombre de la carrera. */
    private $nombre;

    /** @var array $asignaturas Arreglo de las asignaturas de la carrera */
    private $asignaturas;

    /**
     * Constructor de clase.
     */
    public function __construct($codigo = NULL, $nombre = NULL, $asignaturas = NULL) {
        $this->setCodigo($codigo);
        $this->setNombre($nombre);
        $this->setAsignaturas($asignaturas);
    }

    /**
     * Retorna el codigo de la carrera.
     * @return int Codigo de la carrera.
     */
    public function getCodigo() {
        return $this->codigo;
    }

    /**
     * Retorna el nombre de la carrera.
     * @return string Nombre de la carrera.
     */
    public function getNombre() {
        return $this->nombre;
    }

    /**
     * Retorna las asignaturas de la carrera.
     * @return array Arreglo de asignaturas asocidadas a la carrera.
     */
    public function getAsignaturas() {
        return $this->asignaturas;
    }

    /**
     * Modifica el codigo de la carrera solo si cumple el formato requerido.
     * @param int @codigo Codigo de carrera.
     */
    public function setCodigo($codigo) {
        if (Util::validarCarreraCodigo($codigo)) {
            $this->codigo = $codigo;
        }
    }

    /**
     * Modifica el nombre de la carrera solo si cumple el formato requerido.
     * @param string $nombre Nombre de la carrera.
     */
    public function setNombre($nombre) {
        if (Util::validarCarreraNombre($nombre)) {
            $this->nombre = Util::convertirCamelCase($nombre);
        }
    }

    /**
     * Modifica el arreglo de asignaturas asociadas a la carrera.
     * @param array $asignaturas Asignaturas de la carrera.
     */
    public function setAsignaturas($asignaturas) {
        $this->asignaturas = $asignaturas;
    }

    /**
     * Crear nueva carrera. Realiza la creacion de la nueva carrera o se obtienen
     * los datos en caso que ya exista una con el mismo codigo o nombre. Ademas, 
     * se realiza la creacion de las asignaturas asociadas, en caso de tener, junto
     * con las relaciones entre la asignatura y la carrera.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    public function crear() {
        if ($this->codigo && $this->nombre) {
            $consulta = "INSERT INTO carrera VALUES ($this->codigo, '$this->nombre')";
            $resultado = Conexion::getInstancia()->insertar($consulta);
            if ($resultado[0] == 2) {
                Log::guardarActividad("Se creo la carrera ({$this->codigo}, {$this->nombre})");
                return $this->crearAsignaturas();
            }
            return ($resultado[0] == 1) ? $this->obtenerPorDatos() : $resultado;
        }
        return array(0, "Los campos para crear la carrera no cumplen el formato requerido");
    }

    /**
     * Crear asignaturas asociadas a la carrera. Realiza la creacion de cada una
     * de las asignaturas del arreglo. Si el arreglo no contiene asignaturas solo
     * se retorna el mensaje de exito. Cuando hay asignaturas, se crea cada una y 
     * luego se hace la asociacion con la carrera por anio.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    private function crearAsignaturas() {
        $resultado = array(2, "Se creó la carrera correctamente");
        if ($this->asignaturas && (count($this->asignaturas) > 0)) {
            $asignaturas = $this->asignaturas;
            foreach ($asignaturas as $asignaturaCarrera) {
                $asignatura = $asignaturaCarrera->getAsignatura();
                $crear = $asignatura->crear();
                if ($crear[0] == 2) {
                    $agregar = $asignaturaCarrera->agregarAsignatura();
                    $resultado = ($agregar[0] == 2) ? $resultado : array(1, "No se creó la carrera");
                } else {
                    $resultado = array(1, "No se creó la carrera");
                }
            }
        }
        return $resultado;
    }

    /**
     * Obtener informacion de la carrera a partir de su identificador. Obtiene
     * los datos de la carrera y se los asigna a los atributos de clase.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    public function obtenerPorIdentificador() {
        if ($this->codigo) {
            $consulta = "SELECT * FROM carrera WHERE codigo = {$this->codigo}";
            $resultado = Conexion::getInstancia()->obtener($consulta);
            if (gettype($resultado[0]) == "array") {
                $fila = $resultado[0];
                $this->codigo = $fila['codigo'];
                $this->nombre = $fila['nombre'];
                return array(2, "Se obtuvo la información de la carrera");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la carrera");
    }

    /**
     * Obtener el listado de asignaturas asociadas a la carrera. Obtiene los datos 
     * de la asignatura junto con el anio en que se dicta la misma y se asigna al 
     * atributo asignaturas.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    public function obtenerAsignaturas() {
        $resultado = Asignaturas::listarAsignaturasDeCarrera($this->codigo);
        if ($resultado[0] == 2) {
            $this->asignaturas = $resultado[1];
            return array(2, "Se obtuvieron las asignaturas de la carrera");
        }
        return $resultado;
    }

    /**
     * Obtener los datos de la carrera por su codigo o nombre. Obtiene el codigo
     * de la carrera o su nombre cuando cualquiera de los dos coincida con alguna
     * existente.
     * @return array Arreglo de dos posiciones [codigo y mensaje].
     */
    private function obtenerPorDatos() {
        $consulta = "SELECT codigo, nombre FROM carrera WHERE codigo = {$this->codigo} OR nombre = '{$this->nombre}'";
        $resultado = Conexion::getInstancia()->obtener($consulta);
        if (gettype($resultado[0]) == "array") {
            $fila = $resultado[0];
            $this->codigo = $fila['codigo'];
            $this->nombre = $fila['nombre'];
            return array(2, "Se obtuvo la carrera correctamente");
        }
        return $resultado;
    }

}
