<?php

namespace carreras\controadores;

use carreras\modelos\Carrera as Carrera;
use carreras\modelos\Carreras as Carreras;

/**
 * Description of ControladorCarreras
 *
 * @author Oyarzo Mariela <marielaoyarzo89@gmail.com>
 * @author Quiroga Sandra <squiroga17@gmail.com>
 * @author Marquez Emanuel <e.m.a-13@hotmail.com>
 */
class ControladorCarreras {

    public function agregarAsignatura($codigo, $idAsignatura, $anio) {
        $carrera = new Carrera($codigo);
        $resultado = $carrera->agregarAsignatura($idAsignatura, $anio);
        $this->descripcion = $carrera->getDescripcion();
        return $resultado;
    }

    public function buscar($nombreCarrera) {
        $resultado = Carreras::buscar($nombreCarrera);
        return $resultado;
    }

    public function crear($codigo, $nombre, $asignaturas) {
        if (Conexion::getInstancia()->iniciarTransaccion()) {
            $carrera = new Carrera($codigo, $nombre, $asignaturas);
            $resultado = $carrera->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            Conexion::getInstancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function listarResumenCarreras($limite) {
        $resultado = Carreras::listarResumenCarreras($limite);
        return $resultado;
    }

    public function listarCarrerasSinCursada($nombreCarrera) {
        $resultado = Carreras::listarCarrerasSinCursada($nombreCarrera);
        return $resultado;
    }

    public function listarSinMesa($nombreCarrera) {
        $resultado = Carreras::listarCarrerasSinMesa($nombreCarrera);
        return $resultado;
    }

}
