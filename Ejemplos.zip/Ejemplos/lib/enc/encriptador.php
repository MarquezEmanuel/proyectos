<?php
include_once '../../app/principal/modelos/Encriptador.php';

$resultado = "";
if (isset($_POST['formulario'])) {
    $key = $_POST['key'];
    $operacion = $_POST['operacion'];
    $cadena = $_POST['cadena'];
    $encriptador = new Encriptador();
    $resultado = "CLAVE: <b>{$key}</b> <br><br> CADENA: <b>{$cadena}</b> <br><br> <p style='color: blue'>RESULTADO: <b> ";
    $resultado .= ($operacion == 1) ? $encriptador->encriptar($cadena, $key) : $encriptador->desencriptar($cadena, $key);
    $resultado .= "</b></p>";
    unset($_POST);
}
?>
<html>
    <body>
        <form method="POST">
            <input type="hidden" name="formulario" id="formulario" value="true">
            <h3><b>ENCRIPTAR CADENA DE TEXTO</b></h3>
            <table style="width: 80%">
                <tr>
                    <td><label>OPERACIÓN: </label></td>
                    <td>
                        <select name="operacion" id="operacion" style="width: 100%" >
                            <option value="1">ENCRIPTAR</option>
                            <option value="2">DESENCRIPTAR</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><label>CLAVE: </label></td>
                    <td><input type="text" name="key" id="key" style="width: 100%" required></td>
                </tr>
                <tr>
                    <td><label>PALABRA: </label></td>
                    <td><input type="text" name="cadena" id="cadena" style="width: 100%"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="ENVIAR"></td>
                </tr>
            </table>
            <br>
            <p><?= $resultado; ?></p>
        </form>
    </body>
</html>