<?php

# CONFIGURACION DE LA BASE DE DATOS
$g_db_hostname = 'TnpOZW13dExOSmYyZi9ZalYyUDFOZz09OjoewcdJMzoxVrsG/dTXdvEF';
$g_db_basename = 'OVNreU02VnhYb2MvVnhIUzVtVmZKZz09Ojp9NGlSUT5LsdHRREQwuWyl';
$g_db_username = 'cUxuOUtEWEVlYU94VzFqMFFmTklZZz09Ojpce9DB9vBXNGrRFuiYHMo1';
$g_db_password = 'WTkrb2Y0djdSb0NWQ2c0ZFdaUk9TZz09OjpuC80jxSSAkxZ7ld6ZTzrh';

# CONFIGURACION DE ACTIVE DIRECTORY
$g_ldap_hostname = '192.168.250.150';
$g_ldap_port = 389;
$g_ldap_domain = 'desarrollo';

$g_crypto_key = 'ZLorGtdeAahEWrMCmZ/j88JjqqrEz9BYqeBXQV0Zbck=';


