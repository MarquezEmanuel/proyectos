<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Sitio;

$cuerpo = $boton = "";
if (isset($_POST['idSitio'])) {
    $id = $_POST['idSitio'];
    $sitio = new Sitio($id);
    $resultado = $sitio->obtener();
    if ($resultado[0] == 2) {

        $tipo = $sitio->getTipo();
        $nombre = $sitio->getNombre();
        $provincia = $sitio->getProvincia();
        $ciudad = $sitio->getCiudad();
        $codigoPostal = $sitio->getCodigoPostal();
        $direccion = $sitio->getDireccion();
        $origen = $sitio->getOrigen();
        $estado = $sitio->getEstado();

        $opcionTipo = ($tipo == "CPP") ? '<option value="CPP" selected>Centro de Procesamiento Principal</option>' : '<option value="CPP">Centro de Procesamiento Principal</option>';
        $opcionTipo .= ($tipo == "CPA") ? '<option value="CPA" selected>Centro de Procesamiento Alternativo</option>' : '<option value="CPA">Centro de Procesamiento Alternativo</option>';
        $opcionTipo .= ($tipo == "URP") ? '<option value="URP" selected>Centro de Resguardo Principal</option>' : '<option value="URP">Centro de Resguardo Principal</option>';
        $opcionTipo .= ($tipo == "URS") ? '<option value="URS" selected>Centro de Resguardo Secundario</option>' : '<option value="URS">Centro de Resguardo Secundario</option>';
        $opcionTipo .= ($tipo == "Sucursal") ? '<option value="Sucursal" selected>Sucursal</option>' : '<option value="Sucursal">Sucursal</option>';

        if ($origen == "Propio") {
            $opcionOrigen = '<option value="Propio" selected>Propio</option>';
            $opcionOrigen .= '<option value="Tercerizado">Tercerizado</option>';
        } else {
            $opcionOrigen = '<option value="Propio">Propio</option>';
            $opcionOrigen .= '<option value="Tercerizado" selected>Tercerizado</option>';
        }

        if ($estado == 'Activo') {
            $opcionesEstado = '<option value="Activo" selected>Activo</option>';
            $opcionesEstado .= '<option value="Inactivo">Inactivo</option>';
        } else {
            $opcionesEstado = '<option value="Activo">Activo</option>';
            $opcionesEstado .= '<option value="Inactivo" selected>Inactivo</option>';
        }

        $cuerpo = '
            <div class="form-row">
                <label for="codigo" class="col-sm-2 col-form-label">* Código:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="codigo" id="codigo" maxlength="5"
                           value="' . $id . '"
                           placeholder="Código del sitio">
                </div>
                <label for="tipo" class="col-sm-2 col-form-label">* Tipo:</label>
                <div class="col">
                    <select class="form-control mb-2" 
                            name="tipo" id="tipo">' . $opcionTipo . '</select>
                </div>
            </div>
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" maxlength="50"
                           value="' . $nombre . '"
                           placeholder="Nombre del sitio">
                </div>
                <label for="provincia" class="col-sm-2 col-form-label">* Provincia</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="provincia" id="provincia" maxlength="50"
                           value="' . $provincia . '"
                           placeholder="Nombre de la provincia">
                </div>
            </div>
            <div class="form-row">
                <label for="localidad" class="col-sm-2 col-form-label">* Localidad:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="localidad" id="localidad" maxlength="50"
                           value="' . $ciudad . '"
                           placeholder="Nombre de la localidad">
                </div>
                <label class="col-sm-2 col-form-label">* Código postal:</label>
                <div class="col">
                    <input type="number" class="form-control mb-2" 
                           name="codigoPostal" id="codigoPostal" maxlength="50"
                           value="' . $codigoPostal . '"
                           placeholder="Código postal">
                </div>
            </div>
            <div class="form-row">
                <label for="direccion" class="col-sm-2 col-form-label">* Dirección:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="direccion" id="direccion" maxlength="50"
                           value="' . $direccion . '"
                           placeholder="Dirección">
                </div>
                <label class="col-sm-2 col-form-label">* Origen:</label>
                <div class="col">
                    <select class="form-control mb-2" 
                            name="origen" id="origen">' . $opcionOrigen . '</select>
                </div>
            </div>
            <div class="form-row">
                <label for="nombreCorto" class="col-sm-2 col-form-label">* Estado:</label>
                <div class="col">
                    <select class="form-control mb-2" id="estado" name="estado">' . $opcionesEstado . '</select>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col"></div>
            </div>';
        $boton = '
            <button type="submit" class="btn btn-success" 
                    id="btnModificarSitio" disabled>
                    <i class="far fa-save"></i> GUARDAR
            </button>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_SITIO; ?> MODIFICAR SITIO</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <div id="seccionCentral">
        <form id="formModificarSitio" name="formModificarSitio" method="POST">
            <div class="card border-azul-clasico">
                <div class="card-header text-left bg-azul-clasico text-white">Formulario de modificación</div>
                <div class="card-body">
                    <?= $cuerpo; ?>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <?= $boton; ?>
                    <button type="button" class="btn btn-outline-info" 
                            onclick="window.location.reload()">
                        <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="./js/sitio_modificar.js"></script>