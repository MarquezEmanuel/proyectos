<?php
require_once './core_header.php';
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "Constantes.php");
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "GeneradorHTML.php");

use app\modelo\Constantes;
?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row">
                <div class="col text-left">
                    <h4><?= Constantes::ICON_MOD_INSTALACION; ?> BUSCAR INSTALACIÓN</h4>
                </div>
            </div>
            <div class="mt-3 mb-4">
                <form method="POST" id="formBuscarInstalacion" name="formBuscarInstalacion">
                    <input type="hidden" name="peticion" id="peticion">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="nombreLargo" class="col-2 col-form-label">Nombre largo:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreLargo" id="nombreLargo" 
                                           maxlength="50"
                                           title="Nombre largo de la instalación"
                                           placeholder="Nombre largo">
                                </div>
                                <label for="nombreGerencia" class="col-2 col-form-label">Gerencia:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreGerencia" id="nombreGerencia" 
                                           title="Nombre de la gerencia"
                                           placeholder="Nombre de gerencia">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="nombreEmpleado" class="col-2 col-form-label">Empleado:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreEmpleado" id="nombreEmpleado" 
                                           title="Nombre del empleado"
                                           placeholder="Nombre de empleado">
                                </div>
                                <label for="nombreSitio" class="col-2 col-form-label">Sitio:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreSitio" id="nombreSitio" 
                                           title="Nombre del sitio"
                                           placeholder="Nombre de sitio">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="nombrePlataforma" class="col-2 col-form-label">Plataforma:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombrePlataforma" id="nombrePlataforma" 
                                           title="Nombre de la plataforma"
                                           placeholder="Nombre de plataforma">
                                </div>
                                <label for="estado" class="col-2 col-form-label">* Estado:</label>
                                <div class="col">
                                    <select id="estado" name="estado" class="form-control mb-2" required>
                                        <option value="Activa">Activa</option>
                                        <option value="Inactiva">Inactiva</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success" name="btnBuscarInstalacion">
                                <?= Constantes::ICON_BUSCAR; ?>  BUSCAR
                            </button>
                            <button type="button" class="btn btn-outline-info" 
                                    id="btnCrearInstalacion" name="btnCrearInstalacion">
                                <?= Constantes::ICON_AGREGAR; ?> CREAR
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div id="seccionInferior" class="mt-4 mb-2"></div>
        </div>
    </div>
</div>
<script type="text/javascript" src="./js/instalacion_buscar.js"></script>