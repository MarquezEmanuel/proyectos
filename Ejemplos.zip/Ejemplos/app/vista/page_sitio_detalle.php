<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Sitio;

if ($_POST['idSitio']) {
    $id = $_POST['idSitio'];
    $sitio = new Sitio($id);
    $resultado = $sitio->obtener();
    if ($resultado[0] == 2) {

        $tipo = $sitio->getTipo();
        $nombre = $sitio->getNombre();
        $provincia = $sitio->getProvincia();
        $ciudad = $sitio->getCiudad();
        $codigoPostal = $sitio->getCodigoPostal();
        $direccion = $sitio->getDireccion();
        $origen = $sitio->getOrigen();
        $estado = $sitio->getEstado();
        $fechaCreacion = $sitio->getFechaCreacion();
        $fechaEdicion = $sitio->getFechaEdicion();
        $fechaCreacionFormateada = isset($fechaCreacion) ? date_format($fechaCreacion, 'd/m/Y H:i') : "";
        $fechaEdicionFormateada = isset($fechaEdicion) ? date_format($fechaEdicion, 'd/m/Y H:i') : "";

        /* CARGA EL CUERPO DEL FORMULARIO CON LOS DATOS OBTENIDOS */
        $cuerpo = '
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Tipo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $tipo . '"
                           placeholder="Tipo" readonly>
                </div>
                <label for="marca" class="col-sm-2 col-form-label">Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombre . '"
                           placeholder="Nombre" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Provincia:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $provincia . '"
                           placeholder="Provincia" readonly>
                </div>
                <label for="nroSerie" class="col-sm-2 col-form-label">Ciudad:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $ciudad . '"
                           placeholder="Ciudad" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Código postal:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $codigoPostal . '"
                           placeholder="Código postal" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Dirección:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $direccion . '"
                           placeholder="Dirección" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Origen:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $origen . '"
                           placeholder="Origen" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Estado:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $estado . '"
                           placeholder="Estado" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Fecha de creación:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value = "' . $fechaCreacionFormateada . '"
                           placeholder="Fecha de creación" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Fecha de edición:</label>
                <div class="col">
                    <input type="input" class="form-control mb-2" 
                           value="' . $fechaEdicionFormateada . '"
                           placeholder="Fecha de ultima edición" readonly>
                </div>
            </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_SITIO; ?> DETALLE DE SITIO</h4>
        </div>
    </div>
    <div class="card border-azul-clasico mt-3">
        <div class="card-header bg-azul-clasico text-white">Información</div>
        <div class="card-body">
            <?= $cuerpo; ?>
        </div>
    </div>
    <div class="form-row mt-2 mb-4">
        <div class="col text-right">
            <button type="button" class="btn btn-outline-info" 
                    onClick="window.location.reload();" >
                <?= Constantes::ICON_REGRESAR; ?> REGRESAR
            </button>
        </div>
    </div>
</div>