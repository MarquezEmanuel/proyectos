<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Instalacion;

$boton = "";
if ($_POST['idInstalacion']) {
    $id = $_POST['idInstalacion'];
    $instalacion = new Instalacion($id);
    $resultado = $instalacion->obtener();
    if ($resultado[0] == 2) {

        $nombreCorto = $instalacion->getNombreCorto();
        $nombreLargo = $instalacion->getNombreLargo();
        $descripcion = $instalacion->getDescripcion();
        $estado = $instalacion->getEstado();
        $getGerencia = $instalacion->obtenerGerencia();
        $getEmpleado = $instalacion->obtenerEmpleado();
        $getSitio = $instalacion->obtenerSitio();
        $getPlataforma = $instalacion->obtenerPlataforma();

        if ($estado == 'Activa') {
            $opcionesEstado = '<option value="Activa" selected>Activa</option>';
            $opcionesEstado .= '<option value="Inactiva">Inactiva</option>';
        } else {
            $opcionesEstado = '<option value="Activa">Activa</option>';
            $opcionesEstado .= '<option value="Inactiva" selected>Inactiva</option>';
        }

        $boton = '<button type="submit" class="btn btn-success" 
                          id="btnModificarInstalacion" disabled>
                          <i class="far fa-save"></i> GUARDAR
                  </button>';

        /* CARGA LOS DATOS DE LA GERENCIA */

        if ($getGerencia[0] == 2) {
            $gerencia = $instalacion->getGerencia();
            $idGerencia = $gerencia->getId();
            $nombreGerencia = $gerencia->getNombre();
            $opcionGerencia = "
                <select class='form-control mb-2' id='gerencia' name='gerencia' required>
                        <option value='{$idGerencia}'>{$nombreGerencia}</option>
                </select>";
        } else {
            $boton = '';
            $opcionGerencia = GeneradorHTML::getAlertaOperacion($getGerencia[0], $getGerencia[1]);
        }

        /* CARGA LOS DATOS DEL EMPLEADO DELEGADO */

        if ($getEmpleado[0] == 2) {
            $empleado = $instalacion->getEmpleado();
            $idEmpleado = $empleado->getId();
            $nombreEmpleado = $empleado->getNombre();
            $opcionEmpleado = "
                <select class='form-control mb-2' id='empleado' name='empleado' required>
                        <option value='{$idEmpleado}'>{$nombreEmpleado}</option>
                </select>";
        } else {
            $boton = '';
            $opcionEmpleado = GeneradorHTML::getAlertaOperacion($getEmpleado[0], $getEmpleado[1]);
        }

        /* CARGA LOS DATOS DEL SITIO */

        if ($getSitio[0] == 2) {
            $sitio = $instalacion->getSitio();
            $idSitio = $sitio->getId();
            $nombreSitio = $sitio->getNombre();
            $opcionSitio = "
                <select class='form-control mb-2' id='sitio' name='sitio' required>
                        <option value='{$idSitio}'>{$nombreSitio}</option>
                </select>";
        } else {
            $boton = '';
            $opcionSitio = GeneradorHTML::getAlertaOperacion($getSitio[0], $getSitio[1]);
        }

        /* CARGA LOS DATOS DE LA PLATAFORMA SISTEMA OPERATIVO */

        if ($getPlataforma[0] == 2) {
            $plataforma = $instalacion->getPlataforma();
            $idPlataforma = $plataforma->getId();
            $nombrePlataforma = $plataforma->getNombre();
            $opcionPlataforma = "
                <select class='form-control mb-2' id='plataforma' name='plataforma' required>
                        <option value='{$idPlataforma}'>{$nombrePlataforma}</option>
                </select>";
        } else {
            $boton = '';
            $opcionPlataforma = GeneradorHTML::getAlertaOperacion($getPlataforma[0], $getPlataforma[1]);
        }

        $cuerpo = '
            <input type="hidden" name="idInstalacion" id="idInstalacion" value="' . $id . '">
            <div class="form-row">
                    <label for="nombreCorto" class="col-sm-2 col-form-label">* Nombre corto:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreCorto" id="nombreCorto" maxlength="20" 
                               value="' . $nombreCorto . '"
                               placeholder="Nombre corto" required>
                    </div>
                    <label for="nombreLargo" class="col-sm-2 col-form-label">* Nombre largo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreLargo" id="nombreLargo" maxlength="50"
                               value="' . $nombreLargo . '"
                               placeholder="Nombre largo" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="gerencia" class="col-sm-2 col-form-label">* Gerencia:</label>
                    <div class="col">' . $opcionGerencia . '</div>
                    <label for="empleado" class="col-sm-2 col-form-label">* Responsable:</label>
                    <div class="col">' . $opcionEmpleado . '</div>
                </div>
                <div class="form-row">
                    <label for="sitio" class="col-sm-2 col-form-label">* Sitio:</label>
                    <div class="col">' . $opcionSitio . '</div>
                    <label for="plataforma" class="col-sm-2 col-form-label">* Plataforma:</label>
                    <div class="col">' . $opcionPlataforma . '</div>
                </div>
                <div class="form-row">
                    <label for="estado" class="col-sm-2 col-form-label">* Estado:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="estado" name="estado">' . $opcionesEstado . '</select>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label">* Descripción:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  name="descripcion" id="descripcion" 
                                  rows="5" minlength="10" maxlength="500"
                                  placeholder="Descripción" required>' . $descripcion . '</textarea>
                    </div>
                </div>';
    } else {
        $cuerpo = ControladorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = ControladorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_INSTALACION; ?> MODIFICAR INSTALACIÓN</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarInstalacion" name="formModificarInstalacion" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info"
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/instalacion_modificar.js"></script>
