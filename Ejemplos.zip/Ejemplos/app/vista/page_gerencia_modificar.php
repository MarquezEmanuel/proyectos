<?php
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Gerencia;

AutoCargador::cargarModulos();
session_start();

$boton = "";
if (isset($_POST['idGerencia'])) {
    $id = $_POST['idGerencia'];
    $gerencia = new Gerencia($id);
    $resultado = $gerencia->obtener();
    if ($resultado[0] == 2) {
        $nombre = $gerencia->getNombre();
        $estado = $gerencia->getEstado();
        $jefe = $gerencia->getJefe();
        $getEmpleado = $gerencia->obtenerEmpleado();

        if ($estado == 'Activa') {
            $opcionesEstado = '<option value="Activa" selected>Activa</option>';
            $opcionesEstado .= '<option value="Inactiva">Inactiva</option>';
        } else {
            $opcionesEstado = '<option value="Activa">Activa</option>';
            $opcionesEstado .= '<option value="Inactiva" selected>Inactiva</option>';
        }

        $boton = '
            <button type="submit" class="btn btn-success" 
                    id="btnModificarGerencia" disabled>
                    ' . Constantes::ICON_GUARDAR . ' GUARDAR
            </button>';

        /* CARGA LOS DATOS DEL DEPARTAMENTO */

        if ($getEmpleado[0] == 2) {
            $empleado = $gerencia->getJefe();
            $idEmpleado = $empleado->getId();
            $nombreEmpleado = $empleado->getNombre();
            $opcionEmpleado = "
                <select class='form-control mb-2' 
                        id='jefe' name='jefe'>
                        <option value='{$idEmpleado}'>{$nombreEmpleado}</option>
                </select>";
        } else {
            if (!$jefe) {
                $opcionEmpleado = "<select class='form-control mb-2' id='jefe' name='jefe'></select>";
            } else {
                $boton = '';
                $opcionEmpleado = GeneradorHTML::getAlertaOperacion($getEmpleado[0], $getEmpleado[1]);
            }
        }

        $cuerpo = '
            <input type="hidden" name="idGerencia" id="idGerencia" value="' . $id . '">
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" 
                           value="' . $nombre . '"
                           placeholder="Nombre de la gerencia">
                </div>
                <label for="jefe" class="col-sm-2 col-form-label">Jefe:</label>
                <div class="col">' . $opcionEmpleado . '</div>
            </div>
            <div class="form-row">
                <label for="estado" class="col-sm-2 col-form-label">* Estado:</label>
                <div class="col">
                    <select class="form-control mb-2" id="estado" name="estado">' . $opcionesEstado . '</select>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col"></div>
            </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $formulario = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_GERENCIA; ?> MODIFICAR GERENCIA</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarGerencia" name="formModificarGerencia" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/gerencia_modificar.js"></script>