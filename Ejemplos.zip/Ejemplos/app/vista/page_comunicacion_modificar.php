<?php
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Comunicacion;

AutoCargador::cargarModulos();
session_start();

$boton = "";
if ($_POST['idComunicacion']) {
    $id = $_POST['idComunicacion'];
    $comunicacion = new Comunicacion($id);
    $resultado = $comunicacion->obtener();
    if ($resultado[0] == 2) {

        $nombreCorto = $comunicacion->getNombreCorto();
        $nombreLargo = $comunicacion->getNombreLargo();
        $cantidad = $comunicacion->getCantidad();
        $descripcion = $comunicacion->getDescripcion();
        $estado = $comunicacion->getEstado();
        $getGerencia = $comunicacion->obtenerGerencia();
        $getEmpleado = $comunicacion->obtenerEmpleado();
        $getSitio = $comunicacion->obtenerSitio();
        $getProveedor = $comunicacion->obtenerProveedor();

        $boton = '
            <button type="submit" class="btn btn-success" 
                    id="btnModificarComunicacion" disabled>
                    <i class="far fa-save"></i> GUARDAR
            </button>';

        if ($estado == 'Activa') {
            $opcionesEstado = '<option value="Activa" selected>Activa</option>';
            $opcionesEstado .= '<option value="Inactiva">Inactiva</option>';
        } else {
            $opcionesEstado = '<option value="Activa">Activa</option>';
            $opcionesEstado .= '<option value="Inactiva" selected>Inactiva</option>';
        }

        /* CARGA LOS DATOS DE LA GERENCIA */

        if ($getGerencia[0] == 2) {
            $gerencia = $comunicacion->getGerencia();
            $idGerencia = $gerencia->getId();
            $nombreGerencia = $gerencia->getNombre();
            $opcionGerencia = "
                <select class='form-control mb-2' id='gerencia' name='gerencia' data-width='100%' required>
                        <option value='{$idGerencia}'>{$nombreGerencia}</option>
                </select>";
        } else {
            $boton = '';
            $opcionGerencia = GeneradorHTML::getAlertaOperacion($getGerencia[0], $getGerencia[1]);
        }

        /* CARGA LOS DATOS DEL EMPLEADO DELEGADO */

        if ($getEmpleado[0] == 2) {
            $empleado = $comunicacion->getEmpleado();
            $idEmpleado = $empleado->getId();
            $nombreEmpleado = $empleado->getNombre();
            $opcionEmpleado = "
                <select class='form-control mb-2' id='delegado' name='delegado' data-width='100%' required>
                        <option value='{$idEmpleado}'>{$nombreEmpleado}</option>
                </select>";
        } else {
            $boton = '';
            $opcionEmpleado = GeneradorHTML::getAlertaOperacion($getEmpleado[0], $getEmpleado[1]);
        }

        /* CARGA LOS DATOS DEL SITIO */

        if ($getSitio[0] == 2) {
            $sitio = $comunicacion->getSitio();
            $idSitio = $sitio->getId();
            $nombreSitio = $sitio->getNombre();
            $opcionSitio = "
                <select class='form-control mb-2' id='sitio' name='sitio' data-width='100%' required>
                        <option value='{$idSitio}'>{$nombreSitio}</option>
                </select>";
        } else {
            $boton = '';
            $opcionSitio = GeneradorHTML::getAlertaOperacion($getSitio[0], $getSitio[1]);
        }

        /* CARGA LOS DATOS DEL PROVEEDOR */

        if ($getProveedor[0] == 2) {
            $proveedor = $comunicacion->getProveedor();
            $idProveedor = $proveedor->getId();
            $nombreProveedor = $proveedor->getNombre();
            $opcionProveedor = "
                <select class='form-control mb-2' id='proveedor' name='proveedor' data-width='100%' required>
                        <option value='{$idProveedor}'>{$nombreProveedor}</option>
                </select>";
        } else {
            $boton = '';
            $opcionProveedor = GeneradorHTML::getAlertaOperacion($getProveedor[0], $getProveedor[1]);
        }

        $cuerpo = '
            <input type="hidden" name="idComunicacion" id="idComunicacion" value="' . $id . '">
            <div class="form-row">
                    <label for="nombreCorto" class="col-sm-2 col-form-label">* Nombre corto:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreCorto" id="nombreCorto" maxlength="20" 
                               value="' . $nombreCorto . '"
                               placeholder="Nombre corto" required>
                    </div>
                    <label for="nombreLargo" class="col-sm-2 col-form-label">* Nombre largo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreLargo" id="nombreLargo" maxlength="50"
                               value="' . $nombreLargo . '"
                               placeholder="Nombre largo" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="gerencia" class="col-sm-2 col-form-label">* Gerencia:</label>
                    <div class="col">' . $opcionGerencia . '</div>
                    <label for="delegado" class="col-sm-2 col-form-label">* Delegado:</label>
                    <div class="col">' . $opcionEmpleado . '</div>
                </div>
                <div class="form-row">
                    <label for="sitio" class="col-sm-2 col-form-label">* Sitio:</label>
                    <div class="col">' . $opcionSitio . '</div>
                    <label for="proveedor" class="col-sm-2 col-form-label">* Proveedor:</label>
                    <div class="col">' . $opcionProveedor . '</div>
                </div>
                <div class="form-row">
                    <label for="cantidad" class="col-sm-2 col-form-label">* Cantidad:</label>
                    <div class="col">
                        <input type="number" class="form-control mb-2" 
                               name="cantidad" id="cantidad" min="1"
                               value="' . $cantidad . '"
                               placeholder="Cantidad" required>
                    </div>
                    <label for="estado" class="col-sm-2 col-form-label">* Estado:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="estado" id="estado">' . $opcionesEstado . '</select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="cantidad" class="col-sm-2 col-form-label">* Descripción:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  name="descripcion" id="descripcion"
                                  rows="5" minlength="10" maxlength="500"
                                  placeholder="Decripción">' . $descripcion . '</textarea>
                    </div>
                </div>';
    } else {
        $cuerpo = ControladorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = ControladorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_COMUNICACION; ?> MODIFICAR COMUNICACIÓN</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarComunicacion" name="formModificarComunicacion" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/comunicacion_modificar.js"></script>