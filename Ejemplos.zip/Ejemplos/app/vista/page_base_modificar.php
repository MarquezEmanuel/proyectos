<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\BaseDatosManual;

date_default_timezone_set(Constantes::TIMEZONE);

$boton = "";
if ($_POST['idBase']) {

    $id = $_POST['idBase'];
    $baseDatos = new BaseDatosManual($id);
    $resultado = $baseDatos->obtener();
    if ($resultado[0] == 2) {
        $nombre = $baseDatos->getNombre();
        $collation = $baseDatos->getCollation();
        $estadoBase = $baseDatos->getEstadoBase();
        $descripcion = $baseDatos->getDescripcion();
        $estado = $baseDatos->getEstado();
        $getServidores = $baseDatos->obtenerServidores();

        if ($estadoBase == "ONLINE") {
            $opcionesEstadoBase = '<option value="ONLINE" selected>ONLINE</option>';
            $opcionesEstadoBase .= '<option value="OFFLINE">OFFLINE</option>';
        } else {
            $opcionesEstadoBase = '<option value="ONLINE">ONLINE</option>';
            $opcionesEstadoBase .= '<option value="OFFLINE" selected>OFFLINE</option>';
        }

        if ($estado == 'Activa') {
            $opcionesEstado = '<option value="Activa" selected>Activa</option>';
            $opcionesEstado .= '<option value="Inactiva">Inactiva</option>';
        } else {
            $opcionesEstado = '<option value="Activa">Activa</option>';
            $opcionesEstado .= '<option value="Inactiva" selected>Inactiva</option>';
        }

        $boton = '<button type="submit" class="btn btn-success" 
                          id="btnModificarBase" disabled>
                          <i class="far fa-save"></i> GUARDAR
                  </button>';

        if ($getServidores[0] == 2) {

            $servidoresBase = $baseDatos->getServidores();

            $fechaHoy = date('Y-m-d');
            $filaServidores = '
                <div class="form-row">
                    <div class="col-1"></div>
                    <div class="col">
                        <label class="col-form-label mb-2">Hardware</label>
                    </div>
                    <div class="col">
                        <label class="col-form-label mb-2">Fecha de creación</label>
                    </div>
                </div>';
            for ($indice = 1; $indice <= 6; $indice++) {

                $obligatorio = ($indice == 1) ? "required" : "";
                $servidor = "servidor{$indice}";
                $fechaCreacion = "fechaCreacion{$indice}";

                if (isset($servidoresBase[$indice])) {
                    $hardware = $servidoresBase[$indice];
                    $idHardware = $hardware['id'];
                    $tipoHardware = utf8_encode($hardware['tipo']);
                    $nombreHardware = utf8_encode($hardware['nombreLargo']);
                    $fechaCreacionBase = isset($hardware['fechaCreacionBase']) ? date_format($hardware['fechaCreacionBase'], 'Y-m-d') : "";
                    $filaServidores .= '
                        <div class="form-row">
                            <div class="col-1 align-middle">
                                <input type="checkbox" class="checkboxServidor" checked
                                       value="' . $indice . '" ' . $obligatorio . '
                                       id="orden" name="orden[]">
                            </div>
                            <div class="col">
                                <select class="form-control mb-2 hardware" data-width="100%"
                                        name="' . $servidor . '" id="' . $servidor . '">
                                    <option value="' . $idHardware . '">' . $tipoHardware . ': ' . $nombreHardware . '</option>
                                </select>
                            </div>
                            <div class="col">
                                <input type="date" class="form-control mb-2 fecha" 
                                       name="' . $fechaCreacion . '" id="' . $fechaCreacion . '"
                                       max=' . $fechaHoy . ' value="' . $fechaCreacionBase . '"
                                       placeholder="Fecha de creación">
                            </div>
                        </div>';
                } else {
                    $filaServidores .= '
                        <div class="form-row">
                            <div class="col-1 align-middle">
                                <input type="checkbox" class="checkboxServidor"
                                       value="' . $indice . '" ' . $obligatorio . '
                                       id="orden" name="orden[]">
                            </div>
                            <div class="col">
                                <select class="form-control mb-2 hardware" data-width="100%"
                                        name="' . $servidor . '" id="' . $servidor . '" 
                                        disabled></select>
                            </div>
                            <div class="col">
                                <input type="date" class="form-control mb-2 fecha" 
                                       name="' . $fechaCreacion . '" id="' . $fechaCreacion . '"
                                       max=' . $fechaHoy . ' disabled
                                       placeholder="Fecha de creación">
                            </div>
                        </div>';
                }
            }
        } else {
            $boton = '';
            $filaServidores = GeneradorHTML::getAlertaOperacion($getServidores[0], $getServidores[1]);
        }

        $cuerpo = '
            <input type="hidden" name="idBase" id="idBase" value="' . $id . '">
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" 
                           value="' . $nombre . '"
                           placeholder="Nombre" required>
                </div>
                <label for="collation" class="col-sm-2 col-form-label">* Collation:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="collation" id="collation"
                           value="' . $collation . '"
                           placeholder="Collation" required>
                </div>
            </div>
            <div class="form-row">
                <label for="estadoBase" class="col-sm-2 col-form-label">* Estado base:</label>
                <div class="col">
                    <select class="form-control mb-2" 
                            id="estadoBase" name="estadoBase">' . $opcionesEstadoBase . '</select>
                </div>
                <label for="estado" class="col-sm-2 col-form-label">* Estado:</label>
                <div class="col">
                    <select class="form-control mb-2" 
                            id="estado" name="estado">' . $opcionesEstado . '</select>
                </div>
            </div>
            <div class="form-row">
                <label for="descripcion" class="col-sm-2 col-form-label">* Descripcion:</label>
                <div class="col">
                    <textarea class="form-control mb-2" 
                              id="descripcion" name="descripcion"
                             rows="5" minlength="10" maxlength="500"
                              placeholder="Descripcion" required>' . $descripcion . '</textarea>
                </div>
            </div>
            <div class="form-row mt-4 mb-3">
                <div class="col-2"><p class="font-weight-bold">DATOS DE HARDWARE</p></div>
                <div class="col-10"><hr></div>
            </div>' . $filaServidores;
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_BASE; ?> MODIFICAR BASE DE DATOS</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarBase" name="formModificarBase" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/base_modificar.js"></script>

