<?php
require_once './core_header.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row">
                <div class="col text-left">
                    <h4><?= Constantes::ICON_MOD_HARDWARE; ?> BUSCAR HARDWARE</h4>
                </div>
            </div>
            <div class="mt-3 mb-4">
                <form method="POST" id="formBuscarHardware" name="formBuscarHardware">
                    <input type="hidden" name="peticion" id="peticion">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="tipo" class="col-sm-2 col-form-label">* Tipo:</label>
                                <div class="col">
                                    <select class="form-control mb-2" id="tipo" name="tipo">
                                        <option value="">Todos</option>
                                        <option value="Host virtual">Host virtual</option>
                                        <option value="Maquina virtual">Máquina virtual</option>
                                        <option value="Hardware fisico">Hardware físico</option>
                                        <option value="Otro">Otro</option>
                                    </select>
                                </div>
                                <label for="nombreLargo" class="col-2 col-form-label text-left">Nombre largo:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreLargo" id="nombreLargo" 
                                           maxlength="50"
                                           title="Nombre del hardware"
                                           placeholder="Nombre del hardware">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="ambiente" class="col-sm-2 col-form-label">* Ambiente:</label>
                                <div class="col">
                                    <select class="form-control mb-2" id="ambiente" name="ambiente">
                                        <option value="">Todos</option>
                                        <option value="Produccion">Producción</option>
                                        <option value="Test">Test</option>
                                        <option value="Desarrollo">Desarrollo</option>
                                    </select>
                                </div>
                                <label for="sitio" class="col-2 col-form-label text-left">Sitio:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="sitio" id="sitio" 
                                           maxlength="50"
                                           title="Nombre del sitio"
                                           placeholder="Nombre del sitio">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="estado" class="col-2 col-form-label text-left">* Dominio:</label>
                                <div class="col">
                                    <select class="form-control mb-2" id="dominio" name="dominio">
                                        <option value="">Todos</option>
                                        <option value="CORP">CORP</option>
                                        <option value="DMZ">DMZ</option>
                                        <option value="SANTACRUZ">SANTA CRUZ</option>
                                    </select>
                                </div>
                                <label for="estado" class="col-2 col-form-label text-left">* Estado:</label>
                                <div class="col">
                                    <select id="estado" name="estado" class="form-control mb-2" required>
                                        <option value="Activo">Activo</option>
                                        <option value="Inactivo">Inactivo</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success" name="btnBuscarHardware">
                                <?= Constantes::ICON_BUSCAR; ?>  BUSCAR
                            </button>
                            <button type="button" class="btn btn-outline-info" 
                                    id="btnCrearHardware" name="btnCrearHardware">
                                <?= Constantes::ICON_AGREGAR; ?> CREAR
                            </button>  
                        </div>
                    </div>
                </form>
            </div>
            <div id="seccionInferior" class="mt-4 mb-2"></div>
        </div>
        <?php echo GeneradorHTML::getModalProcesando(); ?>
    </div>
</div>
<script type="text/javascript" src="./js/hardware_buscar.js"></script>