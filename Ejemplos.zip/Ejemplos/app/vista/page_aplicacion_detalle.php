<?php
require_once './core_autoload.php';

use app\modelo\GeneradorHTML;
use app\modelo\Aplicacion;

session_start();

$boton = "";
if ($_POST['idAplicacion']) {
    $id = $_POST['idAplicacion'];
    $aplicacion = new Aplicacion($id);
    $resultado = $aplicacion->obtener();
    if ($resultado[0] == 2) {

        $nombreCorto = $aplicacion->getNombreCorto();
        $nombreLargo = $aplicacion->getNombreLargo();
        $tipo = $aplicacion->getTipo();
        $seguridad = $aplicacion->getSeguridad();
        $tecnologia = $aplicacion->getTecnologia();
        $fechaCaducidad = $aplicacion->getFechaCaducidad();
        $codigoSAS = $aplicacion->getCodigoSAS();
        $tipoLog = $aplicacion->getTipoLog();
        $confidencialidad = $aplicacion->getConfidencialidad();
        $integridad = $aplicacion->getIntegridad();
        $disponibilidad = $aplicacion->getDisponibilidad();
        $criticidad = $aplicacion->getCriticidad();
        $rti = $aplicacion->getRti();
        $descripcion = $aplicacion->getDescripcion();
        $estado = $aplicacion->getEstado();
        $fechaCreacion = $aplicacion->getFechaCreacion();
        $fechaEdicion = $aplicacion->getFechaEdicion();
        $fechaCreacionFormateada = isset($fechaCreacion) ? date_format($fechaCreacion, 'd/m/Y H:i') : "";
        $fechaEdicionFormateada = isset($fechaEdicion) ? date_format($fechaEdicion, 'd/m/Y H:i') : "";
        $fechaCaducidadFormateada = isset($fechaCaducidad) ? date_format($fechaCaducidad, 'd/m/Y') : "";
        $getLenguaje = $aplicacion->obtenerLenguaje();
        $getHerramienta = $aplicacion->obtenerHerramienta();
        $getGerencia = $aplicacion->obtenerGerencia();
        $getEmpleado = $aplicacion->obtenerEmpleado();
        $getModo = $aplicacion->obtenerModo();
        $getLugar = $aplicacion->obtenerLugar();
        $getPlataforma = $aplicacion->obtenerPlataforma();
        $getBases = $aplicacion->obtenerBasesDatos();
        $getProveedores = $aplicacion->obtenerProveedores();
        $getHardwares = $aplicacion->obtenerServidores();


        /* CARGA LOS DATOS DEL LENGUAJE DE PROGRAMACION ASOCIADO A LA APLICACION */

        if ($getHerramienta[0] == 2) {
            $herramienta = $aplicacion->getHerramienta();
            $idHerramienta = $herramienta->getId();
            $nombreHerramienta = $herramienta->getNombre();
            $versionHerramienta = $herramienta->getVersion();
            $estadoHerramienta = $herramienta->getEstado();
            $referenciaHerramienta = '#' . str_pad($idHerramienta, 6, "0", STR_PAD_LEFT);
            $filaHerramienta = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Referencia:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $referenciaHerramienta . '"
                               title="Referencia de la herramienta de desarrollo"
                               placeholder="Referencia" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreHerramienta . '"
                               title="Nombre de la herramienta de desarrollo"
                               placeholder="Nombre" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Versión:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $versionHerramienta . '"
                               title="Versión de la herramienta de desarrollo"
                               placeholder="Versión" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoHerramienta . '"
                               title="Estado de la herramienta de desarrollo"
                               placeholder="Estado" readonly>
                    </div>
                </div>';
        } else {
            $datosHerramienta = GeneradorHTML::getAlertaOperacion($getHerramienta[0], $getHerramienta[1]);
            $filaHerramienta = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosHerramienta . '</div>
                </div>';
        }

        /* CARGA LOS DATOS DEL LENGUAJE DE PROGRAMACION ASOCIADO A LA APLICACION */

        if ($getLenguaje[0] == 2) {
            $lenguaje = $aplicacion->getLenguaje();
            $idLenguaje = $lenguaje->getId();
            $nombreLenguaje = $lenguaje->getNombre();
            $versionLenguaje = $lenguaje->getVersion();
            $estadoLenguaje = $lenguaje->getEstado();
            $referenciaLenguaje = '#' . str_pad($idLenguaje, 6, "0", STR_PAD_LEFT);
            $filaLenguaje = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Referencia:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $referenciaLenguaje . '"
                               title="Referencia del lenguaje de programación"
                               placeholder="Referencia" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreLenguaje . '"
                               title="Nombre del lenguaje de programación"
                               placeholder="Nombre" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Versión:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $versionLenguaje . '"
                               title="Versión del lenguaje de programación"
                               placeholder="Versión" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoLenguaje . '"
                               title="Estado del lenguaje de programación"
                               placeholder="Estado" readonly>
                    </div>
                </div>';
        } else {
            $datosLenguaje = GeneradorHTML::getAlertaOperacion($getLenguaje[0], $getLenguaje[1]);
            $filaLenguaje = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosLenguaje . '</div>
                </div>';
        }

        /* CARGA LOS DATOS DE LA GERENCIA ASOCIADA A LA APLICACION */

        if ($getGerencia[0] == 2) {
            $gerencia = $aplicacion->getGerencia();
            $idGerencia = $gerencia->getId();
            $nombreGerencia = $gerencia->getNombre();
            $estadoGerencia = $gerencia->getEstado();
            $referenciaGerencia = '#' . str_pad($idGerencia, 6, "0", STR_PAD_LEFT);
            $filaGerencia = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Referencia:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $referenciaGerencia . '"
                               title="Referencia de la gerencia"
                               placeholder="Referencia" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreGerencia . '"
                               title="Nombre de la gerencia"
                               placeholder="Nombre" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoGerencia . '"
                               title="Estado de la gerencia"
                               placeholder="Estado" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>';
        } else {
            $datosGerencia = GeneradorHTML::getAlertaOperacion($getGerencia[0], $getGerencia[1]);
            $filaGerencia = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosGerencia . '</div>
                </div>';
        }

        /* CARGA LOS DATOS DEL EMPLEADO DELEGADO ASOCIADO LA APLICACION */

        if ($getEmpleado[0] == 2) {
            $empleado = $aplicacion->getEmpleado();
            $legajoEmpleado = $empleado->getId();
            $nombreEmpleado = $empleado->getNombre();
            $estadoEmpleado = $empleado->getEstado();
            $filaEmpleado = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Legajo:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $legajoEmpleado . '"
                               title="Número de legajo del empleado delegado"
                               placeholder="Legajo" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreEmpleado . '"
                               title="Nombre del empleado delegado"
                               placeholder="Nombre" readonly>
                    </div>
                    
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoEmpleado . '"
                               title="Estado de empleado delegado"
                               placeholder="Estado" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>';
        } else {
            $datosEmpleado = GeneradorHTML::getAlertaOperacion($getEmpleado[0], $getEmpleado[1]);
            $filaEmpleado = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosEmpleado . '</div>
                </div>';
        }

        /* CARGA LOS DATOS DEL LUGAR DE PROCESAMIENTO */

        if ($getLugar[0] == 2) {
            $lugar = $aplicacion->getLugarProcesamiento();
            $idLugar = $lugar->getId();
            $nombreLugar = $lugar->getNombre();
            $estadoLugar = $lugar->getEstado();
            $referenciaLugar = '#' . str_pad($idLugar, 6, "0", STR_PAD_LEFT);
            $filaLugar = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Referencia:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $referenciaLugar . '"
                               title="Referencia del lugar de procesamiento"
                               placeholder="Referencia" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreLugar . '"
                               title="Nombre del lugar de procesamiento"
                               placeholder="Nombre" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoLugar . '"
                               title="Estado del lugar de procesamiento"
                               placeholder="Estado" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>';
        } else {
            $datosLugar = GeneradorHTML::getAlertaOperacion($getLugar[0], $getLugar[1]);
            $filaLugar = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosLugar . '</div>
                </div>';
        }

        /* CARGA LOS DATOS DEL MODO DE PROCESAMIENTO */

        if ($getModo[0] == 2) {
            $modo = $aplicacion->getModoProcesamiento();
            $idModo = $modo->getId();
            $nombreModo = $modo->getNombre();
            $estadoModo = $modo->getEstado();
            $referenciaModo = '#' . str_pad($idModo, 6, "0", STR_PAD_LEFT);
            $filaModo = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Referencia:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $referenciaModo . '"
                               title="Referencia del modo de procesamiento"
                               placeholder="Referencia" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreModo . '"
                               title="Nombre del modo de procesamiento"
                               placeholder="Nombre" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoModo . '"
                               title="Estado del modo de procesamiento"
                               placeholder="Estado" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>';
        } else {
            $datosModo = GeneradorHTML::getAlertaOperacion($getModo[0], $getModo[1]);
            $filaModo = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosModo . '</div>
                </div>';
        }



        /* CARGA LOS DATOS DE LA PLATAFORMA SO */

        if ($getPlataforma[0] == 2) {
            $plataforma = $aplicacion->getPlataforma();
            $idPlataforma = $plataforma->getId();
            $nombrePlataforma = $plataforma->getNombre();
            $estadoPlataforma = $plataforma->getEstado();
            $referenciaPlataforma = '#' . str_pad($idPlataforma, 6, "0", STR_PAD_LEFT);
            $filaPlataforma = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Referencia:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $referenciaPlataforma . '"
                               title="Referencia de la plataforma"
                               placeholder="Referencia" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombrePlataforma . '"
                               title="Nombre de la plataforma"
                               placeholder="Nombre" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoPlataforma . '"
                               title="Estado de la plataforma"
                               placeholder="Estado" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>';
        } else {
            $datosPlataforma = GeneradorHTML::getAlertaOperacion($getPlataforma[0], $getPlataforma[1]);
            $filaPlataforma = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosPlataforma . '</div>
                </div>';
        }


        if ($getHardwares[0] == 2) {
            $servidores = $aplicacion->getServidores();
            $filas = "";
            foreach ($servidores as $servidor) {
                $idServidor = $servidor['id'];
                $nombreCortoServidor = utf8_encode($servidor['nombreCorto']);
                $nombreLargoServidor = utf8_encode($servidor['nombreLargo']);
                $estadoServidor = $servidor['estado'];
                $rutaServidor = $servidor['ruta'];
                $referenciaServidor = '#' . str_pad($idServidor, 6, "0", STR_PAD_LEFT);
                $filas .= "
                    <tr>
                        <td class='align-middle'>{$referenciaServidor}</td>
                        <td class='align-middle'>{$nombreCortoServidor}</td>
                        <td class='align-middle'>{$nombreLargoServidor}</td>
                        <td class='align-middle'>{$rutaServidor}</td>
                        <td class='align-middle'>{$estadoServidor}</td>
                    </tr>";
            }
            $tablaServidores = '
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" 
                           cellspacing="0" style="width:100%">
                        <thead>
                            <tr>
                                <th>Referencia</th>
                                <th>Nombre corto</th>
                                <th>Nombre largo</th>
                                <th>Ruta</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>' . $filas . '</tbody>
                    </table>
                </div>';
        } else {
            $tablaServidores = GeneradorHTML::getAlertaOperacion($getHardwares[0], $getHardwares[1]);
        }

        if ($getBases[0] == 2) {
            $bases = $aplicacion->getBasesDatos();
            $filas = "";
            foreach ($bases as $base) {
                $id = $base['id'];
                $referencia = '#' . str_pad($id, 5, "0", STR_PAD_LEFT);
                $nombreBase = $base['nombre'];
                $collationBase = $base['collation'];
                $estadoBase = $base['estadoBase'];
                $estado = $base['estado'];
                $filas .= "
                    <tr>
                        <td class='align-middle'>{$referencia}</td>
                        <td class='align-middle'>{$nombreBase}</td>
                        <td class='align-middle'>{$collationBase}</td>
                        <td class='align-middle'>{$estadoBase}</td>
                        <td class='align-middle'>{$estado}</td>
                    </tr>";
            }
            $tablaBases = '
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" 
                           cellspacing="0" style="width:100%">
                        <thead>
                            <tr>
                                <th>Referencia</th>
                                <th>Nombre</th>
                                <th>Collation</th>
                                <th>Estado base</th>
                                <th>Estado activo</th>
                            </tr>
                        </thead>
                        <tbody>' . $filas . '</tbody>
                    </table>
                </div>';
        } else {
            $tablaBases = GeneradorHTML::getAlertaOperacion($getBases[0], $getBases[1]);
        }

        /* CARGA LOS DATOS DE LOS PROVEEDORES ASOCIADOS */

        if ($getProveedores[0] == 2) {
            $proveedores = $aplicacion->getProveedores();
            $filas = "";
            foreach ($proveedores as $proveedor) {
                $idProveedor = $proveedor['id'];
                $nombreProveedor = utf8_encode($proveedor['nombre']);
                $telefonoProveedor = $proveedor['telefono'];
                $correoProveedor = $proveedor['correo'];
                $estadoProveedor = $proveedor['estado'];
                $referencia = '#' . str_pad($idProveedor, 5, "0", STR_PAD_LEFT);
                $filas .= "
                    <tr>
                        <td class='align-middle'>{$referencia}</td>
                        <td class='align-middle'>{$nombreProveedor}</td>
                        <td class='align-middle'>{$telefonoProveedor}</td>
                        <td class='align-middle'>{$correoProveedor}</td>
                        <td class='align-middle'>{$estadoProveedor}</td>
                    </tr>";
            }
            $tablaProveedores = '
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" 
                           cellspacing="0" style="width:100%">
                        <thead>
                            <tr>
                                <th>Referencia</th>
                                <th>Nombre</th>
                                <th>Telefono</th>
                                <th>Correo</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>' . $filas . '</tbody>
                    </table>
                </div>';
        } else {
            $tablaProveedores = GeneradorHTML::getAlertaOperacion($getProveedores[0], $getProveedores[1]);
        }


        /* CARGA EL CUERPO DEL FORMULARIO CON LOS DATOS OBTENIDOS */
        $cuerpo = '
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Nombre corto:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombreCorto . '"
                           placeholder="Nombre corto" readonly>
                </div>
                <label for="marca" class="col-sm-2 col-form-label">Nombre largo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombreLargo . '"
                           placeholder="Nombre largo" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Tipo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $tipo . '"
                           placeholder="Tipo" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Tecnologia:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $tecnologia . '"
                           placeholder="Tecnologia" readonly>
                </div>
            </div>
             <div class="form-row">
                <label class="col-sm-2 col-form-label">Seguridad:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $seguridad . '"
                           placeholder="Seguridad" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Tipo de log:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $tipoLog . '"
                           placeholder="Tipo de log" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Fecha caducidad:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $fechaCaducidadFormateada . '"
                           placeholder="Fecha de caducidad" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Código SAS:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $codigoSAS . '"
                           placeholder="Código SAS" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Confidencialidad:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $confidencialidad . '"
                           placeholder="Confidencialidad" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Integridad:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $integridad . '"
                           placeholder="Integridad" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Disponibilidad:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $disponibilidad . '"
                           placeholder="Disponibilidad" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Criticidad:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $criticidad . '"
                           placeholder="Criticidad" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">RTI:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $rti . '"
                           placeholder="RTI" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Estado:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $estado . '"
                           placeholder="Estado" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Descripcion:</label>
                <div class="col">
                    <textarea class="form-control mb-2"
                              placeholder="Descripción" readonly>' . $descripcion . '</textarea>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Fecha de creación:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value = "' . $fechaCreacionFormateada . '"
                           placeholder="Fecha de creación" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Fecha de edición:</label>
                <div class="col">
                    <input type="input" class="form-control mb-2" 
                           value="' . $fechaEdicionFormateada . '"
                           placeholder="Fecha de ultima edición" readonly>
                </div>
            </div>
            <div class="form-row mt-4 mb-2">
                <div class="col-2"><p class="font-weight-bold">HERRAMIENTA</p></div>
                <div class="col-10"><hr></div>
            </div>
            ' . $filaHerramienta . '
            <div class="form-row mt-4 mb-2">
                <div class="col-2"><p class="font-weight-bold">LENGUAJE</p></div>
                <div class="col-10"><hr></div>
            </div>
            ' . $filaLenguaje . '
            
            <div class="form-row mt-4 mb-2">
                <div class="col-2"><p class="font-weight-bold">GERENCIA</p></div>
                <div class="col-10"><hr></div>
            </div>
            ' . $filaGerencia . '
            <div class="form-row mt-4 mb-2">
                <div class="col-2"><p class="font-weight-bold">RESPONSABLE</p></div>
                <div class="col-10"><hr></div>
            </div>
            ' . $filaEmpleado . '
            <div class="form-row mt-4 mb-2">
                <div class="col-2"><p class="font-weight-bold">LUGAR</p></div>
                <div class="col-10"><hr></div>
            </div>
            ' . $filaLugar . '
            <div class="form-row mt-4 mb-2">
                <div class="col-2"><p class="font-weight-bold">MODO</p></div>
                <div class="col-10"><hr></div>
            </div>
            ' . $filaModo . '
            <div class="form-row mt-4 mb-2">
                <div class="col-2"><p class="font-weight-bold">PLATAFORMA</p></div>
                <div class="col-10"><hr></div>
            </div>
            ' . $filaPlataforma . '
            <div class="form-row mt-4 mb-3">
                <div class="col-2"><p class="font-weight-bold">HARDWARES</p></div>
                <div class="col-10"><hr></div>
            </div>
            <div class="form-row">
                <div class="col">' . $tablaServidores . '</div>
            </div>
            <div class="form-row mt-4 mb-2">
                <div class="col-2"><p class="font-weight-bold">BASE DE DATOS</p></div>
                <div class="col-10"><hr></div>
            </div>
            <div class="form-row">
                <div class="col">' . $tablaBases . '</div>
            </div>
            <div class="form-row mt-4 mb-3">
                <div class="col-2"><p class="font-weight-bold">PROVEEDORES</p></div>
                <div class="col-10"><hr></div>
            </div>
            <div class="form-row">
                <div class="col">' . $tablaProveedores . '</div>
            </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-desktop"></i> DETALLE DE APLICACIÓN</h4>
        </div>
    </div>
    <div class="card border-azul-clasico mt-3">
        <div class="card-header bg-azul-clasico text-white">Información</div>
        <div class="card-body">
            <?= $cuerpo; ?>
        </div>
    </div>
    <div class="form-row mt-2 mb-4">
        <div class="col text-right">
            <button type="button" class="btn btn-outline-info" 
                    onClick="window.location.reload();" >
                <i class="fas fa-search"></i> REGRESAR
            </button>
        </div>
    </div>
</div>

