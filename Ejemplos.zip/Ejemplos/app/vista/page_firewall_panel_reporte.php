<?php
require_once './core_header.php';
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorFirewall;

AutoCargador::cargarModulos();

$controlador = new ControladorFirewall();
$resultado = $controlador->buscarInformesFirewall();
if ($resultado[0] == 2) {
    $informes = $resultado[1];
    $filasReportes = $cardDetalle = '';
    foreach ($informes as $informe) {
        $id = $informe[0];
        $titulo = utf8_encode($informe[1]);
        $distribucion = $informe[2];
        $registros = $informe[3];
        $referencia = '#' . str_pad($id, 3, "0", STR_PAD_LEFT);
        $filasReportes .= "
            <tr>
                <td class='align-middle'>{$referencia}</td>
                <td class='align-middle'>{$titulo}</td>
                <td class='align-middle'>{$distribucion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$id}' title='Detalle: {$titulo}'>
                                <i class='fas fa-info-circle'></i>
                        </button>
                    </div>
                </td>
            </tr>";
        $filasDetalle = '';
        foreach ($registros as $registro) {
            $detalle = utf8_encode($registro['detalle']);
            $total = $registro['total'];
            $filasDetalle .= "
                <tr>
                    <td>{$detalle}</td>
                    <td class='text-right'>{$total}</td>
                </tr>";
        }
        $cardDetalle .= '
            <div class="card-group mb-2 mt-2 panel" style="display: none;"  id="panel' . $id . '" name="panel' . $id . '">
                <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white">
                        <i class="fas fa-table"></i> ' . $titulo . '
                    </div>
                    <div class="card-body">
                        <div class="table-responsive mt-4 mb-4">
                            <table id="tabla' . $id . '" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Detalle</th>
                                        <th class="text-right">Total</th>
                                    </tr>
                                </thead>
                                <tbody>' . $filasDetalle . '</tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white">
                        <i class="fas fa-chart-pie"></i> Gráfico
                    </div>
                    <div class="card-body"></div>
                </div>
            </div>';
    }

    $formulario = '
        <div class="card border-azul-clasico">
            <div class="card-header bg-azul-clasico text-white">Listado de informes</div>
            <div class="card-body">
                <div class="table-responsive mt-4 mb-4">
                    <table class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                        <thead>
                            <tr>
                                <th>Referencia</th>
                                <th>Nombre de reporte</th>
                                <th>Distribución</th>
                                <th>Detalle</th>
                            </tr>
                        </thead>
                        <tbody>' . $filasReportes . '</tbody>
                    </table>
                </div>
            </div>
        </div> ' . $cardDetalle;
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    $formulario = '
        <div class="card border-azul-clasico">
            <div class="card-header bg-azul-clasico text-white">Listado de informes</div>
            <div class="card-body">' . $cuerpo . '</div>
        </div>';
}
?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row">
                <div class="col text-left">
                    <h4><?= Constantes::ICON_MOD_FIREWALL; ?> PANEL DE REPORTES DE FIREWALLS</h4>
                </div>
            </div>
            <div class="mt-3 mb-4"><?= $formulario; ?></div>
        </div>
    </div>
</div>
<script type="text/javascript" src="./js/firewall_panel_reporte.js"></script>

