/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {


    var formOriginal = $("#formModificarBase").serialize();

    $("#formModificarBase").change(function () {
        var formModificado = $("#formModificarBase").serialize();
        var disabled = (formOriginal !== formModificado) ? false : true;
        $("#btnModificarBase").prop("disabled", disabled);
    });

    $('#formModificarBase').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: "./procesa/load_base_modificar.php",
            data: $("#formModificarBase").serialize(),
            success: function (data) {
                $('#seccionResultado').html(data[0]['resultado']);
                if (data[0]['exito'] === true) {
                    $('#formModificarBase').find('input, textarea, select').prop('disabled', true);
                    $("#btnModificarBase").prop("disabled", true);
                }
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionResultado").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#seccionResultado").offset().top}, '1250');
            }
        });
    });

    $(".checkboxServidor").change(function () {
        var orden = $(this).val();
        var tildado = $(this).prop('checked');
        var disabled = (tildado) ? false : true;
        $("#servidor" + orden).prop('disabled', disabled);
        $("#servidor" + orden).prop('required', 'required');
        $("#fechaCreacion" + orden).prop('disabled', disabled);
    });

    $(".hardware").each(function () {
        var nombre = "#" + $(this).attr("name");
        $(nombre).select2({
            placeholder: 'Seleccionar',
            theme: "bootstrap",
            maximumInputLength: 30,
            allowClear: true,
            ajax: {
                url: "./procesa/load_hardware_seleccionar.php",
                dataType: 'json',
                type: "POST",
                delay: 250,
                data: function (params) {
                    return {nombre: params.term};
                },
                processResults: function (data) {
                    return {results: data};
                },
                cache: true
            }
        });
    });
});
