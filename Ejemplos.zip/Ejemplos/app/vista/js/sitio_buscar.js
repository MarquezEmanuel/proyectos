/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {

    /* EJECUTA LA FUNCION QUE REALIZA LA BUSQUEDA */

    realizarBusqueda();

    /* ENVIA EL FORMULARIO DE BUSQUEDA INDICANDO QUE SE PETICIONO POR EL USUARIO */

    $('#formBuscarSitio').submit(function (event) {
        event.preventDefault();
        $("#peticion").val("true");
        realizarBusqueda();
    });

    /* CARGA EL FORMULARIO DE CREACION CUANDO SE PRESIONA EL BOTON EN PANTALLA */

    $('#btnCrearSitio').click(function () {
        $.ajax({
            type: "POST",
            url: "./page_sitio_crear.php",
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html, body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });

    $('#seccionInferior').on('click', '.datos', function () {
        var idSitio = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./page_sitio_detalle.php",
            data: "idSitio=" + idSitio,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('#seccionInferior').on('click', '.editar', function () {
        var idSitio = $(this).attr("name");
        $.ajax({
            type: "POST",
            url: "./page_sitio_modificar.php",
            data: "idSitio=" + idSitio,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });

    $('#seccionInferior').on('change', '.col_checkbox', function () {
        var columna = $(this).val();
        var checked = $(this).prop('checked');
        (checked) ? $('.' + columna).show() : $('.' + columna).hide();
    });

    $('#seccionInferior').on('change', '.col_diagrama', function () {
        var columna = $(this).val();
        let matriz = [];
        matriz.push(['atributo', 'valor']);
        $("." + columna).each(function () {
            var texto = $(this).text();
            if (matriz.length === 0) {
                matriz.push([texto, 1]);
            } else {
                var i = 0;
                var agregar = true;
                while ((i < matriz.length) && agregar) {
                    if (matriz[i][0] === texto) {
                        matriz[i][1] = (matriz[i][1]) + 1;
                        agregar = false;
                    }
                    i++;
                }
                if (agregar) {
                    matriz.push([texto, 1]);
                }
            }
        });
        google.charts.load('current', {'packages': ['corechart']});
        google.charts.setOnLoadCallback(function () {
            drawChart(matriz);
        });
    });

});

function drawChart(matriz) {
    var data = google.visualization.arrayToDataTable(matriz);
    var options = {
        title: 'My Daily Activities'
    };
    var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
    chart.draw(data, options);
}

/* ENVIA LA PETICION AJAX PARA CARGAR EL RESULTADO PREVIO DE UNA BUSQUEDA */

function realizarBusqueda() {
    $.ajax({
        type: "POST",
        url: "./procesa/load_sitio_buscar.php",
        data: $("#formBuscarSitio").serialize(),
        success: function (data) {
            $('#seccionInferior').html(data);
            $('#tbSitios').dataTable({
                dom: 'Bfrtip',
                lengthChange: false,
                language: {url: "./js/_dt_spanish.json"}
            });
        },
        error: function (data) {
            console.log(data);
            var men = '<strong>No se procesó la petición (Informe al administrador)</strong>';
            var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
            $("#seccionInferior").html(div);
        },
        complete: function () {
            $('html,body').animate({scrollTop: $("#seccionInferior").offset().top}, '1250');
        }
    });
}

