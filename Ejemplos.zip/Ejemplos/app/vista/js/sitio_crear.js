/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * 
 * 
 * var columna = $(this).val();
        var arreglo = {};
        let matriz = [];
        $("." + columna).each(function () {
            var texto = $(this).text();
            if (matriz.length === 0) {
                matriz.push([texto, 1]);
            } else {
                var i = 0;
                var agregar = true;
                while ((i < matriz.length) && agregar) {
                    if (matriz[i][0] === texto) {
                        matriz[i][1] = (matriz[i][1]) + 1;
                        agregar = false;
                    }
                    i++;
                }
                if (agregar) {
                    matriz.push([texto, 1]);
                }
            }

        });
 */
$(document).ready(function () {

    $('#formCrearSitio').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: "./procesa/load_sitio_crear.php",
            data: $("#formCrearSitio").serialize(),
            success: function (data) {
                $('#seccionResultado').html(data[0]['resultado']);
                if (data[0]['exito'] === true) {
                    $("#formCrearSitio")[0].reset();
                }
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionResultado").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#seccionResultado").offset().top}, '1250');
            }
        });
    });

});

