/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {

    /* EJECUTA LA FUNCION QUE REALIZA LA BUSQUEDA */

    realizarBusqueda();

    /* ENVIA EL FORMULARIO DE BUSQUEDA INDICANDO QUE SE PETICIONO POR EL USUARIO */

    $('#formBuscarLenguaje').submit(function (event) {
        event.preventDefault();
        $("#peticion").val("true");
        realizarBusqueda();
    });

    /* CARGA EL FORMULARIO DE CREACION CUANDO SE PRESIONA EL BOTON EN PANTALLA */

    $('#btnCrearLenguaje').click(function () {
        $.ajax({
            type: "POST",
            url: "./page_lenguaje_crear.php",
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html, body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('#seccionInferior').on('click', '.editar', function () {
        var idLenguaje = $(this).attr("name");
        event.preventDefault();
        $.ajax({
            type: "POST",
            url: "./page_lenguaje_modificar.php",
            data: "idLenguaje=" + idLenguaje,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });


});

function realizarBusqueda() {
    $.ajax({
        type: "POST",
        url: "./procesa/load_lenguaje_buscar.php",
        data: $("#formBuscarLenguaje").serialize(),
        success: function (data) {
            $('#seccionInferior').html(data);
            $('#tbLenguajes').dataTable({
                lengthChange: false,
                language: {url: "./js/_dt_spanish.json"}
            });
        },
        error: function (data) {
            console.log(data);
            var men = '<b>No se procesó la petición (Informe al administrador)</b>';
            var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
            $("#seccionInferior").html(div);
        },
        complete: function () {
            $('html,body').animate({scrollTop: $("#seccionInferior").offset().top}, '1250');
        }
    });
}
