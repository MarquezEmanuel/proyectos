/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    $('#formCrearAplicacion').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: "./procesa/load_aplicacion_crear.php",
            data: $("#formCrearAplicacion").serialize(),
            success: function (data) {
                $('#seccionResultado').html(data[0]['resultado']);
                if (data[0]['exito'] === true) {
                    $("#formCrearAplicacion")[0].reset();
                    $("select#herramienta").val('').trigger('change');
                    $("select#lenguaje").val('').trigger('change');
                    $("select#gerencia").val('').trigger('change');
                    $("select#plataforma").val('').trigger('change');
                    $("select#modo").val('').trigger('change');
                    $("select#lugar").val('').trigger('change');
                    $("select#bases").val('').trigger('change');
                    $("select#proveedores").val('').trigger('change');
                }
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionResultado").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#seccionResultado").offset().top}, '1250');
            }
        });
    });

    $('select#herramienta').select2({
        placeholder: 'Seleccionar',
        theme: "bootstrap",
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "./procesa/load_herramienta_seleccionar.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#lenguaje').select2({
        placeholder: 'Seleccionar',
        theme: "bootstrap",
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "./procesa/load_lenguaje_seleccionar.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#bases').select2({
        placeholder: 'Seleccionar',
        theme: "bootstrap",
        maximumInputLength: 30,
        maximumSelectionLength: 3,
        allowClear: true,
        ajax: {
            url: "procesa/load_base_seleccionar.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#proveedores').select2({
        placeholder: 'Seleccionar',
        theme: "bootstrap",
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "procesa/load_proveedor_seleccionar.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#plataforma').select2({
        placeholder: 'Seleccionar',
        theme: "bootstrap",
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "./procesa/load_plataforma_seleccionar.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#modo').select2({
        placeholder: 'Seleccionar',
        theme: "bootstrap",
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "./procesa/load_modo_seleccionar.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#lugar').select2({
        placeholder: 'Seleccionar',
        theme: "bootstrap",
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "./procesa/load_lugar_seleccionar.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#gerencia').select2({
        placeholder: 'Seleccionar',
        theme: "bootstrap",
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "./procesa/load_gerencia_seleccionar.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#delegado').select2({
        placeholder: 'Seleccionar',
        theme: "bootstrap",
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "./procesa/load_empleado_seleccionar_delegado.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

});

