<?php
require_once './core_header.php';
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "Constantes.php");
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "GeneradorHTML.php");

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;

$ruta = dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "logs";
$botones = '';
if (is_dir($ruta)) {
    $archivos = scandir($ruta);
    if ($archivos && count($archivos) > 2) {
        $filas = "";
        foreach ($archivos as $archivo) {

            if ($archivo != "." && $archivo != '..') {
                $filas .= "
                    <tr>
                        <td class='text-center'>
                            <input type='checkbox' name='archivos[]' id='archivos' value='{$archivo}'>
                        </td>
                        <td>{$archivo}</td>
                    </tr>";
            }
        }
        $cuerpo = '
            <div class="table-responsive mt-4 mb-4">
                <table id="tbArchivosLog" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th class="text-center"><input type="checkbox" name="cbTodos" id="cbTodos"></th>
                            <th>Nombre del archivo</th>
                        </tr>
                    </thead>
                    <tbody>' . $filas . '</tbody>
                </table>
            </div>';

        $botones = '
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <button type="button" class="btn btn-outline-success">
                        <i class="fas fa-download"></i> DESCARGAR
                    </button>
                    <button type="button" class="btn btn-outline-danger">
                        <i class="fas fa-trash"></i> BORRAR
                    </button>
                </div>
            </div>';
    } else {
        $mensaje = "No se encontraron archivos para mostrar";
        $cuerpo = GeneradorHTML::getAlertaOperacion(1, $mensaje);
    }
} else {
    $mensaje = "No se detectó un directorio válido";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_ACTIVIDAD; ?> BUSCAR ARCHIVOS LOG</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formBuscarArchivos" name="formBuscarArchivos" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
<?= $cuerpo; ?>
            </div>
        </div>
<?= $botones; ?>
    </form>
</div>

<script type="text/javascript" src="./js/actividad_buscar.js"></script>
