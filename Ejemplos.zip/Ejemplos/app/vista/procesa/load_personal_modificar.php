<?php

require_once './core_procesa_autoload.php';

use app\modelo\GeneradorHTML;
use app\controlador\ControladorPersonal;

$exito = FALSE;
if (isset($_POST['idPersonal'])) {
    $controlador = new ControladorPersonal();
    $id = $_POST['idPersonal'];
    $nombreCorto = $_POST['nombreCorto'];
    $nombreLargo = $_POST['nombreLargo'];
    $idDepartamento = $_POST['departamento'];
    $descripcion = $_POST['descripcion'];
    $modificacion = $controlador->modificar($id, $nombreCorto, $nombreLargo, $idDepartamento, $descripcion);
    $exito = ($modificacion[0] == 2) ? true : false;
    $mensaje = "{$nombreLargo}: {$modificacion[1]}";
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
