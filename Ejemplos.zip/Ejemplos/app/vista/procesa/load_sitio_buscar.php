<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorSitio;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorSitio();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $provincia = $_POST['provincia'];
    $ciudad = $_POST['ciudad'];
    $estado = $_POST['estado'];
    $resultado = $controlador->buscar($nombre, $provincia, $ciudad, $estado);
    $datos = "<span class=dropdown-item>Nombre: {$nombre}</span>";
    $datos .= "<span class=dropdown-item>Provincia: {$provincia}</span>";
    $datos .= "<span class=dropdown-item>Ciudad: {$ciudad}</span>";
    $datos .= "<span class=dropdown-item>Estado: {$estado}</span>";
    $filtro = "Resultado de la búsqueda";
    $_SESSION['LOAD_SIT_BUSCAR'] = array($nombre, $provincia, $ciudad, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_SITIO_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_SITIO_BUSCAR'];
        $nombre = $parametros[0];
        $provincia = $parametros[1];
        $ciudad = $parametros[2];
        $estado = $parametros[3];
        $datos = $parametros[4];
        $filtro = "Ultima búsqueda realizada";
        $resultado = $controlador->buscar($nombre, $provincia, $ciudad, $estado);
        $_SESSION['LOAD_SITIO_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $datos = "<span class=dropdown-item>Limite: {$cantidad}</span>";
        $datos .= "<span class=dropdown-item>Estado: {$estado}</span>";
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial";
        $_SESSION['LOAD_SITIO_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $sitios = $resultado[1];
    $filas = $operaciones = "";
    while ($sitio = sqlsrv_fetch_array($sitios, SQLSRV_FETCH_ASSOC)) {
        $id = $sitio['id'];
        $tipo = $sitio['tipo'];
        $nombre = utf8_encode($sitio['nombre']);
        $provincia = utf8_encode($sitio['provincia']);
        $ciudad = utf8_encode($sitio['ciudad']);
        $codigoPostal = $sitio['codigoPostal'];
        $direccion = utf8_encode($sitio['direccion']);
        $origen = $sitio['origen'];
        $estado = $sitio['estado'];
        $fechaCreacion = isset($sitio['fechaCreacion']) ? date_format($sitio['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($sitio['fechaUltimaEdicion']) ? date_format($sitio['fechaUltimaEdicion'], 'd/m/Y H:i') : "";

        $filas .= "
            <tr>
                <td class='align-middle'>{$id}</td>
                <td class='align-middle col_tipo'>{$tipo}</td>
                <td class='align-middle col_nombre'>{$nombre}</td>
                <td class='align-middle col_provincia'>{$provincia}</td>
                <td class='align-middle col_ciudad'>{$ciudad}</td>
                <td class='align-middle col_codigo_postal' style='display: none;'>{$codigoPostal}</td>
                <td class='align-middle col_direccion' style='display: none;'>{$direccion}</td>
                <td class='align-middle col_origen'>{$origen}</td>
                <td class='align-middle col_estado' style='display: none;'>{$estado}</td>
                <td class='align-middle col_fecha_creacion' style='display: none;'>{$fechaCreacion}</td>
                <td class='align-middle col_fecha_edicion' style='display: none;'>{$fechaEdicion}</td>
                <td class='text-center align-middle'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$id}' title='Detalle: $nombre'>
                                " . Constantes::ICON_DETALLE . "
                        </button>
                        <button class='btn btn-outline-warning editar' 
                                name='{$id}' title='Editar: $nombre'>
                                " . Constantes::ICON_EDITAR . "
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="form-row">
            <div class="col text-right">
                <div class="btn-group">
                    <button class="btn btn-outline-dark dropdown-toggle"
                            title="Configurar columnas a visualizar"
                            type="button" data-toggle="dropdown" 
                            aria-haspopup="true" aria-expanded="false">
                            ' . Constantes::ICON_RUEDAS . '
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_tipo"/> 
                            <span class="ml-4">Tipo</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_nombre"/>
                            <span class="ml-4">Nombre</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox"checked class="col_checkbox" value="col_provincia"/> 
                            <span class="ml-4">Provincia</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_ciudad"/> 
                            <span class="ml-4">Ciudad</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_codigo_postal"/> 
                            <span class="ml-4">Código postal</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_direccion"/> 
                            <span class="ml-4">Dirección</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_origen"/> 
                            <span class="ml-4">Origen</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_estado"/>
                            <span class="ml-4">Estado</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_fecha_creacion"/>
                            <span class="ml-4">Fecha de creación</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_fecha_edicion"/>
                            <span class="ml-4">Fecha de edición</span>
                        </a>
                    </div>
                </div>
                <div class="btn-group">
                    <button class="btn btn-outline-dark dropdown-toggle"
                            title="Datos del filtro aplicado"
                            type="button" data-toggle="dropdown" 
                            aria-haspopup="true" aria-expanded="false">
                            ' . Constantes::ICON_FILTRO . '
                    </button>
                    <div class="dropdown-menu">' . $datos . '</div>
                </div>   
            </div>  
        </div>';

    /* COMPLETA EL CUERPO DEL FORMULARIO CON LA TABLA DE RESULTADOS */

    $cuerpo .= '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbSitios" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th class="col_tipo">Tipo</th>
                        <th class="col_nombre">Nombre</th>
                        <th class="col_provincia">Provincia</th>
                        <th class="col_ciudad">Ciudad</th>
                        <th class="col_codigo_postal" style="display: none;">Código postal</th>
                        <th class="col_direccion" style="display: none;">Dirección</th>
                        <th class="col_origen">Origen</th>
                        <th class="col_estado" style="display: none;">Estado</th>
                        <th class="col_fecha_creacion" style="display: none;">Fecha de creación</th>
                        <th class="col_fecha_edicion" style="display: none;">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
