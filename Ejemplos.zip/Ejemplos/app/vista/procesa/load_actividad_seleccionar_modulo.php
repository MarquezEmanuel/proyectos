<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Log;
use app\controlador\ControladorActividad;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['modulo'])) {
    $controlador = new ControladorActividad();
    $modulo = $_POST['modulo'];
    $resultado = $controlador->buscarParaSeleccionarModulo($modulo);
    if ($resultado[0] == 2) {
        $registros = $resultado[1];
        while ($registro = sqlsrv_fetch_array($registros, SQLSRV_FETCH_ASSOC)) {
            $moduloActividad = utf8_encode($registro["modulo"]);
            $arreglo[] = array('id' => $moduloActividad, 'text' => $moduloActividad);
        }
    }
} else {
    $detalle = "No se recibio modulo para seleccionar";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'ACTIVIDAD', 'busqueda', 'PSeleccionarModulo', '', $detalle);
}
echo json_encode($arreglo);
