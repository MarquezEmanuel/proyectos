<?php

require_once './core_procesa_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorGerencia;

$controlador = new ControladorGerencia();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreGerencia = $_POST['nombreGerencia'];
    $nombreEmpleado = $_POST['nombreEmpleado'];
    $estado = $_POST['estado'];
    $datos = ($nombreGerencia) ? "'{$nombreGerencia}', " : "Sin gerencia, ";
    $datos .= ($nombreEmpleado) ? "'{$nombreEmpleado}', " : "Sin empleado, ";
    $datos .= ($estado) ? "'{$estado}'" : "Sin estado";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombreGerencia, $nombreEmpleado, $estado);
    $_SESSION['LOAD_GERENCIA_BUSCAR'] = array($nombreGerencia, $nombreEmpleado, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_GERENCIA_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_GERENCIA_BUSCAR'];
        $nombreGerencia = $parametros[0];
        $nombreEmpleado = $parametros[1];
        $estado = $parametros[2];
        $filtro = "Ultima búsqueda realizada: " . $parametros[3];
        $resultado = $controlador->buscar($nombreGerencia, $nombreEmpleado, $estado);
        $_SESSION['LOAD_GERENCIA_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activa';
        $resultado = $controlador->buscarUltimasCreadas($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['LOAD_GERENCIA_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $gerencias = $resultado[1];
    $filas = "";
    while ($gerencia = sqlsrv_fetch_array($gerencias, SQLSRV_FETCH_ASSOC)) {
        $id = $gerencia['idGerencia'];
        $nombreGerencia = utf8_encode($gerencia['nombreGerencia']);
        $idEmpleado = $gerencia['idEmpleado'];
        $nombreEmpleado = utf8_encode($gerencia['nombreEmpleado']);
        $estadoEmpleado = $gerencia['estadoEmpleado'];
        $estadoGerencia = $gerencia['estadoGerencia'];
        $fechaCreacion = isset($gerencia['fechaCreacionGerencia']) ? date_format($gerencia['fechaCreacionGerencia'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($gerencia['fechaUltimaEdicionGerencia']) ? date_format($gerencia['fechaUltimaEdicionGerencia'], 'd/m/Y H:i') : "";
        $tituloEmpleado = ($estadoEmpleado) ? "Estado del gerente: {$estadoEmpleado}" : "";
        $filas .= "
            <tr>
                <td>{$nombreGerencia}</td>
                <td title='{$tituloEmpleado}'>{$idEmpleado}</td>
                <td title='{$tituloEmpleado}'>{$nombreEmpleado}</td>
                <td style='display: none;'>{$estadoGerencia}</td>
                <td style='display: none;'>{$fechaCreacion}</td>
                <td style='display: none;'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' 
                                name='{$id}' title='Editar: $nombreGerencia'>
                            <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbGerencias" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead >
                    <tr>
                        <th>Nombre</th>
                        <th>Legajo gerente</th>
                        <th>Nombre gerente</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">Fecha de creación</th>
                        <th style="display: none;">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
