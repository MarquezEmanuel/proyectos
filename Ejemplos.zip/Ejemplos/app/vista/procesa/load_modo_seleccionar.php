<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\controlador\ControladorModoProcesamiento;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
$controlador = new ControladorModoProcesamiento();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $modos = $resultado[1];
    while ($modo = sqlsrv_fetch_array($modos, SQLSRV_FETCH_ASSOC)) {
        $idModo = $modo["id"];
        $nombreModo = utf8_encode($modo["nombre"]);
        $arreglo[] = array('id' => $idModo, 'text' => $nombreModo);
    }
}

echo json_encode($arreglo);
