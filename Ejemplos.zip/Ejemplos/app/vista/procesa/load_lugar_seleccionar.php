<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\controlador\ControladorLugarProcesamiento;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
$controlador = new ControladorLugarProcesamiento();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $lugares = $resultado[1];
    while ($lugar = sqlsrv_fetch_array($lugares, SQLSRV_FETCH_ASSOC)) {
        $idLugar = $lugar["id"];
        $nombreLugar = utf8_encode($lugar["nombre"]);
        $arreglo[] = array('id' => $idLugar, 'text' => $nombreLugar);
    }
}

echo json_encode($arreglo);

