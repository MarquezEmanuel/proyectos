<?php

require_once './core_procesa_autoload.php';

use app\controlador\ControladorLugarProcesamiento;

$arreglo = array();
$controlador = new ControladorLugarProcesamiento();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $lugares = $resultado[1];
    while ($lugar = sqlsrv_fetch_array($lugares, SQLSRV_FETCH_ASSOC)) {
        $idLugar = $lugar["id"];
        $nombreLugar = utf8_encode($lugar["nombre"]);
        $arreglo[] = array('id' => $idLugar, 'text' => $nombreLugar);
    }
}

echo json_encode($arreglo);

