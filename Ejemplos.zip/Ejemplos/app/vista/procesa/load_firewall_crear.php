<?php

require_once './core_procesa_autoload.php';

use app\modelo\GeneradorHTML;
use app\controlador\ControladorFirewall;

$exito = FALSE;
if ($_POST['nombre'] && $_POST['sucursal']) {
    $nombre = $_POST['nombre'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $numeroSerie = $_POST['nroSerie'];
    $version = $_POST['version'];
    $sitio = $_POST['sucursal'];
    $ip = $_POST['ip'];
    $descripcion = $_POST['descripcion'];
    $proveedores = $_POST['proveedores'];
    $controlador = new ControladorFirewall();
    $creacion = $controlador->crear($nombre, $marca, $modelo, $numeroSerie, $version, $sitio, $ip, $descripcion, $proveedores);
    $mensaje = "$nombre: $creacion[1]";
    $exito = ($creacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($creacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
