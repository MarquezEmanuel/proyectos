<?php

require_once './core_procesa_autoload.php';

use app\controlador\ControladorGerencia;

$arreglo = array();
$controlador = new ControladorGerencia();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $gerencias = $resultado[1];
    while ($gerencia = sqlsrv_fetch_array($gerencias, SQLSRV_FETCH_ASSOC)) {
        $idGerencia = $gerencia["id"];
        $nombreGerencia = utf8_encode($gerencia["nombre"]);
        $arreglo[] = array('id' => $idGerencia, 'text' => $nombreGerencia);
    }
}

echo json_encode($arreglo);
