<?php

require_once './core_procesa_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorBaseDatosManual;

$controlador = new ControladorBaseDatosManual();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $collation = $_POST['collation'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " : "TODOS, ";
    $datos .= ($collation) ? "'{$collation}', " : "TODAS, ";
    $datos .= ($estado) ? "'{$estado}', " : "TODOS, ";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombre, $collation, $estado);
    $_SESSION['LOAD_BASE_BUSCAR'] = array($nombre, $collation, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_BASE_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_BASE_BUSCAR'];
        $nombre = $parametros[0];
        $collation = $parametros[1];
        $estado = $parametros[2];
        $filtro = "Ultima búsqueda realizada: " . $parametros[3];
        $resultado = $controlador->buscar($nombre, $collation, $estado);
        $_SESSION['LOAD_BASE_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activa';
        $resultado = $controlador->buscarUltimasCreadas($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['LOAD_BASE_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $basesDatos = $resultado[1];
    $filas = "";
    while ($base = sqlsrv_fetch_array($basesDatos, SQLSRV_FETCH_ASSOC)) {

        $id = $base['id'];
        $numero = '#' . str_pad($id, 4, "0", STR_PAD_LEFT);
        $nombre = utf8_encode($base['nombre']);
        $collation = utf8_encode($base['collation']);
        $estadoBase = utf8_encode($base['estadoBase']);
        $descripcion = utf8_encode($base['descripcion']);
        $estado = $base['estado'];
        $fechaCreacion = isset($base['fechaCreacion']) ? date_format($base['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($base['fechaUltimaEdicion']) ? date_format($base['fechaUltimaEdicion'], 'd/m/Y H:i') : "";
        $cantidadHardwares = $base['cantidadHardwares'];

        $filas .= "
            <tr>
                <td class='align-middle'>{$numero}</td>
                <td class='align-middle col_nombre'>{$nombre}</td>
                <td class='align-middle col_collation'>{$collation}</td>
                <td class='align-middle col_estado_base'>{$estadoBase}</td> 
                <td class='align-middle col_descripcion' style='display: none;'>{$descripcion}</td>
                <td class='align-middle col_estado' style='display: none;'>{$estado}</td>
                <td class='align-middle col_fecha_creacion' style='display: none;'>{$fechaCreacion}</td>
                <td class='align-middle col_fecha_edicion' style='display: none;'>{$fechaEdicion}</td>
                <td class='align-middle col_cantidad_harwares'>{$cantidadHardwares}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$id}' title='Detalle: {$nombre}'>
                                " . Constantes::ICON_DETALLE . "
                        </button>
                        <button class='btn btn-outline-warning editar' 
                                name='{$id}' title='Editar: {$nombre}'>
                                " . Constantes::ICON_EDITAR . "
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbBasesManual" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th class="col_nombre">Nombre</th>
                        <th class="col_collation">Collation</th>
                        <th class="col_estado_base">Estado de base</th>
                        <th class="col_descripcion" style="display: none;">Descripción</th>
                        <th class="col_estado" style="display: none;">Estado</th>
                        <th class="col_fecha_creacion" style="display: none;">Fecha de creación</th>
                        <th class="col_fecha_edicion" style="display: none;">Fecha de edición</th>
                        <th class="col_cantidad_hardwares" >Cantidad de hardwares</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
