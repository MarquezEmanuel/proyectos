<?php

require_once './core_procesa_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorPerfil;

$controlador = new ControladorPerfil();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " . $estado : "TODOS, " . $estado;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombre, $estado);
    $_SESSION['LOAD_PERFIL_BUSCAR'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_PERFIL_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_PERFIL_BUSCAR'];
        $nombre = $parametros[0];
        $nivel = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $resultado = $controlador->buscar($nombre, $nivel);
        $_SESSION['LOAD_PERFIL_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $limite = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($limite, $estado);
        $filtro = "Resumen inicial de perfiles";
        $_SESSION['LOAD_PERFIL_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $filas = "";
    $perfiles = $resultado[1];
    while ($perfil = sqlsrv_fetch_array($perfiles, SQLSRV_FETCH_ASSOC)) {
        $id = $perfil['id'];
        $numero = '#' . str_pad($id, 4, "0", STR_PAD_LEFT);
        $nombre = utf8_encode($perfil['nombre']);
        $descripcion = utf8_encode($perfil['descripcion']);
        $totalUsuarios = $perfil['usuarios'];
        $totalPermisos = $perfil['permisos'];
        $filas .= "
            <tr>
                <td>{$numero}</td>
                <td>{$nombre}</td>
                <td>{$descripcion}</td>
                <td>{$totalUsuarios}</td>
                <td>{$totalPermisos}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' 
                                name='{$id}' title='Editar'>
                                " . Constantes::ICON_EDITAR . "
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbPerfiles" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th title="Cantidad de usuarios asociados">Usuarios</th>
                        <th title="Cantidad de permisos asociados">Permisos</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
