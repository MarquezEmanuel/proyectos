<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorInstalacion;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['nombreCorto'])) {
    $controlador = new ControladorInstalacion();
    $nombreCorto = $_POST['nombreCorto'];
    $nombreLargo = $_POST['nombreLargo'];
    $gerencia = $_POST['gerencia'];
    $empleado = $_POST['empleado'];
    $sitio = $_POST['sitio'];
    $plataforma = $_POST['plataforma'];
    $descripcion = $_POST['descripcion'];
    $creacion = $controlador->crear($nombreCorto, $nombreLargo, $gerencia, $empleado, $sitio, $plataforma, $descripcion);
    $mensaje = "{$nombreLargo}: {$creacion[1]}";
    $exito = ($creacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($creacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
