<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorEmpleado;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorEmpleado();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $legajo = $_POST['legajo'];
    $nombreEmpleado = $_POST['nombreEmpleado'];
    $nombreDepartamento = $_POST['nombreDepartamento'];
    $estado = $_POST['estado'];
    $datos = ($legajo) ? "'{$legajo}', " : "Sin legajo, ";
    $datos .= ($nombreEmpleado) ? "'{$nombreEmpleado}', " : "Sin nombre, ";
    $datos .= ($nombreDepartamento) ? "'{$nombreDepartamento}', " : "Sin departamento, ";
    $datos .= ($estado) ? "'{$estado}'" : "Sin estado";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($legajo, $nombreEmpleado, $nombreDepartamento, $estado);
    $_SESSION['LOAD_EMPLEADO_BUSCAR'] = array($legajo, $nombreEmpleado, $nombreDepartamento, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_EMPLEADO_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_EMPLEADO_BUSCAR'];
        $legajo = $parametros[0];
        $nombreEmpleado = $parametros[1];
        $nombreDepartamento = $parametros[2];
        $estado = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[4];
        $resultado = $controlador->buscar($legajo, $nombreEmpleado, $nombreDepartamento, $estado);
        $_SESSION['LOAD_EMPLEADO_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['LOAD_EMPLEADO_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $trabajadores = $resultado[1];
    $filas = "";
    while ($trabajador = sqlsrv_fetch_array($trabajadores, SQLSRV_FETCH_ASSOC)) {

        $id = $trabajador['idEmpleado'];
        $nombreEmpleado = utf8_encode($trabajador['nombreEmpleado']);
        $nombreDepartamento = utf8_encode($trabajador['nombreDepartamento']);
        $estadoDepartamento = $trabajador['estadoDepartamento'];
        $esGerente = $trabajador['gerente'];
        $estadoEmpleado = $trabajador['estadoEmpleado'];
        $fechaCreacion = isset($trabajador['fechaCreacionEmpleado']) ? date_format($trabajador['fechaCreacionEmpleado'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($trabajador['fechaUltimaEdicionEmpleado']) ? date_format($trabajador['fechaUltimaEdicionEmpleado'], 'd/m/Y H:i') : "";
        $tituloDepartamento = ($estadoDepartamento) ? "Estado del departamento: {$estadoDepartamento}" : "";

        $filas .= "
            <tr>
                <td title='{$tituloDepartamento}'>{$nombreDepartamento}</td>
                <td>{$id}</td>
                <td>{$nombreEmpleado}</td>
                <td>{$esGerente}</td>
                <td style='display: none;'>{$estadoEmpleado}</td>
                <td style='display: none;'>{$fechaCreacion}</td>
                <td style='display: none;'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' 
                                name='{$id}' title='Editar: $nombreEmpleado'>
                            <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbEmpleados" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Departamento</th>
                        <th>Legajo</th>
                        <th>Nombre</th>
                        <th>Gerente</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">Fecha de creación</th>
                        <th style="display: none;">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
