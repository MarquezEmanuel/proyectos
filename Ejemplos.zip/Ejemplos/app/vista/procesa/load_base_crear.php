<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorBaseDatosManual;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if ($_POST['nombre'] && $_POST['collation']) {
    $nombre = $_POST['nombre'];
    $collation = $_POST['collation'];
    $estadoBase = $_POST['estadoBase'];
    $descripcion = $_POST['descripcion'];
    $orden = $_POST['orden'];
    $hardwares = array();
    foreach ($orden as $index) {
        if (isset($_POST["servidor{$index}"])) {
            $servidor = $_POST["servidor{$index}"];
            $fechaCreacion = isset($_POST["fechaCreacion{$index}"]) ? $_POST["fechaCreacion{$index}"] : NULL;
            $hardwares[] = array($servidor, $index, $fechaCreacion);
        }
    }
    $controlador = new ControladorBaseDatosManual();
    $creacion = $controlador->crear($nombre, $collation, $estadoBase, $descripcion, $hardwares);
    $mensaje = "$nombre: $creacion[1]";
    $exito = ($creacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($creacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);

