<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorAplicacion;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if ($_POST['idAplicacion']) {
    $controlador = new ControladorAplicacion();
    $id = $_POST['idAplicacion'];
    $nombreCorto = $_POST['nombreCorto'];
    $nombreLargo = $_POST['nombreLargo'];
    $tipo = $_POST['tipo'];
    $seguridad = $_POST['seguridad'];
    $tecnologia = $_POST['tecnologia'];
    $lenguaje = isset($_POST['lenguaje']) ? $_POST['lenguaje'] : NULL;
    $herramienta = isset($_POST['herramienta']) ? $_POST['herramienta'] : NULL;
    $modo = $_POST['modo'];
    $lugar = $_POST['lugar'];
    $plataforma = $_POST['plataforma'];
    $gerencia = $_POST['gerencia'];
    $empleado = isset($_POST['delegado']) ? $_POST['delegado'] : NULL;
    $fechaCaducidad = $_POST['fechaCaducidad'] ? $_POST['fechaCaducidad'] . "T00:00:00" : NULL;
    $codigoSAS = $_POST['codigoSAS'];
    $tipoLog = $_POST['tipoLog'];
    $estado = $_POST['estado'];
    $descripcion = $_POST['descripcion'];
    $basesDatos = $_POST['bases'];
    $proveedores = $_POST['proveedores'];
    $modificacion = $controlador->modificarSistemas($id, $nombreCorto, $nombreLargo, $tipo, $seguridad, $tecnologia, $lenguaje, $herramienta, $modo, $lugar, $plataforma, $gerencia, $empleado, $fechaCaducidad, $codigoSAS, $tipoLog, $descripcion, $estado, $basesDatos, $proveedores);
    $mensaje = "{$nombreLargo}: $modificacion[1]";
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
