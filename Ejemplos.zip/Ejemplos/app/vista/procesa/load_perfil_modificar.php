<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");


modelos\AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['idPerfil'])) {
    $controlador = new controladores\ControladorPerfil();
    $id = $_POST['idPerfil'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $permisos = $_POST['permisos'];
    $modificacion = $controlador->modificar($id, $nombre, $descripcion, $permisos);
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = controladores\ControladorHTML::getAlertaOperacion($modificacion[0], $modificacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = controladores\ControladorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
