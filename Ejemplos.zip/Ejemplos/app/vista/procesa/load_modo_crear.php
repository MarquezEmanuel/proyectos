<?php

require_once './core_procesa_autoload.php';

use app\controlador\ControladorModoProcesamiento;
use app\modelo\GeneradorHTML;

$exito = FALSE;
if ($_POST['nombre']) {
    $controlador = new ControladorModoProcesamiento();
    $nombre = $_POST['nombre'];
    $creacion = $controlador->crear($nombre);
    $mensaje = "{$nombre}: $creacion[1]";
    $exito = ($creacion[0] == 2) ? TRUE : FALSE;
    $resultado = GeneradorHTML::getAlertaOperacion($creacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
