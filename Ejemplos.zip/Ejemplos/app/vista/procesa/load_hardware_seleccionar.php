<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Log;
use app\controlador\ControladorHardware;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorHardware();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $hadwares = $resultado[1];
        while ($hadware = sqlsrv_fetch_array($hadwares, SQLSRV_FETCH_ASSOC)) {
            $idHardware = $hadware["id"];
            $nombreHardware = utf8_encode($hadware["tipo"]) . ': ' . utf8_encode($hadware["nombreLargo"]);
            $arreglo[] = array('id' => $idHardware, 'text' => $nombreHardware);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar hardware";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'HARDWARES', 'busqueda', 'PSeleccionarHardware', '', $detalle);
}

echo json_encode($arreglo);
