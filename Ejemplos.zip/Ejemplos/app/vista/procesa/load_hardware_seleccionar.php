<?php

require_once './core_procesa_autoload.php';

use app\modelo\Log;
use app\controlador\ControladorHardware;

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorHardware();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $hadwares = $resultado[1];
        while ($hadware = sqlsrv_fetch_array($hadwares, SQLSRV_FETCH_ASSOC)) {
            $idHardware = $hadware["id"];
            $nombreHardware = utf8_encode($hadware["tipo"]) . ': ' . utf8_encode($hadware["nombreLargo"]);
            $arreglo[] = array('id' => $idHardware, 'text' => $nombreHardware);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar hardware";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'HARDWARES', 'busqueda', 'PSeleccionarHardware', '', $detalle);
}

echo json_encode($arreglo);
