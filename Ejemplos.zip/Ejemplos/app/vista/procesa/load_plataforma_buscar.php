<?php

require_once './core_procesa_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorPlataformaSO;

$controlador = new ControladorPlataformaSO();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', '{$estado}'" : "'$estado'";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombre, $estado);
    $_SESSION['LOAD_PLATAFORMA_BUSCAR'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_PLATAFORMA_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_PLATAFORMA_BUSCAR'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $resultado = $controlador->buscar($nombre, $estado);
        $_SESSION['LOAD_PLATAFORMA_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activa';
        $resultado = $controlador->buscarUltimasCreadas($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['LOAD_PLATAFORMA_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $plataformas = $resultado[1];
    $filas = "";
    while ($plataforma = sqlsrv_fetch_array($plataformas, SQLSRV_FETCH_ASSOC)) {
        $id = $plataforma['id'];
        $nombre = utf8_encode($plataforma['nombre']);
        $estado = $plataforma['estado'];
        $fechaCreacion = isset($plataforma['fechaCreacion']) ? date_format($plataforma['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($plataforma['fechaUltimaEdicion']) ? date_format($plataforma['fechaUltimaEdicion'], 'd/m/Y H:i') : "";
        $filas .= "
            <tr>
                <td>{$nombre}</td>
                <td style='display: none;'>{$estado}</td>
                <td class='align-middle'>{$fechaCreacion}</td>
                <td class='align-middle'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' 
                                name='{$id}' title='Editar: $nombre'>
                            <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbPlataformas" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th style="display: none;">Estado</th>
                        <th>Fecha de creación</th>
                        <th>Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
