<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;

AutoCargador::cargarModulos();

session_start();

$exito = FALSE;
if (isset($_POST['legajo'])) {
    $controlador = new controladores\ControladorUsuario();
    $legajo = $_POST['legajo'];
    $nombre = $_POST['nombre'];
    $perfil = $_POST['perfil'];
    $creacion = $controlador->crear($legajo, $nombre, $perfil);
    $exito = ($creacion[0] == 2) ? true : false;
    $resultado = controladores\ControladorHTML::getAlertaOperacion($creacion[0], $creacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = controladores\ControladorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
