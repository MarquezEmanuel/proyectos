<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorPersonal;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorPersonal();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombrePersonal = $_POST['nombrePersonal'];
    $nombreDepartamento = $_POST['nombreDepartamento'];
    $estado = $_POST['estado'];
    $datos = ($nombrePersonal) ? "'{$nombrePersonal}', " : "TODOS, ";
    $datos .= ($nombreDepartamento) ? "'{$nombreDepartamento}', " : "TODOS, ";
    $datos .= ($estado) ? "'{$estado}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombrePersonal, $nombreDepartamento, $estado);
    $_SESSION['LOAD_PERSONAL_BUSCAR'] = array($nombrePersonal, $nombreDepartamento, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_PERSONAL_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_PERSONAL_BUSCAR'];
        $nombrePersonal = $parametros[0];
        $nombreDepartamento = $parametros[1];
        $estado = $parametros[2];
        $filtro = "Ultima búsqueda realizada: " . $parametros[3];
        $resultado = $controlador->buscar($nombrePersonal, $nombreDepartamento, $estado);
        $_SESSION['LOAD_PERSONAL_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial";
        $_SESSION['LOAD_PERSONAL_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $personales = $resultado[1];
    $filas = "";
    while ($personal = sqlsrv_fetch_array($personales, SQLSRV_FETCH_ASSOC)) {
        $idPersonal = $personal['idPersonal'];
        $nombreCortoPersonal = utf8_encode($personal['nombreCortoPersonal']);
        $nombreLargoPersonal = utf8_encode($personal['nombreLargoPersonal']);
        $idDepartamento = $personal['idDepartamento'];
        $nombreDepartamento = utf8_encode($personal['nombreDepartamento']);
        $estadoDepartamento = $personal['estadoDepartamento'];
        $descripcionPersonal = utf8_encode($personal['descripcionPersonal']);
        $estadoPersonal = $personal['estadoPersonal'];
        $fechaCreacion = isset($personal['fechaCreacionPersonal']) ? date_format($personal['fechaCreacionPersonal'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($personal['fechaUltimaEdicionPersonal']) ? date_format($personal['fechaUltimaEdicionPersonal'], 'd/m/Y H:i') : "";
        $filas .= "
            <tr>
                <td>{$nombreCortoPersonal}</td>
                <td>{$nombreLargoPersonal}</td>
                <td title='$nombreDepartamento: $estadoDepartamento'>{$nombreDepartamento}</td> 
                <td style='display: none;'>{$estadoDepartamento}</td>
                <td style='display: none;'>{$descripcionPersonal}</td>
                <td style='display: none;'>{$estadoPersonal}</td>
                <td style='display: none;'>{$fechaCreacion}</td>
                <td style='display: none;'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$idPersonal}' title='Ver información básica: $nombreLargoPersonal'>
                                <i class='fas fa-info-circle'></i>
                        </button>
                        <button class='btn btn-outline-warning editar' 
                                name='{$idPersonal}' title='Editar: $nombreLargoPersonal'>
                            <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbPersonales" class="table table-bordered table-hover" 
                   cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre corto</th>
                        <th>Nombre largo</th>
                        <th>Nombre departamento</th>
                        <th style="display: none;">Estado departamento</th>
                        <th style="display: none;">Descripcion personal</th>
                        <th style="display: none;">Estado personal</th>
                        <th style="display: none;">Fecha de creación</th>
                        <th style="display: none;">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
