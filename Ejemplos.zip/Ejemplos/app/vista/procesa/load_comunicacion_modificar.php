<?php

require_once './core_procesa_autoload.php';

use app\modelo\GeneradorHTML;
use app\controlador\ControladorComunicacion;

$exito = FALSE;
if (isset($_POST['idComunicacion'])) {
    $controlador = new ControladorComunicacion();
    $id = $_POST['idComunicacion'];
    $nombreCorto = $_POST['nombreCorto'];
    $nombreLargo = $_POST['nombreLargo'];
    $cantidad = $_POST['cantidad'];
    $gerencia = $_POST['gerencia'];
    $empleado = $_POST['delegado'];
    $sitio = $_POST['sitio'];
    $proveedor = $_POST['proveedor'];
    $estado = $_POST['estado'];
    $descripcion = $_POST['descripcion'];
    $modificacion = $controlador->modificar($id, $nombreCorto, $nombreLargo, $cantidad, $gerencia, $empleado, $sitio, $proveedor, $estado, $descripcion);
    $mensaje = "{$nombreLargo}: {$modificacion[1]}";
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
