<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Log;
use app\controlador\ControladorActividad;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['operacion'])) {
    $controlador = new ControladorActividad();
    $operacion = $_POST['operacion'];
    $resultado = $controlador->buscarParaSeleccionarOperacion($operacion);
    if ($resultado[0] == 2) {
        $registros = $resultado[1];
        while ($registro = sqlsrv_fetch_array($registros, SQLSRV_FETCH_ASSOC)) {
            $operacionActividad = utf8_encode($registro["operacion"]);
            $arreglo[] = array('id' => $operacionActividad, 'text' => $operacionActividad);
        }
    }
} else {
    $detalle = "No se recibio operacion para seleccionar";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'ACTIVIDAD', 'busqueda', 'PSeleccionarOperacion', '', $detalle);
}
echo json_encode($arreglo);
