<?php

require_once './core_procesa_autoload.php';

use app\controlador\ControladorEmpleado;

$arreglo = array();
$controlador = new ControladorEmpleado();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionarDelegado($nombre);
if ($resultado[0] == 2) {
    $empleados = $resultado[1];
    while ($empleado = sqlsrv_fetch_array($empleados, SQLSRV_FETCH_ASSOC)) {
        $idEmpleado = $empleado["id"];
        $nombreEmpleado = utf8_encode($empleado["nombre"]);
        $arreglo[] = array('id' => $idEmpleado, 'text' => $nombreEmpleado);
    }
}
echo json_encode($arreglo);
