<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\controlador\ControladorHerramientaDesarrollo;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
$controlador = new ControladorHerramientaDesarrollo();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $herramientas = $resultado[1];
    while ($herramienta = sqlsrv_fetch_array($herramientas, SQLSRV_FETCH_ASSOC)) {
        $idHerramienta = $herramienta["id"];
        $nombreHerramienta = utf8_encode($herramienta["nombre"]) . " (" . utf8_encode($herramienta["version"]) . ')';
        $arreglo[] = array('id' => $idHerramienta, 'text' => $nombreHerramienta);
    }
}

echo json_encode($arreglo);
