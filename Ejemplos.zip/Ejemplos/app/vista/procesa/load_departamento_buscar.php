<?php

require_once './core_procesa_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorDepartamento;

$controlador = new ControladorDepartamento();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreDepartamento = $_POST['nombreDepartamento'];
    $nombreGerencia = $_POST['nombreGerencia'];
    $estado = $_POST['estado'];
    $datos = ($nombreDepartamento) ? "'{$nombreDepartamento}', " : "";
    $datos .= ($nombreGerencia) ? "'{$nombreGerencia}', " : "";
    $datos .= ($estado) ? "'{$estado}'" : "";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombreDepartamento, $nombreGerencia, $estado);
    $_SESSION['LOAD_DEPARTAMENTO_BUSCAR'] = array($nombreDepartamento, $nombreGerencia, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_DEPARTAMENTO_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_DEPARTAMENTO_BUSCAR'];
        $nombreDepartamento = $parametros[0];
        $nombreGerencia = $parametros[1];
        $estado = $parametros[2];
        $filtro = "Ultima búsqueda realizada: " . $parametros[3];
        $resultado = $controlador->buscar($nombreDepartamento, $nombreGerencia, $estado);
        $_SESSION['LOAD_DEPARTAMENTO_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['LOAD_DEPARTAMENTO_BUSCAR'] = NULL;
    }
}
if ($resultado[0] == 2) {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $departamentos = $resultado[1];
    $filas = "";
    while ($deparamento = sqlsrv_fetch_array($departamentos, SQLSRV_FETCH_ASSOC)) {
        $id = $deparamento['idDepartamento'];
        $nombreDepartamento = utf8_encode($deparamento['nombreDepartamento']);
        $nombreGerencia = utf8_encode($deparamento['nombreGerencia']);
        $estadoGerencia = $deparamento['estadoGerencia'];
        $estadoDepartamento = $deparamento['estadoDepartamento'];
        $fechaCreacion = isset($deparamento['fechaCreacionDepartamento']) ? date_format($deparamento['fechaCreacionDepartamento'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($deparamento['fechaUltimaEdicionDepartamento']) ? date_format($deparamento['fechaUltimaEdicionDepartamento'], 'd/m/Y H:i') : "";

        $filas .= "
            <tr>
                <td title='Estado de la gerencia: {$estadoGerencia}'>{$nombreGerencia}</td>
                <td>{$nombreDepartamento}</td>
                <td style='display: none;'>{$estadoDepartamento}</td>
                <td>{$fechaCreacion}</td>
                <td>{$fechaEdicion}</td>
                <td class='text-center'> 
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' 
                                name='{$id}' title='Editar: $nombreDepartamento'>
                            <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbDepartamentos" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Gerencia</th>
                        <th>Nombre</th>
                        <th style="display: none;">Estado</th>
                        <th>Fecha de creación</th>
                        <th>Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
