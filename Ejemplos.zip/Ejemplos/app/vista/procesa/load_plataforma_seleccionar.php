<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\controlador\ControladorPlataformaSO;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorPlataformaSO();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $plataformas = $resultado[1];
        while ($plataforma = sqlsrv_fetch_array($plataformas, SQLSRV_FETCH_ASSOC)) {
            $id = $plataforma["id"];
            $nombrePlataforma = utf8_encode($plataforma["nombre"]);
            $arreglo[] = array('id' => $id, 'text' => $nombrePlataforma);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar plataforma";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'PLATAFORMAS', 'busqueda', 'PSeleccionarPlataformaSO', '', $detalle);
}

echo json_encode($arreglo);
