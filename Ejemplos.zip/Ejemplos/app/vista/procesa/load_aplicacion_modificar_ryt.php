<?php

require_once './core_procesa_autoload.php';

use app\modelo\GeneradorHTML;
use app\controlador\ControladorAplicacion;

$exito = FALSE;
if ($_POST['idAplicacion']) {
    $controlador = new ControladorAplicacion();
    $id = $_POST['idAplicacion'];
    $nombreLargo = $_POST['nombreLargo'];
    $hardwares = array();
    for ($index = 1; $index <= 3; $index++) {
        $servidor = isset($_POST["servidor{$index}"]) ? $_POST["servidor{$index}"] : NULL;
        $ruta = isset($_POST["ruta{$index}"]) ? $_POST["ruta{$index}"] : NULL;
        if ($servidor) {
            $hardwares[] = array($servidor, $index, $ruta);
        }
    }
    $modificacion = $controlador->modificarTecnologiaInformatica($id, $hardwares);
    $mensaje = "{$nombreLargo}: {$modificacion[1]}";
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
