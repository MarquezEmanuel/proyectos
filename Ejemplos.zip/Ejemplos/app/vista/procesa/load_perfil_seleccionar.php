<?php

require_once './core_procesa_autoload.php';

use app\controlador\ControladorPerfil;

$arreglo = array();
$controlador = new ControladorPerfil();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : "";
$resultado = $controlador->buscarParaSeleccionar($nombre);

if ($resultado[0] == 2) {
    $perfiles = $resultado[1];
    while ($perfil = sqlsrv_fetch_array($perfiles, SQLSRV_FETCH_ASSOC)) {
        $idPerfil = $perfil["id"];
        $nombrePerfil = utf8_encode($perfil["nombre"]);
        $arreglo[] = array('id' => $idPerfil, 'text' => $nombrePerfil);
    }
}

echo json_encode($arreglo);
