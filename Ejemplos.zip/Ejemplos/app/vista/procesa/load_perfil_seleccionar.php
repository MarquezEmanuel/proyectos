<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

modelos\AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre']) && isset($_POST['estado'])) {
    $controlador = new controladores\ControladorPerfil();
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $perfiles = $controlador->seleccionar($nombre, $estado);
    if (gettype($perfiles[0]) == "resource") {
        $resource = $perfiles[0];
        while ($perfil = sqlsrv_fetch_array($resource, SQLSRV_FETCH_ASSOC)) {
            $arreglo[] = array('id' => $perfil["id"], 'text' => utf8_encode($perfil["nombre"]));
        }
    }
}

echo json_encode($arreglo);
