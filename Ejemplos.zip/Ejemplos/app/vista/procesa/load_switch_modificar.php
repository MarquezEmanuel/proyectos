<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorSwitch;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['idSwitch'])) {
    $controlador = new ControladorSwitch();
    $id = $_POST['idSwitch'];
    $nombre = $_POST['nombre'];
    $modelo = $_POST['modelo'];
    $version = $_POST['version'];
    $instalacion = $_POST['instalacion'];
    $sitio = $_POST['sitio'];
    $estado = $_POST['estado'];
    $descripcion = $_POST['descripcion'];
    $proveedores = $_POST['proveedores'];
    $modificacion = $controlador->modificar($id, $nombre, $modelo, $version, $sitio, $instalacion, $descripcion, $estado, $proveedores);
    $mensaje = "{$nombre}: {$modificacion[1]}";
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
