<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

modelos\AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['legajo'])) {
    $original = $_POST['legajoOriginal'];
    $legajo = $_POST['legajo'];
    $nombre = $_POST['nombre'];
    $perfil = $_POST['perfil'];
    $controlador = new controladores\ControladorUsuario();
    $modificacion = $controlador->modificar($original, $legajo, $nombre, $perfil);
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = controladores\ControladorHTML::getAlertaOperacion($modificacion[0], $modificacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = controladores\ControladorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);

