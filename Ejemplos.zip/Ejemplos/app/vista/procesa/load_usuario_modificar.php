<?php

require_once './core_procesa_autoload.php';

use app\modelo\GeneradorHTML;
use app\controlador\ControladorUsuario;

$exito = FALSE;
if (isset($_POST['legajo'])) {
    $original = $_POST['legajoOriginal'];
    $legajo = $_POST['legajo'];
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $perfil = $_POST['perfil'];
    $controlador = new ControladorUsuario();
    $modificacion = $controlador->modificar($original, $legajo, $nombre, $estado, $perfil);
    $mensaje = "{$nombre}: {$modificacion[1]}";
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);

