<?php

require_once './core_procesa_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorProveedor;

$controlador = new ControladorProveedor();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $provincia = $_POST['provincia'];
    $ciudad = $_POST['ciudad'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " : "TODAS, ";
    $datos .= ($provincia) ? "'{$provincia}', " : "TODAS, ";
    $datos .= ($ciudad) ? "'{$ciudad}', " : "TODAS, ";
    $datos .= ($estado) ? "'{$estado}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombre, $provincia, $ciudad, $estado);
    $_SESSION['LOAD_PROVEEDOR_BUSCAR'] = array($nombre, $provincia, $ciudad, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_PROVEEDOR_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_PROVEEDOR_BUSCAR'];
        $nombre = $parametros[0];
        $provincia = $parametros[1];
        $ciudad = $parametros[2];
        $estado = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[4];
        $resultado = $controlador->buscar($nombre, $provincia, $ciudad, $estado);
        $_SESSION['LOAD_PROVEEDOR_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['LOAD_PROVEEDOR_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $proveedores = $resultado[1];
    $filas = "";
    while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
        $id = $proveedor['id'];
        $numero = '#' . str_pad($id, 4, "0", STR_PAD_LEFT);
        $nombre = utf8_encode($proveedor['nombre']);
        $tipo = utf8_encode($proveedor['tipo']);
        $telefono = $proveedor['telefono'];
        $correo = $proveedor['correo'];
        $provincia = utf8_encode($proveedor['provincia']);
        $ciudad = utf8_encode($proveedor['ciudad']);
        $direccion = utf8_encode($proveedor['direccion']);
        $estado = $proveedor['estado'];
        $fechaCreacion = isset($proveedor['fechaCreacion']) ? date_format($proveedor['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($proveedor['fechaUltimaEdicion']) ? date_format($proveedor['fechaUltimaEdicion'], 'd/m/Y H:i') : "";

        $filas .= "
            <tr>
                <td class='align-middle'>{$numero}</td>
                <td class='align-middle col_nombre'>{$nombre}</td>
                <td class='align-middle col_tipo'>{$tipo}</td>
                <td class='align-middle col_telefono'>{$telefono}</td>
                <td class='align-middle col_correo'>{$correo}</td>
                <td class='align-middle col_provincia'>{$provincia}</td>
                <td class='align-middle col_ciudad' style='display: none;'>{$ciudad}</td>
                <td class='align-middle col_direccion' style='display: none;'>{$direccion}</td>
                <td class='align-middle col_estado' style='display: none;'>{$estado}</td>
                <td class='align-middle col_fecha_creacion' style='display: none;'>{$fechaCreacion}</td>
                <td class='align-middle col_fecha_edicion' style='display: none;'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$id}' title='Detalle: $nombre'>
                                <i class='fas fa-info-circle'></i>
                        </button>
                        <button class='btn btn-outline-warning editar' 
                                name='{$id}' title='Editar: $nombre'>
                                <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbProveedores" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th class="col_nombre">Nombre</th>
                        <th class="col_tipo">Tipo</th>
                        <th class="col_telefono">Telefono</th>
                        <th class="col_corre">Correo</th>
                        <th class="col_provincia">Provincia</th>
                        <th class="col_ciudad" style="display: none;">Ciudad</th>
                        <th class="col_direccion" style="display: none;">Dirección</th>
                        <th class="col_estado" style="display: none;">Estado</th>
                        <th class="col_fecha_creacion" style="display: none;">Fecha de creación</th>
                        <th class="col_fecha_edicion" style="display: none;">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
