<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorHerramientaDesarrollo;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorHerramientaDesarrollo();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $version = $_POST['version'];
    $fabricante = $_POST['fabricante'];
    $datos = ($nombre) ? "'{$nombre}', " : "TODOS, ";
    $datos .= ($version) ? "'{$version}', " : "TODAS, ";
    $datos .= ($fabricante) ? "'{$fabricante}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $herramientas = $controlador->consultar($nombre, $version, $fabricante);
    $_SESSION['LOAD_HERRAMIENTA_CONSULTAR'] = array($nombre, $version, $fabricante, $datos);
} else {
    if (isset($_SESSION['LOAD_HERRAMIENTA_CONSULTAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_HERRAMIENTA_CONSULTAR'];
        $nombre = $parametros[0];
        $version = $parametros[1];
        $fabricante = $parametros[2];
        $filtro = "Ultima búsqueda realizada: " . $parametros[3];
        $herramientas = $controlador->consultar($nombre, $version, $fabricante);
        $_SESSION['LOAD_HERRAMIENTA_CONSULTAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $herramientas = $controlador->listarUltimasCreadas();
        $filtro = "Resumen inicial";
        $_SESSION['LOAD_HERRAMIENTA_CONSULTAR'] = NULL;
    }
}

if (gettype($herramientas) == "resource") {
    $filas = "";
    while ($herramienta = sqlsrv_fetch_array($herramientas, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr>
                <td>" . utf8_encode($herramienta['nombre']) . "</td>
                <td>" . utf8_encode($herramienta['version']) . "</td>
                <td>" . utf8_encode($herramienta['fabricante']) . "</td>
                <td>" . utf8_encode($herramienta['descripcion']) . "</td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbHerramientas" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Versión</th>
                        <th>Fabricante</th>
                        <th>Descripción</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($herramientas == 1) ? " para el filtro ingresado" : "";
    $cuerpo = GeneradorHTML::getAlertaOperacion($herramientas, $mensaje);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
