<?php

require_once './core_procesa_autoload.php';

use app\modelo\GeneradorHTML;
use app\controlador\ControladorHerramientaDesarrollo;

$controlador = new ControladorHerramientaDesarrollo();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $version = $_POST['version'];
    $fabricante = $_POST['fabricante'];
    $estado = 'Activa';
    $datos = ($nombre) ? "'{$nombre}', " : "Sin nombre, ";
    $datos .= ($version) ? "'{$version}', " : "Sin version, ";
    $datos .= ($fabricante) ? "'{$fabricante}', " : "Sin fabricante, ";
    $datos .= ($estado) ? "'{$estado}'" : "Sin estado";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombre, $version, $fabricante, $estado);
    $_SESSION['LOAD_HERRAMIENTA_CONSULTAR'] = array($nombre, $version, $fabricante, $datos);
} else {
    if (isset($_SESSION['LOAD_HERRAMIENTA_CONSULTAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_HERRAMIENTA_CONSULTAR'];
        $nombre = $parametros[0];
        $version = $parametros[1];
        $fabricante = $parametros[2];
        $filtro = "Ultima búsqueda realizada: " . $parametros[3];
        $resultado = $controlador->consultar($nombre, $version, $fabricante);
        $_SESSION['LOAD_HERRAMIENTA_CONSULTAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activa';
        $resultado = $controlador->buscarUltimasCreadas($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['LOAD_HERRAMIENTA_CONSULTAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $filas = "";
    $herramientas = $resultado[1];
    while ($herramienta = sqlsrv_fetch_array($herramientas, SQLSRV_FETCH_ASSOC)) {
        $id = $herramienta['id'];
        $numero = '#' . str_pad($id, 4, "0", STR_PAD_LEFT);
        $nombre = utf8_encode($herramienta['nombre']);
        $version = utf8_encode($herramienta['version']);
        $fabricante = utf8_encode($herramienta['fabricante']);
        $fechaCaducidad = isset($herramienta['fechaCaducidad']) ? date_format($herramienta['fechaCaducidad'], 'd/m/Y') : "";
        $descripcion = utf8_encode($herramienta['descripcion']);
        $estado = $herramienta['estado'];
        $fechaCreacion = isset($herramienta['fechaCreacion']) ? date_format($herramienta['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($herramienta['fechaUltimaEdicion']) ? date_format($herramienta['fechaUltimaEdicion'], 'd/m/Y H:i') : "";

        $filas .= "
            <tr>
                <td>{$numero}</td>
                <td>{$nombre}</td>
                <td>{$version}</td>
                <td>{$fabricante}</td>
                <td>{$fechaCaducidad}</td>
                <td style='display: none;'>{$descripcion}</td>
                <td style='display: none;'>{$estado}</td>
                <td style='display: none;'>{$fechaCreacion}</td>
                <td style='display: none;'>{$fechaEdicion}</td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbHerramientas" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Versión</th>
                        <th>Fabricante</th>
                        <th>Fecha caducidad</th>
                        <th style="display: none;">Descripción</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">Fecha de creación</th>
                        <th style="display: none;">Fecha de edición</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
