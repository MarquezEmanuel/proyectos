<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorHardware;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['idHardware'])) {
    $id = $_POST['idHardware'];
    $tipo = $_POST['tipo'];
    $ambiente = $_POST['ambiente'];
    $nombreCorto = $_POST['nombreCorto'];
    $nombreLargo = $_POST['nombreLargo'];
    $sitio = $_POST['sitio'];
    $dominio = $_POST['dominio'];
    $swBase = $_POST['softwareBase'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $arquitectura = $_POST['arquitectura'];
    $core = $_POST['core'];
    $procesador = $_POST['procesador'];
    $mhz = $_POST['mhz'];
    $memoria = $_POST['memoria'];
    $disco = $_POST['disco'];
    $raid = $_POST['raid'];
    $red = $_POST['red'];
    $funcion = $_POST['funcion'];
    $descripcion = $_POST['descripcion'];
    $proveedores = $_POST['proveedores'];
    $controlador = new ControladorHardware();
    $modificacion = $controlador->modificar($id, $tipo, $nombreCorto, $nombreLargo, $dominio, $swBase, $ambiente, $funcion, $sitio, $marca, $modelo, $arquitectura, $core, $procesador, $mhz, $memoria, $disco, $raid, $red, $descripcion, $proveedores);
    $exito = ($modificacion[0] == 2) ? true : false;
    $mensaje = "{$nombreLargo}: $modificacion[1]";
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
