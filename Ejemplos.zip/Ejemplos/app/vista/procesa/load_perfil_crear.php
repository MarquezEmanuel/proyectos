<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if ($_POST['nombre'] && $_POST['descripcion'] && $_POST['permisos']) {
    $controlador = new controladores\ControladorPerfil();
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $permisos = $_POST['permisos'];
    $creacion = $controlador->crear($nombre, $descripcion, $permisos);
    $exito = ($creacion[0] == 2) ? true : false;
    $resultado = controladores\ControladorHTML::getAlertaOperacion($creacion[0], $creacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = controladores\ControladorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
