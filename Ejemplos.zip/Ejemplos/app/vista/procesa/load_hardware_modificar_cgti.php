<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorHardware;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['idHardware'])) {
    $id = $_POST['idHardware'];
    $nombreLargo = $_POST['nombreLargo'];
    $visibilidad = $_POST['visibilidad'];
    $rti = $_POST['rti'];
    $controlador = new ControladorHardware();
    $modificacion = $controlador->modificarGCTI($id, $rti, $visibilidad);
    $exito = ($modificacion[0] == 2) ? true : false;
    $mensaje = "{$nombreLargo}: $modificacion[1]";
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
