<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\controlador\ControladorEmpleado;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
$controlador = new ControladorEmpleado();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionarJefe($nombre);
if ($resultado[0] == 2) {
    $trabajadores = $resultado[1];
    while ($empleado = sqlsrv_fetch_array($trabajadores, SQLSRV_FETCH_ASSOC)) {
        $idEmpleado = $empleado["idEmpleado"];
        $nombreEmpleado = utf8_encode($empleado["nombreEmplado"]);
        $arreglo[] = array('id' => $idEmpleado, 'text' => $nombreEmpleado);
    }
}

echo json_encode($arreglo);
