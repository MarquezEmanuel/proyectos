<?php

require_once './core_procesa_autoload.php';

use app\controlador\ControladorEmpleado;

$arreglo = array();
$controlador = new ControladorEmpleado();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionarJefe($nombre);
if ($resultado[0] == 2) {
    $trabajadores = $resultado[1];
    while ($empleado = sqlsrv_fetch_array($trabajadores, SQLSRV_FETCH_ASSOC)) {
        $idEmpleado = $empleado["idEmpleado"];
        $nombreEmpleado = utf8_encode($empleado["nombreEmpleado"]);
        $arreglo[] = array('id' => $idEmpleado, 'text' => $nombreEmpleado);
    }
}

echo json_encode($arreglo);
