<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\modelo\Log;
use app\controlador\ControladorAplicacion;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if ($_POST['nombreCorto'] && $_POST['nombreLargo']) {
    $controlador = new ControladorAplicacion();
    $nombreCorto = $_POST['nombreCorto'];
    $nombreLargo = $_POST['nombreLargo'];
    $tipo = $_POST['tipo'];
    $seguridad = $_POST['seguridad'];
    $tecnologia = $_POST['tecnologia'];
    $lenguaje = isset($_POST['lenguaje']) ? $_POST['lenguaje'] : NULL;
    $herramienta = isset($_POST['herramienta']) ? $_POST['herramienta'] : NULL;
    $modo = $_POST['modo'];
    $lugar = $_POST['lugar'];
    $plataforma = $_POST['plataforma'];
    $gerencia = $_POST['gerencia'];
    $empleado = isset($_POST['delegado']) ? $_POST['delegado'] : NULL;
    $fechaCaducidad = $_POST['fechaCaducidad'] ? $_POST['fechaCaducidad'] . "T00:00:00" : NULL;
    $codigoSAS = $_POST['codigoSAS'];
    $tipoLog = $_POST['tipoLog'];
    $descripcion = $_POST['descripcion'];
    $basesDatos = $_POST['bases'];
    $proveedores = $_POST['proveedores'];
    $creacion = $controlador->crear($nombreCorto, $nombreLargo, $tipo, $seguridad, $tecnologia, $lenguaje, $herramienta, $modo, $lugar, $plataforma, $gerencia, $empleado, $fechaCaducidad, $codigoSAS, $tipoLog, $descripcion, $basesDatos, $proveedores);
    $mensaje = "{$nombreLargo}: {$creacion[1]}";
    $exito = ($creacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($creacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}


/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
