<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorHerramientaDesarrollo;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if ($_POST['nombre'] && $_POST['version'] && $_POST['fabricante'] && $_POST['descripcion']) {
    $controlador = new ControladorHerramientaDesarrollo();
    $nombre = $_POST['nombre'];
    $version = $_POST['version'];
    $fabricante = $_POST['fabricante'];
    $fechaCaducidad = ($_POST['fechaCaducidad']) ? "{$_POST['fechaCaducidad']}T00:00:00" : NULL;
    $descripcion = $_POST['descripcion'];
    $proveedores = $_POST['proveedores'];
    $creacion = $controlador->crear($nombre, $version, $fabricante, $fechaCaducidad, $descripcion, $proveedores);
    $mensaje = "{$nombre} : {$creacion[1]}";
    $exito = ($creacion[0] == 2) ? TRUE : FALSE;
    $resultado = GeneradorHTML::getAlertaOperacion($creacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
