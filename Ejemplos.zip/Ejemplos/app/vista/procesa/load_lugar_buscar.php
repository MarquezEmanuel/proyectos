<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorLugarProcesamiento;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorLugarProcesamiento();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', '{$estado}'" : "'$estado'";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombre, $estado);
    $_SESSION['LOAD_LUGAR_BUSCAR'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_LUGAR_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_LUGAR_BUSCAR'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $resultado = $controlador->buscar($nombre, $estado);
        $_SESSION['LOAD_LUGAR_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['LOAD_LUGAR_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $lugares = $resultado[1];
    $filas = "";
    while ($lugar = sqlsrv_fetch_array($lugares, SQLSRV_FETCH_ASSOC)) {
        $id = $lugar['id'];
        $numero = '#' . str_pad($id, 4, "0", STR_PAD_LEFT);
        $nombre = utf8_encode($lugar['nombre']);
        $estado = $lugar['estado'];
        $fechaCreacion = isset($lugar['fechaCreacion']) ? date_format($lugar['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($lugar['fechaUltimaEdicion']) ? date_format($lugar['fechaUltimaEdicion'], 'd/m/Y H:i') : "";
        $filas .= "
            <tr>
                <td class='align-middle'>{$numero}</td>
                <td class='align-middle'>{$nombre}</td>
                <td class='align-middle' style='display: none;'>{$estado}</td>
                <td class='align-middle'>{$fechaCreacion}</td>
                <td class='align-middle'>{$fechaEdicion}</td>
                <td class='align-middle text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' 
                                name='{$id}' title='Editar: $nombre'>
                            <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbLugares" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th style="display: none;">Estado</th>
                        <th>Fecha de creación</th>
                        <th>Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
