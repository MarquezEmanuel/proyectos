<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorSwitch;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorSwitch();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $modelo = $_POST['modelo'];
    $instalacion = $_POST['instalacion'];
    $sitio = $_POST['sitio'];
    $datos = ($nombre) ? "'{$nombre}', " : "TODOS, ";
    $datos .= ($modelo) ? "'{$modelo}', " : "TODOS, ";
    $datos .= ($instalacion) ? "'{$instalacion}', " : "TODAS, ";
    $datos .= ($sitio) ? "'{$sitio}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $switchs = $controlador->consultar($nombre, $modelo, $instalacion, $sitio);
    $_SESSION['LOAD_SWITCH_CONSULTAR'] = array($nombre, $modelo, $instalacion, $sitio, $datos);
} else {
    if (isset($_SESSION['LOAD_SWITCH_CONSULTAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_SWITCH_CONSULTAR'];
        $nombre = $parametros[0];
        $modelo = $parametros[1];
        $instalacion = $parametros[2];
        $sitio = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[4];
        $switchs = $controlador->consultar($nombre, $modelo, $instalacion, $sitio);
        $_SESSION['LOAD_SWITCH_CONSULTAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $switchs = $controlador->listarUltimosCreados();
        $filtro = "Resumen inicial";
        $_SESSION['LOAD_SWITCH_CONSULTAR'] = NULL;
    }
}

if (gettype($switchs) == "resource") {
    $filas = "";
    while ($switch = sqlsrv_fetch_array($switchs, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr class='fila' title='Haga doble click para acceder a los detalles del elemento'>
                <td>" . utf8_encode($switch['snombre']) . "</td>
                <td>" . utf8_encode($switch['smodelo']) . "</td>
                <td>" . utf8_encode($switch['sversion']) . "</td>
                <td>" . utf8_encode($switch['inombre']) . "</td> 
                <td>" . utf8_encode($switch['unombre']) . "</td> 
                <td>" . utf8_encode($switch['srti']) . "</td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbSwitchs" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Modelo</th>
                        <th>Versión</th>
                        <th>Instalación</th>
                        <th>Ubicación</th>
                        <th>RTI</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $controlador->getMensaje();
    $mensaje .= ($switchs == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($switchs, $mensaje);
}

echo ControladorHTML::getCardBusqueda($filtro, $cuerpo);


