<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Log;
use app\controlador\ControladorBaseDatosManual;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();

$controlador = new ControladorBaseDatosManual();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $basesDatos = $resultado[1];
    while ($base = sqlsrv_fetch_array($basesDatos, SQLSRV_FETCH_ASSOC)) {
        $idBase = $base["id"];
        $nombreBase = utf8_encode($base["nombre"]);
        $arreglo[] = array('id' => $idBase, 'text' => $nombreBase);
    }
}
echo json_encode($arreglo);
