<?php

require_once './core_procesa_autoload.php';

use app\controlador\ControladorBaseDatosManual;

$arreglo = array();
$controlador = new ControladorBaseDatosManual();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $basesDatos = $resultado[1];
    while ($base = sqlsrv_fetch_array($basesDatos, SQLSRV_FETCH_ASSOC)) {
        $idBase = $base["id"];
        $nombreBase = utf8_encode($base["nombre"]);
        $arreglo[] = array('id' => $idBase, 'text' => $nombreBase);
    }
}
echo json_encode($arreglo);
