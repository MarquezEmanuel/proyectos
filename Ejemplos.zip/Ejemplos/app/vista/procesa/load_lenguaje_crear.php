<?php

require_once './core_procesa_autoload.php';

use app\modelo\GeneradorHTML;
use app\controlador\ControladorLenguaje;

$exito = FALSE;
if ($_POST['nombre'] && $_POST['version'] && $_POST['descripcion']) {
    $controlador = new ControladorLenguaje();
    $nombre = $_POST['nombre'];
    $version = $_POST['version'];
    $descipcion = $_POST['descripcion'];
    $creacion = $controlador->crear($nombre, $version, $descipcion);
    $mensaje = "$nombre: {$creacion[1]}";
    $exito = ($creacion[0] == 2) ? TRUE : FALSE;
    $resultado = GeneradorHTML::getAlertaOperacion($creacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
