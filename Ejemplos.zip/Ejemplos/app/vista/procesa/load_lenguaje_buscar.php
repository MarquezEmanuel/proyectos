<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorLenguaje;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorLenguaje();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $version = $_POST['version'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " : "";
    $datos .= ($version) ? "'{$version}', " : "";
    $datos .= ($descripcion) ? "'{$descripcion}', " : "";
    $datos .= ($estado) ? "'{$estado}'" : "";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombre, $version, $descripcion, $estado);
    $_SESSION['LOAD_LENGUAJE_BUSCAR'] = array($nombre, $version, $descripcion, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_LENGUAJE_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_LENGUAJE_BUSCAR'];
        $nombre = $parametros[0];
        $version = $parametros[1];
        $descripcion = $parametros[2];
        $estado = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[4];
        $resultado = $controlador->buscar($nombre, $estado);
        $_SESSION['LOAD_LENGUAJE_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['LOAD_LENGUAJE_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $lenguajes = $resultado[1];
    $filas = "";
    while ($lenguaje = sqlsrv_fetch_array($lenguajes, SQLSRV_FETCH_ASSOC)) {

        $id = $lenguaje['id'];
        $numero = '#' . str_pad($id, 4, "0", STR_PAD_LEFT);
        $nombre = utf8_encode($lenguaje['nombre']);
        $version = utf8_encode($lenguaje['version']);
        $descripcion = utf8_encode($lenguaje['descripcion']);
        $estado = $lenguaje['estado'];
        $fechaCreacion = isset($lenguaje['fechaCreacion']) ? date_format($lenguaje['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($lenguaje['fechaUltimaEdicion']) ? date_format($lenguaje['fechaUltimaEdicion'], 'd/m/Y H:i') : "";

        $filas .= "
            <tr>
                <td class='align-middle'>{$numero}</td>
                <td class='align-middle col_nombre'>{$nombre}</td>
                <td class='align-middle col_version'>{$version}</td>
                <td class='align-middle col_descripcion' style='display: none;'>{$descripcion}</td>
                <td class='align-middle col_fecha_creacion'>{$fechaCreacion}</td>
                <td class='align-middle col_fecha_edicion'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' 
                                name='{$id}' title='Editar: $nombre'>
                            <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbLenguajes" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th class="col_nombre">Nombre</th>
                        <th class="col_version">Versión</th>
                        <th class="col_descripcion" style="display: none;">Descripción</th>
                        <th class="col_fecha_creacion">Fecha de creación</th>
                        <th class="col_fecha_edicion">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}


echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
