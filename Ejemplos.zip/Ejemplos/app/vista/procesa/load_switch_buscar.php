<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorSwitch;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorSwitch();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreSwitch = $_POST['nombreSwitch'];
    $modelo = $_POST['modelo'];
    $nombreInstalacion = $_POST['nombreInstalacion'];
    $nombreSitio = $_POST['nombreSitio'];
    $estado = $_POST['estado'];
    $datos = "<span class=dropdown-item>Nombre: {$nombreSwitch}</span>";
    $datos .= "<span class=dropdown-item>Mondelo: {$modelo}</span>";
    $datos .= "<span class=dropdown-item>Nombre de instalación: {$nombreInstalacion}</span>";
    $datos .= "<span class=dropdown-item>Nombre de sitio: {$nombreSitio}</span>";
    $datos .= "<span class=dropdown-item>Estado: {$estado}</span>";
    $filtro = "Resultado de la búsqueda";
    $resultado = $controlador->buscar($nombreSwitch, $modelo, $nombreInstalacion, $nombreSitio, $estado);
    $_SESSION['LOAD_SWITCH_BUSCAR'] = array($nombreSwitch, $modelo, $nombreInstalacion, $nombreSitio, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_SWITCH_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_SWITCH_BUSCAR'];
        $nombreSwitch = $parametros[0];
        $modelo = $parametros[1];
        $nombreInstalacion = $parametros[2];
        $nombreSitio = $parametros[3];
        $estado = $parametros[4];
        $datos = $parametros[5];
        $filtro = "Ultima búsqueda realizada";
        $resultado = $controlador->buscar($nombreSwitch, $modelo, $nombreInstalacion, $nombreSitio, $estado);
        $_SESSION['LOAD_SWITCH_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $datos = "<span class=dropdown-item>Limite: {$cantidad}</span>";
        $datos .= "<span class=dropdown-item>Estado: {$estado}</span>";
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial";
        $_SESSION['LOAD_SWITCH_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $filas = "";
    $switchs = $resultado[1];
    while ($switch = sqlsrv_fetch_array($switchs, SQLSRV_FETCH_ASSOC)) {
        $idSwitch = $switch['idSwitch'];
        $numeroSwitch = '#' . str_pad($idSwitch, 4, "0", STR_PAD_LEFT);
        $nombreSwitch = utf8_encode($switch['nombreSwitch']);
        $modeloSwitch = utf8_encode($switch['modeloSwitch']);
        $versionSwitch = utf8_encode($switch['versionSwitch']);
        $idInstalacion = $switch['idInstalacion'];
        $nombreInstalacion = utf8_encode($switch['nombreLargoInstalacion']);
        $estadoInstalacion = $switch['estadoInstalacion'];
        $idSitio = $switch['idSitio'];
        $tipoSitio = utf8_encode($switch['tipoSitio']);
        $nombreSitio = utf8_encode($switch['nombreSitio']);
        $estadoSitio = $switch['estadoSitio'];
        $rtiSwitch = $switch['rtiSwitch'];
        $descripcionSwitch = utf8_encode($switch['descripcionSwitch']);
        $estadoSwitch = $switch['estadoSwitch'];
        $fechaCreacion = isset($switch['fechaCreacionSwitch']) ? date_format($switch['fechaCreacionSwitch'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($switch['fechaUltimaEdicionSwitch']) ? date_format($switch['fechaUltimaEdicionSwitch'], 'd/m/Y H:i') : "";
        $cantidadProveedores = $switch['cantidadProveedores'];

        $filas .= "
            <tr>
                <td>{$numeroSwitch}</td>
                <td class='col_nombre'>{$nombreSwitch}</td>
                <td class='col_modelo'>{$modeloSwitch}</td>
                <td class='col_version'>{$versionSwitch}</td>
                <td class='col_nombre_instalacion' title='Instalación: {$estadoInstalacion}'>{$nombreInstalacion}</td>
                <td class='col_estado_instalacion' style='display: none;'>{$estadoInstalacion}</td>
                <td class='col_codigo_sitio' style='display: none;'>{$idSitio}</td>
                <td class='col_tipo_sitio' style='display: none;'>{$tipoSitio}</td>
                <td class='col_nombre_sitio' title='Sitio: {$idSitio} {$tipoSitio} {$estadoSitio}'>{$nombreSitio}</td>
                <td class='col_estado_sitio' style='display: none;'>{$estadoSitio}</td>
                <td class='col_rti' style='display: none;'>{$rtiSwitch}</td>
                <td class='col_descripcion' style='display: none;'>{$descripcionSwitch}</td>
                <td class='col_estado' style='display: none;'>{$estadoSwitch}</td>
                <td class='col_fecha_creacion' style='display: none;'>{$fechaCreacion}</td>
                <td class='col_fecha_edicion' style='display: none;'>{$fechaEdicion}</td>
                <td class='col_cantidad_proveedores' style='display: none;'>{$cantidadProveedores}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$idSwitch}' title='Detalle: {$nombreSwitch}'>
                                " . Constantes::ICON_DETALLE . "
                        </button>
                        <button class='btn btn-outline-warning editar' 
                                name='{$idSwitch}' title='Editar: {$nombreSwitch}'>
                                " . Constantes::ICON_EDITAR . "
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="form-row">
            <div class="col text-right">
                <div class="btn-group">
                    <button class="btn btn-outline-dark dropdown-toggle"
                            title="Configurar columnas a visualizar"
                            type="button" data-toggle="dropdown" 
                            aria-haspopup="true" aria-expanded="false">
                            ' . Constantes::ICON_RUEDAS . '
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_nombre"/> 
                            <span class="ml-4">Nombre</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_modelo"/>
                            <span class="ml-4">Modelo</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_version"/> 
                            <span class="ml-4">Versión</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_nombre_instalacion"/> 
                            <span class="ml-4">Nombre de instalación</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_estado_instalacion"/> 
                            <span class="ml-4">Estado de instalación</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_codigo_sitio"/> 
                            <span class="ml-4">Código de sitio</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_tipo_sitio"/> 
                            <span class="ml-4">Tipo de sitio</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_nombre_sitio"/> 
                            <span class="ml-4">Nombre de sitio</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_estado_sitio"/> 
                            <span class="ml-4">Estado de sitio</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_rti"/> 
                            <span class="ml-4">RTI</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_descripcion"/> 
                            <span class="ml-4">Descripción</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_estado"/>
                            <span class="ml-4">Estado</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_fecha_creacion"/>
                            <span class="ml-4">Fecha de creación</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_fecha_edicion"/>
                            <span class="ml-4">Fecha de edición</span>
                        </a>
                    </div>
                </div>
                <div class="btn-group">
                    <button class="btn btn-outline-dark dropdown-toggle"
                            title="Datos del filtro aplicado"
                            type="button" data-toggle="dropdown" 
                            aria-haspopup="true" aria-expanded="false">
                            ' . Constantes::ICON_FILTRO . '
                    </button>
                    <div class="dropdown-menu">' . $datos . '</div>
                </div>   
            </div>  
        </div>';

    /* COMPLETA EL CUERPO DEL FORMULARIO CON LA TABLA DE RESULTADOS */

    $cuerpo .= '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbSwitchs" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th class="col_nombre">Nombre</th>
                        <th class="col_modelo">Modelo</th>
                        <th class="col_version">Versión</th>
                        <th class="col_nombre_instalacion">Nombre instalación</th>
                        <th class="col_estado_instalacion" style="display: none;">Estado instalación</th>
                        <th class="col_codigo_sitio" style="display: none;">Código sitio</th>
                        <th class="col_tipo_sitio" style="display: none;">Tipo sitio</th>
                        <th class="col_nombre_sitio">Nombre sitio</th>
                        <th class="col_estado_sitio" style="display: none;">Estado sitio</th>
                        <th class="col_rti" style="display: none;">RTI</th>
                        <th class="col_descripcion" style="display: none;">Descripción</th>
                        <th class="col_estado" style="display: none;">Estado</th>
                        <th class="col_fecha_creacion" style="display: none;">Fecha de creación</th>
                        <th class="col_fecha_edicion" style="display: none;">Fecha de edición</th>
                        <th class="col_cantidad_proveedores" style="display: none;">Cantidad de proveedores</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
