<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\controlador\ControladorInstalacion;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
$controlador = new ControladorInstalacion();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $instalaciones = $resultado[1];
    while ($instalacion = sqlsrv_fetch_array($instalaciones, SQLSRV_FETCH_ASSOC)) {
        $id = $instalacion['id'];
        $nombreInstalacion = utf8_encode($instalacion["nombreLargo"]);
        $arreglo[] = array('id' => $id, 'text' => $nombreInstalacion);
    }
}
echo json_encode($arreglo);
