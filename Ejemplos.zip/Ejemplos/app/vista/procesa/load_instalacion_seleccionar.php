<?php

require_once './core_procesa_autoload.php';

use app\controlador\ControladorInstalacion;

$arreglo = array();
$controlador = new ControladorInstalacion();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $instalaciones = $resultado[1];
    while ($instalacion = sqlsrv_fetch_array($instalaciones, SQLSRV_FETCH_ASSOC)) {
        $id = $instalacion['id'];
        $nombreInstalacion = utf8_encode($instalacion["nombreLargo"]);
        $arreglo[] = array('id' => $id, 'text' => $nombreInstalacion);
    }
}
echo json_encode($arreglo);
