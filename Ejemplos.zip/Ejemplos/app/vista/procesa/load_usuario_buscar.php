<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\seguridad\controlador\ControladorUsuario;

AutoCargador::cargarModulos();

$controlador = new ControladorUsuario();

if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " . $estado : "TODOS, " . $estado;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $usuarios = $controlador->buscar($nombre, $estado);
    $_SESSION['LOAD_USUARIO_BUSCAR'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_USUARIO_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_USUARIO_BUSCAR'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $usuarios = $controlador->buscar($nombre, $estado);
        $_SESSION['LOAD_USUARIO_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $usuarios = $controlador->listarConTope(20);
        $filtro = "Resumen inicial de usuarios";
        $_SESSION['LOAD_USUARIO_BUSCAR'] = NULL;
    }
}

if (gettype($usuarios[0]) == "resource") {
    $filas = "";
    $resource = $usuarios[0];
    while ($usuario = sqlsrv_fetch_array($resource, SQLSRV_FETCH_ASSOC)) {
        if ($usuario['usuEstado'] == 'Activo') {
            $operaciones = "
                <button class='btn btn-outline-warning editar' 
                        name='{$usuario['usuId']}' title='Editar'>
                    <i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger baja' 
                        name='{$usuario['usuId']}' title='Dar de baja'>
                    <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-success alta' 
                    name='{$usuario['usuId']}' title='Dar de alta'>
                        <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td>{$usuario['usuId']}</td>
                <td>" . utf8_encode($usuario['usuNombre']) . "</td>
                <td>{$usuario['usuEstado']}</td>
                <td>{$usuario['perNombre']}</td>  
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>{$operaciones}</div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbUsuarios" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Legajo</th>
                        <th>Nombre</th>
                        <th>Estado</th>
                        <th>Perfil</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $mensaje = $usuarios[1];
    $mensaje .= ($usuarios[0] == 1) ? " para el filtro ingresado" : "";
    $cuerpo = ControladorHTML::getAlertaOperacion($usuarios, $mensaje);
}

$formulario = ControladorHTML::getCardBusqueda($filtro, $cuerpo);

echo $formulario;
