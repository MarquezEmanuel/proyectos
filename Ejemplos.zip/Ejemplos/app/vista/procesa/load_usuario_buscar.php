<?php

require_once './core_procesa_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorUsuario;

$controlador = new ControladorUsuario();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " . $estado : "TODOS, " . $estado;
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombre, $estado);
    $_SESSION['LOAD_USUARIO_BUSCAR'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_USUARIO_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_USUARIO_BUSCAR'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $resultado = $controlador->buscar($nombre, $estado);
        $_SESSION['LOAD_USUARIO_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $limite = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarConTope($limite, $estado);
        $filtro = "Resumen inicial de usuarios";
        $_SESSION['LOAD_USUARIO_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $filas = "";
    $usuarios = $resultado[1];
    while ($usuario = sqlsrv_fetch_array($usuarios, SQLSRV_FETCH_ASSOC)) {

        $idUsuario = $usuario['idUsuario'];
        $nombreUsuario = utf8_encode($usuario['nombreUsuario']);
        $estadoUsuario = $usuario['estadoUsuario'];
        $nombrePerfil = utf8_encode($usuario['nombrePerfil']);
        $estadoPerfil = $usuario['estadoPerfil'];
        $filas .= "
            <tr>
                <td>{$idUsuario}</td>
                <td>{$nombreUsuario}</td>
                <td>{$estadoUsuario}</td>
                <td>{$nombrePerfil}</td>  
                <td>{$estadoPerfil}</td>  
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' 
                                name='{$idUsuario}' title='Editar: {$nombreUsuario}'>
                            " . Constantes::ICON_EDITAR . "
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbUsuarios" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Legajo</th>
                        <th>Nombre</th>
                        <th>Estado</th>
                        <th>Nombre perfil</th>
                        <th>Estado perfil</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
