<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorEmpleado;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['idEmpleado'])) {
    $id = $_POST['idEmpleado'];
    $legajo = $_POST['legajo'];
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $departamento = isset($_POST['departamento']) ? $_POST['departamento'] : NULL;
    $controlador = new ControladorEmpleado();
    $modificacion = $controlador->modificar($id, $nombre, $departamento, $legajo, $estado);
    $mensaje = "{$nombre}: {$modificacion[1]}";
    $exito = ($modificacion[0] == 2) ? TRUE : FALSE;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
