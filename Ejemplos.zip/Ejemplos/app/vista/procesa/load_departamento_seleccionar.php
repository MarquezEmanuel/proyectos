<?php

require_once './core_procesa_autoload.php';

use app\controlador\ControladorDepartamento;

$arreglo = array();
$controlador = new ControladorDepartamento();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : "";
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $departamentos = $resultado[1];
    while ($deparamento = sqlsrv_fetch_array($departamentos, SQLSRV_FETCH_ASSOC)) {
        $idDepartamento = $deparamento["id"];
        $nombreDepartamento = utf8_encode($deparamento["nombre"]);
        $arreglo[] = array('id' => $idDepartamento, 'text' => $nombreDepartamento);
    }
}
echo json_encode($arreglo);
