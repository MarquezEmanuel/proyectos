<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\controlador\ControladorDepartamento;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
$controlador = new ControladorDepartamento();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : "";
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $departamentos = $resultado[1];
    while ($deparamento = sqlsrv_fetch_array($departamentos, SQLSRV_FETCH_ASSOC)) {
        $idDepartamento = $deparamento["id"];
        $nombreDepartamento = utf8_encode($deparamento["nombre"]);
        $arreglo[] = array('id' => $idDepartamento, 'text' => $nombreDepartamento);
    }
}
echo json_encode($arreglo);
