<?php

require_once './core_procesa_autoload.php';

use app\controlador\ControladorPermiso;

$arreglo = array();
$controlador = new ControladorPermiso();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : "";
$resultado = $controlador->buscarParaSeleccionarPadre($nombre);

if ($resultado[0] == 2) {
    $permisos = $resultado[1];
    while ($permiso = sqlsrv_fetch_array($permisos, SQLSRV_FETCH_ASSOC)) {
        $idPermiso = $permiso["id"];
        $nombrePermiso = utf8_encode($permiso["titulo"]);
        $arreglo[] = array('id' => $idPermiso, 'text' => $nombrePermiso);
    }
}

echo json_encode($arreglo);

