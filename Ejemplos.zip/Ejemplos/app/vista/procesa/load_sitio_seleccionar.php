<?php

require_once './core_procesa_autoload.php';

use app\modelo\Log;
use app\controlador\ControladorSitio;

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorSitio();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $sitios = $resultado[1];
        while ($sitio = sqlsrv_fetch_array($sitios, SQLSRV_FETCH_ASSOC)) {
            $idSitio = $sitio['id'];
            $tipo = $sitio['tipo'];
            $nombreSitio = utf8_encode($sitio['nombre']);
            $texto = "$tipo : $nombreSitio";
            $arreglo[] = array('id' => $idSitio, 'text' => $texto);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar sitios";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'SITIOS', 'busqueda', 'PSeleccionarSitio', '', $detalle);
}

echo json_encode($arreglo);


