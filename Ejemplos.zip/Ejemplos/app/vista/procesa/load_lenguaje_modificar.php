<?php

require_once './core_procesa_autoload.php';

use app\modelo\GeneradorHTML;
use app\controlador\ControladorLenguaje;

$exito = FALSE;
if ($_POST['idLenguaje']) {
    $id = $_POST['idLenguaje'];
    $nombre = $_POST['nombre'];
    $version = $_POST['version'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];
    $controlador = new ControladorLenguaje();
    $modificacion = $controlador->modificar($id, $nombre, $version, $descripcion, $estado);
    $mensaje = "{$nombre}: $modificacion[1]";
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);

