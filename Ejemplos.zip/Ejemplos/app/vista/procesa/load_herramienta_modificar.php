<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorHerramientaDesarrollo;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if ($_POST['idHerramienta']) {
    $id = $_POST['idHerramienta'];
    $nombre = $_POST['nombre'];
    $version = $_POST['version'];
    $fabricante = $_POST['fabricante'];
    $fechaCaducidad = ($_POST['fechaCaducidad']) ? "{$_POST['fechaCaducidad']}T00:00:00" : NULL;
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];
    $proveedores = $_POST['proveedores'];
    $controlador = new ControladorHerramientaDesarrollo();
    $modificacion = $controlador->modificar($id, $nombre, $version, $fabricante, $fechaCaducidad, $descripcion, $estado, $proveedores);
    $mensaje = "{$nombre}: {$modificacion[1]}";
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
