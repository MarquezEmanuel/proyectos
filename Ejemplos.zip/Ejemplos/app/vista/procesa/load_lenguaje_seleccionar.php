<?php

require_once './core_procesa_autoload.php';

use app\controlador\ControladorLenguaje;

$arreglo = array();
$controlador = new ControladorLenguaje();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $lenguajes = $resultado[1];
    while ($lenguaje = sqlsrv_fetch_array($lenguajes, SQLSRV_FETCH_ASSOC)) {
        $idLenguaje = $lenguaje["id"];
        $nombreLenguaje = utf8_encode($lenguaje["nombre"]) . ' (' . utf8_encode($lenguaje["version"]) . ')';
        $arreglo[] = array('id' => $idLenguaje, 'text' => $nombreLenguaje);
    }
}
echo json_encode($arreglo);
