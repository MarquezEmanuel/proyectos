<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\controlador\ControladorLenguaje;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
$controlador = new ControladorLenguaje();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $lenguajes = $resultado[1];
    while ($lenguaje = sqlsrv_fetch_array($lenguajes, SQLSRV_FETCH_ASSOC)) {
        $idLenguaje = $lenguaje["id"];
        $nombreLenguaje = utf8_encode($lenguaje["nombre"]) . ' (' . utf8_encode($lenguaje["version"]) . ')';
        $arreglo[] = array('id' => $idLenguaje, 'text' => $nombreLenguaje);
    }
}
echo json_encode($arreglo);
