<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorAuxiliar;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorAuxiliar();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreLargo = $_POST['nombreLargo'];
    $nombreGerencia = $_POST['nombreGerencia'];
    $nombreEmpleado = $_POST['nombreEmpleado'];
    $nombreSitio = $_POST['nombreSitio'];
    $estado = $_POST['estado'];
    $datos = ($nombreLargo) ? "'{$nombreLargo}', " : "TODOS, ";
    $datos .= ($nombreGerencia) ? "'{$nombreGerencia}', " : "TODAS, ";
    $datos .= ($nombreEmpleado) ? "'{$nombreEmpleado}', " : "TODOS, ";
    $datos .= ($nombreSitio) ? "'{$nombreSitio}', " : "TODOS, ";
    $datos .= ($estado) ? "'{$estado}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $estado);
    $_SESSION['LOAD_AUXILIAR_BUSCAR'] = array($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_AUXILIAR_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_AUXILIAR_BUSCAR'];
        $nombreLargo = $parametros[0];
        $nombreGerencia = $parametros[1];
        $nombreEmpleado = $parametros[2];
        $nombreSitio = $parametros[3];
        $estado = $parametros[4];
        $filtro = "Ultima búsqueda realizada: " . $parametros[5];
        $resultado = $controlador->buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $estado);
        $_SESSION['LOAD_AUXILIAR_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['LOAD_AUXILIAR_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $filas = "";
    $auxiliares = $resultado[1];
    while ($auxiliar = sqlsrv_fetch_array($auxiliares, SQLSRV_FETCH_ASSOC)) {

        $idAuxiliar = $auxiliar['idAuxiliar'];
        $nombreCortoAuxiliar = utf8_encode($auxiliar['nombreCortoAuxiliar']);
        $nombreLargoAuxiliar = utf8_encode($auxiliar['nombreLargoAuxiliar']);
        $cantidadAuxiliar = $auxiliar['cantidadAuxiliar'];
        $idGerencia = $auxiliar['idGerencia'];
        $nombreGerencia = utf8_encode($auxiliar['nombreGerencia']);
        $estadoGerencia = $auxiliar['estadoGerencia'];
        $idEmpleado = $auxiliar['idEmpleado'];
        $nombreEmpleado = utf8_encode($auxiliar['nombreEmpleado']);
        $estadoEmpleado = $auxiliar['estadoEmpleado'];
        $idSitio = $auxiliar['idSitio'];
        $tipoSitio = utf8_encode($auxiliar['tipoSitio']);
        $nombreSitio = utf8_encode($auxiliar['nombreSitio']);
        $estadoSitio = $auxiliar['estadoSitio'];
        $rtiAuxiliar = $auxiliar['rtiAuxiliar'];
        $descripcionAuxiliar = utf8_encode($auxiliar['descripcionAuxiliar']);
        $estadoAuxiliar = $auxiliar['estadoAuxiliar'];
        $fechaCreacion = isset($auxiliar['fechaCreacionAuxiliar']) ? date_format($auxiliar['fechaCreacionAuxiliar'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($auxiliar['fechaUltimaEdicionAuxiliar']) ? date_format($auxiliar['fechaUltimaEdicionAuxiliar'], 'd/m/Y H:i') : "";

        $filas .= "
            <tr>
                <td>{$nombreCortoAuxiliar}</td>
                <td>{$nombreLargoAuxiliar}</td>
                <td>{$cantidadAuxiliar}</td>
                <td>{$nombreGerencia}</td>
                <td style='display: none;'>{$estadoGerencia}</td> 
                <td style='display: none;'>{$idEmpleado}</td> 
                <td>{$nombreEmpleado}</td>
                <td style='display: none;'>{$estadoEmpleado}</td>
                <td style='display: none;'>{$idSitio}</td>
                <td style='display: none;'>{$tipoSitio}</td>
                <td>{$nombreSitio}</td>
                <td style='display: none;'>{$estadoSitio}</td>
                <td style='display: none;'>{$rtiAuxiliar}</td>
                <td style='display: none;'>{$descripcionAuxiliar}</td>
                <td style='display: none;'>{$estadoAuxiliar}</td>
                <td style='display: none;'>{$fechaCreacion}</td>
                <td style='display: none;'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$idAuxiliar}' title='Detalle: {$nombreLargoAuxiliar}'>
                                <i class='fas fa-info-circle'></i>
                        </button>
                        <button class='btn btn-outline-warning editar' 
                                name='{$idAuxiliar}' title='Editar: {$nombreLargoAuxiliar}'>
                                <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbAuxiliares" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre corto</th>
                        <th>Nombre largo</th>
                        <th>Cantidad</th>
                        <th>Nombre gerencia</th>
                        <th style="display: none;">Estado gerencia</th>
                        <th style="display: none;">Legajo delegado</th>
                        <th>Nombre delegado</th>
                        <th style="display: none;">Estado delegado</th>
                        <th style="display: none;">Código sitio</th>
                        <th style="display: none;">Tipo sitio</th>
                        <th>Nombre sitio</th>
                        <th style="display: none;">Estado sitio</th>
                        <th style="display: none;">RTI</th>
                        <th style="display: none;">Descripción</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">Fecha creación</th>
                        <th style="display: none;">Fecha edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
