<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorComunicacion;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorComunicacion();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreLargo = $_POST['nombreLargo'];
    $nombreGerencia = $_POST['nombreGerencia'];
    $nombreEmpleado = $_POST['nombreEmpleado'];
    $nombreSitio = $_POST['nombreSitio'];
    $nombreProveedor = $_POST['nombreProveedor'];
    $estado = 'Activa';
    $datos = ($nombreLargo) ? "'{$nombreLargo}', " : "TODOS, ";
    $datos .= ($nombreGerencia) ? "'{$nombreGerencia}', " : "TODAS, ";
    $datos .= ($nombreEmpleado) ? "'{$nombreEmpleado}', " : "TODOS, ";
    $datos .= ($nombreSitio) ? "'{$nombreSitio}', " : "TODOS, ";
    $datos .= ($nombreProveedor) ? "'{$nombreProveedor}', " : "TODOS, ";
    $datos .= ($estado) ? "'{$estado}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $nombreProveedor, $estado);
    $_SESSION['LOAD_COMUNICACION_CONSULTAR'] = array($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $nombreProveedor, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_COMUNICACION_CONSULTAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_COMUNICACION_CONSULTAR'];
        $nombreLargo = $parametros[0];
        $nombreGerencia = $parametros[1];
        $nombreEmpleado = $parametros[2];
        $nombreSitio = $parametros[3];
        $nombreProveedor = $parametros[4];
        $estado = $parametros[5];
        $filtro = "Ultima búsqueda realizada: " . $parametros[6];
        $resultado = $controlador->buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $nombreProveedor, $estado);
        $_SESSION['LOAD_COMUNICACION_CONSULTAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activa';
        $resultado = $controlador->buscarUltimasCreadas($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['LOAD_COMUNICACION_CONSULTAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $filas = "";
    $comunicaciones = $resultado[1];
    while ($comunicacion = sqlsrv_fetch_array($comunicaciones, SQLSRV_FETCH_ASSOC)) {

        $idComunicacion = $comunicacion['idComunicacion'];
        $nombreCortoComunicacion = utf8_encode($comunicacion['nombreCortoComunicacion']);
        $nombreLargoComunicacion = utf8_encode($comunicacion['nombreLargoComunicacion']);
        $cantidadComunicacion = $comunicacion['cantidadComunicacion'];
        $idGerencia = $comunicacion['idGerencia'];
        $nombreGerencia = utf8_encode($comunicacion['nombreGerencia']);
        $estadoGerencia = $comunicacion['estadoGerencia'];
        $idEmpleado = $comunicacion['idEmpleado'];
        $nombreEmpleado = utf8_encode($comunicacion['nombreEmpleado']);
        $estadoEmpleado = $comunicacion['estadoEmpleado'];
        $idSitio = $comunicacion['idSitio'];
        $tipoSitio = utf8_encode($comunicacion['tipoSitio']);
        $nombreSitio = utf8_encode($comunicacion['nombreSitio']);
        $estadoSitio = $comunicacion['estadoSitio'];
        $rtiComunicacion = $comunicacion['rtiComunicacion'];
        $descripcionComunicacion = utf8_encode($comunicacion['descripcionComunicacion']);
        $estadoComunicacion = $comunicacion['estadoComunicacion'];
        $fechaCreacion = isset($comunicacion['fechaCreacionComunicacion']) ? date_format($comunicacion['fechaCreacionComunicacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($comunicacion['fechaUltimaEdicionComunicacion']) ? date_format($comunicacion['fechaUltimaEdicionComunicacion'], 'd/m/Y H:i') : "";

        $filas .= "
            <tr>
                <td>{$nombreCortoComunicacion}</td>
                <td>{$nombreLargoComunicacion}</td>
                <td>{$cantidadComunicacion}</td>
                <td>{$nombreGerencia}</td>
                <td style='display: none;'>{$estadoGerencia}</td> 
                <td style='display: none;'>{$idEmpleado}</td> 
                <td>{$nombreEmpleado}</td>
                <td style='display: none;'>{$estadoEmpleado}</td>
                <td style='display: none;'>{$idSitio}</td>
                <td style='display: none;'>{$tipoSitio}</td>
                <td>{$nombreSitio}</td>
                <td style='display: none;'>{$estadoSitio}</td>
                <td>{$rtiComunicacion}</td>
                <td style='display: none;'>{$descripcionComunicacion}</td>
                <td style='display: none;'>{$estadoComunicacion}</td>
                <td style='display: none;'>{$fechaCreacion}</td>
                <td style='display: none;'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$idComunicacion}' title='Detalle: {$nombreLargoComunicacion}'>
                                <i class='fas fa-info-circle'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbComunicaciones" class="table table-bordered table-hover" 
                   cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre corto</th>
                        <th>Nombre largo</th>
                        <th>Cantidad</th>
                        <th>Nombre gerencia</th>
                        <th style="display: none;">Estado gerencia</th>
                        <th style="display: none;">Legajo delegado</th>
                        <th>Nombre delegado</th>
                        <th style="display: none;">Estado delegado</th>
                        <th style="display: none;">Código sitio</th>
                        <th style="display: none;">Tipo sitio</th>
                        <th>Nombre sitio</th>
                        <th style="display: none;">Estado sitio</th>
                        <th>RTI</th>
                        <th style="display: none;">Descripción</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">Fecha creación</th>
                        <th style="display: none;">Fecha edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
