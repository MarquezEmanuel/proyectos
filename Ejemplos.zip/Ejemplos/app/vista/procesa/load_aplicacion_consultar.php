<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorAplicacion;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorAplicacion();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreLargo = $_POST['nombreLargo'];
    $tipo = $_POST['tipo'];
    $tecnologia = $_POST['tecnologia'];
    $seguridad = $_POST['seguridad'];
    $tipoLog = $_POST['tipoLog'];
    $nombreLenguaje = $_POST['nombreLenguaje'];
    $nombreGerencia = $_POST['nombreGerencia'];
    $nombreEmpleado = $_POST['nombreEmpleado'];
    $estado = "Activa";
    $datos = ($nombreLargo) ? "'{$nombreLargo}', " : "TODOS, ";
    $datos .= ($tipo) ? "'{$tipo}', " : "TODOS, ";
    $datos .= ($tecnologia) ? "'{$tecnologia}', " : "TODAS, ";
    $datos .= ($seguridad) ? "'{$seguridad}', " : "TODAS, ";
    $datos .= ($tipoLog) ? "'{$tipoLog}', " : "TODOS, ";
    $datos .= ($nombreLenguaje) ? "'{$nombreLenguaje}', " : "TODOS, ";
    $datos .= ($nombreGerencia) ? "'{$nombreGerencia}', " : "TODAS, ";
    $datos .= ($nombreEmpleado) ? "'{$nombreEmpleado}', " : "TODOS, ";
    $datos .= ($estado) ? "'{$estado}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombreLargo, $tipo, $tecnologia, $seguridad, $tipoLog, $nombreLenguaje, $nombreGerencia, $nombreEmpleado, $estado);
    $_SESSION['LOAD_APLICACION_CONSULTAR'] = array($nombreLargo, $tipo, $tecnologia, $seguridad, $tipoLog, $nombreLenguaje, $nombreGerencia, $nombreEmpleado, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_APLICACION_CONSULTAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_APLICACION_CONSULTAR'];
        $nombreLargo = $parametros[0];
        $tipo = $parametros[1];
        $tecnologia = $parametros[2];
        $seguridad = $parametros[3];
        $tipoLog = $parametros[4];
        $nombreLenguaje = $parametros[5];
        $nombreGerencia = $parametros[6];
        $nombreEmpleado = $parametros[7];
        $estado = $parametros[8];
        $filtro = "Ultima búsqueda realizada: " . $parametros[9];
        $resultado = $controlador->buscar($nombreLargo, $tipo, $tecnologia, $seguridad, $tipoLog, $nombreLenguaje, $nombreGerencia, $nombreEmpleado, $estado);
        $_SESSION['LOAD_APLICACION_CONSULTAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = "Activa";
        $resultado = $controlador->buscarUltimasCreadas($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado {$estado}";
        $_SESSION['LOAD_APLICACION_CONSULTAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $filas = "";
    $aplicaciones = $resultado[1];
    while ($aplicacion = sqlsrv_fetch_array($aplicaciones, SQLSRV_FETCH_ASSOC)) {

        $id = $aplicacion['idAplicacion'];
        $nombreCortoAplicacion = utf8_encode($aplicacion['nombreCortoAplicacion']);
        $nombreLargoAplicacion = utf8_encode($aplicacion['nombreLargoAplicacion']);
        $tipoAplicacion = utf8_encode($aplicacion['tipoAplicacion']);
        $seguridadAplicacion = utf8_encode($aplicacion['seguridadAplicacion']);
        $tecnologiaAplicacion = utf8_encode($aplicacion['tecnologiaAplicacion']);
        $idLenguaje = $aplicacion['idLenguaje'];
        $nombreLenguaje = utf8_encode($aplicacion['nombreLenguaje']);
        $versionLenguaje = utf8_encode($aplicacion['versionLenguaje']);
        $estadoLenguaje = $aplicacion['estadoLenguaje'];
        $idHerramienta = $aplicacion['idHerramienta'];
        $nombreHerramienta = utf8_encode($aplicacion['nombreHerramienta']);
        $versionHerramienta = utf8_encode($aplicacion['versionHerramienta']);
        $estadoHerramienta = $aplicacion['estadoHerramienta'];
        $idModo = $aplicacion['idModo'];
        $nombreModo = utf8_encode($aplicacion['nombreModo']);
        $estadoModo = $aplicacion['estadoModo'];
        $idLugar = $aplicacion['idLugar'];
        $nombreLugar = utf8_encode($aplicacion['nombreLugar']);
        $estadoLugar = $aplicacion['estadoLugar'];
        $idGerencia = $aplicacion['idGerencia'];
        $nombreGerencia = utf8_encode($aplicacion['nombreGerencia']);
        $estadoGerencia = $aplicacion['estadoGerencia'];
        $idEmpleado = $aplicacion['idEmpleado'];
        $nombreEmpleado = utf8_encode($aplicacion['nombreEmpleado']);
        $estadoEmpleado = $aplicacion['estadoEmpleado'];
        $codigoSASAplicacion = utf8_encode($aplicacion['codigoSASAplicacion']);
        $fechaCaducidadAplicacion = isset($aplicacion['fechaCaducidadAplicacion']) ? date_format($aplicacion['fechaCaducidadAplicacion'], 'd/m/Y') : '';
        $tipoLogAplicacion = utf8_encode($aplicacion['tipoLogAplicacion']);
        $confidencialidadAplicacion = $aplicacion['confidencialidadAplicacion'];
        $integridadAplicacion = $aplicacion['integridadAplicacion'];
        $disponibilidadAplicacion = $aplicacion['disponibilidadAplicacion'];
        $criticidadAplicacion = $aplicacion['criticidadAplicacion'];
        $rtiAplicacion = $aplicacion['rtiAplicacion'];
        $descripcionAplicacion = utf8_encode($aplicacion['descripcionAplicacion']);
        $estadoAplicacion = $aplicacion['estadoAplicacion'];
        $fechaCreacion = isset($aplicacion['fechaCreacionAplicacion']) ? date_format($aplicacion['fechaCreacionAplicacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($aplicacion['fechaUltimaEdicionAplicacion']) ? date_format($aplicacion['fechaUltimaEdicionAplicacion'], 'd/m/Y H:i') : "";

        $filas .= "
            <tr>
                <td>{$nombreCortoAplicacion}</td>
                <td>{$nombreLargoAplicacion}</td>
                <td>{$tipoAplicacion}</td>
                <td>{$seguridadAplicacion}</td>
                <td>{$tecnologiaAplicacion}</td>
                <td style='display: none;'>{$nombreLenguaje}</td>
                <td style='display: none;'>{$versionLenguaje}</td>
                <td style='display: none;'>{$estadoLenguaje}</td>
                <td style='display: none;'>{$nombreHerramienta}</td>
                <td style='display: none;'>{$versionHerramienta}</td>
                <td style='display: none;'>{$estadoHerramienta}</td>
                <td style='display: none;'>{$nombreModo}</td>
                <td style='display: none;'>{$estadoModo}</td>
                <td style='display: none;'>{$nombreLugar}</td>
                <td style='display: none;'>{$estadoLugar}</td>
                <td style='display: none;'>{$nombreGerencia}</td>
                <td style='display: none;'>{$estadoGerencia}</td>
                <td style='display: none;'>{$idEmpleado}</td>
                <td>{$nombreEmpleado}</td>
                <td style='display: none;'>{$estadoEmpleado}</td>
                <td style='display: none;'>{$codigoSASAplicacion}</td>
                <td style='display: none;'>{$fechaCaducidadAplicacion}</td>
                <td style='display: none;'>{$tipoLog}</td>
                <td style='display: none;'>{$confidencialidadAplicacion}</td>
                <td style='display: none;'>{$integridadAplicacion}</td>
                <td style='display: none;'>{$disponibilidadAplicacion}</td>
                <td style='display: none;'>{$criticidadAplicacion}</td>
                <td>{$rtiAplicacion}</td>
                <td style='display: none;'>{$descripcionAplicacion}</td>
                <td style='display: none;'>{$estadoAplicacion}</td>
                <td style='display: none;'>{$fechaCreacion}</td>
                <td style='display: none;'>{$fechaEdicion}</td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbAplicaciones" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre corto</th>
                        <th>Nombre largo</th>
                        <th>Tipo</th>
                        <th>Seguridad</th>
                        <th>Técnologia</th>
                        <th style="display: none;">Nombre lenguaje</th>
                        <th style="display: none;">Versión lenguaje</th>
                        <th style="display: none;">Estado lenguaje</th>
                        <th style="display: none;">Nombre herramienta</th>
                        <th style="display: none;">Versión herramienta</th>
                        <th style="display: none;">Estado herramienta</th>
                        <th style="display: none;">Nombre modo</th>
                        <th style="display: none;">Estado modo</th>
                        <th style="display: none;">Nombre lugar</th>
                        <th style="display: none;">Estado lugar</th>
                        <th style="display: none;">Nombre gerencia</th>
                        <th style="display: none;">Estado gerencia</th>
                        <th style="display: none;">Legajo responsable</th>
                        <th>Nombre responsable</th>
                        <th style="display: none;">Estado responsable</th>
                        <th style="display: none;">Código SAS</th>
                        <th style="display: none;">Fecha caducidad</th>
                        <th style="display: none;">Tipo de log</th>
                        <th style="display: none;">Confidencialidad</th>
                        <th style="display: none;">Integridad</th>
                        <th style="display: none;">Disponibilidad</th>
                        <th style="display: none;">Criticidad</th>
                        <th>RTI</th>
                        <th style="display: none;">Descripción</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">Fecha de creación</th>
                        <th style="display: none;">Fecha de edición</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
