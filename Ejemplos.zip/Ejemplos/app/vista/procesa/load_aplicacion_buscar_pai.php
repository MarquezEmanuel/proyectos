<?php

require_once './core_procesa_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorAplicacion;

$controlador = new ControladorAplicacion();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreLargo = $_POST['nombreLargo'];
    $tipo = $_POST['tipo'];
    $tecnologia = $_POST['tecnologia'];
    $seguridad = $_POST['seguridad'];
    $tipoLog = $_POST['tipoLog'];
    $nombreLenguaje = $_POST['nombreLenguaje'];
    $nombreGerencia = $_POST['nombreGerencia'];
    $nombreEmpleado = $_POST['nombreEmpleado'];
    $estado = 'Activa';
    $datos = "<span class=dropdown-item>Nombre largo: {$nombreLargo}</span>";
    $datos .= "<span class=dropdown-item>Tipo: {$tipo}</span>";
    $datos .= "<span class=dropdown-item>Tipo de tecnologia: {$tecnologia}</span>";
    $datos .= "<span class=dropdown-item>Tipo de seguridad: {$seguridad}</span>";
    $datos .= "<span class=dropdown-item>Tipo de log: {$tipoLog}</span>";
    $datos .= "<span class=dropdown-item>Nombre de lenguaje: {$nombreLenguaje}</span>";
    $datos .= "<span class=dropdown-item>Nombre de gerencia: {$nombreGerencia}</span>";
    $datos .= "<span class=dropdown-item>Nombre de empleado: {$nombreEmpleado}</span>";
    $datos .= "<span class=dropdown-item>Estado: {$estado}</span>";
    $filtro = "Resultado de la búsqueda";
    $resultado = $controlador->buscar($nombreLargo, $tipo, $tecnologia, $seguridad, $tipoLog, $nombreLenguaje, $nombreGerencia, $nombreEmpleado, $estado);
    $_SESSION['LOAD_APLICACION_BUSCAR_PAI'] = array($nombreLargo, $tipo, $tecnologia, $seguridad, $tipoLog, $nombreLenguaje, $nombreGerencia, $nombreEmpleado, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_APLICACION_BUSCAR_PAI'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_APLICACION_BUSCAR_PAI'];
        $nombreLargo = $parametros[0];
        $tipo = $parametros[1];
        $tecnologia = $parametros[2];
        $seguridad = $parametros[3];
        $tipoLog = $parametros[4];
        $nombreLenguaje = $parametros[5];
        $nombreGerencia = $parametros[6];
        $nombreEmpleado = $parametros[7];
        $estado = $parametros[8];
        $datos = $parametros[9];
        $filtro = "Ultima búsqueda realizadaF";
        $resultado = $controlador->buscar($nombreLargo, $tipo, $tecnologia, $seguridad, $tipoLog, $nombreLenguaje, $nombreGerencia, $nombreEmpleado, $estado);
        $_SESSION['LOAD_APLICACION_BUSCAR_PAI'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = "Activa";
        $datos = "<span class=dropdown-item>Limite: {$cantidad}</span>";
        $datos .= "<span class=dropdown-item>Estado: {$estado}</span>";
        $resultado = $controlador->buscarUltimasCreadas($cantidad, $estado);
        $filtro = "Resumen inicial";
        $_SESSION['LOAD_APLICACION_BUSCAR_PAI'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $filas = "";
    $aplicaciones = $resultado[1];
    while ($aplicacion = sqlsrv_fetch_array($aplicaciones, SQLSRV_FETCH_ASSOC)) {

        $id = $aplicacion['idAplicacion'];
        $numeroAplicacion = '#' . str_pad($id, 4, "0", STR_PAD_LEFT);
        $nombreCortoAplicacion = utf8_encode($aplicacion['nombreCortoAplicacion']);
        $nombreLargoAplicacion = utf8_encode($aplicacion['nombreLargoAplicacion']);
        $tipoAplicacion = utf8_encode($aplicacion['tipoAplicacion']);
        $seguridadAplicacion = utf8_encode($aplicacion['seguridadAplicacion']);
        $tecnologiaAplicacion = utf8_encode($aplicacion['tecnologiaAplicacion']);
        $idLenguaje = $aplicacion['idLenguaje'];
        $nombreLenguaje = utf8_encode($aplicacion['nombreLenguaje']);
        $versionLenguaje = utf8_encode($aplicacion['versionLenguaje']);
        $estadoLenguaje = $aplicacion['estadoLenguaje'];
        $idHerramienta = $aplicacion['idHerramienta'];
        $nombreHerramienta = utf8_encode($aplicacion['nombreHerramienta']);
        $versionHerramienta = utf8_encode($aplicacion['versionHerramienta']);
        $estadoHerramienta = $aplicacion['estadoHerramienta'];
        $idModo = $aplicacion['idModo'];
        $nombreModo = utf8_encode($aplicacion['nombreModo']);
        $estadoModo = $aplicacion['estadoModo'];
        $idLugar = $aplicacion['idLugar'];
        $nombreLugar = utf8_encode($aplicacion['nombreLugar']);
        $estadoLugar = $aplicacion['estadoLugar'];
        $idGerencia = $aplicacion['idGerencia'];
        $nombreGerencia = utf8_encode($aplicacion['nombreGerencia']);
        $estadoGerencia = $aplicacion['estadoGerencia'];
        $idEmpleado = $aplicacion['idEmpleado'];
        $nombreEmpleado = utf8_encode($aplicacion['nombreEmpleado']);
        $estadoEmpleado = $aplicacion['estadoEmpleado'];
        $codigoSASAplicacion = utf8_encode($aplicacion['codigoSASAplicacion']);
        $fechaCaducidadAplicacion = isset($aplicacion['fechaCaducidadAplicacion']) ? date_format($aplicacion['fechaCaducidadAplicacion'], 'd/m/Y') : '';
        $tipoLogAplicacion = utf8_encode($aplicacion['tipoLogAplicacion']);
        $confidencialidadAplicacion = $aplicacion['confidencialidadAplicacion'];
        $integridadAplicacion = $aplicacion['integridadAplicacion'];
        $disponibilidadAplicacion = $aplicacion['disponibilidadAplicacion'];
        $criticidadAplicacion = $aplicacion['criticidadAplicacion'];
        $rtiAplicacion = $aplicacion['rtiAplicacion'];
        $descripcionAplicacion = utf8_encode($aplicacion['descripcionAplicacion']);
        $estadoAplicacion = $aplicacion['estadoAplicacion'];
        $fechaCreacion = isset($aplicacion['fechaCreacionAplicacion']) ? date_format($aplicacion['fechaCreacionAplicacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($aplicacion['fechaUltimaEdicionAplicacion']) ? date_format($aplicacion['fechaUltimaEdicionAplicacion'], 'd/m/Y H:i') : "";

        $filas .= "
            <tr>
                <td>{$numeroAplicacion}</td>
                <td class='col_nombre_corto'>{$nombreCortoAplicacion}</td>
                <td class='col_nombre_largo'>{$nombreLargoAplicacion}</td>
                <td class='col_tipo'>{$tipoAplicacion}</td>
                <td class='col_seguridad'>{$seguridadAplicacion}</td>
                <td class='col_tecnologia'>{$tecnologiaAplicacion}</td>
                <td class='col_nombre_lenguaje' style='display: none;'>{$nombreLenguaje}</td>
                <td class='col_version_lenguaje' style='display: none;'>{$versionLenguaje}</td>
                <td class='col_estado_lenguaje' style='display: none;'>{$estadoLenguaje}</td>
                <td class='col_nombre_herramienta' style='display: none;'>{$nombreHerramienta}</td>
                <td class='col_version_herramienta' style='display: none;'>{$versionHerramienta}</td>
                <td class='col_estado_herramienta' style='display: none;'>{$estadoHerramienta}</td>
                <td class='col_nombre_modo' style='display: none;'>{$nombreModo}</td>
                <td class='col_estado_modo' style='display: none;'>{$estadoModo}</td>
                <td class='col_nombre_lugar' style='display: none;'>{$nombreLugar}</td>
                <td class='col_estado_lugar' style='display: none;'>{$estadoLugar}</td>
                <td class='col_nombre_gerencia' style='display: none;'>{$nombreGerencia}</td>
                <td class='col_estado_gerencia' style='display: none;'>{$estadoGerencia}</td>
                <td class='col_legajo_empleado' style='display: none;'>{$idEmpleado}</td>
                <td class='col_nombre_empleado'>{$nombreEmpleado}</td>
                <td class='col_estado_empleado' style='display: none;'>{$estadoEmpleado}</td>
                <td class='col_codigo_sas' style='display: none;'>{$codigoSASAplicacion}</td>
                <td class='col_fecha_caducidad' style='display: none;'>{$fechaCaducidadAplicacion}</td>
                <td class='col_tipo_log' style='display: none;'>{$tipoLog}</td>
                <td class='col_confidencialidad' style='display: none;'>{$confidencialidadAplicacion}</td>
                <td class='col_integridad' style='display: none;'>{$integridadAplicacion}</td>
                <td class='col_disponibilidad' style='display: none;'>{$disponibilidadAplicacion}</td>
                <td class='col_criticidad' style='display: none;'>{$criticidadAplicacion}</td>
                <td class='col_rti' style='display: none;'>{$rtiAplicacion}</td>
                <td class='col_descripcion' style='display: none;'>{$descripcionAplicacion}</td>
                <td class='col_estado' style='display: none;'>{$estadoAplicacion}</td>
                <td class='col_fecha_creacion' style='display: none;'>{$fechaCreacion}</td>
                <td class='col_fecha_edicion' style='display: none;'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$id}' title='Detalle: {$nombreLargoAplicacion}'>
                                <i class='fas fa-info-circle'></i>
                        </button>
                        <button class='btn btn-outline-warning editar' 
                                name='{$id}' title='Editar: {$nombreLargoAplicacion}'>
                                <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="form-row">
            <div class="col text-right">
                <div class="btn-group">
                    <button class="btn btn-outline-dark dropdown-toggle"
                            title="Configurar columnas a visualizar"
                            type="button" data-toggle="dropdown" 
                            aria-haspopup="true" aria-expanded="false">
                            ' . Constantes::ICON_RUEDAS . '
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_nombre_corto"/> 
                            <span class="ml-4">Nombre corto</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_nombre_largo"/>
                            <span class="ml-4">Nombre largo</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_tipo"/> 
                            <span class="ml-4">Tipo</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_seguridad"/> 
                            <span class="ml-4">Seguridad</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox"checked class="col_checkbox" value="col_tecnologia"/> 
                            <span class="ml-4">Tecnologia</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_nombre_lenguaje"/> 
                            <span class="ml-4">Nombre lenguaje</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_version_lenguaje"/> 
                            <span class="ml-4">Versión lenguaje</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_estado_lenguaje"/> 
                            <span class="ml-4">Estado lenguaje</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_nombre_herramienta"/> 
                            <span class="ml-4">Nombre herramienta</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_version_herramienta"/> 
                            <span class="ml-4">Versión herramienta</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_estado_herramienta"/> 
                            <span class="ml-4">Estado herramienta</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_nombre_modo"/> 
                            <span class="ml-4">Nombre de modo</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_estado_modo"/> 
                            <span class="ml-4">Estado de modo</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_nombre_lugar"/> 
                            <span class="ml-4">Nombre de lugar</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_estado_lugar"/> 
                            <span class="ml-4">Estado de lugar</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_nombre_gerencia"/> 
                            <span class="ml-4">Nombre de gerencia</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_estado_gerencia"/> 
                            <span class="ml-4">Estado de gerencia</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_legajo_empleado"/> 
                            <span class="ml-4">Legajo de responsable</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_nombre_empleado"/> 
                            <span class="ml-4">Nombre de responsable</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_estado_empleado"/> 
                            <span class="ml-4">Estado de responsable</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_codigo_sas"/> 
                            <span class="ml-4">Código SAS</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_fecha_caducidad"/> 
                            <span class="ml-4">Fecha de caducidad</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_tipo_log"/> 
                            <span class="ml-4">Tipo de log</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_confidencialidad"/> 
                            <span class="ml-4">Confidencialidad</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_integridad"/> 
                            <span class="ml-4">Integridad</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_disponibilidad"/> 
                            <span class="ml-4">Disponibilidad</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_criticidad"/> 
                            <span class="ml-4">Criticidad</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_rti"/> 
                            <span class="ml-4">RTI</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_descripcion"/> 
                            <span class="ml-4">Descripción</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_estado"/>
                            <span class="ml-4">Estado</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_fecha_creacion"/>
                            <span class="ml-4">Fecha de creación</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_fecha_edicion"/>
                            <span class="ml-4">Fecha de edición</span>
                        </a>
                    </div>
                </div>
                <div class="btn-group">
                    <button class="btn btn-outline-dark dropdown-toggle"
                            title="Datos del filtro aplicado"
                            type="button" data-toggle="dropdown" 
                            aria-haspopup="true" aria-expanded="false">
                            ' . Constantes::ICON_FILTRO . '
                    </button>
                    <div class="dropdown-menu">' . $datos . '</div>
                </div>   
            </div>  
        </div>';

    $cuerpo .= '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbAplicaciones" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th class="col_nombre_corto">Nombre corto</th>
                        <th class="col_nombre_largo">Nombre largo</th>
                        <th class="col_tipo">Tipo</th>
                        <th class="col_seguridad">Seguridad</th>
                        <th class="col_tecnologia">Técnologia</th>
                        <th class="col_nombre_lenguaje" style="display: none;">Nombre lenguaje</th>
                        <th class="col_version_lenguaje" style="display: none;">Versión lenguaje</th>
                        <th class="col_estado_lenguaje" style="display: none;">Estado lenguaje</th>
                        <th class="col_nombre_herramienta" style="display: none;">Nombre herramienta</th>
                        <th class="col_version_herramienta" style="display: none;">Versión herramienta</th>
                        <th class="col_estado_herramienta" style="display: none;">Estado herramienta</th>
                        <th class="col_nombre_modo" style="display: none;">Nombre modo</th>
                        <th class="col_estado_modo" style="display: none;">Estado modo</th>
                        <th class="col_nombre_lugar" style="display: none;">Nombre lugar</th>
                        <th class="col_estado_lugar" style="display: none;">Estado lugar</th>
                        <th class="col_nombre_gerencia" style="display: none;">Nombre gerencia</th>
                        <th class="col_estado_gerencia" style="display: none;">Estado gerencia</th>
                        <th class="col_legajo_responsable" style="display: none;">Legajo responsable</th>
                        <th class="col_nombre_responsable">Nombre responsable</th>
                        <th class="col_estado_responsable" style="display: none;">Estado responsable</th>
                        <th class="col_codigo_sas" style="display: none;">Código SAS</th>
                        <th class="col_fecha_caducidad" style="display: none;">Fecha caducidad</th>
                        <th class="col_tipo_log" style="display: none;">Tipo de log</th>
                        <th class="col_confidencialidad" style="display: none;">Confidencialidad</th>
                        <th class="col_integridad" style="display: none;">Integridad</th>
                        <th class="col_disponibilidad" style="display: none;">Disponibilidad</th>
                        <th class="col_criticidad" style="display: none;">Criticidad</th>
                        <th class="col_rti" style="display: none;">RTI</th>
                        <th class="col_descripcion" style="display: none;">Descripción</th>
                        <th class="col_estado" style="display: none;">Estado</th>
                        <th class="col_fecha_creacion" style="display: none;">Fecha de creación</th>
                        <th class="col_fecha_edicion" style="display: none;">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
