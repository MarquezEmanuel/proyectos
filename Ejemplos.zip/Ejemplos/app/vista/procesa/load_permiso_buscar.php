<?php

require_once './core_procesa_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorPermiso;

$controlador = new ControladorPermiso();

if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $nivel = $_POST['nivel'];
    $resultado = $controlador->buscar($nombre, $nivel);
    $filtro = "Resultado de la búsqueda: ";
    $filtro .= ($nombre) ? $nombre . ", " . $nivel : "TODOS, " . $nivel;
    $_SESSION['LOAD_PERMISO_BUSCAR'] = array($nombre, $nivel);
} else {
    if (isset($_SESSION['LOAD_PERMISO_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_PERMISO_BUSCAR'];
        $nombre = $parametros[0];
        $nivel = $parametros[1];
        $resultado = $controlador->buscar($nombre, $nivel);
        $filtro = "Ultima búsqueda realizada: ";
        $filtro .= ($nombre) ? $nombre . ", " . $nivel : $nivel;
        $_SESSION['LOAD_PERMISO_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $resultado = $controlador->buscarConTope(20);
        $filtro = "Resumen inicial de permisos";
        $_SESSION['LOAD_PERMISO_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $filas = "";
    $permisos = $resultado[1];
    while ($permiso = sqlsrv_fetch_array($permisos, SQLSRV_FETCH_ASSOC)) {

        $id = $permiso['id'];
        $numero = '#' . str_pad($id, 4, "0", STR_PAD_LEFT);
        $titulo = utf8_encode($permiso['titulo']);
        $padre = utf8_encode($permiso['padre']);
        $descripcion = utf8_encode($permiso['descripcion']);
        $totalPerfiles = $permiso['perfiles'];
        $totalHijos = $permiso['hijos'];
        $filas .= "
            <tr>
                <td>{$numero}</td>
                <td>{$titulo}</td>
                <td>{$padre}</td>
                <td>{$descripcion}</td>
                <td>{$totalPerfiles}</td>
                <td>{$totalHijos}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' 
                                name='{$id}' title='Editar: {$titulo}'>
                                " . Constantes::ICON_EDITAR . "
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbPermisos" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Titulo</th>
                        <th>Padre</th>
                        <th>Descripción</th>
                        <th title="Cantidad de roles asociados">Roles</th>
                        <th title="Cantidad de permisos asociados">Permisos</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
