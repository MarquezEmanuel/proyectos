<?php

require_once './core_procesa_autoload.php';

use app\modelo\Log;
use app\controlador\ControladorActividad;


$arreglo = array();
if (isset($_POST['tipo'])) {
    $controlador = new ControladorActividad();
    $tipo = $_POST['tipo'];
    $resultado = $controlador->buscarParaSeleccionarTipo($tipo);
    if ($resultado[0] == 2) {
        $registros = $resultado[1];
        while ($registro = sqlsrv_fetch_array($registros, SQLSRV_FETCH_ASSOC)) {
            $tipoActividad = utf8_encode($registro["tipo"]);
            $arreglo[] = array('id' => $tipoActividad, 'text' => $tipoActividad);
        }
    }
} else {
    $detalle = "No se recibio tipo para seleccionar";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'ACTIVIDAD', 'busqueda', 'PSeleccionarTipo', '', $detalle);
}
echo json_encode($arreglo);
