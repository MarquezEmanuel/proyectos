<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorFirewall;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorFirewall();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreFirewall = $_POST['nombreFirewall'];
    $marca = $_POST['marca'];
    $nombreSitio = $_POST['nombreSitio'];
    $estado = 'Activo';
    $datos = ($nombreFirewall) ? "'{$nombreFirewall}', " : "TODOS, ";
    $datos .= ($marca) ? "'{$marca}', " : "TODAS, ";
    $datos .= ($nombreSitio) ? "'{$nombreSitio}', " : "TODOS, ";
    $datos .= "'{$estado}'";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombreFirewall, $marca, $nombreSitio, $estado);
    $_SESSION['LOAD_FIREWALL_CONSULTAR'] = array($nombreFirewall, $marca, $nombreSitio, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_FIREWALL_CONSULTAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_FIREWALL_CONSULTAR'];
        $nombreFirewall = $parametros[0];
        $marca = $parametros[1];
        $nombreSitio = $parametros[2];
        $estado = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[4];
        $resultado = $controlador->buscar($nombreFirewall, $marca, $nombreSitio, $estado);
        $_SESSION['LOAD_FIREWALL_CONSULTAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['LOAD_FIREWALL_CONSULTAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $firewalls = $resultado[1];
    $filas = "";
    while ($firewall = sqlsrv_fetch_array($firewalls, SQLSRV_FETCH_ASSOC)) {

        $idFirewall = $firewall['idFirewall'];
        $nombreFirewall = utf8_encode($firewall['nombreFirewall']);
        $marcaFirewall = utf8_encode($firewall['marcaFirewall']);
        $modeloFirewall = utf8_encode($firewall['modeloFirewall']);
        $numeroSerieFirewall = utf8_encode($firewall['numeroSerieFirewall']);
        $versionFirewall = utf8_encode($firewall['versionFirewall']);
        $ipFirewall = utf8_encode($firewall['ipFirewall']);
        $idSitio = $firewall['idSitio'];
        $tipoSitio = $firewall['tipoSitio'];
        $nombreSitio = $firewall['nombreSitio'];
        $estadoSitio = $firewall['estadoSitio'];
        $estadoFirewall = $firewall['estadoFirewall'];
        $fechaCreacion = isset($firewall['fechaCreacionFirewall']) ? date_format($firewall['fechaCreacionFirewall'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($firewall['fechaUltimaEdicionFirewall']) ? date_format($firewall['fechaUltimaEdicionFirewall'], 'd/m/Y H:i') : "";
        $cantidadProveedores = $firewall['cantidadProveedores'];

        $filas .= "
            <tr>
                <td>{$nombreFirewall}</td>
                <td>{$marcaFirewall}</td>
                <td>{$modeloFirewall}</td> 
                <td>{$numeroSerieFirewall}</td>
                <td>{$versionFirewall}</td>
                <td>{$ipFirewall}</td>
                <td style='display: none;'>{$idSitio}</td>
                <td style='display: none;'>{$tipoSitio}</td>
                <td>{$nombreSitio}</td>
                <td style='display: none;'>{$estadoSitio}</td>
                <td style='display: none;'>{$estadoFirewall}</td>
                <td style='display: none;'>{$fechaCreacion}</td>
                <td style='display: none;'>{$fechaEdicion}</td>
                <td style='display: none;'>{$cantidadProveedores}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$idFirewall}' title='Ver información básica: $nombreFirewall'>
                                <i class='fas fa-info-circle'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbFirewalls" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Número serie</th>
                        <th>Versión firmware</th>
                        <th>IP</th>
                        <th style="display: none;">Codigo sitio</th>
                        <th style="display: none;">Tipo sitio</th>
                        <th>Nombre sitio</th>
                        <th style="display: none;">Estado sitio</th>
                        <th style="display: none;">Estado firewall</th>
                        <th style="display: none;">Fecha de creación</th>
                        <th style="display: none;">Fecha de edición</th>
                        <th style="display: none;">Cantidad de proveedores</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
