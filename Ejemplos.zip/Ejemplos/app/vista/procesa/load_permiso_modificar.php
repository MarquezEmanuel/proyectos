<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

modelos\AutoCargador::cargarModulos();

$exito = FALSE;
if (isset($_POST['idPermiso'])) {
    $controlador = new controladores\ControladorPermiso();
    $id = $_POST['idPermiso'];
    $titulo = $_POST['titulo'];
    $nivel = $_POST['nivel'];
    $padre = ($nivel == 2) ? $_POST['padre'] : 0;
    $link = ($nivel == 2) ? $_POST['link'] : "";
    $modificacion = $controlador->modificar($id, $titulo, $nivel, $padre, $link);
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = controladores\ControladorHTML::getAlertaOperacion($modificacion[0], $modificacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = controladores\ControladorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
