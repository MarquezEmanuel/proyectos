<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorFirewall;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['idFirewall']) && isset($_POST['nombre'])) {
    $id = $_POST['idFirewall'];
    $nombre = $_POST['nombre'];
    $visibilidad = $_POST['visibilidad'];
    $rti = $_POST['rti'];
    $controlador = new ControladorFirewall();
    $modificacion = $controlador->modificarGCTI($id, $rti, $visibilidad);
    $exito = ($modificacion[0] == 2) ? true : false;
    $mensaje = "$nombre: $modificacion[1]";
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);

