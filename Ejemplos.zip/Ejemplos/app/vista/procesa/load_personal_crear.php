<?php

require_once './core_procesa_autoload.php';

use app\modelo\GeneradorHTML;
use app\controlador\ControladorPersonal;

$exito = FALSE;
if ($_POST['nombreLargo'] && $_POST['nombreCorto']) {
    $controlador = new ControladorPersonal();
    $nombreCorto = $_POST['nombreCorto'];
    $nombreLargo = $_POST['nombreLargo'];
    $idDepartamento = $_POST['departamento'];
    $descripcion = $_POST['descripcion'];
    $creacion = $controlador->crear($nombreCorto, $nombreLargo, $idDepartamento, $descripcion);
    $exito = ($creacion[0] == 2) ? true : false;
    $mensaje = "{$nombreLargo}: {$creacion[1]}";
    $resultado = GeneradorHTML::getAlertaOperacion($creacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
