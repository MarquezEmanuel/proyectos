<?php

require_once './core_procesa_autoload.php';

use app\controlador\ControladorProveedor;

$arreglo = array();

$controlador = new ControladorProveedor();
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$resultado = $controlador->buscarParaSeleccionar($nombre);
if ($resultado[0] == 2) {
    $proveedores = $resultado[1];
    while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
        $idProveedor = $proveedor["id"];
        $nombre = utf8_encode($proveedor["nombre"]);
        $arreglo[] = array('id' => $idProveedor, 'text' => $nombre);
    }
}

echo json_encode($arreglo);
