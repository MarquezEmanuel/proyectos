<?php

require_once './core_procesa_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorServicio;

$controlador = new ControladorServicio();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreCorto = $_POST['nombreCorto'];
    $nombreLargo = $_POST['nombreLargo'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];
    $resultado = $controlador->buscar($nombreCorto, $nombreLargo, $descripcion, $estado);
    $datos = "<span class=dropdown-item>Nombre corto: {$nombreCorto}</span>";
    $datos .= "<span class=dropdown-item>Nombre largo: {$nombreLargo}</span>";
    $datos .= "<span class=dropdown-item>Descripción: {$descripcion}</span>";
    $datos .= "<span class=dropdown-item>Estado: {$estado}</span>";
    $filtro = "Resultado de la búsqueda";
    $_SESSION['LOAD_SERVICIO_BUSCAR'] = array($nombreCorto, $nombreLargo, $descripcion, $estado, $datos);
} else {
    if (isset($_SESSION['LOAD_SERVICIO_BUSCAR'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['LOAD_SERVICIO_BUSCAR'];
        $nombreCorto = $parametros[0];
        $nombreLargo = $parametros[1];
        $descripcion = $parametros[2];
        $estado = $parametros[3];
        $datos = $parametros[4];
        $filtro = "Ultima búsqueda realizada";
        $resultado = $controlador->buscar($nombreCorto, $nombreLargo, $descripcion, $estado);
        $_SESSION['LOAD_SERVICIO_BUSCAR'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $datos = "<span class=dropdown-item>Limite: {$cantidad}</span>";
        $datos .= "<span class=dropdown-item>Estado: {$estado}</span>";
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial";
        $_SESSION['LOAD_SERVICIO_BUSCAR'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $servicios = $resultado[1];
    $filas = $operaciones = "";
    while ($servicio = sqlsrv_fetch_array($servicios, SQLSRV_FETCH_ASSOC)) {
        $id = $servicio['id'];
        $numero = '#' . str_pad($id, 4, "0", STR_PAD_LEFT);
        $nombreCorto = utf8_encode($servicio['nombreCorto']);
        $nombreLargo = utf8_encode($servicio['nombreLargo']);
        $descripcion = utf8_encode($servicio['descripcion']);
        $fechaCreacion = isset($servicio['fechaCreacion']) ? date_format($servicio['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($servicio['fechaUltimaEdicion']) ? date_format($servicio['fechaUltimaEdicion'], 'd/m/Y H:i') : "";
        $estado = $servicio['estado'];
        $filas .= "
            <tr>
                <td class='align-middle'>{$numero}</td>
                <td class='align-middle col_nombre_corto'>{$nombreCorto}</td>
                <td class='align-middle col_nombre_largo'>{$nombreLargo}</td>
                <td class='align-middle col_descripcion' style='display: none;' >{$descripcion}</td>
                <td class='align-middle col_estado' style='display: none;'>{$estado}</td>
                <td class='align-middle col_fecha_creacion'>{$fechaCreacion}</td>
                <td class='align-middle col_fecha_edicion'>{$fechaEdicion}</td>
                <td class='text-center align-middle'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                            name='{$id}' title='Detalle: $nombreCorto'>
                            " . Constantes::ICON_DETALLE . "
                        </button>
                        <button class='btn btn-outline-warning editar' 
                            name='{$id}' title='Editar: $nombreCorto'>
                            " . Constantes::ICON_EDITAR . "
                        </button>
                    </div>
                </td>
            </tr>";
    }

    $cuerpo = '
        <div class="form-row">
            <div class="col text-right">
                <div class="btn-group">
                    <button class="btn btn-outline-dark dropdown-toggle"
                            title="Configurar columnas a visualizar"
                            type="button" data-toggle="dropdown" 
                            aria-haspopup="true" aria-expanded="false">
                            ' . Constantes::ICON_RUEDAS . '
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_nombre_corto"/> 
                            <span class="ml-4">Nombre corto</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_nombre_largo"/>
                            <span class="ml-4">Nombre largo</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_descripcion"/> 
                            <span class="ml-4">Descripción</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" class="col_checkbox" value="col_estado"/>
                            <span class="ml-4">Estado</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_fecha_creacion"/>
                            <span class="ml-4">Fecha de creación</span>
                        </a>
                        <a class="dropdown-item">
                            <input type="checkbox" checked class="col_checkbox" value="col_fecha_edicion"/>
                            <span class="ml-4">Fecha de edición</span>
                        </a>
                    </div>
                </div>
                <div class="btn-group">
                    <button class="btn btn-outline-dark dropdown-toggle"
                            title="Datos del filtro aplicado"
                            type="button" data-toggle="dropdown" 
                            aria-haspopup="true" aria-expanded="false">
                            ' . Constantes::ICON_FILTRO . '
                    </button>
                    <div class="dropdown-menu">' . $datos . '</div>
                </div>   
            </div>  
        </div>';

    /* COMPLETA EL CUERPO DEL FORMULARIO CON LA TABLA DE RESULTADOS */

    $cuerpo .= '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbServicios" class="table table-bordered table-hover" 
                   cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th class="col_nombre_corto">Nombre corto</th>
                        <th class="col_nombre_largo">Nombre largo</th>
                        <th class="col_descripcion" style="display: none;">Descripción</th>
                        <th class="col_estado" style="display: none;">Estado</th>
                        <th class="col_fecha_creacion">Fecha de creación</th>
                        <th class="col_fecha_edicion">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
