<?php

require_once (dirname(__FILE__, 4) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorAuxiliar;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['idAuxiliar'])) {
    $controlador = new ControladorAuxiliar();
    $id = $_POST['idAuxiliar'];
    $nombreLargo = $_POST['nombreLargo'];
    $rti = $_POST['rti'];
    $visibilidad = $_POST['visibilidad'];
    $modificacion = $controlador->modificarGCTI($id, $rti, $visibilidad);
    $mensaje = "{$nombreLargo}: {$modificacion[1]}";
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
