<?php
require_once './core_header.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row">
                <div class="col text-left">
                    <h4><?= Constantes::ICON_MOD_AUXILIAR; ?> CONSULTAR ELEMENTO AUXILIAR</h4>
                </div>
            </div>
            <div class="mt-3 mb-4">
                <form method="POST" id="formConsultarAuxiliar" name="formConsultarAuxiliar">
                    <input type="hidden" name="peticion" value="peticion">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="nombreLargo" class="col-2 col-form-label">Nombre largo:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreLargo" id="nombreLargo" 
                                           maxlength="50"
                                           title="Nombre largo del elemento auxiliar"
                                           placeholder="Nombre largo">
                                </div>
                                <label for="nombreGerencia" class="col-2 col-form-label">Gerencia:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreGerencia" id="nombreGerencia" 
                                           maxlength="50"
                                           title="Nombre de la gerencia"
                                           placeholder="Nombre de gerencia">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="nombreEmpleado" class="col-2 col-form-label">Empleado:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreEmpleado" id="nombreEmpleado" 
                                           maxlength="50"
                                           title="Nombre de empleado delegado"
                                           placeholder="Nombre delegado">
                                </div>
                                <label for="nombreSitio" class="col-2 col-form-label">Sitio:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreSitio" id="nombreSitio" 
                                           maxlength="50"
                                           title="Nombre del sitio"
                                           placeholder="Nombre de sitio">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success">
                                <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div id="seccionInferior" class="mt-4 mb-2"></div>
        </div>
        <?php echo GeneradorHTML::getModalProcesando(); ?>
    </div>
</div>
<script type="text/javascript" src="./js/auxiliar_consultar.js"></script>