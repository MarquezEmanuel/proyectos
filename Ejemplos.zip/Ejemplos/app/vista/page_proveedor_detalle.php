<?php
require_once './core_autoload.php';

use app\modelo\GeneradorHTML;
use app\modelo\Proveedor;

$boton = "";
if (isset($_POST['idProveedor'])) {
    $id = $_POST['idProveedor'];
    $proveedor = new Proveedor($id);
    $resultado = $proveedor->obtener();
    if ($resultado[0] == 2) {
        $nombre = $proveedor->getNombre();
        $telefono = $proveedor->getTelefono();
        $correo = $proveedor->getCorreo();
        $provincia = $proveedor->getProvincia();
        $ciudad = $proveedor->getCiudad();
        $direccion = $proveedor->getDireccion();
        $tipo = $proveedor->getTipo();
        $getServicios = $proveedor->obtenerServicios();

        /* CARGA LOS DATOS DE LOS PROVEEDORES ASOCIADOS AL FIREWALL */

        if ($getServicios[0] == 2) {
            $servicios = $proveedor->getServicios();
            $filas = "";
            foreach ($servicios as $servicio) {
                $idServicio = $servicio['id'];
                $nombreCortoServicio = utf8_encode($servicio['nombreCorto']);
                $nombreLargoServicio = utf8_encode($servicio['nombreLargo']);
                $estadoServicio = $servicio['estado'];
                $referencia = '#' . str_pad($idServicio, 6, "0", STR_PAD_LEFT);
                $filas .= "
                    <tr>
                        <td class='align-middle'>{$referencia}</td>
                        <td class='align-middle'>{$nombreCortoServicio}</td>
                        <td class='align-middle'>{$nombreLargoServicio}</td>
                        <td class='align-middle'>{$estadoServicio}</td>
                    </tr>";
            }
            $tablaServicios = '
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" 
                           cellspacing="0" style="width:100%">
                        <thead>
                            <tr>
                                <th>Referencia</th>
                                <th>Nombre corto</th>
                                <th>Nombre largo</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>' . $filas . '</tbody>
                    </table>
                </div>';
        } else {
            $tablaServicios = GeneradorHTML::getAlertaOperacion($getServicios[0], $getServicios[1]);
        }

        $cuerpo = '
            <input type="hidden" name="idProveedor" id="idProveedor" value="' . $id . '">
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label">Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2"
                           value="' . $nombre . '"
                           placeholder="Nombre del proveedor" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Tipo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $tipo . '"
                           placeholder="Tipo" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Correo:</label>
                <div class="col">
                    <input type="email" class="form-control mb-2" 
                           value="' . $correo . '"
                           placeholder="Correo electrónico" readonly>
                </div>
                <label for="telefono" class="col-sm-2 col-form-label">Telefono:</label>
                <div class="col">
                    <input type="tel" class="form-control mb-2" 
                           value="' . $telefono . '"
                           placeholder="Número de telefono" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Provincia:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2"
                           value="' . $provincia . '"
                           placeholder="Provincia" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Ciudad:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2"
                           value="' . $ciudad . '"
                           placeholder="Nombre de localidad" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Dirección:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2"
                           value="' . $direccion . '"
                           placeholder="Direccion" readonly>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col"></div>
            </div>
            <div class="form-row mt-4 mb-3">
                <div class="col-2">
                    <p class="font-weight-bold">SERVICIOS</p>
                </div>
                <div class="col-10"><hr></div>
            </div>
            <div class="form-row">
                <div class="col">' . $tablaServicios . '</div>
            </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="far fa-address-card"></i> DETALLE DE PROVEEDOR</h4>
        </div>
    </div>
    <div class="card border-azul-clasico mt-3">
        <div class="card-header bg-azul-clasico text-white">Información</div>
        <div class="card-body">
            <?= $cuerpo; ?>
        </div>
    </div>
    <div class="form-row mt-2 mb-4">
        <div class="col text-right">
            <button type="button" class="btn btn-outline-info" 
                    onClick="window.location.reload();" >
                <i class="fas fa-search"></i> REGRESAR
            </button>
        </div>
    </div>
</div>

