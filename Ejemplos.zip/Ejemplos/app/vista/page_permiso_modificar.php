<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Permiso;

$boton = "";
if ($_POST['idPermiso']) {
    $id = $_POST['idPermiso'];
    $permiso = new Permiso($id);
    $resultado = $permiso->obtener();
    if ($resultado[0] == 2) {

        $titulo = $permiso->getTitulo();
        $nivel = $permiso->getNivel();
        $descripcion = $permiso->getDescripcion();

        $boton = '<button type="submit" class="btn btn-success" 
                        id="btnModificarPermiso" disabled>
                        ' . Constantes::ICON_GUARDAR . ' GUARDAR
                  </button>';

        $cuerpo = '
            <input type="hidden" name="idPermiso" id="idPermiso" value="' . $id . '">
            <input type="hidden" name="nivel" id="nivel" value="' . $nivel . '">
            <div class="form-row">
                <label for="titulo" class="col-sm-2 col-form-label">* Titulo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" name="titulo" id="titulo" 
                           minlength="5" maxlength="20" pattern="[A-Za-zÁÉÍÓÚÑáéíóúñ ]{5,20}"
                           value = "' . $titulo . '"
                           placeholder="Titulo del permiso" required>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col"></div>
            </div>';

        if ($nivel > 1) {
            $getPadre = $permiso->obtenerPadre();
            if ($getPadre[0] == 2) {
                $padre = $permiso->getPadre();
                $idPadre = $padre->getId();
                $titulo = $padre->getTitulo();
                $cuerpo .= '
                    <div class="form-row">
                        <label for="padre" class="col-sm-2 col-form-label">* Padre:</label>
                        <div class="col">
                            <select class="form-control mb-2" id="padre" name="padre" required>
                                <option value="' . $idPadre . '">' . $titulo . '</option>
                            </select>
                        </div>
                        <label class="col-sm-2 col-form-label"></label>
                        <div class="col"></div>
                    </div>';
            } else {
                $boton = '';
                $alerta = GeneradorHTML::getAlertaOperacion($getPadre[0], $getPadre[1]);
                $cuerpo .= '
                    <div class="form-row">
                        <label for="padre" class="col-sm-2 col-form-label">* Padre:</label>
                        <div class="col">' . $alerta . '</div>
                    </div>';
            }
        }

        $cuerpo .= '
            <div class="form-row">
                <label for="descripcion" class="col-sm-2 col-form-label">* Descripción:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" name="descripcion" id="descripcion" 
                           minlength="5" maxlength="80" pattern="[A-Za-zÁÉÍÓÚÑáéíóúñ ]{5,80}"
                           value = "' . $descripcion . '"
                           placeholder="Descripción del permiso" required>
                </div>
            </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_PERMISO; ?> MODIFICAR PERMISO</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarPermiso" name="formModificarPermiso" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info"
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/permiso_modificar.js"></script>