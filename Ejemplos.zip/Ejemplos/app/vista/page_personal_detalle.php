<?php
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\GeneradorHTML;
use app\modelo\Personal;

AutoCargador::cargarModulos();
session_start();

if ($_POST['idPersonal']) {
    $id = $_POST['idPersonal'];
    $personal = new Personal($id);
    $resultado = $personal->obtener();
    if ($resultado[0] == 2) {

        $referencia = '#' . str_pad($id, 10, "0", STR_PAD_LEFT);
        $nombreCorto = $personal->getNombreCorto();
        $nombreLargo = $personal->getNombreLargo();
        $descripcion = $personal->getDescripcion();
        $estado = $personal->getEstado();
        $rti = $personal->getRti();
        $fechaCreacion = $personal->getFechaCreacion();
        $fechaEdicion = $personal->getFechaEdicion();
        $fechaCreacionFormateada = isset($fechaCreacion) ? date_format($fechaCreacion, 'd/m/Y H:i') : "";
        $fechaEdicionFormateada = isset($fechaEdicion) ? date_format($fechaEdicion, 'd/m/Y H:i') : "";
        $getDepartamento = $personal->obtenerDepartamento();

        if ($getDepartamento[0] == 2) {
            $departamento = $personal->getDepartamento();
            $idDepartamento = $departamento->getId();
            $nombreDepartamento = $departamento->getNombre();
            $estadoDepartamento = $departamento->getEstado();
            $referenciaDepartamento = '#' . str_pad($idDepartamento, 10, "0", STR_PAD_LEFT);
            $filaDepartamento = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Referencia:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $referenciaDepartamento . '"
                               placeholder="Referencia del departamento" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreDepartamento . '"
                               placeholder="Nombre del departamento" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoDepartamento . '"
                               placeholder="Estado del departamento" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>';
        } else {
            $datosDepartamento = GeneradorHTML::getAlertaOperacion($getDepartamento[0], $getDepartamento[1]);
            $filaDepartamento = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosSucursal . '</div>
                </div>';
        }

        $cuerpo = '           
            <div class="form-row">
                <label class="col-sm-2 col-form-label">* Nombre corto:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombreCorto . '"
                           placeholder="Nombre corto" readonly>
                </div>
                <label class="col-sm-2 col-form-label">* Nombre largo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombreLargo . '"
                           placeholder="Nombre largo" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">RTI:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $rti . '"
                           placeholder="RTI" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Estado:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $estado . '"
                           placeholder="Estado" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Descripcion:</label>
                <div class="col">
                    <textarea class="form-control mb-2"
                              placeholder="Descripción" readonly>' . $descripcion . '</textarea>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Fecha de creación:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value = "' . $fechaCreacionFormateada . '"
                           placeholder="Fecha de creación" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Fecha de edición:</label>
                <div class="col">
                    <input type="input" class="form-control mb-2" 
                           value="' . $fechaEdicionFormateada . '"
                           placeholder="Fecha de ultima edición" readonly>
                </div>
            </div>
            <div class="form-row mt-4 mb-3">
                <div class="col-2"><strong><p>DEPARTAMENTO</p></strong></div>
                <div class="col-10"><hr></div>
            </div> ' . $filaDepartamento;
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-users"></i> DETALLE DE PERSONAL</h4>
        </div>
    </div>
    <div class="card border-azul-clasico mt-3">
        <div class="card-header bg-azul-clasico text-white">Información</div>
        <div class="card-body">
            <?= $cuerpo; ?>
        </div>
    </div>
    <div class="form-row mt-2 mb-4">
        <div class="col text-right">
            <button type="button" class="btn btn-outline-info" 
                    onClick="window.location.reload();" >
                <i class="fas fa-search"></i> REGRESAR
            </button>
        </div>
    </div>
</div>