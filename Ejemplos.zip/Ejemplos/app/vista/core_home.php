<?php

require './core_header.php';



echo "HOME";
