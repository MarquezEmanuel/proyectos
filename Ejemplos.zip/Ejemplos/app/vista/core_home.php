<?php
require_once './core_header.php';

use app\modelo\Constantes;
use app\modelo\ConstantesVersion as Version;
use app\modelo\GeneradorHTML;
use app\controlador\ControladorActividad;

$fechaHoy = date("d/m/Y");

if (isset($_SESSION['USUARIO_CAP'])) {

    $usuario = $_SESSION['USUARIO_CAP'];
    $legajo = $usuario->getId();
    $nombre = $usuario->getNombre();
    $nombrePerfil = $usuario->getPerfil()->getNombre();
    $descripcionPerfil = $usuario->getPerfil()->getDescripcion();

    $controladorLog = new ControladorActividad();
    $actividadesHistoricas = $controladorLog->listarResumenHistoricoUsuario($legajo);
    $actividadesHoy = $controladorLog->listarResumenHoyUsuario($legajo);

    if ($actividadesHistoricas[0] == 2) {
        $filas = "";
        $total = 0;
        $actividades = $actividadesHistoricas[1];
        while ($actividad = sqlsrv_fetch_array($actividades, SQLSRV_FETCH_ASSOC)) {
            $total = $total + $actividad['total'];
            $operacion = utf8_decode($actividad['operacion']);
            $filas .= " 
                <tr>
                    <td>{$operacion}</td>
                    <td class='text-center'>{$actividad['total']}</td>
                </tr>";
        }
        $cuerpoCardHistorico = '
            <div class="table-responsive mt-2 mb-2">
                <table id="tbModos" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th>Operación</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ' . $filas . '
                        <tr>
                            <td><b>TOTAL</b></td>
                            <td class="text-center"><b>' . $total . '</b></td>
                        </tr>
                    </tbody>
                </table>
            </div>';
    } else {
        $cuerpoCardHistorico = GeneradorHTML::getAlertaOperacion($actividadesHistoricas[0], $actividadesHistoricas[1]);
    }

    if ($actividadesHoy[0] == 2) {
        $filas = "";
        $total = 0;
        $actividades = $actividadesHoy[1];
        while ($actividad = sqlsrv_fetch_array($actividades, SQLSRV_FETCH_ASSOC)) {
            $total = $total + $actividad['total'];
            $operacion = utf8_decode($actividad['operacion']);
            $filas .= " 
                <tr>
                    <td>{$operacion}</td>
                    <td class='text-center'>{$actividad['total']}</td>
                </tr>";
        }
        $cuerpoCardHoy = '
            <div class="table-responsive mt-2 mb-2">
                <table id="tbModos" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th>Operación</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ' . $filas . '
                        <tr>
                            <td><b>TOTAL</b></td>
                            <td class="text-center"><b>' . $total . '</b></td>
                        </tr>
                    </tbody>
                </table>
            </div>';
    } else {
        $cuerpoCardHoy = GeneradorHTML::getAlertaOperacion($actividadesHoy[0], $actividadesHoy[1]);
    }
} else {
    header("Location: ../../index.php");
}
?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row">
            <div class="col text-left">
                <h4><?= Constantes::ICON_HOME; ?> <?= strtoupper(Constantes::APP_NOMBRE_LARGO); ?></h4>
            </div>
        </div>
        <div class="mt-4 mb-4">
            <div class="card border-azul-clasico">
                <div class="card-header bg-azul-clasico text-white">
                    <div class="row">
                        <div class="col">INICIO</div>
                        <div class="col text-right"><?= $fechaHoy; ?></div>
                    </div>
                </div>
                <div class="card-body bg-light">
                    <div class="card-deck mt-4 mb-4">
                        <div class="card">
                            <div class="card-header"><i class="fas fa-user"></i> <b>PERFIL DE USUARIO</b></div>
                            <div class="card-body bg-light">
                                <div class="form-row mt-2">
                                    <h6>Legajo: <?= $legajo; ?></h6>
                                </div>
                                <div class="form-row mt-2">
                                    <h6>Nombre: <?= $nombre; ?></h6>
                                </div>
                                <div class="form-row mt-2">
                                    <h6>Perfil: <?= $nombrePerfil; ?></h6>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <i class="fas fa-table"></i> <b>TABLERO DE OPERACIONES</b>
                            </div>
                            <div class="card-body bg-light">
                                <div class="form-row mt-2">
                                    <button class="btn btn-outline-success btn-block" 
                                            name="btnActividad" id="btnActividad">
                                        <i class="fas fa-chart-line"></i> MI ACTIVIDAD </button>
                                </div>
                                <div class="form-row mt-2">
                                    <a href="../../principal/vistas/procesarSalir.php" class="btn-block">
                                        <button class="btn btn-outline-danger btn-block">
                                            <i class="fas fa-sign-out-alt"></i> SALIR 
                                        </button>
                                    </a>
                                </div>
                                <div class="form-row mt-2">
                                    <h6></h6>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <i class="fas fa-info-circle"></i> <b>SOBRE <?= strtoupper(Constantes::APP_NOMBRE_CORTO); ?></b>
                            </div>
                            <div class="card-body bg-light">
                                <div class="form-row mt-2">
                                    <h6>Fecha de creación: <?= Version::APP_FECHA_CREACION; ?></h6>
                                </div>
                                <div class="form-row mt-2">
                                    <h6>Última actualización: <?= Version::APP_FECHA_EDICION; ?></h6>
                                </div>
                                <div class="form-row mt-2">
                                    <h6>Versión actual: <?= Version::APP_VERSION; ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="deckActividad" class="card-deck mt-5 mb-4" style="display: none;">
                        <div class="card">
                            <div class="card-header">
                                <i class="fas fa-history fa-spin"></i> <b>MI ACTIVIDAD HISTORICA REGISTRADA</b>
                            </div>
                            <div class="card-body">
                                <?= $cuerpoCardHistorico; ?>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <i class="fas fa-chart-line"></i> <b>MI ACTIVIDAD DE HOY</b>
                            </div>
                            <div class="card-body">
                                <?= $cuerpoCardHoy; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-azul-clasico text-white">
                    <div class="row">
                        <div class="col text-right">
                            <p class="mb-0">Sistema Desarrollado por la Gerencia de Sistemas del Banco Santa Cruz</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        $("#btnActividad").click(function () {
            if ($('div#deckActividad').is(":visible")) {
                $('div#deckActividad').hide();
            } else {
                $('div#deckActividad').show();
            }
        });

    });
</script>


