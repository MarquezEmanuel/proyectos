<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Empleado;

$boton = "";
if ($_POST['idEmpleado']) {
    $id = $_POST['idEmpleado'];
    $empleado = new Empleado($id);
    $resultado = $empleado->obtener();
    if ($resultado[0] == 2) {
        $nombre = $empleado->getNombre();
        $estado = $empleado->getEstado();
        $departamento = $empleado->getDepartamento();
        $getDepartamento = $empleado->obtenerDepartamento();


        if ($estado == 'Activo') {
            $opcionesEstado = '<option value="Activo" selected>Activo</option>';
            $opcionesEstado .= '<option value="Inactivo">Inactivo</option>';
        } else {
            $opcionesEstado = '<option value="Activo">Activo</option>';
            $opcionesEstado .= '<option value="Inactivo" selected>Inactivo</option>';
        }

        $boton = '
            <button type="submit" class="btn btn-success" 
                    id="btnModificarEmpleado" disabled>
                    ' . Constantes::ICON_GUARDAR . ' GUARDAR
            </button>';

        /* CARGA LOS DATOS DEL DEPARTAMENTO */

        if ($getDepartamento[0] == 2) {
            $departamento = $empleado->getDepartamento();
            $idDepartamento = $departamento->getId();
            $nombreDepartamento = $departamento->getNombre();
            $opcionDepartamento = "
                <select class='form-control mb-2' 
                        id='departamento' name='departamento'>
                        <option value='{$idDepartamento}'>{$nombreDepartamento}</option>
                </select>";
        } else {
            if (!$departamento) {
                $opcionDepartamento = "
                    <select class='form-control mb-2' 
                            id='departamento' name='departamento'>
                    </select>";
            } else {
                $boton = '';
                $opcionDepartamento = GeneradorHTML::getAlertaOperacion($getDepartamento[0], $getDepartamento[1]);
            }
        }

        $cuerpo = '
            <input type="hidden" name="idEmpleado" id="idEmpleado" value="' . $id . '">
            <div class="form-row">
                <label for="legajo" class="col-sm-2 col-form-label">* Legajo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="legajo" id="legajo" maxlength="10"
                           value="' . $id . '"
                           placeholder="Número de legajo" required>
                </div>
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" 
                           value="' . $nombre . '"
                           placeholder="Nombre completo" required>
                </div>
            </div>
            <div class="form-row">
                <label for="departamento" class="col-sm-2 col-form-label">Departamento:</label>
                <div class="col">' . $opcionDepartamento . '</div>
                <label for="estado" class="col-sm-2 col-form-label">* Estado:</label>
                <div class="col">
                    <select class="form-control mb-2" id="estado" name="estado">' . $opcionesEstado . '</select>
                </div>
            </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_EMPLEADO; ?> MODIFICAR EMPLEADO</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarEmpleado" name="formModificarEmpleado" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/empleado_modificar.js"></script>