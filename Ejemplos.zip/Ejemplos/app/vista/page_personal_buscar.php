<?php
require_once './core_header.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row">
                <div class="col text-left">
                    <h4><?= Constantes::ICON_MOD_PERSONAL; ?> BUSCAR PERSONAL</h4>
                </div>
            </div>
            <div class="mt-3 mb-4">
                <form method="POST" id="formBuscarPersonal" name="formBuscarPersonal">
                    <input type="hidden" name="peticion" id="peticion">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="nombrePersonal" class="col-2 col-form-label">Nombre:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombrePersonal" id="nombrePersonal" 
                                           title="Nombre del personal: campo no obligatorio"
                                           placeholder="Nombre del personal">
                                </div>
                                <label for="nombreDepartamento" class="col-2 col-form-label">Departamento:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreDepartamento" id="nombreDepartamento" 
                                           title="Nombre del departamento"
                                           placeholder="Nombre del departamento">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="estado" class="col-2 col-form-label">* Estado:</label>
                                <div class="col">
                                    <select id="estado" name="estado" class="form-control mb-2" required>
                                        <option value="Activo">Activo</option>
                                        <option value="Inactivo">Inactivo</option>
                                    </select>
                                </div>
                                <label class="col-2 col-form-label"></label>
                                <div class="col"></div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success">
                                <?= Constantes::ICON_BUSCAR; ?>  BUSCAR
                            </button>
                            <button type="button" class="btn btn-outline-info" 
                                    id="btnCrearPersonal" name="btnCrearPersonal">
                                <?= Constantes::ICON_AGREGAR; ?> CREAR
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div id="seccionInferior" class="mt-4 mb-2"></div>
        </div>
        <?php echo GeneradorHTML::getModalProcesando(); ?>
    </div>
</div>
<script type="text/javascript" src="./js/personal_buscar.js"></script>