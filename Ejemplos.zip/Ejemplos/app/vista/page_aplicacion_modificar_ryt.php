<?php
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Aplicacion;

AutoCargador::cargarModulos();
session_start();

$boton = "";
if ($_POST['idAplicacion']) {
    $id = $_POST['idAplicacion'];
    $aplicacion = new Aplicacion($id);
    $resultado = $aplicacion->obtener();
    if ($resultado[0] == 2) {
        $nombreCorto = $aplicacion->getNombreCorto();
        $nombreLargo = $aplicacion->getNombreLargo();

        $getHardwares = $aplicacion->obtenerServidores();

        $boton = '<button type="submit" class="btn btn-success" 
                          id="btnModificarAplicacion" disabled>
                          <i class="far fa-save"></i> GUARDAR
                  </button>';

        if ($getHardwares[0] == 2) {
            $servidores = $aplicacion->getServidores();

            $servidor01 = $servidores[0];
            $servidor02 = isset($servidores[1]) ? $servidores[1] : NULL;
            $servidor03 = isset($servidores[2]) ? $servidores[2] : NULL;

            $idServidor01 = $servidor01['id'];
            $nombreServidor01 = utf8_encode($servidor01['nombreLargo']);
            $rutaServidor01 = utf8_encode($servidor01['ruta']);

            $opcionServidor02 = ($servidor02) ? "<option value='{$servidor02['id']}'>" . utf8_encode($servidor02['nombreLargo']) . "</option>" : '';
            $rutaServidor02 = ($servidor02) ? utf8_encode($servidor02['ruta']) : '';

            $opcionServidor03 = ($servidor03) ? "<option value='{$servidor03['id']}'>" . utf8_encode($servidor03['nombreLargo']) . "</option>" : '';
            $rutaServidor03 = ($servidor03) ? utf8_encode($servidor03['ruta']) : '';

            $filaHardware = '
                    <div class="form-row">
                        <label class="col-sm-2 col-form-label"></label>
                        <div class="col">
                            <label class="col-form-label mb-2">Hardware</label>
                        </div>
                        <div class="col">
                            <label class="col-form-label mb-2">Ruta</label>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="servidor1" class="col-sm-2 col-form-label">* N° 1:</label>
                        <div class="col">
                            <select class="form-control mb-2 hardware"  data-width="100%"
                                    name="servidor1" id="servidor1" required>
                                <option value="' . $idServidor01 . '">' . $nombreServidor01 . '</option>    
                            </select>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="ruta1" id="ruta1" maxlength="250"
                                   value="' . $rutaServidor01 . '"
                                   placeholder="Ruta">
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="servidor2" class="col-sm-2 col-form-label">N° 2:</label>
                        <div class="col">
                            <select class="form-control mb-2 hardware" data-width="100%"
                                    name="servidor2" id="servidor2">' . $opcionServidor02 . '</select>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="ruta2" id="ruta2" maxlength="250"
                                   value="' . $rutaServidor02 . '"
                                   placeholder="Ruta">
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="servidor1" class="col-sm-2 col-form-label">N° 3:</label>
                        <div class="col">
                            <select class="form-control mb-2 hardware" data-width="100%"
                                    name="servidor3" id="servidor3">' . $opcionServidor03 . '</select>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="ruta3" id="ruta3" maxlength="250"
                                   value="' . $rutaServidor03 . '"
                                   placeholder="Ruta">
                        </div>
                    </div>';
        } else {

            if ($getHardwares[0] == 1) {

                /* NO SE ASOCIARON HARDWARES PARA LA APLICACION */

                $filaHardware = '
                    <div class="form-row">
                        <label class="col-sm-2 col-form-label"></label>
                        <div class="col">
                            <label class="col-form-label mb-2">Hardware</label>
                        </div>
                        <div class="col">
                            <label class="col-form-label mb-2">Ruta</label>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="servidor1" class="col-sm-2 col-form-label">* N° 1:</label>
                        <div class="col">
                            <select class="form-control mb-2 hardware"  data-width="100%"
                                    name="servidor1" id="servidor1" required> 
                            </select>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="ruta1" id="ruta1" maxlength="250"
                                   placeholder="Ruta">
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="servidor2" class="col-sm-2 col-form-label">N° 2:</label>
                        <div class="col">
                            <select class="form-control mb-2 hardware"  data-width="100%"
                                    name="servidor2" id="servidor2"></select>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="ruta2" id="ruta2" maxlength="250"
                                   placeholder="Ruta">
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="servidor1" class="col-sm-2 col-form-label">N° 3:</label>
                        <div class="col">
                            <select class="form-control mb-2 hardware" data-width="100%"
                                    name="servidor3" id="servidor3"></select>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control mb-2" 
                                   name="ruta3" id="ruta3" maxlength="250"
                                   placeholder="Ruta">
                        </div>
                    </div>';
            } else {
                $boton = '';
                $datosHardware = GeneradorHTML::getAlertaOperacion($getHardwares[0], $getHardwares[1]);
                $filaHardware = '
                    <div class="form-row">
                        <div class="col">' . $datosHardware . '</div>
                    </div>';
            }
        }

        /* CARGA EL CUERPO DEL FORMULARIO CON LOS DATOS OBTENIDOS */
        $cuerpo = '
            <input type="hidden" name="idAplicacion" id="idAplicacion" value="' . $id . '"/>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Nombre corto:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombreCorto . '"
                           id="nombreCorto" name="nombreCorto"
                           placeholder="Nombre corto" readonly>
                </div>
                <label for="marca" class="col-sm-2 col-form-label">Nombre largo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombreLargo . '"
                           id="nombreLargo" name="nombreLargo"
                           placeholder="Nombre largo" readonly>
                </div>
            </div>
            <div class="form-row mt-4 mb-2">
                <div class="col-2"><strong><p>DATOS DE HARDWARE</p></strong></div>
                <div class="col-10"><hr></div>
            </div>
            ' . $filaHardware;
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_APLICACION; ?> MODIFICAR APLICACIÓN</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarAplicacion" name="formModificarAplicacion" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/aplicacion_modificar_ryt.js"></script>
