<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\HerramientaDesarrollo;

$boton = "";
if ($_POST['idHerramienta']) {
    $id = $_POST['idHerramienta'];
    $herramienta = new HerramientaDesarrollo($id);
    $resultado = $herramienta->obtener();
    if ($resultado[0] == 2) {

        $nombre = $herramienta->getNombre();
        $version = $herramienta->getVersion();
        $fabricante = $herramienta->getFabricante();
        $fechaCaducidad = $herramienta->getFechaCaducidad();
        $estado = $herramienta->getEstado();
        $fechaCaducidadFormateada = isset($fechaCaducidad) ? date_format($fechaCaducidad, 'Y-m-d') : "";
        $descripcion = $herramienta->getDescripcion();
        $getProveedores = $herramienta->obtenerProveedores();

        if ($estado == 'Activa') {
            $opcionesEstado = '<option value="Activa" selected>Activa</option>';
            $opcionesEstado .= '<option value="Inactiva">Inactiva</option>';
        } else {
            $opcionesEstado = '<option value="Activa">Activa</option>';
            $opcionesEstado .= '<option value="Inactiva" selected>Inactiva</option>';
        }

        $boton = '<button type="submit" class="btn btn-success" 
                          id="btnModificarHerramienta" disabled>
                          <i class="far fa-save"></i> GUARDAR</button>';

        /* CARGA LA TABLA DE PROVEEDORES */

        /* CARGA LOS PROVEEDORES ACTIVOS QUE ESTAN EN LA BASE DE DATOS */

        if ($getProveedores[0] == 2) {
            $proveedores = $herramienta->getProveedores();
            $opciones = "";
            foreach ($proveedores as $proveedor) {
                $idProveedor = $proveedor['id'];
                $nombreProveedor = utf8_encode($proveedor['nombre']);
                $opciones .= "<option value='{$idProveedor}' selected>{$nombreProveedor}</option>";
            }
            $opcionProveedor = "
                <select class='form-control mb-2' multiple='multiple' 
                        data-width='100%' id='proveedores' name='proveedores[]' 
                        required>{$opciones}</select>";
        } else {
            $opcionProveedor = GeneradorHTML::getAlertaOperacion($getProveedores[0], $getProveedores[1]);
        }

        $cuerpo = '
                <input type="hidden" name="idHerramienta" id="idHerramienta" 
                       value="' . $id . '">
                <div class="form-row">
                    <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombre" id="nombre" maxlength="50"
                               value = "' . $nombre . '"
                               placeholder="Nombre" required>
                    </div>
                    <label for="version" class="col-sm-2 col-form-label">* Versión:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="version" id="version" maxlength="20"
                               value = "' . $version . '"
                               placeholder="Versión" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="fabricante" class="col-sm-2 col-form-label">* Fabricante:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="fabricante" id="fabricante" maxlength="50"
                               value = "' . $fabricante . '"
                               placeholder="Nombre del fabricante" required>
                    </div>
                    <label class="col-sm-2 col-form-label">Fecha caducidad:</label>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCaducidad" id="fechaCaducidad"
                               value="' . $fechaCaducidadFormateada . '"
                               placeholder="Fecha de caducidad">
                    </div>
                </div>
                <div class="form-row">
                    <label for="estado" class="col-sm-2 col-form-label">* Estado:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="estado" name="estado">' . $opcionesEstado . '</select>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>
                <div class="form-row">
                    <label for="proveedores" class="col-sm-2 col-form-label">* Proveedores:</label>
                    <div class="col mb-2">' . $opcionProveedor . '</div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label">* Descripción:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  name="descripcion" id="descripcion" maxlength="300"
                                  placeholder="Descripción adicional" required>' . $descripcion . '</textarea>
                    </div>
                </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_HERRAMIENTA; ?> MODIFICAR HERRAMIENTA</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarHerramienta" name="formModificarHerramienta" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/herramienta_modificar.js"></script>