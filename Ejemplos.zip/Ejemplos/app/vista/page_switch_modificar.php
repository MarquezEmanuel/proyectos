<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Switchs;

$boton = "";
if ($_POST['idSwitch']) {
    $id = $_POST['idSwitch'];
    $switch = new Switchs($id);
    $resultado = $switch->obtener();
    if ($resultado[0] == 2) {

        $nombre = $switch->getNombre();
        $modelo = $switch->getModelo();
        $version = $switch->getVersion();
        $descripcion = $switch->getDescripcion();
        $estado = $switch->getEstado();
        $getInstalacion = $switch->obtenerInstalacion();
        $getSitio = $switch->obtenerSitio();
        $getProveedores = $switch->obtenerProveedores();

        $boton = '
            <button type="submit" class="btn btn-success" 
                    id="btnModificarSwitch" disabled>
                    <i class="far fa-save"></i> GUARDAR
            </button>';

        if ($estado == 'Activo') {
            $opcionesEstado = '<option value="Activo" selected>Activo</option>';
            $opcionesEstado .= '<option value="Inactivo">Inactivo</option>';
        } else {
            $opcionesEstado = '<option value="Activo">Activo</option>';
            $opcionesEstado .= '<option value="Inactivo" selected>Inactivo</option>';
        }

        /* CARGA LOS DATOS DE LA SUCURSAL */

        if ($getSitio[0] == 2) {
            $sitio = $switch->getSitio();
            $idSitio = $sitio->getId();
            $nombreSitio = $sitio->getNombre();
            $opcionSitio = "
                <select class='form-control mb-2' required data-width='100%' 
                        id='sitio' name='sitio'>
                        <option value='{$idSitio}'>{$nombreSitio}</option>
                </select>";
        } else {
            $boton = '';
            $opcionSitio = GeneradorHTML::getAlertaOperacion($getSitio[0], $getSitio[1]);
        }

        /* CARGA LOS DATOS DE LA SUCURSAL */

        if ($getInstalacion[0] == 2) {
            $instalacion = $switch->getInstalacion();
            $idInstalacion = $instalacion->getId();
            $nombreInstalacion = $instalacion->getNombreLargo();
            $opcionInstalacion = "
                <select class='form-control mb-2' required data-width='100%' 
                        id='instalacion' name='instalacion'>
                        <option value='{$idInstalacion}'>{$nombreInstalacion}</option>
                </select>";
        } else {
            $boton = '';
            $opcionInstalacion = GeneradorHTML::getAlertaOperacion($getInstalacion[0], $getInstalacion[1]);
        }


        /* CARGA LOS PROVEEDORES ACTIVOS QUE ESTAN EN LA BASE DE DATOS */

        if ($getProveedores[0] == 2) {
            $proveedores = $switch->getProveedores();
            $opciones = "";
            foreach ($proveedores as $proveedor) {
                $idProveedor = $proveedor['id'];
                $nombreProveedor = utf8_encode($proveedor['nombre']);
                $opciones .= "<option value='{$idProveedor}' selected>{$nombreProveedor}</option>";
            }
            $opcionProveedor = "
                <select class='form-control mb-2' multiple='multiple' 
                        data-width='100%' id='proveedores' name='proveedores[]' 
                        required>{$opciones}</select>";
        } else {
            $opcionProveedor = GeneradorHTML::getAlertaOperacion($getProveedores[0], $getProveedores[1]);
        }


        $cuerpo = '
            <input type="hidden" name="idSwitch" id="idSwitch" value="' . $id . '">
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" maxlength="50"
                           value="' . $nombre . '"
                           placeholder="Nombre" required>
                </div>
                <label for="modelo" class="col-sm-2 col-form-label">* Modelo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="modelo" id="modelo" maxlength="50"
                           value="' . $modelo . '"
                           placeholder="Modelo" required>
                </div>
            </div>
            <div class="form-row">
                <label for="version" class="col-sm-2 col-form-label">* Versión:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="version" id="version" maxlength="50"
                           value="' . $version . '"
                           placeholder="IOS Versión" required>
                </div>
                <label for="instalacion" class="col-sm-2 col-form-label">* Instalación:</label>
                <div class="col">' . $opcionInstalacion . '</div>
            </div>
            <div class="form-row">
                <label for="sitio" class="col-sm-2 col-form-label">* Sitio:</label>
                <div class="col">' . $opcionSitio . '</div>
                <label for="estado" class="col-sm-2 col-form-label">* Estado:</label>
                <div class="col">
                    <select class="form-control mb-2" id="estado" name="estado">' . $opcionesEstado . '</select>
                </div>
            </div>
            <div class="form-row">
                <label for="proveedores" class="col-sm-2 col-form-label">* Proveedores:</label>
                <div class="col">' . $opcionProveedor . '</div>
            </div>
            <div class="form-row">
                <label for="descripcion" class="col-sm-2 col-form-label">* Descripcion:</label>
                <div class="col">
                    <textarea class="form-control mb-2" 
                              id="descripcion" name="descripcion"
                              rows="5" minlength="10" maxlength="500"
                              placeholder="Descripcion" required>' . $descripcion . '</textarea>
                </div>
            </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-ethernet"></i> MODIFICAR SWITCH</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarSwitch" name="formModificarSwitch" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info" onclick="window.location.reload()">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/switch_modificar.js"></script>