<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Usuario;

$boton = "";
if ($_POST['idUsuario']) {
    $legajo = $_POST['idUsuario'];
    $usuario = new Usuario($legajo);
    $resultado = $usuario->obtener();
    if ($resultado[0] == 2) {

        $nombre = $usuario->getNombre();
        $estado = $usuario->getEstado();
        $getPerfil = $usuario->obtenerPerfil();

        if ($estado == 'Activo') {
            $opcionesEstado = '<option value="Activo" selected>Activo</option>';
            $opcionesEstado .= '<option value="Inactivo">Inactivo</option>';
        } else {
            $opcionesEstado = '<option value="Activo">Activo</option>';
            $opcionesEstado .= '<option value="Inactivo" selected>Inactivo</option>';
        }

        $boton = '<button type="submit" class="btn btn-success" 
                        id="btnModificarUsuario" disabled>
                        ' . Constantes::ICON_GUARDAR . ' GUARDAR
                  </button>';

        if ($getPerfil[0] == 2) {
            $perfil = $usuario->getPerfil();
            $idPerfil = $perfil->getId();
            $nombrePerfil = $perfil->getNombre();
            $opcionPerfil = "
                <select class='form-control mb-2' 
                        id='perfil' name='perfil' required>
                        <option value='{$idPerfil}'>{$nombrePerfil}</option>
                </select>";
        } else {
            $boton = '';
            $opcionPerfil = GeneradorHTML::getAlertaOperacion($getPerfil[0], $getPerfil[1]);
        }

        $cuerpo = '
            <input type="hidden" name="legajoOriginal" id="legajoOriginal" value="' . $legajo . '">
            <div class="form-row">
                <label for="legajo" class="col-sm-2 col-form-label">* Legajo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="legajo" id="legajo" 
                           maxlength="10" pattern="[0-9A-Z]{4,10}"
                           value="' . $legajo . '"
                           placeholder="Legajo del usuario" required>
                </div>
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre"
                           value="' . $nombre . '"
                           placeholder="Nombre del usuario" required>
                </div>
            </div>
            <div class="form-row">
                <label for="perfil" class="col-sm-2 col-form-label">* Perfil:</label>
                <div class="col">' . $opcionPerfil . '</div>
                <label for="nombreCorto" class="col-sm-2 col-form-label">* Estado:</label>
                <div class="col">
                    <select class="form-control mb-2" id="estado" name="estado">' . $opcionesEstado . '</select>
                </div>
            </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_USUARIO; ?> MODIFICAR USUARIO</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarUsuario" name="formModificarUsuario" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info"
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/usuario_modificar.js"></script>

