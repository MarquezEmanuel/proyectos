<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Responsable;

$boton = "";
if (isset($_POST['idResponsable'])) {
    $id = $_POST['idResponsable'];
    $responsable = new Responsable($id);
    $resultado = $responsable->obtener();
    if ($resultado[0] == 2) {
        $nombre = $responsable->getNombre();
        $telefono = $responsable->getTelefono();
        $correo = $responsable->getCorreo();
        $estado = $responsable->getEstado();
        $getProveedor = $responsable->obtenerProveedor();

        if ($estado == 'Activo') {
            $opcionesEstado = '<option value="Activo" selected>Activo</option>';
            $opcionesEstado .= '<option value="Inactivo">Inactivo</option>';
        } else {
            $opcionesEstado = '<option value="Activo">Activo</option>';
            $opcionesEstado .= '<option value="Inactivo" selected>Inactivo</option>';
        }

        $boton = '
            <button type="submit" class="btn btn-success" 
                    id="btnModificarResponsable" disabled>
                    ' . Constantes::ICON_GUARDAR . ' GUARDAR
            </button>';

        /* CARGA LOS DATOS DEL PROVEEDOR */

        if ($getProveedor[0] == 2) {
            $proveedor = $responsable->getProveedor();
            $idProveedor = $proveedor->getId();
            $nombreProveedor = $proveedor->getNombre();
            $opcionProveedor = "
                <select class='form-control mb-2' id='proveedor' name='proveedor' data-width='100%' required>
                        <option value='{$idProveedor}'>{$nombreProveedor}</option>
                </select>";
        } else {
            $boton = '';
            $opcionProveedor = GeneradorHTML::getAlertaOperacion($getProveedor[0], $getProveedor[1]);
        }

        $cuerpo = '
            <input type="hidden" name="idResponsable" id="idResponsable" value="' . $id . '">
            <div class="form-row">
                <label for="proveedor" class="col-sm-2 col-form-label">* Proveedor:</label>
                <div class="col">' . $opcionProveedor . '</div>
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" maxlength="50"
                           value="' . $nombre . '"
                           placeholder="Nombre del responsable" required>
                </div>
            </div>
            <div class="form-row">
                <label for="telefono" class="col-sm-2 col-form-label">Telefono:</label>
                <div class="col">
                    <input type="tel" class="form-control mb-2" 
                           name="telefono" id="telefono" maxlength="20"
                           value="' . $telefono . '"
                           placeholder="Número de telefono">
                </div>
                <label for="correo" class="col-sm-2 col-form-label">* Correo:</label>
                <div class="col">
                    <input type="email" class="form-control mb-2" 
                           name="correo" id="correo" maxlength="50"
                           value="' . $correo . '"
                           placeholder="Correo electrónico" required>
                </div>
            </div>
            <div class="form-row">
                <label for="estado" class="col-sm-2 col-form-label">* Estado:</label>
                <div class="col">
                    <select class="form-control mb-2" id="estado" name="estado">' . $opcionesEstado . '</select>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col"></div>
            </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_RESPONSABLE; ?> MODIFICAR RESPONSABLE</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <div id="seccionCentral">
        <form id="formModificarResponsable" name="formModificarResponsable" method="POST">
            <div class="card border-azul-clasico mt-3 ">
                <div class="card-header text-left bg-azul-clasico text-white">Formulario de modificación</div>
                <div class="card-body">
                    <?= $cuerpo; ?>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <?= $boton; ?>
                    <button type="button" class="btn btn-outline-info" 
                            onclick="window.location.reload()">
                        <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="./js/responsable_modificar.js"></script>