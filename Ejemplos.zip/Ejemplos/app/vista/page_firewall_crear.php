<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_FIREWALL; ?> CREAR FIREWALL</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formCrearFirewall" name="formCrearFirewall" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombre" id="nombre" 
                               placeholder="Nombre" required>
                    </div>
                    <label for="marca" class="col-sm-2 col-form-label">* Marca:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="marca" id="marca"
                               placeholder="Nombre de la marca" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="modelo" class="col-sm-2 col-form-label">* Modelo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="modelo" id="modelo" maxlength="50"
                               placeholder="Modelo" required>
                    </div>
                    <label for="nroSerie" class="col-sm-2 col-form-label">* Nro Serie:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nroSerie" id="nroSerie" maxlength="50"
                               placeholder="Número de serie" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="version" class="col-sm-2 col-form-label">* Versión Firmware:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="version" id="version" maxlength="50"
                               placeholder="Versión" required>
                    </div>
                    <label for="ip" class="col-sm-2 col-form-label">* IP:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="ip" id="ip" maxlength="15"
                               placeholder="IP" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="sucursal" class="col-sm-2 col-form-label">* Sitio:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="sucursal" name="sucursal" data-width='100%' required></select>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>
                <div class="form-row mb-2">
                    <label for="proveedores" class="col-sm-2 col-form-label">* Proveedores:</label>
                    <div class="col">
                        <select class="form-control mb-2" multiple="multiple" data-width='100%' 
                                id="proveedores" name="proveedores[]"></select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label">* Descripcion:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  id="descripcion" name="descripcion"
                                  rows="5" minlength="10" maxlength="500"
                                  placeholder="Descripcion" required></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-success">
                    <?= Constantes::ICON_GUARDAR; ?> GUARDAR
                </button>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/firewall_crear.js"></script>
