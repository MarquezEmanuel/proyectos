<?php
require_once './core_header.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;

$fechaHoy = date('Y-m-d');
?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div id="seccionSuperior" class="form-row mt-3">
            <div class="col text-left">
                <h4><?= Constantes::ICON_MOD_ACTIVIDAD; ?> BUSCAR ACTIVIDAD DE USUARIOS</h4>
            </div>
        </div>
        <div id="seccionCentral" class="mt-3 mb-4">
            <form id="formBuscarActividad" name="formBuscarActividad" method="POST">
                <input type="hidden" name="peticion" id="peticion">
                <div class="card border-azul-clasico mt-3">
                    <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                    <div class="card-body">
                        <div class="form-row">
                            <label for="tipo" class="col-2 col-form-label">Tipo:</label>
                            <div class="col-4">
                                <select id="tipo" name="tipo" class="form-control mb-2" data-width="100%"></select>
                            </div>
                            <label for="modulo" class="col-2 col-form-label">Modulo:</label>
                            <div class="col-4">
                                <select class="form-control mb-2" data-width="100%" 
                                        id="modulo" name="modulo"></select>
                            </div>
                        </div>
                        <div class="form-row">
                            <label for="operacion" class="col-2 col-form-label">Operación:</label>
                            <div class="col-4">
                                <select class="form-control mb-2" data-width="100%" id="operacion" name="operacion"></select>
                            </div>
                            <label for="nombreUsuario" class="col-2 col-form-label">Usuario:</label>
                            <div class="col-4">
                                <input type="text" class="form-control mb-2" 
                                       name="nombreUsuario" id="nombreUsuario" maxlength="50"
                                       placeholder="Nombre de usuario">
                            </div>
                        </div>
                        <div class="form-row">
                            <label for="fechaInicio" class="col-2 col-form-label">Fecha de inicio:</label>
                            <div class="col-4">
                                <input type="date" class="form-control mb-2" 
                                       max="<?= $fechaHoy ?>" value="<?= $fechaHoy ?>"
                                       name="fechaInicio" id="fechaInicio">
                            </div>
                            <label for="fechaFin" class="col-2 col-form-label">Fecha de fin:</label>
                            <div class="col-4">
                                <input type="date" class="form-control mb-2" 
                                       max="<?= $fechaHoy ?>" value="<?= $fechaHoy ?>"
                                       name="fechaFin" id="fechaFin">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-row mt-2">
                    <div class="col text-right">
                        <button type="submit" class="btn btn-success">
                            <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                        </button>
                    </div>
                </div>
            </form>


        </div>
        <div id="seccionInferior" class="mt-4 mb-3"></div>
    </div>
    <?php echo GeneradorHTML::getModalProcesando(); ?>
</div>
<script type="text/javascript" src="./js/actividad_buscar.js"></script>
