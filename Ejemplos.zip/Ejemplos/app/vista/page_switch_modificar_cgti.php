<?php
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Switchs;

AutoCargador::cargarModulos();
session_start();

$boton = "";
if ($_POST['idSwitch']) {
    $id = $_POST['idSwitch'];
    $switch = new Switchs($id);
    $resultado = $switch->obtener();
    if ($resultado[0] == 2) {

        $nombre = $switch->getNombre();
        $visibilidad = $switch->getVisibilidad();
        $riesgo = $switch->getRti();

        if (strtoupper($riesgo) == "SI") {
            $opcionesRTI = "<option value='Si' selected>Si</option>";
            $opcionesRTI .= "<option value='No'>No</option>";
        } else {
            $opcionesRTI = "<option value='Si'>Si</option>";
            $opcionesRTI .= "<option value='No' selected>No</option>";
        }

        $cuerpo = '
            <input type="hidden" name="idSwitch" id="idSwitch" value="' . $id . '">
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label">Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" maxlength="50"
                           value="' . $nombre . '"
                           placeholder="Nombre" readonly>
                </div>
            </div>
            <div class="form-row">
                <label for="version" class="col-sm-2 col-form-label">* Visibilidad:</label>
                <div class="col">
                    <input type="number" class="form-control mb-2" 
                           name="visibilidad" id="visibilidad" min="1" max="10"
                           value="' . $visibilidad . '"
                           title="Nivel de visibilidad del registro"
                           placeholder="Nivel de visibilidad" required>
                </div>
                <label for="rti" class="col-sm-2 col-form-label">* RTI:</label>
                <div class="col">
                    <select class="form-control mb-2" name="rti" id="rti">' . $opcionesRTI . '</select>
                </div>
            </div>';
        $boton = '
            <button type="submit" class="btn btn-success" 
                    id="btnModificarSwitch" disabled>
                    <i class="far fa-save"></i> GUARDAR
            </button>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_SWITCH; ?> MODIFICAR SWITCH</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarSwitch" name="formModificarSwitch" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/switch_modificar_cgti.js"></script>