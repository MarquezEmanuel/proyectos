<?php
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "Constantes.php");

use app\modelo\Constantes;
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_COMUNICACION; ?> CREAR COMUNICACIÓN</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formCrearComunicacion" name="formCrearComunicacion" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="nombreCorto" class="col-sm-2 col-form-label">* Nombre corto:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreCorto" id="nombreCorto" maxlength="20" 
                               placeholder="Nombre corto" required>
                    </div>
                    <label for="nombreLargo" class="col-sm-2 col-form-label">* Nombre largo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreLargo" id="nombreLargo" maxlength="50"
                               placeholder="Nombre largo" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="gerencia" class="col-sm-2 col-form-label">* Gerencia:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="gerencia" id="gerencia" data-width='100%' required></select>
                    </div>
                    <label for="delegado" class="col-sm-2 col-form-label">* Delegado:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="delegado" id="delegado" data-width='100%' required></select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="sitio" class="col-sm-2 col-form-label">* Sitio:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="sitio" id="sitio" data-width='100%' required></select>
                    </div>
                    <label for="proveedor" class="col-sm-2 col-form-label">* Proveedor:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="proveedor" id="proveedor" data-width='100%' required></select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="cantidad" class="col-sm-2 col-form-label">* Cantidad:</label>
                    <div class="col">
                        <input type="number" class="form-control mb-2" 
                               name="cantidad" id="cantidad" min="1"
                               placeholder="Cantidad" required>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>
                <div class="form-row">
                    <label for="cantidad" class="col-sm-2 col-form-label">* Descripción:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  name="descripcion" id="descripcion"
                                  rows="5" minlength="10" maxlength="500"
                                  placeholder="Decripción"></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-success">
                    <?= Constantes::ICON_GUARDAR; ?> GUARDAR
                </button>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/comunicacion_crear.js"></script>