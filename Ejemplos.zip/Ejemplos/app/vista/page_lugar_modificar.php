<?php
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\LugarProcesamiento;
use app\modelo\GeneradorHTML;

AutoCargador::cargarModulos();
$boton = "";
if ($_POST['idLugar']) {
    $id = $_POST['idLugar'];
    $lugar = new LugarProcesamiento($id);
    $resultado = $lugar->obtener();
    if ($resultado[0] == 2) {
        $nombre = $lugar->getNombre();
        $estado = $lugar->getEstado();

        if ($estado == 'Activo') {
            $opcionesEstado = '<option value="Activo" selected>Activo</option>';
            $opcionesEstado .= '<option value="Inactivo">Inactivo</option>';
        } else {
            $opcionesEstado = '<option value="Activo">Activo</option>';
            $opcionesEstado .= '<option value="Inactivo" selected>Inactivo</option>';
        }

        $cuerpo = '
            <input type="hidden" name="idLugar" id="idLugar" value="' . $id . '">
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" maxlength="50" minlength="3"
                           value="' . $nombre . '"
                           placeholder="Nombre" required>
                </div>
                <label for="estado" class="col-sm-2 col-form-label">* Estado:</label>
                <div class="col">
                    <select class="form-control mb-2" id="estado" name="estado">' . $opcionesEstado . '</select>
                </div>
            </div>';
        $boton = '<button type="submit" class="btn btn-success" 
                          id="btnModificarLugar" disabled>
                          <i class="far fa-save"></i> GUARDAR
                   </button>';
    } else {
        $codigo = $resultado[0];
        $mensaje = $resultado[1];
        $cuerpo = GeneradorHTML::getAlertaOperacion($codigo, $mensaje);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_LUGARPR; ?> MODIFICAR LUGAR PROCESAMIENTO</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarLugar" name="formModificarLugar" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/lugar_procesamiento_modificar.js"></script>
