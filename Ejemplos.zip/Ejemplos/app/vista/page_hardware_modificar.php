<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Hardware;

$boton = "";
if (isset($_POST['idHardware'])) {
    $id = $_POST['idHardware'];
    $hardware = new Hardware($id);
    $resultado = $hardware->obtener();
    if ($resultado[0] == 2) {

        $tipo = $hardware->getTipo();
        $nombreCorto = $hardware->getNombreCorto();
        $nombreLargo = $hardware->getNombreLargo();
        $dominio = $hardware->getDominio();
        $softwareBase = $hardware->getSwBase();
        $ambiente = $hardware->getAmbiente();
        $funcion = $hardware->getFuncion();
        $marca = $hardware->getMarca();
        $modelo = $hardware->getModelo();
        $arquitectura = $hardware->getArquitectura();
        $core = $hardware->getCore();
        $procesador = $hardware->getProcesador();
        $mhz = $hardware->getMhz();
        $memoria = $hardware->getMemoria();
        $disco = $hardware->getDisco();
        $raid = $hardware->getRaid();
        $red = $hardware->getRed();
        $estado = $hardware->getEstado();
        $descripcion = $hardware->getDescripcion();
        $getSitio = $hardware->obtenerSitio();
        $getProveedores = $hardware->obtenerProveedores();

        if ($estado == 'Activo') {
            $opcionesEstado = '<option value="Activo" selected>Activo</option>';
            $opcionesEstado .= '<option value="Inactivo">Inactivo</option>';
        } else {
            $opcionesEstado = '<option value="Activo">Activo</option>';
            $opcionesEstado .= '<option value="Inactivo" selected>Inactivo</option>';
        }

        $boton = '<button type="submit" class="btn btn-success" 
                          id="btnModificarHardware" disabled>
                          <i class="far fa-save"></i> GUARDAR
                 </button>';

        // Se cargan las opciones para el tipo de hardware 
        $opcionesTipo = ($tipo == "Host virtual") ? '<option value="Host virtual" selected>Host virtual</option>' : '<option value="Host virtual">Host virtual</option>';
        $opcionesTipo .= ($tipo == "Maquina virtual") ? '<option value="Maquina virtual" selected>Máquina virtual</option>' : '<option value="Maquina virtual">Máquina virtual</option>';
        $opcionesTipo .= ($tipo == "Hardware fisico") ? '<option value="Hardware fisico" selected>Hardware físico</option>' : '<option value="Hardware fisico">Hardware físico</option>';
        $opcionesTipo .= ($tipo == "Otro") ? '<option value="Otro" selected>Otro</option>' : '<option value="Otro">Otro</option>';

        // Se cargan las opciones para el ambiente
        $opcionesAmbiente = ($ambiente == "Produccion") ? '<option value="Produccion" selected>Producción</option>' : '<option value="Produccion">Producción</option>';
        $opcionesAmbiente .= ($ambiente == "Test") ? '<option value="Test" selected>Test</option>' : '<option value="Test">Test</option>';
        $opcionesAmbiente .= ($ambiente == "Desarrollo") ? '<option value="Desarrollo" selected>Desarrollo</option>' : '<option value="Desarrollo">Desarrollo</option>';

        // Se cargan las opciones para el dominio
        $opcionesDominio = ($dominio == "CORP") ? '<option value="CORP" selected>CORP</option>' : '<option value="CORP">CORP</option>';
        $opcionesDominio .= ($dominio == "DMZ") ? '<option value="DMZ" selected>DMZ</option>' : '<option value="DMZ">DMZ</option>';
        $opcionesDominio .= ($dominio == "SANTACRUZ") ? '<option value="SANTACRUZ" selected>SANTA CRUZ</option>' : '<option value="SANTACRUZ">SANTA CRUZ</option>';

        /* CARGA LOS DATOS DE LA SUCURSAL */

        if ($getSitio[0] == 2) {
            $sitio = $hardware->getSitio();
            $idSitio = $sitio->getId();
            $nombreSitio = $sitio->getNombre();
            $opcionSitio = "
                <select class='form-control mb-2' 
                        id='sitio' name='sitio'>
                        <option value='{$idSitio}'>{$nombreSitio}</option>
                </select>";
        } else {
            $boton = '';
            $opcionSitio = GeneradorHTML::getAlertaOperacion($getSitio[0], $getSitio[1]);
        }
        
        /* CARGA LOS PROVEEDORES ACTIVOS QUE ESTAN EN LA BASE DE DATOS */

        if ($getProveedores[0] == 2) {
            $proveedores = $hardware->getProveedores();
            $opciones = "";
            foreach ($proveedores as $proveedor) {
                $idProveedor = $proveedor['id'];
                $nombreProveedor = utf8_encode($proveedor['nombre']);
                $opciones .= "<option value='{$idProveedor}' selected>{$nombreProveedor}</option>";
            }
            $opcionProveedor = "
                <select class='form-control mb-2' multiple='multiple' 
                        data-width='100%' id='proveedores' name='proveedores[]' 
                        required>{$opciones}</select>";
        } else {
            $opcionProveedor = GeneradorHTML::getAlertaOperacion($getProveedores[0], $getProveedores[1]);
        }

        $cuerpo = '
                <input type="hidden" name="idHardware" id="idHardware" value="' . $id . '">
                <div class="form-row">
                    <label for="tipo" class="col-sm-2 col-form-label">* Tipo:</label>
                    <div class="col">
                        <select class="form-control mb-2" 
                                id="tipo" name="tipo">' . $opcionesTipo . '</select>
                    </div>
                    <label for="ambiente" class="col-sm-2 col-form-label">* Ambiente:</label>
                    <div class="col">
                        <select class="form-control mb-2" 
                                id="ambiente" name="ambiente">' . $opcionesAmbiente . '</select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="nombreCorto" class="col-sm-2 col-form-label">* Nombre corto:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreCorto" id="nombreCorto" maxlength="20" 
                               value="' . $nombreCorto . '"
                               placeholder="Nombre corto" required>
                    </div>
                    <label for="nombreLargo" class="col-sm-2 col-form-label">* Nombre largo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreLargo" id="nombreLargo" maxlength="50" 
                               value="' . $nombreLargo . '"
                               placeholder="Nombre largo" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="sitio" class="col-sm-2 col-form-label">* Sitio:</label>
                    <div class="col">' . $opcionSitio . '</div>
                    <label for="dominio" class="col-sm-2 col-form-label">* Dominio:</label>
                    <div class="col">
                        <select class="form-control mb-2" 
                                id="dominio" name="dominio">' . $opcionesDominio . '</select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="softwareBase" class="col-sm-2 col-form-label">Software base:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="softwareBase" id="softwareBase" 
                               maxlength="50" value="' . $softwareBase . '"
                               placeholder="Software base">
                    </div>
                    <label for="marca" class="col-sm-2 col-form-label">Marca:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="marca" id="marca" maxlength="50" 
                               value="' . $marca . '"
                               placeholder="Marca">
                    </div>
                </div>
                <div class="form-row">
                    <label for="modelo" class="col-sm-2 col-form-label">Modelo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="modelo" id="modelo" maxlength="50" 
                               value="' . $modelo . '"
                               placeholder="Modelo">
                    </div>
                    <label for="arquitectura" class="col-sm-2 col-form-label">Arquitectura:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="arquitectura" id="arquitectura" maxlength="50" 
                               value="' . $arquitectura . '"
                               placeholder="Arquitectura">
                    </div>
                </div>
                <div class="form-row">
                    <label for="core" class="col-sm-2 col-form-label">Core:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="core" id="core" maxlength="50" 
                               value="' . $core . '"
                               placeholder="Core">
                    </div>
                    <label for="procesador" class="col-sm-2 col-form-label">Procesador:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="procesador" id="procesador" maxlength="50" 
                               value="' . $procesador . '"
                               placeholder="Procesador">
                    </div>
                </div>
                <div class="form-row">
                    <label for="mhz" class="col-sm-2 col-form-label">Mhz:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="mhz" id="mhz" maxlength="50" 
                               value="' . $mhz . '"
                               placeholder="Mhz">
                    </div>
                    <label for="memoria" class="col-sm-2 col-form-label">Memoria:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="memoria" id="memoria" maxlength="50" 
                               value="' . $memoria . '"
                               placeholder="Memoria">
                    </div>
                </div>
                <div class="form-row">
                    <label for="disco" class="col-sm-2 col-form-label">Disco:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="disco" id="disco" maxlength="50" 
                               value="' . $disco . '"
                               placeholder="Disco">
                    </div>
                    <label for="raid" class="col-sm-2 col-form-label">Raid:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="raid" id="raid" maxlength="50" 
                               value="' . $raid . '"
                               placeholder="Raid">
                    </div>
                </div>
                <div class="form-row">
                    <label for="disco" class="col-sm-2 col-form-label">Red:</label>
                    <div class="col">
                        <input type="number" class="form-control mb-2" 
                               name="red" id="red" min="1" 
                               value="' . $red . '"
                               placeholder="Red">
                    </div>
                    <label for="estado" class="col-sm-2 col-form-label">* Estado:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="estado" name="estado">' . $opcionesEstado . '</select>
                    </div>
                </div>
                <div class="form-row mb-2">
                    <label for="proveedores" class="col-sm-2 col-form-label">* Proveedores:</label>
                    <div class="col">' . $opcionProveedor . '</div>
                </div>
                <div class="form-row">
                    <label for="funcion" class="col-sm-2 col-form-label">* Función: </label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  name="funcion" id="funcion" maxlength="300" 
                                  placeholder="Función" required>' . $funcion . '</textarea>
                    </div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label">* Descripción: </label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  name="descripcion" id="descripcion" maxlength="500" 
                                  placeholder="Descripción" required>' . $descripcion . '</textarea>
                    </div>
                </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_HARDWARE; ?> MODIFICAR HARDWARE</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarHardware" name="formModificarHardware" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/hardware_modificar.js"></script>