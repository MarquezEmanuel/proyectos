<?php
require_once './core_autoload.php';

use app\modelo\Constantes;

date_default_timezone_set(Constantes::TIMEZONE);

$fechaHoy = date('Y-m-d');
$filaServidores = "";
for ($indice = 1; $indice <= 6; $indice++) {
    $obligatorio = ($indice == 1) ? "required" : "";
    $servidor = "servidor{$indice}";
    $fechaCreacion = "fechaCreacion{$indice}";
    $filaServidores .= '
        <div class="form-row">
            <div class="col-1 align-middle">
                <input type="checkbox" class="checkboxServidor"
                       value="' . $indice . '" ' . $obligatorio . '
                       id="orden" name="orden[]">
            </div>
            <div class="col">
                <select class="form-control mb-2 hardware" data-width="100%"
                        name="' . $servidor . '" id="' . $servidor . '" 
                        disabled></select>
            </div>
            <div class="col">
                <input type="date" class="form-control mb-2 fecha" 
                       name="' . $fechaCreacion . '" id="' . $fechaCreacion . '"
                       max=' . $fechaHoy . ' disabled
                       placeholder="Fecha de creación">
            </div>
        </div>';
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_BASE; ?> CREAR BASE DE DATOS</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formCrearBase" name="formCrearBase" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombre" id="nombre" 
                               placeholder="Nombre" required>
                    </div>
                    <label for="collation" class="col-sm-2 col-form-label">* Collation:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="collation" id="collation"
                               placeholder="Collation" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="estadoBase" class="col-sm-2 col-form-label">* Estado:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="estadoBase" name="estadoBase">
                            <option value="ONLINE">ONLINE</option>
                            <option value="OFFLINE">OFFLINE</option>
                        </select>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label">* Descripcion:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  id="descripcion" name="descripcion"
                                 rows="5" minlength="10" maxlength="500"
                                  placeholder="Descripcion" required></textarea>
                    </div>
                </div>
                <div class="form-row mt-4 mb-3">
                    <div class="col-2"><p class="font-weight-bold">DATOS DE HARDWARE</p></div>
                    <div class="col-10"><hr></div>
                </div>
                <div class="form-row">
                    <div class="col-1"></div>
                    <div class="col">
                        <label class="col-form-label mb-2">Hardware</label>
                    </div>
                    <div class="col">
                        <label class="col-form-label mb-2">Fecha de creación</label>
                    </div>
                </div>
                <?= $filaServidores; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-success">
                    <?= Constantes::ICON_GUARDAR; ?> GUARDAR
                </button>
                <button type="button" class="btn btn-outline-info"
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/base_crear.js"></script>