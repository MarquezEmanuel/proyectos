<?php
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\Hardware;

AutoCargador::cargarModulos();
session_start();

if ($_POST['idHardware']) {

    $id = $_POST['idHardware'];
    $hardware = new Hardware($id);
    $resultado = $hardware->obtener();
    if ($resultado[0] == 2) {

        $tipo = $hardware->getTipo();
        $nombreCorto = $hardware->getNombreCorto();
        $nombreLargo = $hardware->getNombreLargo();
        $dominio = $hardware->getDominio();
        $softwareBase = $hardware->getSwBase();
        $ambiente = $hardware->getAmbiente();
        $funcion = $hardware->getFuncion();
        $marca = $hardware->getMarca();
        $modelo = $hardware->getModelo();
        $arquitectura = $hardware->getArquitectura();
        $core = $hardware->getCore();
        $procesador = $hardware->getProcesador();
        $mhz = $hardware->getMhz();
        $memoria = $hardware->getMemoria();
        $disco = $hardware->getDisco();
        $raid = $hardware->getRaid();
        $red = $hardware->getRed();
        $rti = $hardware->getRti();
        $estado = $hardware->getEstado();
        $descripcion = $hardware->getDescripcion();
        $fechaCreacion = $hardware->getFechaCreacion();
        $fechaEdicion = $hardware->getFechaEdicion();
        $fechaCreacionFormateada = isset($fechaCreacion) ? date_format($fechaCreacion, 'd/m/Y H:i') : "";
        $fechaEdicionFormateada = isset($fechaEdicion) ? date_format($fechaEdicion, 'd/m/Y H:i') : "";
        $getSitio = $hardware->obtenerSitio();
        $getProveedores = $hardware->obtenerProveedores();

        /* CARGA LOS DATOS DE LA SUCURSAL ASOCIADA AL FIREWALL */

        if ($getSitio[0] == 2) {
            $sitio = $hardware->getSitio();
            $idSitio = $sitio->getId();
            $tipoSitio = $sitio->getTipo();
            $nombreSitio = $sitio->getNombre();
            $estadoSitio = $sitio->getEstado();
            $filaSucursal = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Código:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $idSitio . '"
                               title="Código del sitio"
                               placeholder="Código" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Tipo:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $tipoSitio . '"
                               title="Tipo de sitio"
                               placeholder="Tipo" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreSitio . '"
                               title="Nombre del sitio"
                               placeholder="Nombre" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoSitio . '"
                               title="Estado del sitio"
                               placeholder="Estado" readonly>
                    </div>
                </div>';
        } else {
            $datosSucursal = GeneradorHTML::getAlertaOperacion($getSitio[0], $getSitio[1]);
            $filaSucursal = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosSucursal . '</div>
                </div>';
        }

        /* CARGA LOS DATOS DE LOS PROVEEDORES ASOCIADOS AL FIREWALL */

        if ($getProveedores[0] == 2) {
            $proveedores = $hardware->getProveedores();
            $filas = "";
            foreach ($proveedores as $proveedor) {
                $idProveedor = $proveedor['id'];
                $nombreProveedor = utf8_encode($proveedor['nombre']);
                $telefonoProveedor = $proveedor['telefono'];
                $correoProveedor = $proveedor['correo'];
                $estadoProveedor = $proveedor['estado'];
                $referencia = '#' . str_pad($idProveedor, 6, "0", STR_PAD_LEFT);
                $filas .= "
                    <tr>
                        <td class='align-middle'>{$referencia}</td>
                        <td class='align-middle'>{$nombreProveedor}</td>
                        <td class='align-middle'>{$telefonoProveedor}</td>
                        <td class='align-middle'>{$correoProveedor}</td>
                        <td class='align-middle'>{$estadoProveedor}</td>
                    </tr>";
            }
            $tablaProveedores = '
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" 
                           cellspacing="0" style="width:100%">
                        <thead>
                            <tr>
                                <th>Referencia</th>
                                <th>Nombre</th>
                                <th>Telefono</th>
                                <th>Correo</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>' . $filas . '</tbody>
                    </table>
                </div>';
        } else {
            $tablaProveedores = GeneradorHTML::getAlertaOperacion($getProveedores[0], $getProveedores[1]);
        }

        /* CARGA EL CUERPO DEL FORMULARIO CON LOS DATOS OBTENIDOS */

        $cuerpo = '
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Tipo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $tipo . '"
                           title="Tipo de hardware"
                           placeholder="Tipo" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Nombre corto:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombreCorto . '"
                           title="Nombre corto del hardware"
                           placeholder="Nombre corto" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Nombre largo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombreLargo . '"
                           title="Nombre largo del hardware"
                           placeholder="Nombre largo" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Dominio:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $dominio . '"
                           title="Dominio del hardware"
                           placeholder="Dominio" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Software base:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $softwareBase . '"
                           title="Nombre largo del hardware"
                           placeholder="Nombre largo" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Ambiente:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $ambiente . '"
                           title="Dominio del hardware"
                           placeholder="Dominio" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Marca:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $marca . '"
                           title="Nombre de la marca del hardware"
                           placeholder="Nombre de la marca" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Modelo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $modelo . '"
                           title="Modelo del hardware"
                           placeholder="Modelo" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Arquitectura:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $arquitectura . '"
                           title="Arquitectura del hardware"
                           placeholder="Arquitectura" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Core:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $core . '"
                           title="Core del hardware"
                           placeholder="Core" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Procesador:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $procesador . '"
                           title="Procesador del hardware"
                           placeholder="Procesador" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Mhz:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $mhz . '"
                           title="Mhz del hardware"
                           placeholder="Mhz" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Memoria:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $memoria . '"
                           title="Memoria del hardware"
                           placeholder="Memoria" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Disco:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $disco . '"
                           title="Disco del hardware"
                           placeholder="Disco" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Raid:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $raid . '"
                           title="Raid del hardware"
                           placeholder="Raid" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Red:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $red . '"
                           title="Red del hardware"
                           placeholder="Red" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">RTI:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $rti . '"
                           title="RTI del hardware"
                           placeholder="RTI" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Estado:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $estado . '"
                           title="Estado del hardware"
                           placeholder="Estado" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Función:</label>
                <div class="col">
                    <textarea class="form-control mb-2"
                           title="Función del hardware"
                           placeholder="Función" readonly>' . $funcion . '</textarea>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Descripción:</label>
                <div class="col">
                    <textarea class="form-control mb-2"
                           title="Descripción del hardware"
                           placeholder="Descripción" readonly>' . $descripcion . '</textarea>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Fecha de creación:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value = "' . $fechaCreacionFormateada . '"
                           title="Fecha de creación"
                           placeholder="Fecha de creación" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Fecha de edición:</label>
                <div class="col">
                    <input type="input" class="form-control mb-2" 
                           value="' . $fechaEdicionFormateada . '"
                           title="Fecha de ultima edición"
                           placeholder="Fecha de ultima edición" readonly>
                </div>
            </div>
            <div class="form-row mt-4 mb-3">
                <div class="col-2"><strong><p>SITIO</p></strong></div>
                <div class="col-10"><hr></div>
            </div>
            ' . $filaSucursal . '
            <div class="form-row mt-4 mb-3">
                <div class="col-2"><strong><p>PROVEEDORES</p></strong></div>
                <div class="col-10"><hr></div>
            </div>
            <div class="form-row">
                <div class="col">' . $tablaProveedores . '</div>
            </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_HARDWARE; ?> DETALLE DE HARDWARE</h4>
        </div>
    </div>
    <div class="card border-azul-clasico mt-3">
        <div class="card-header bg-azul-clasico text-white">Información</div>
        <div class="card-body">
            <?= $cuerpo; ?>
        </div>
    </div>
    <div class="form-row mt-2 mb-4">
        <div class="col text-right">
            <button type="button" class="btn btn-outline-info" 
                    onClick="window.location.reload();" >
                <?= Constantes::ICON_REGRESAR; ?> REGRESAR
            </button>
        </div>
    </div>
</div>

