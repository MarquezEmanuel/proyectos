<?php
if (version_compare(phpversion(), '7.1.31', '<')) {
    $carpeta_modelo = dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "modelo";
} else {
    $carpeta_modelo = dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo";
}

require_once ($carpeta_modelo . DIRECTORY_SEPARATOR . "Constantes.php");
require_once ($carpeta_modelo . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\Constantes;
use app\modelo\AutoCargador;

AutoCargador::cargarModulos();

date_default_timezone_set(Constantes::TIMEZONE);
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <title><?= Constantes::APP_NOMBRE_CORTO; ?></title>
        <link rel="icon" href="../../lib/img/logo_bsc_1064x1065.jpg" type="image/gif" sizes="16x16">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Archivos de estilo -->
        <link href="../../lib/cap/cap-admin.min.css" rel="stylesheet">
        <link href="../../lib/cap/cap.css" rel="stylesheet">
        <link href="../../lib/dataTables/dataTables.bootstrap4.min.css" rel="stylesheet">
        <link href="../../lib/dataTables/buttons.dataTables.min.css" rel="stylesheet">
        <link href="../../lib/fontAwesome/css/all.min.css" rel="stylesheet">
        <link href="../../lib/select2/select2.min.css" rel="stylesheet">
        <link href="../../lib/select2/select2.bootstrap.css" rel="stylesheet">
        <!-- Archivos JavaScript -->
        <script src="../../lib/JQuery/jquery.min.js"></script>
        <script src="../../lib/bootstrap/bootstrap.bundle.min.js"></script>
        <script src="../../lib/JQuery/jquery.easing.min.js"></script>
        <script src="../../lib/dataTables/jquery.dataTables.js"></script>
        <script src="../../lib/dataTables/dataTables.bootstrap4.min.js"></script>
        <script src="../../lib/dataTables/dataTables.buttons.js"></script>
        <script src="../../lib/dataTables/jszip.min.js"></script>
        <script src="../../lib/dataTables/pdfmake.min.js"></script>
        <script src="../../lib/dataTables/buttons.flash.min.js"></script>
        <script src="../../lib/dataTables/buttons.html5.min.js"></script>
        <script src="../../lib/dataTables/buttons.print.min.js"></script>
        <script src="../../lib/fontAwesome/js/all.min.js"></script>
        <script src="../../lib/select2/select2.min.js"></script>
        <script src="../../lib/cap/menuLateral.js"></script>
        <script src="../../lib/googleCharts/loader.js"></script>
    </head>
    <body>
        <nav class="navbar navbar-expand navbar-dark bg-azul-clasico static-top">
            <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
                <i class="fas fa-bars fa-lg"></i>
            </button>
            <a class="navbar-brand mr-1" href="core_home.php">
<?= Constantes::APP_NOMBRE_CORTO; ?> - <?= Constantes::BSC_NOMBRE_LARGO ?>
            </a>
            <!-- Navbar -->
            <ul class="navbar-nav d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
                <li class="nav-item dropdown no-arrow">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user-circle fa-lg"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                        <a class="dropdown-item" href="core_manual_suario.php">
                            <i class="fas fa-file-pdf"></i> Manual de usuario
                        </a>
                        <a class="dropdown-item" href="core_salir.php">
                            <i class="fas fa-sign-out-alt"></i> Salir
                        </a>
                    </div>
                </li>
            </ul>
        </nav>
        <div id="wrapper">
            <ul class="sidebar navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Actividades</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_actividad_buscar_log.php"
                           title="' . $descripcionSubmenu . '">Buscar actividad</a>
                        <a class="dropdown-item" 
                           href="page_actividad_buscar_archivo.php"
                           title="' . $descripcionSubmenu . '">Buscar archivo</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Aplicacion</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_aplicacion_buscar_cgti.php"
                           title="' . $descripcionSubmenu . '">Buscar cgti</a>
                        <a class="dropdown-item" 
                           href="page_aplicacion_buscar_ryt.php"
                           title="' . $descripcionSubmenu . '">Buscar ryt</a>
                        <a class="dropdown-item" 
                           href="page_aplicacion_buscar_sistemas.php"
                           title="' . $descripcionSubmenu . '">Buscar sistemas</a>
                        <a class="dropdown-item" 
                           href="page_aplicacion_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar</a>
                        <a class="dropdown-item" 
                           href="page_aplicacion_panel_reporte.php"
                           title="' . $descripcionSubmenu . '">Panel</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Auxiliar</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_auxiliar_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                        <a class="dropdown-item" 
                           href="page_auxiliar_buscar_cgti.php"
                           title="' . $descripcionSubmenu . '">Buscar cgti</a>
                        <a class="dropdown-item" 
                           href="page_auxiliar_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar</a>
                        <a class="dropdown-item" 
                           href="page_auxiliar_panel_reporte.php"
                           title="' . $descripcionSubmenu . '">Panel</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Bases de datos</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_base_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                        <a class="dropdown-item" 
                           href="page_base_buscar_cgti.php"
                           title="' . $descripcionSubmenu . '">Buscar cgti</a>
                        <a class="dropdown-item" 
                           href="page_base_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar</a>
                        <a class="dropdown-item" 
                           href="page_base_panel_reporte.php"
                           title="' . $descripcionSubmenu . '">Panel</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Comunicacion</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_comunicacion_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                        <a class="dropdown-item" 
                           href="page_comunicacion_buscar_cgti.php"
                           title="' . $descripcionSubmenu . '">Buscar cgti</a>
                        <a class="dropdown-item" 
                           href="page_comunicacion_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar</a>
                        <a class="dropdown-item" 
                           href="page_comunicacion_panel_reporte.php"
                           title="' . $descripcionSubmenu . '">Panel</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Firewall</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_firewall_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                        <a class="dropdown-item" 
                           href="page_firewall_buscar_cgti.php"
                           title="' . $descripcionSubmenu . '">Buscar cgti</a>
                        <a class="dropdown-item" 
                           href="page_firewall_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar</a>
                        <a class="dropdown-item" 
                           href="page_firewall_panel_reporte.php"
                           title="' . $descripcionSubmenu . '">Panel</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Gerencias</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_departamento_buscar.php"
                           title="' . $descripcionSubmenu . '">Departamento</a>
                        <a class="dropdown-item" 
                           href="page_empleado_buscar.php"
                           title="' . $descripcionSubmenu . '">Empleado</a>
                        <a class="dropdown-item" 
                           href="page_gerencia_buscar.php"
                           title="' . $descripcionSubmenu . '">Gerencia</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Hardware</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_hardware_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                        <a class="dropdown-item" 
                           href="page_hardware_buscar_cgti.php"
                           title="' . $descripcionSubmenu . '">Buscar cgti</a>
                        <a class="dropdown-item" 
                           href="page_hardware_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar</a>
                        <a class="dropdown-item" 
                           href="page_hardware_panel_reporte.php"
                           title="' . $descripcionSubmenu . '">Panel</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Herramienta</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_herramienta_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                        <a class="dropdown-item" 
                           href="page_herramienta_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Instalacion</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_instalacion_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                        <a class="dropdown-item" 
                           href="page_instalacion_buscar_cgti.php"
                           title="' . $descripcionSubmenu . '">Buscar cgti</a>
                        <a class="dropdown-item" 
                           href="page_instalacion_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar</a>
                        <a class="dropdown-item" 
                           href="page_instalacion_panel_reporte.php"
                           title="' . $descripcionSubmenu . '">Panel</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Lenguaje</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_lenguaje_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                        <a class="dropdown-item" 
                           href="page_lenguaje_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Personal</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_personal_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                        <a class="dropdown-item" 
                           href="page_personal_buscar_cgti.php"
                           title="' . $descripcionSubmenu . '">Buscar cgti</a>
                        <a class="dropdown-item" 
                           href="page_personal_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar</a>
                        <a class="dropdown-item" 
                           href="page_personal_panel_reporte.php"
                           title="' . $descripcionSubmenu . '">Panel</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Plataforma</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_plataforma_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Procesamiento</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_lugar_buscar.php"
                           title="' . $descripcionSubmenu . '">Lugar</a>
                        <a class="dropdown-item" 
                           href="page_modo_buscar.php"
                           title="' . $descripcionSubmenu . '">Modo</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Proveedor</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_proveedor_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar proveedor</a>
                        <a class="dropdown-item" 
                           href="page_proveedor_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar proveedor</a>
                        <a class="dropdown-item" 
                           href="page_responsable_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar contacto</a>
                        <a class="dropdown-item" 
                           href="page_responsable_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar contacto</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Servicios</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_servicio_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Servidores</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_servidor_buscar_servidor.php"
                           title="">Servidor</a>
                        <a class="dropdown-item" 
                           href="page_servidor_buscar_base.php"
                           title="">Base de datos</a>
                        <a class="dropdown-item" 
                           href="page_servidor_buscar_vista.php"
                           title="">Vistas</a>
                        <a class="dropdown-item" 
                           href="page_servidor_buscar_tabla.php"
                           title="">Tablas</a>
                        <a class="dropdown-item" 
                           href="page_servidor_buscar_job.php"
                           title="">Jobs</a>
                        <a class="dropdown-item" 
                           href="page_servidor_buscar_columna.php"
                           title="">Campos</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Sitios</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_sitio_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" 
                       id="pagesDropdown" role="button" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"
                       title="' . $descripcionMenu . '">
                        <span>Switch</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                        <a class="dropdown-item" 
                           href="page_switch_buscar.php"
                           title="' . $descripcionSubmenu . '">Buscar</a>
                        <a class="dropdown-item" 
                           href="page_switch_buscar_cgti.php"
                           title="' . $descripcionSubmenu . '">Buscar cgti</a>
                        <a class="dropdown-item" 
                           href="page_switch_consultar.php"
                           title="' . $descripcionSubmenu . '">Consultar</a>
                        <a class="dropdown-item" 
                           href="page_switch_"
                           title="' . $descripcionSubmenu . '">Panel</a>
                    </div>
                </li>
            </ul>