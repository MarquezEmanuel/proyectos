<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
use app\modelo\ModoProcesamiento;
use app\modelo\GeneradorHTML;

$boton = "";
if ($_POST['idModo']) {
    $id = $_POST['idModo'];
    $modo = new ModoProcesamiento($id);
    $resultado = $modo->obtener();
    if ($resultado[0] == 2) {
        $nombre = $modo->getNombre();
        $estado = $modo->getEstado();

        if ($estado == 'Activo') {
            $opcionesEstado = '<option value="Activo" selected>Activo</option>';
            $opcionesEstado .= '<option value="Inactivo">Inactivo</option>';
        } else {
            $opcionesEstado = '<option value="Activo">Activo</option>';
            $opcionesEstado .= '<option value="Inactivo" selected>Inactivo</option>';
        }

        $cuerpo = '
            <input type="hidden" name="idModo" id="idModo" value="' . $id . '">
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombre" id="nombre" maxlength="50" minlength="3"
                           value="' . $nombre . '"
                           placeholder="Nombre" required>
                </div>
                <label for="nombreCorto" class="col-sm-2 col-form-label">* Estado:</label>
                <div class="col">
                    <select class="form-control mb-2" id="estado" name="estado">' . $opcionesEstado . '</select>
                </div>
            </div>';
        $boton = '<button type="submit" class="btn btn-success" 
                          id="btnModificarModo" disabled>
                        <i class="far fa-save"></i> GUARDAR</button>';
    } else {
        $codigo = $resultado[0];
        $mensaje = $resultado[1];
        $cuerpo = GeneradorHTML::getAlertaOperacion($codigo, $mensaje);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_MODOPR; ?> MODIFICAR MODO PROCESAMIENTO</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarModo" name="formModificarModo" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/modo_procesamiento_modificar.js"></script>