<?php

function getDirectorio($path, $count = 1) {
    if (version_compare(phpversion(), '7.1.31', '<')) {
        return ($count > 1) ? dirname(getDirectorio($path, --$count)) : dirname($path);
    } else {
        return dirname($path, $count);
    }
}

require_once (getDirectorio(__FILE__, 3) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (getDirectorio(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;

AutoCargador::cargarModulos();

session_start();
