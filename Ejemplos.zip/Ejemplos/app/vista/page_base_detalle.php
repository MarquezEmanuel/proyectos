<?php
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\GeneradorHTML;
use app\modelo\BaseDatosManual;

AutoCargador::cargarModulos();
session_start();

if ($_POST['idBase']) {

    $id = $_POST['idBase'];
    $baseDatos = new BaseDatosManual($id);
    $resultado = $baseDatos->obtener();
    if ($resultado[0] == 2) {

        $nombre = $baseDatos->getNombre();
        $collation = $baseDatos->getCollation();
        $estadoBase = $baseDatos->getEstadoBase();
        $rti = $baseDatos->getRti();
        $estado = $baseDatos->getEstado();
        $descripcion = $baseDatos->getDescripcion();
        $fechaCreacion = $baseDatos->getFechaCreacion();
        $fechaEdicion = $baseDatos->getFechaEdicion();
        $fechaCreacionFormateada = isset($fechaCreacion) ? date_format($fechaCreacion, 'd/m/Y H:i') : "";
        $fechaEdicionFormateada = isset($fechaEdicion) ? date_format($fechaEdicion, 'd/m/Y H:i') : "";
        $getServidores = $baseDatos->obtenerServidores();

        /* CARGA LOS DATOS DE LOS HARDWARES ASOCIADOS A LA BASE DE DATOS */

        if ($getServidores[0] == 2) {
            $hardwares = $baseDatos->getServidores();
            $filas = "";
            foreach ($hardwares as $hardware) {
                $idHardware = $hardware['id'];
                $tipoHardware = utf8_encode($hardware['tipo']);
                $nombreCortoHardware = utf8_encode($hardware['nombreCorto']);
                $nombreLargoHardware = utf8_encode($hardware['nombreLargo']);
                $ambienteHardware = utf8_encode($hardware['ambiente']);
                $estadoHardware = $hardware['estado'];
                $referencia = '#' . str_pad($idHardware, 6, "0", STR_PAD_LEFT);
                $filas .= "
                    <tr>
                        <td class='align-middle'>{$referencia}</td>
                        <td class='align-middle'>{$tipoHardware}</td>
                        <td class='align-middle'>{$nombreCortoHardware}</td>
                        <td class='align-middle'>{$nombreLargoHardware}</td>
                        <td class='align-middle'>{$ambienteHardware}</td>
                        <td class='align-middle'>{$estadoHardware}</td>
                    </tr>";
            }
            $tablaServidores = '
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" 
                           cellspacing="0" style="width:100%">
                        <thead>
                            <tr>
                                <th>Referencia</th>
                                <th>Tipo</th>
                                <th>Nombre corto</th>
                                <th>Nombre largo</th>
                                <th>Ambiente</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>' . $filas . '</tbody>
                    </table>
                </div>';
        } else {
            $tablaServidores = GeneradorHTML::getAlertaOperacion($getServidores[0], $getServidores[1]);
        }

        /* CARGA EL CUERPO DEL FORMULARIO CON LOS DATOS OBTENIDOS */
        $cuerpo = '
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Nombre:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombre . '"
                           placeholder="Nombre" readonly>
                </div>
                <label for="marca" class="col-sm-2 col-form-label">Collation:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $collation . '"
                           placeholder="Collation" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Estado base:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $estadoBase . '"
                           placeholder="Estado de base de datos" readonly>
                </div>
                <label class="col-sm-2 col-form-label">RTI:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $rti . '"
                           placeholder="RTI" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Estado del registro:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $estado . '"
                           placeholder="Estado" readonly>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col"></div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Descripcion:</label>
                <div class="col">
                    <textarea class="form-control mb-2"
                              placeholder="Descripción" readonly>' . $descripcion . '</textarea>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Fecha de creación:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value = "' . $fechaCreacionFormateada . '"
                           placeholder="Fecha de creación" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Fecha de edición:</label>
                <div class="col">
                    <input type="input" class="form-control mb-2" 
                           value="' . $fechaEdicionFormateada . '"
                           placeholder="Fecha de ultima edición" readonly>
                </div>
            </div>
            <div class="form-row mt-4 mb-3">
                <div class="col-2"><strong><p>HARDWARES</p></strong></div>
                <div class="col-10"><hr></div>
            </div>
            <div class="form-row">
                <div class="col">' . $tablaServidores . '</div>
            </div>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_BASE; ?> DETALLE DE BASE DE DATOS</h4>
        </div>
    </div>
    <div class="card border-azul-clasico mt-3">
        <div class="card-header bg-azul-clasico text-white">Información</div>
        <div class="card-body">
            <?= $cuerpo; ?>
        </div>
    </div>
    <div class="form-row mt-2 mb-4">
        <div class="col text-right">
            <button type="button" class="btn btn-outline-info" 
                    onClick="window.location.reload();" >
                <?= Constantes::ICON_REGRESAR; ?> REGRESAR
            </button>
        </div>
    </div>
</div>