<?php
require_once (dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "inc_config.php");
require_once (dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . "modelo" . DIRECTORY_SEPARATOR . "AutoCargador.php");

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\Servicio;
use app\modelo\GeneradorHTML;

AutoCargador::cargarModulos();

$cuerpo = $boton = "";
if (isset($_POST['idServicio'])) {
    $id = $_POST['idServicio'];
    $servicio = new Servicio($id);
    $resultado = $servicio->obtener();
    if ($resultado[0] == 2) {
        $nombreCorto = $servicio->getNombreCorto();
        $nombreLargo = $servicio->getNombreLargo();
        $estado = $servicio->getEstado();
        $descripcion = $servicio->getDescripcion();

        if ($estado == 'Activo') {
            $opcionesEstado = '<option value="Activo" selected>Activo</option>';
            $opcionesEstado .= '<option value="Inactivo">Inactivo</option>';
        } else {
            $opcionesEstado = '<option value="Activo">Activo</option>';
            $opcionesEstado .= '<option value="Inactivo" selected>Inactivo</option>';
        }
        $cuerpo = '
            <input type="hidden" name="idServicio" id="idServicio" value="' . $id . '">
            <div class="form-row">
                <label for="nombreCorto" class="col-sm-2 col-form-label">* Nombre corto:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombreCorto" id="nombreCorto" 
                           maxlength="20"
                           value="' . $nombreCorto . '"
                           placeholder="Nombre corto para el servicio">
                </div>
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre largo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombreLargo" id="nombreLargo" 
                           maxlength="50"
                           value="' . $nombreLargo . '"
                           placeholder="Nombre del servicio">
                </div>
            </div>
            <div class="form-row">
                <label for="nombreCorto" class="col-sm-2 col-form-label">* Estado:</label>
                <div class="col">
                    <select class="form-control mb-2" id="estado" name="estado">' . $opcionesEstado . '</select>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col"></div>
            </div>
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label">* Descripción:</label>
                <div class="col">
                    <textarea class="form-control" maxlength="500"
                              name="descripcion" id="descripcion">' . $descripcion . '</textarea>
                </div>
            </div>';
        $boton = '
            <button type="submit" class="btn btn-success" 
                    id="btnModificarServicio" disabled>
                    ' . Constantes::ICON_GUARDAR . ' GUARDAR</button>';
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_SERVICIO; ?> MODIFICAR SERVICIO</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <div id="seccionCentral">
        <form id="formModificarServicio" name="formModificarServicio" method="POST">
            <div class="card border-azul-clasico">
                <div class="card-header text-left bg-azul-clasico text-white">Formulario de modificación</div>
                <div class="card-body">
                    <?= $cuerpo; ?>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <?= $boton; ?>
                    <button type="button" class="btn btn-outline-info" 
                            onclick="window.location.reload()">
                        <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="./js/servicio_modificar.js"></script>