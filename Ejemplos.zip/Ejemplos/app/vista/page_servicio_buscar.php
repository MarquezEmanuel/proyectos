<?php
require_once './core_header.php';

use app\modelo\Constantes;
?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row ">
                <div class="col text-left">
                    <h4><?= Constantes::ICON_MOD_SERVICIO; ?> BUSCAR SERVICIO</h4>
                </div>
            </div>
            <div id="seccionCentral" class="mt-3 mb-4">
                <form id="formBuscarServicio" name="formBuscarServicio" method="POST">
                    <input type="hidden" name="peticion" id="peticion">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="nombreCorto" 
                                       title="<?= Constantes::HTML_TITLE_LABEL_NO_REQUIRED; ?>" 
                                       class="col-2 col-form-label">Nombre corto:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreCorto" id="nombreCorto" 
                                           title="Nombre corto del servicio"
                                           maxlength="20"
                                           placeholder="Nombre corto">
                                </div>
                                <label for="nombreLargo" 
                                       title="<?= Constantes::HTML_TITLE_LABEL_NO_REQUIRED; ?>" 
                                       class="col-2 col-form-label">Nombre largo:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreLargo" id="nombreLargo" 
                                           title="Nombre largo del servicio"
                                           maxlength="50"
                                           placeholder="Nombre largo">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="descripcion" 
                                       title="<?= Constantes::HTML_TITLE_LABEL_NO_REQUIRED; ?>" 
                                       class="col-2 col-form-label">Descripción:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="descripcion" id="descripcion" 
                                           title="Descripción del servicio"
                                           maxlength="30"
                                           placeholder="Decripción">
                                </div>
                                <label for="estado" title="<?= Constantes::HTML_TITLE_LABEL_REQUIRED; ?>" class="col-2 col-form-label">* Estado:</label>
                                <div class="col">
                                    <select id="estado" name="estado" class="form-control mb-2" required>
                                        <option value="Activo">Activo</option>
                                        <option value="Inactivo">Inactivo</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success" 
                                    id="btnBuscarServicio" name="btnBuscarServicio">
                                <?= Constantes::ICON_BUSCAR; ?>  BUSCAR
                            </button>
                            <button type="button" class="btn btn-outline-info" 
                                    id="btnCrearServicio" name="btnCrearServicio">
                                <?= Constantes::ICON_AGREGAR; ?> CREAR
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div id="seccionInferior" class="mt-4 mb-3"></div>
        </div>
    </div>
</div>
<script type="text/javascript" src="./js/servicio_buscar.js"></script>
