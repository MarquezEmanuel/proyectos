<?php
require_once './core_autoload.php';

use app\modelo\Constantes;
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mb-3">
        <div class="col text-left">
            <h4><?= Constantes::ICON_MOD_SWITCH; ?> CREAR SWITCH</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formCrearSwitch" name="formCrearSwitch" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombre" id="nombre" maxlength="50"
                               placeholder="Nombre" required>
                    </div>
                    <label for="modelo" class="col-sm-2 col-form-label">* Modelo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="modelo" id="modelo" maxlength="50" 
                               placeholder="Modelo" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="version" class="col-sm-2 col-form-label">* Versión:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="version" id="version" maxlength="50"
                               placeholder="IOS Versión" required>
                    </div>
                    <label for="instalacion" class="col-sm-2 col-form-label">* Instalación:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="instalacion" id="instalacion" data-width='100%' required></select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="sitio" class="col-sm-2 col-form-label">* Sitio:</label>
                    <div class="col">
                        <select class="form-control mb-2" name="sitio" id="sitio" data-width='100%' required></select>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>
                <div class="form-row">
                    <label for="proveedores" class="col-sm-2 col-form-label">* Proveedores:</label>
                    <div class="col">
                        <select class="form-control mb-2" multiple="multiple" data-width='100%' 
                                id="proveedores" name="proveedores[]" required></select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label">* Descripcion:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  id="descripcion" name="descripcion"
                                  rows="5" minlength="10" maxlength="500"
                                  placeholder="Descripcion" required></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-success">
                    <?= Constantes::ICON_GUARDAR; ?> GUARDAR
                </button>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <?= Constantes::ICON_BUSCAR; ?> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="./js/switch_crear.js"></script>