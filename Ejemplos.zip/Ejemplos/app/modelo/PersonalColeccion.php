<?php

namespace app\modelo;

use app\modelo\SQLServer;

class PersonalColeccion {

    public static function buscar($nombrePersonal, $nombreDepartamento, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM vwper_personal WHERE nombreLargoPersonal LIKE ? AND "
                    . "nombreDepartamento LIKE ? AND estadoPersonal = ?";
            $datos = array("%{$nombrePersonal}%", "%{$nombreDepartamento}%", $estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar personales");
    }

    private static function buscarDatosInforme($idInforme) {
        $consulta = "SELECT detalle, total FROM vwper_informes WHERE id = ? ORDER BY detalle";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$idInforme));
        if ($resultado[0] == 2) {
            $datos = array();
            while ($registro = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $datos[] = array('detalle' => $registro['detalle'], 'total' => $registro['total']);
            }
            return $datos;
        }
        return NULL;
    }

    public static function buscarInformesPersonal() {
        $consulta = "SELECT DISTINCT id, informe, COUNT(*) distribucion "
                . " FROM vwper_informes GROUP BY id, informe ORDER BY id";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        if ($resultado[0] == 2) {
            $informes = array();
            while ($informe = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $datos = PersonalColeccion::buscarDatosInforme($informe['id']);
                $informes[] = array($informe['id'], $informe['informe'], $informe['distribucion'], $datos);
            }
            return array(2, $informes);
        }
        return $resultado;
    }

    public static function buscarUltimosCreados($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM vwper_personal "
                    . "WHERE estadoPersonal = ? "
                    . "ORDER BY fechaCreacionPersonal DESC";
            return SQLServer::instancia()->seleccionar($consulta, array(&$top, &$estado));
        }
        return array(0, "No se recibieron los campos obligatorios para consultar personales");
    }

}
