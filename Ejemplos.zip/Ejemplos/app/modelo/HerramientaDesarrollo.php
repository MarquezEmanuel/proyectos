<?php

namespace app\modelo;

use app\modelo\SQLServer;
use app\modelo\ProveedorColeccion as Proveedores;

/**
 * Mapea con la tabla de herramientas.
 * 
 * @package app\plataforma\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class HerramientaDesarrollo {

    /** @var int Identificador de la herramienta de desarrollo [BIGINT] */
    private $id;

    /** @var string Nombre [NVARCHAR(50) NOT NULL] */
    private $nombre;

    /** @var string Version [NVARCHAR(20) NOT NULL] */
    private $version;

    /** @var string Nombre del fabricante [NVARCHAR(50) NOT NULL] */
    private $fabricante;

    /** @var string Fecha de caducidad de licencia [SMALLDATETIME NULL] */
    private $fechaCaducidad;

    /** @var string Descripcion [NVARCHAR(100) NOT NULL] */
    private $descripcion;

    /** @var string Estado [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var array Proveedores asociados a la herramienta */
    private $proveedores;

    /** @var string Fecha de creacion [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de ultima edicion del registro [SMALLDATETIME NOT NULL] */
    private $fechaEdicion;

    public function __construct($id = NULL, $nombre = NULL, $version = NULL, $fabricante = NULL, $fechaCaducidad = NULL, $descripcion = NULL, $proveedores = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setVersion($version);
        $this->setFabricante($fabricante);
        $this->setFechaCaducidad($fechaCaducidad);
        $this->setDescripcion($descripcion);
        $this->setProveedores($proveedores);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getVersion() {
        return utf8_encode($this->version);
    }

    public function getFabricante() {
        return utf8_encode($this->fabricante);
    }

    public function getFechaCaducidad() {
        return $this->fechaCaducidad;
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getProveedores() {
        return $this->proveedores;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setNombre($nombre) {
        if ($nombre && (strlen($nombre) <= 50)) {
            $this->nombre = utf8_decode($nombre);
        }
    }

    public function setVersion($version) {
        if ($version && (strlen($version) <= 20)) {
            $this->version = utf8_decode($version);
        }
    }

    public function setFabricante($fabricante) {
        if ($fabricante && (strlen($fabricante) <= 50)) {
            $this->fabricante = utf8_decode($fabricante);
        }
    }

    public function setFechaCaducidad($fechaCaducidad) {
        $this->fechaCaducidad = ($fechaCaducidad) ? $fechaCaducidad : NULL;
    }

    public function setDescripcion($descripcion) {
        if ($descripcion && (strlen($descripcion) <= 300)) {
            $this->descripcion = utf8_decode($descripcion);
        }
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setProveedores($proveedores) {
        $this->proveedores = $proveedores;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function crear() {
        if ($this->nombre && $this->version && $this->fabricante && $this->descripcion && $this->proveedores) {
            $consulta = "INSERT INTO her_herramienta OUTPUT INSERTED.id VALUES (?, ?, ?, ?, ?, 'Activa', GETDATE(), NULL)";
            $datos = array(&$this->nombre, &$this->version, &$this->fabricante, &$this->fechaCaducidad, &$this->descripcion);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            $this->id = ($resultado[0] == 2) ? $resultado[2] : NULL;
            if ($resultado[0] == 2) {
                $this->id = $resultado[2];
                $rservicios = HerramientaDesarrolloProveedor::crear($this->id, $this->proveedores);
                $resultado = ($rservicios[0] == 2) ? $resultado : $rservicios;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear la herramienta de desarrollo");
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->version && $this->fabricante && $this->descripcion && $this->proveedores) {
            $consulta = "UPDATE her_herramienta SET nombre=?, version=?, fabricante=?, "
                    . "descripcion=?, estado=?, fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->nombre, &$this->version, &$this->fabricante, &$this->descripcion, &$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            if ($resultado[0] == 2) {
                $actualizar = HerramientaDesarrolloProveedor::actualizarProveedoresHerramienta($this->id, $this->proveedores);
                $resultado = ($actualizar[0] == 2) ? $resultado : $actualizar;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para modificar la herramienta de desarrollo");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM her_herramienta WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->version = $fila['version'];
                $this->fabricante = $fila['fabricante'];
                $this->fechaCaducidad = $fila['fechaCaducidad'];
                $this->descripcion = $fila['descripcion'];
                $this->estado = $fila['estado'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la informacion correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la herramienta de desarrollo");
    }

    public function obtenerProveedores() {
        $this->proveedores = NULL;
        $resultado = Proveedores::buscarProveedoresHerramienta($this->id);
        if ($resultado[0] == 2) {
            $proveedores = $resultado[1];
            while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
                $this->proveedores[] = $proveedor;
            }
            $resultado[1] = ($this->proveedores) ? NULL : $resultado[1];
        }
        return $resultado;
    }

    public function toString() {
        $herramienta = ($this->id) ? "{{$this->getId()}," : "{0,";
        $herramienta .= ($this->nombre) ? "'{$this->getNombre()}'," : "'',";
        $herramienta .= ($this->version) ? "'{$this->getVersion()}'," : "'',";
        $herramienta .= ($this->fabricante) ? "'{$this->getFabricante()}'," : "'',";
        $herramienta .= ($this->fechaCaducidad) ? "'{$this->fechaCaducidad}'," : "'',";
        $herramienta .= ($this->estado) ? "'{$this->getEstado()}'}" : "''}";
        return $herramienta;
    }

}
