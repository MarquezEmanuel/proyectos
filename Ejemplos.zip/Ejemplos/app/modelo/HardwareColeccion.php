<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla de hardwares y con la vista asociada.
 * 
 * @package app\hardware\modelo.
 * 
 * @uses vwhar_hardware Vista de activos hardware.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 * 
 * @version 1.1
 */
class HardwareColeccion {

    public static function buscar($tipo, $nombreLargo, $ambiente, $nombreSitio, $dominio, $estado) {
        $consulta = "SELECT * FROM vwhar_hardware WHERE tipoHardware LIKE ? "
                . " AND nombreLargoHardware LIKE ? "
                . " AND ambienteHardware LIKE ? "
                . " AND nombreSitio LIKE ? "
                . " AND dominioHardware LIKE ? "
                . " AND estadoHardware = ?";
        $datos = array("%{$tipo}%", "%{$nombreLargo}%", "%{$ambiente}%", "%{$nombreSitio}%", "%{$dominio}%", &$estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    private static function buscarDatosInforme($idInforme) {
        $consulta = "SELECT detalle, total FROM vwhar_informes WHERE id = ? ORDER BY detalle";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$idInforme));
        if ($resultado[0] == 2) {
            $datos = array();
            while ($registro = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $datos[] = array('detalle' => $registro['detalle'], 'total' => $registro['total']);
            }
            return $datos;
        }
        return NULL;
    }

    public static function buscarInformesHardware() {
        $consulta = "SELECT DISTINCT id, informe, COUNT(*) distribucion "
                . " FROM vwhar_informes GROUP BY id, informe ORDER BY id";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        if ($resultado[0] == 2) {
            $informes = array();
            while ($informe = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $datos = HardwareColeccion::buscarDatosInforme($informe['id']);
                $informes[] = array($informe['id'], $informe['informe'], $informe['distribucion'], $datos);
            }
            return array(2, $informes);
        }
        return $resultado;
    }

    /**
     * Buscar elementos de hardware en estado activo a partir de su nombre largo. 
     * De la consulta se obtiene el id, tipo y nombre largo. El objetivo del metodo 
     * es obtener los datos necesarios para seleccionar y relacionar.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombreLargo Nombre o parte del nombre del hardware (LIKE).
     * @return array Arreglo de dos posiciones (codigo, datos o mensaje).
     */
    public static function buscarParaSeleccionar($nombreLargo) {
        $consulta = "SELECT id, tipo, nombreLargo FROM har_hardware "
                . "WHERE nombreLargo LIKE ? AND estado = 'Activo'"
                . "ORDER BY tipo, nombreLargo";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombreLargo}%"));
    }

    /**
     * Lista los hardwares (Servidores) asociados a una aplicacion.
     * @see SQLServer::instancia()->seleccionar
     * @param int $idAplicacion Identificador de la aplicacion.
     * @return array Arreglo de dos posiciones (codigo, mensaje).
     */
    public static function buscarHardwaresAplicacion($idAplicacion) {
        if ($idAplicacion > 0) {
            $consulta = "SELECT har.*, apl.ruta FROM apl_despliegue apl "
                    . "INNER JOIN har_hardware har on har.id = apl.idHardware "
                    . "WHERE apl.idAplicacion = ? ORDER BY har.ambiente, har.nombreLargo";
            return SQLServer::instancia()->seleccionar($consulta, array(&$idAplicacion));
        }
        return array(0, "No se pudo hacer referencia a la aplicación");
    }

    /**
     * Lista los hardwares (Servidores) asociados a una base de datos cargada de
     * forma manual.
     * @see SQLServer::instancia()->seleccionar
     * @param int $idBaseDatosManual Identificador del proveedor.
     * @return array Arreglo de dos posiciones (codigo, mensaje).
     */
    public static function buscarHardwaresBaseDatosManual($idBaseDatosManual) {
        if ($idBaseDatosManual > 0) {
            $consulta = "SELECT hardware.*,relacion.orden, relacion.fechaCreacionBase "
                    . " FROM bas_base_hardware relacion "
                    . " INNER JOIN har_hardware hardware ON hardware.id = relacion.idHardware "
                    . " WHERE relacion.idBaseDatosManual = ? "
                    . " ORDER BY relacion.orden ASC ";
            return SQLServer::instancia()->seleccionar($consulta, array(&$idBaseDatosManual));
        }
        return array(0, "No se pudo hacer referencia a la base de datos");
    }

    public static function buscarUltimosCreados($top, $estado) {
        $consulta = "SELECT TOP(?) * FROM vwhar_hardware "
                . " WHERE estadoHardware = ? "
                . " ORDER BY fechaCreacionHardware DESC";
        return SQLServer::instancia()->seleccionar($consulta, array(&$top, &$estado));
    }

}
