<?php

namespace app\modelo;

/**
 * Contiene las constantes que se actualizan con cada pase del sistema.
 * 
 * @package app\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ConstantesVersion {

    const APP_FECHA_CREACION = '01/02/2020';
    const APP_FECHA_EDICION = '11/08/2020';
    const APP_VERSION = '1.0.1';

}
