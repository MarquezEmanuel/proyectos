<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla que relaciona switchs con proveedores.
 * 
 * @package app\switchs\modelo.
 * 
 * @uses swi_switch_proveedor Tabla relacion de switch con proveedor.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 * 
 * @version 1.0
 * 
 */
class SwitchProveedor {

    /**
     * Realiza la eliminacion de los proveedores asociados al activo switch y luego 
     * la creacion de los nuevos proveedores asociados.
     * @param int $idSwitch Identificador del activo.
     * @param array $proveedores Arreglo con los identificadores de los proveedores.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function actualizarProveedoresSwitch($idSwitch, $proveedores) {
        $resultado = SwitchProveedor::borrar($idSwitch);
        if ($resultado[0] == 2) {
            $resultado = SwitchProveedor::crear($idSwitch, $proveedores);
        }
        return $resultado;
    }

    /**
     * Elimina todos los proveedores asociados al switch.
     * @see SQLServer::$instancia->borrar
     * @param int $idSwitch Identificador del switch.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function borrar($idSwitch) {
        if ($idSwitch > 0) {
            $consulta = "DELETE FROM swi_switch_proveedor WHERE idSwitch = ?";
            return SQLServer::$instancia->borrar($consulta, array(&$idSwitch));
        }
        return array(0, "No se pudo hacer referencia al switch");
    }

    /**
     * Crea todas las relaciones de un switch con sus proveedores.
     * @see SQLServer::instancia()->insertar
     * @param int $idSwitch Identificador del switch.
     * @param array $proveedores Arreglo con los identificadores de los proveedores.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function crear($idSwitch, $proveedores) {
        if (($idSwitch > 0) && !empty($proveedores)) {
            $registros = "";
            for ($index = 0; $index < count($proveedores); $index++) {
                $registros .= "({$idSwitch}, ?),";
            }
            $consulta = "INSERT INTO swi_switch_proveedor VALUES " . substr($registros, 0, -1);
            return SQLServer::instancia()->insertar($consulta, $proveedores);
        }
        return array(0, "No se recibieron los campos obligatorios para relacionar proveedores");
    }

}
