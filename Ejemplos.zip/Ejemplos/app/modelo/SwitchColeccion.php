<?php

namespace app\modelo;

use app\modelo\SQLServer;

class SwitchColeccion {

    public static function buscar($nombreSwitch, $modelo, $nombreInstalacion, $nombreSitio, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM vwswi_switch WHERE nombreSwitch LIKE ? "
                    . "AND modeloSwitch LIKE ? AND nombreLargoInstalacion LIKE ? "
                    . "AND nombreSitio LIKE ? AND estadoSwitch = ?";
            $datos = array("%{$nombreSwitch}%", "%{$modelo}%", "%{$nombreInstalacion}%", "%{$nombreSitio}%", &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar switch");
    }

    public static function buscarUltimosCreados($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM vwswi_switch "
                    . "WHERE estadoSwitch = ? ORDER BY fechaCreacionSwitch DESC";
            return SQLServer::instancia()->seleccionar($consulta, array(&$top, &$estado));
        }
        return array(0, "No se recibieron los campos obligatorios para consultar switchs");
    }

    public static function consultar($nombre, $modelo, $instalacion, $sitio) {
        $consulta = "SELECT * FROM vwswi_switch WHERE snombre LIKE ? AND smodelo LIKE ? AND inombre LIKE ? AND unombre LIKE ? AND sestado = 'Activo'";
        $datos = array('%' . $nombre . '%', '%' . $modelo . '%', '%' . $instalacion . '%', '%' . $sitio . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
