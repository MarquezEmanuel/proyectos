<?php

namespace app\modelo;

class SQLServer {

    public static $instancia;
    private $conexion;

    public static function instancia() {
        if (!self::$instancia instanceof self) {
            try {
                self::$instancia = new self;
                self::$instancia->conectar();
            } catch (Throwable $e) {
                echo "<p> ERROR AL ESTABLECER CONEXION A LA BASE DE DATOS: {$e->getMessage()}</p>";
                self::$instancia = NULL;
                exit;
            }
        }
        return self::$instancia;
    }

    public function conectar() {
        try {
            global $g_db_hostname, $g_db_basename, $g_db_username, $g_db_password, $g_crypto_key;
            $encriptador = new Encriptador();
            $host = $encriptador->desencriptar($g_db_hostname, $g_crypto_key);
            $base = $encriptador->desencriptar($g_db_basename, $g_crypto_key);
            $user = $encriptador->desencriptar($g_db_username, $g_crypto_key);
            $pass = $encriptador->desencriptar($g_db_password, $g_crypto_key);
            $datos = array("Database" => $base, "UID" => $user, "PWD" => $pass);
            $this->conexion = sqlsrv_connect($host, $datos);
            if (!$this->conexion) {
                $this->conexion = NULL;
                return false;
            }
        } catch (Throwable $e) {
            echo "<p> ERROR AL ESTABLECER CONEXION A LA BASE DE DATOS: {$e->getMessage()}</p>";
            return false;
        }
        return true;
    }

    public function borrar($consulta, $parametros) {
        $resultado = sqlsrv_prepare($this->conexion, $consulta, $parametros);
        if ($resultado && sqlsrv_execute($resultado)) {
            if (sqlsrv_rows_affected($resultado) > 0) {
                return array(2, "Se eliminó el registro correctamente");
            }
            return array(1, "No se eliminó el registro");
        }
        $this->grabarError("borrar", $consulta, sqlsrv_errors());
        return array(0, "No se creó el registro por un error interno (comunicar al administrador)");
    }

    /**
     * Busca un codigo de error dentro del arreglo de errrores.
     * @param array $errores Arreglo de errores.
     * @param int $codigo Codigo del error.
     * @return bool True si lo encuentra, false caso contrario
     */
    private function buscarError($errores, $codigo) {
        if ($errores != null) {
            return (in_array($codigo, array_column($errores, 'code')));
        }
        return false;
    }

    /**
     * Finaliza la transaccion con la BD. Cuando se indica que el resultado es true
     * se aplica un commit en la BD, cuando se indica que el resultado es false se
     * aplica un rollback en la BD. 
     * @param boolean $resultado Resultado del conjunto de operaciones realizadas.
     */
    public function finalizarTransaccion($resultado = TRUE) {
        ($resultado) ? sqlsrv_commit($this->conexion) : sqlsrv_rollback($this->conexion);
    }

    private function grabarError($metodo, $consulta, $errores, $parametros = NULL) {
        Log::escribirLineaError("$metodo | $consulta");
        if ($parametros && !empty($parametros)) {
            $contador = 0;
            foreach ($parametros as $parametro) {
                Log::escribirLineaError("$metodo | {$contador} = {$parametro}");
                $contador ++;
            }
        }
        foreach ($errores as $error) {
            Log::escribirLineaError("CODE: {$error['code']} --> {$error['message']}");
        }
    }

    /**
     * Inicia el proceso de transaccion. El metodo retorna true cuando la inicializacion
     * es correcta y false en caso contrario.
     * @return boolean True si se inicializa, false en caso contrario.
     */
    public function iniciarTransaccion() {
        if (sqlsrv_begin_transaction($this->conexion) === false) {
            Log::escribirLineaError("Error al inicializar transaccion con la BD");
            return false;
        }
        return true;
    }

    public function insertar($consulta, $parametros) {
        $resultado = sqlsrv_prepare($this->conexion, $consulta, $parametros);
        if ($resultado && sqlsrv_execute($resultado)) {
            $row = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC);
            return array(2, "Se creó el registro correctamente", $row["id"]);
        }
        if ($this->buscarError(sqlsrv_errors(), 2627)) {
            return array(1, "No se creó el registro solicitado porque ya existe");
        }
        $this->grabarError(__FUNCTION__, $consulta, sqlsrv_errors(), $parametros);
        return array(0, "No se creó el registro por un error interno (comunicar al administrador)");
    }

    public function modificar($consulta, $parametros) {
        $resultado = sqlsrv_prepare($this->conexion, $consulta, $parametros);
        if ($resultado && sqlsrv_execute($resultado)) {
            return array(2, "Se modificó el registro correctamente");
        }
        if ($this->buscarError(sqlsrv_errors(), 2627)) {
            return array(1, "No se modificó el registro solicitado porque ya existe");
        }
        $this->grabarError(__FUNCTION__, $consulta, sqlsrv_errors(), $parametros);
        return array(0, "No se modificó el registro por un error interno (comunicar al administrador)");
    }

    public function obtener($consulta, $parametros) {
        $resultado = sqlsrv_query($this->conexion, $consulta, $parametros);
        if ($resultado) {
            if (sqlsrv_has_rows($resultado)) {
                return array(2, sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC));
            }
            return array(1, "No se pudo obtener la información solicitada");
        }
        $this->grabarError(__FUNCTION__, $consulta, sqlsrv_errors());
        return array(0, "Ocurrio un error al obtener registro (informe al administrador)");
    }

    /**
     * Este metodo permite realizar un SELECT sobre la base de datos. Esta 
     * configurado para ser SCROLLABLE con SQLSRV_CURSOR_KEYSET. Como resultado
     * brinda un codigo numerico y una cadena descriptiva sobre la consulta.
     * @param string $consulta Consulta SQL efectuar.
     * @param array $parametros Arreglo con los parametros a consultar.
     * @return array Arreglo con dos posiciones. Un codigo numerico o resource y un texto.
     */
    public function seleccionar($consulta, $parametros) {
        $opciones = array('Scrollable' => SQLSRV_CURSOR_KEYSET);
        $resultado = sqlsrv_query($this->conexion, $consulta, $parametros, $opciones);
        if ($resultado) {
            if (sqlsrv_has_rows($resultado)) {
                return array(2, $resultado);
            }
            return array(1, "No se encontraron resultados para mostrar");
        }
        $this->grabarError(__FUNCTION__, $consulta, sqlsrv_errors());
        return array(0, "Ocurrio un error al realizar la consulta (informe al administrador)");
    }

}
