<?php

namespace app\modelo;

/**
 * Lee el XML de configuracion para establecer la conexion a la base de datos.
 * 
 * @package app\principal\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Constantes {

    const APP_NOMBRE_CORTO = "CAP";
    const APP_NOMBRE_LARGO = "Control de Aplicaciones e Inventario Web";
    const BSC_NOMBRE_CORTO = "BSC";
    const BSC_NOMBRE_LARGO = "Banco de Santa Cruz";

    # DIRECTORIOS
    const DIR_APP = DIRECTORY_SEPARATOR . 'app';
    const DIR_CONFIG = DIRECTORY_SEPARATOR . 'config';
    const DIR_LOGS = DIRECTORY_SEPARATOR . 'logs';
    const DIR_LIB = DIRECTORY_SEPARATOR . 'lib';
    const TIMEZONE = 'America/Argentina/Buenos_Aires';

    # ICONOS
    const ICON_ACTIVAR = '<i class="fas fa-plus-circle"></i>';
    const ICON_AGREGAR = '<i class="fas fa-plus"></i>';
    const ICON_BUSCAR = '<i class="fas fa-search"></i>';
    const ICON_DETALLE = '<i class="fas fa-info-circle"></i>';
    const ICON_EDITAR = '<i class="far fa-edit"></i>';
    const ICON_FILTRO = '<i class="fas fa-filter"></i>';
    const ICON_GUARDAR = '<i class="far fa-save"></i>';
    const ICON_INACTIVAR = '<i class="fas fa-trash"></i>';
    const ICON_REGRESAR = '<i class="fas fa-arrow-circle-left"></i>';
    const ICON_RUEDAS = '<i class="fas fa-cogs"></i>';
    const ICON_MOD_ACTIVIDAD = '<i class="far fa-list-alt"></i>';
    const ICON_MOD_APLICACION = '<i class="fas fa-desktop"></i>';
    const ICON_MOD_AUXILIAR = '<i class="fas fa-network-wired"></i>';
    const ICON_MOD_BASE = '<i class="fas fa-database"></i>';
    const ICON_MOD_COMUNICACION = '<i class="fas fa-broadcast-tower"></i>';
    const ICON_MOD_DEPARTAMENTO = '<i class="fas fa-sitemap"></i>';
    const ICON_MOD_EMPLEADO = '<i class="fas fa-sitemap"></i>';
    const ICON_MOD_FIREWALL = '<i class="fas fa-fire-alt"></i>';
    const ICON_MOD_GERENCIA = '<i class="fas fa-sitemap"></i>';
    const ICON_MOD_HARDWARE = '<i class="fas fa-microchip"></i>';
    const ICON_MOD_HERRAMIENTA = '<i class="fas fa-laptop-code"></i>';
    const ICON_MOD_INSTALACION = '<i class="fas fa-code-branch"></i>';
    const ICON_MOD_LENGUAJE = '<i class="fas fa-code"></i>';
    const ICON_MOD_PERSONAL = '<i class="fas fa-users"></i>';
    const ICON_MOD_PLATAFORMA = '<i class="fas fa-hdd"></i>';
    const ICON_MOD_MODOPR = '<i class="fas fa-cogs"></i>';
    const ICON_MOD_LUGARPR = '<i class="fas fa-cogs"></i>';
    const ICON_MOD_PERFIL = '<i class="fas fa-user-friends"></i>';
    const ICON_MOD_PERMISO = '<i class="fas fa-user-lock"></i>';
    const ICON_MOD_PROVEEDOR = '<i class="far fa-address-card"></i>';
    const ICON_MOD_RESPONSABLE = '<i class="far fa-address-card"></i>';
    const ICON_MOD_SERVICIO = '<i class="fab fa-connectdevelop"></i>';
    const ICON_MOD_SITIO = '<i class="far fa-building"></i>';
    const ICON_MOD_SWITCH = '<i class="fas fa-ethernet"></i>';
    const ICON_MOD_USUARIO = '<i class="fas fa-user-alt"></i>';

    #HTML
    const HTML_TITLE_LABEL_REQUIRED = 'Campo de caracter obligatorio';
    const HTML_TITLE_LABEL_NO_REQUIRED = 'Campo de caracter opcional';

}
