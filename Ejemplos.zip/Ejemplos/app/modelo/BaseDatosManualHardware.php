<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla que relaciona bases de datos creadas de forma manual con
 * los hardware.
 * 
 * @package app\base\modelo.
 * 
 * @uses bas_man_base_hardware Tabla relacion de base de datos con hardware.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 * 
 * @version 1.0
 * 
 */
class BaseDatosManualHardware {

    /**
     * Realiza la eliminacion de los hardwares asociados a la base de datos y 
     * luego la creacion de los nuevos hardwares asociados.
     * @param int $idBaseDatosManual Identificador del activo.
     * @param array $hardwares Arreglo con los identificadores de los hardwares.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function actualizarHardwaresBase($idBaseDatosManual, $hardwares) {
        $resultado = BaseDatosManualHardware::borrar($idBaseDatosManual);
        if ($resultado[0] == 2) {
            $resultado = BaseDatosManualHardware::crear($idBaseDatosManual, $hardwares);
        }
        return $resultado;
    }

    /**
     * Elimina todos los hardwares asociados a la base de datos.
     * @see SQLServer::$instancia->borrar
     * @param int $idBaseDatosManual Identificador de la base de datos.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function borrar($idBaseDatosManual) {
        if ($idBaseDatosManual > 0) {
            $consulta = "DELETE FROM bas_base_hardware WHERE idBaseDatosManual = ?";
            return SQLServer::$instancia->borrar($consulta, array(&$idBaseDatosManual));
        }
        return array(0, "No se pudo hacer referencia a la base de datos");
    }

    /**
     * Crea todas las relaciones de una base de datos con sus hardwares.
     * @see SQLServer::instancia()->insertar
     * @param int $idBaseDatosManual Identificador de la base de datos.
     * @param array $hardwares Arreglo con los identificadores de los hardwares y 
     *        fecha de creacion de la base de datos (id, fecha).
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function crear($idBaseDatosManual, $hardwares) {
        if (($idBaseDatosManual > 0) && !empty($hardwares)) {
            $registros = "";
            foreach ($hardwares as $hardware) {
                $idHardware = $hardware[0];
                $orden = $hardware[1];
                $fechaCreacion = ($hardware[2]) ? "'{$hardware[2]}T00:00:00'" : "NULL";
                $registros .= "({$idBaseDatosManual}, {$idHardware}, {$orden}, {$fechaCreacion}, GETDATE()),";
            }
            $consulta = "INSERT INTO bas_base_hardware VALUES " . substr($registros, 0, -1);
            return SQLServer::instancia()->insertar($consulta, array());
        }
        return array(0, "No se recibieron los campos obligatorios para relacionar hardwares");
    }

}
