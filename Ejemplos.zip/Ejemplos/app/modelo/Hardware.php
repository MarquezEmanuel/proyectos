<?php

namespace app\modelo;

use app\modelo\SQLServer;
use app\modelo\Sitio;
use app\modelo\ProveedorColeccion as Proveedores;

/**
 * 
 * @package app\hardware\modelo.
 * 
 * @uses SQLServer app\principal\modelo\SQLServer.
 * @uses Sitio app\sitio\modelo\Sitio.
 * @uses ColeccionProveedores app\proveedor\modelo\ColeccionProveedores.
 * 
 */
class Hardware {

    private $id;
    private $tipo;
    private $nombreCorto;
    private $nombreLargo;
    private $dominio;
    private $swBase;
    private $ambiente;
    private $funcion;
    private $sitio;
    private $marca;
    private $modelo;
    private $arquitectura;
    private $core;
    private $procesador;
    private $mhz;
    private $memoria;
    private $disco;
    private $raid;
    private $red;

    /** @var string Riesgo de TI [NVARCHAR(5) NOT NULL] */
    private $rti;

    /** @var string Estado del registro [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var string Descripcion del elemento auxiliar [NVARCHAR(500) NOT NULL] */
    private $descripcion;

    /** @var int Nivel de visibilidad [INT NOT NULL] */
    private $visibilidad;

    /** @var string Fecha de creacion del registro [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de ultima edicion del registro [SMALLDATETIME NOT NULL] */
    private $fechaEdicion;
    private $proveedores;

    /**
     * @param int $id Identificador del hardware [PK BIGINT].
     * @param string $tipo Tipo de harware [NVARCHAR(50)].
     * @param string $nombreCorto Nombre corto [NVARCHAR(20)].
     * @param string $nombreLargo Nombre largo [NVARCHAR(50)].
     * @param string $dominio Dominio [NVARCHAR(20)].
     * @param string $swBase Software de base [NVARCHAR(50)].
     * @param string $ambiente Nombre del ambiente [NVARCHAR(20)].
     * @param string $funcion Funcion que cumple [NVARCHAR(300)].
     * @param string $sitio Sitio o identificador de sitio [FK NVARCHAR(10)].
     * @param string $marca Nombre de la marca [NVARCHAR(30)].
     * @param string $modelo Modelo [NVARCHAR(30)].
     * @param string $arquitectura Arquitectura [NVARCHAR(30)].
     * @param string $core Core [NVARCHAR(30)].
     * @param string $procesador Datos del procesador [NVARCHAR(30)].
     * @param string $mhz Datos de los mhz [NVARCHAR(50)].
     * @param string $memoria Datos de la memoria [NVARCHAR(50)].
     * @param string $disco Datos del disco [NVARCHAR(50)].
     * @param string $raid Datos del raid [NVARCHAR(50)].
     * @param int $red Numero de red [INT].
     * @param string $rti Riesgo de TI [NVARCHAR(5)].
     * @param string $estado Estado activo o inactivo [NVARCHAR(20)].
     * @param string $descripcion Descripcion adicional [NVARCHAR(500)].
     * @param int $visibilidad Nivel de visibilidad del registro [INT].
     * @param array $proveedores Arreglo de proveedores.
     */
    public function __construct($id = NULL, $tipo = NULL, $nombreCorto = NULL, $nombreLargo = NULL, $dominio = NULL, $swBase = NULL, $ambiente = NULL, $funcion = NULL, $sitio = NULL, $marca = NULL, $modelo = NULL, $arquitectura = NULL, $core = NULL, $procesador = NULL, $mhz = NULL, $memoria = NULL, $disco = NULL, $raid = NULL, $red = NULL, $rti = NULL, $estado = NULL, $descripcion = NULL, $visibilidad = NULL, $proveedores = NULL) {
        $this->setId($id);
        $this->setTipo($tipo);
        $this->setNombreCorto($nombreCorto);
        $this->setNombreLargo($nombreLargo);
        $this->setDominio($dominio);
        $this->setSwBase($swBase);
        $this->setAmbiente($ambiente);
        $this->setFuncion($funcion);
        $this->setSitio($sitio);
        $this->setMarca($marca);
        $this->setModelo($modelo);
        $this->setArquitectura($arquitectura);
        $this->setCore($core);
        $this->setProcesador($procesador);
        $this->setMhz($mhz);
        $this->setMemoria($memoria);
        $this->setDisco($disco);
        $this->setRaid($raid);
        $this->setRed($red);
        $this->setRti($rti);
        $this->setEstado($estado);
        $this->setDescripcion($descripcion);
        $this->setVisibilidad($visibilidad);
        $this->setProveedores($proveedores);
    }

    public function getId() {
        return $this->id;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getNombreCorto() {
        return $this->nombreCorto;
    }

    public function getNombreLargo() {
        return utf8_encode($this->nombreLargo);
    }

    public function getDominio() {
        return $this->dominio;
    }

    public function getSwBase() {
        return utf8_encode($this->swBase);
    }

    public function getAmbiente() {
        return utf8_encode($this->ambiente);
    }

    public function getFuncion() {
        return utf8_encode($this->funcion);
    }

    public function getSitio() {
        return $this->sitio;
    }

    public function getMarca() {
        return utf8_encode($this->marca);
    }

    public function getModelo() {
        return utf8_encode($this->modelo);
    }

    public function getArquitectura() {
        return utf8_encode($this->arquitectura);
    }

    public function getCore() {
        return utf8_encode($this->core);
    }

    public function getProcesador() {
        return utf8_encode($this->procesador);
    }

    public function getMhz() {
        return ($this->mhz == "NULL") ? NULL : $this->mhz;
    }

    public function getMemoria() {
        return ($this->memoria == "NULL") ? NULL : $this->memoria;
    }

    public function getDisco() {
        return utf8_encode($this->disco);
    }

    public function getRaid() {
        return utf8_encode($this->raid);
    }

    public function getRed() {
        return ($this->red == "NULL") ? NULL : $this->red;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getVisibilidad() {
        return $this->visibilidad;
    }

    public function getProveedores() {
        return $this->proveedores;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setTipo($tipo) {
        $this->tipo = utf8_decode($tipo);
    }

    public function setNombreCorto($nombreCorto) {
        if ($nombreCorto && (strlen($nombreCorto) <= 20)) {
            $this->nombreCorto = utf8_decode($nombreCorto);
        }
    }

    public function setNombreLargo($nombreLargo) {
        if ($nombreLargo && (strlen($nombreLargo) <= 50)) {
            $this->nombreLargo = utf8_decode($nombreLargo);
        }
    }

    public function setDominio($dominio) {
        if ($dominio && (strlen($dominio) <= 20)) {
            $this->dominio = utf8_decode($dominio);
        }
    }

    public function setSwBase($swBase) {
        if ($swBase && (strlen($swBase) <= 50)) {
            $this->swBase = utf8_decode($swBase);
        }
    }

    public function setAmbiente($ambiente) {
        if ($ambiente && (strlen($ambiente) <= 20)) {
            $this->ambiente = utf8_decode($ambiente);
        }
    }

    public function setFuncion($funcion) {
        if ($funcion && (strlen($funcion) <= 300)) {
            $this->funcion = utf8_decode($funcion);
        }
    }

    public function setSitio($sitio) {
        $this->sitio = ($sitio) ? $sitio : NULL;
    }

    public function setMarca($marca) {
        if ($marca && (strlen($marca) <= 30)) {
            $this->marca = utf8_decode($marca);
        }
    }

    public function setModelo($modelo) {
        if ($modelo && (strlen($modelo) <= 30)) {
            $this->modelo = utf8_decode($modelo);
        }
    }

    public function setArquitectura($arquitectura) {
        if ($arquitectura && (strlen($arquitectura) <= 30)) {
            $this->arquitectura = utf8_decode($arquitectura);
        }
    }

    public function setCore($core) {
        $this->core = utf8_decode($core);
    }

    public function setProcesador($procesador) {
        if ($procesador && (strlen($procesador) <= 30)) {
            $this->procesador = utf8_decode($procesador);
        }
    }

    public function setMhz($mhz) {
        $this->mhz = ($mhz) ? $mhz : NULL;
    }

    public function setMemoria($memoria) {
        $this->memoria = ($memoria) ? $memoria : NULL;
    }

    public function setDisco($disco) {
        $this->disco = utf8_decode($disco);
    }

    public function setRaid($raid) {
        if ($raid && (strlen($raid) <= 50)) {
            $this->raid = utf8_decode($raid);
        }
    }

    public function setRed($red) {
        $this->red = ($red) ? $red : NULL;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = utf8_decode($descripcion);
    }

    public function setVisibilidad($visibilidad) {
        $this->visibilidad = ($visibilidad > 0) ? $visibilidad : NULL;
    }

    public function setProveedores($proveedores) {
        $this->proveedores = $proveedores;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function crear() {
        if ($this->tipo && $this->nombreCorto && $this->nombreLargo && $this->dominio && $this->swBase && $this->ambiente && $this->sitio) {
            $consulta = "INSERT INTO har_hardware OUTPUT INSERTED.id  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'Si','Activo', ?, 1, GETDATE(), NULL)";
            $datos = array(&$this->tipo, &$this->nombreCorto, &$this->nombreLargo, &$this->dominio, &$this->swBase, &$this->ambiente, &$this->funcion,
                &$this->sitio, &$this->marca, &$this->modelo, &$this->arquitectura, &$this->core, &$this->procesador, &$this->mhz, &$this->memoria,
                &$this->disco, &$this->raid, &$this->red, &$this->descripcion);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            if ($resultado[0] == 2) {
                $this->id = $resultado[2];
                $rhardware = HardwareProveedor::crear($this->id, $this->proveedores);
                $resultado = ($rhardware[0] == 2) ? $resultado : $rhardware;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear el hardware");
    }

    public function modificar() {
        if ($this->id && $this->tipo && $this->nombreCorto && $this->nombreLargo && $this->dominio && $this->swBase && $this->ambiente && $this->sitio) {
            $consulta = "UPDATE har_hardware SET tipo=?, nombreCorto=?, nombreLargo=?, dominio=?, "
                    . "softwareBase=?, ambiente=?, funcion=?, idSitio=?, marca=?, modelo=?, arquitectura=?, "
                    . "core=?, procesador=?, mhz=?, memoria=?, disco=?, raid=?, red=?, descripcion=?, "
                    . "estado=?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->tipo, &$this->nombreCorto, &$this->nombreLargo, &$this->dominio, &$this->swBase, &$this->ambiente, &$this->funcion,
                &$this->sitio, &$this->marca, &$this->modelo, &$this->arquitectura, &$this->core, &$this->procesador, &$this->mhz, &$this->memoria,
                &$this->disco, &$this->raid, &$this->red, &$this->descripcion, &$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            if ($resultado[0] == 2) {
                $actualizar = HardwareProveedor::actualizarProveedoresHardware($this->id, $this->proveedores);
                $resultado = ($actualizar[0] == 2) ? $resultado : $actualizar;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para modificar el hardware");
    }

    /**
     * Permite modificar los datos del activo que corresponde a Control de Gestion
     * de Tecnologia Informatica (CGTI). Este metodo actualiza los campos
     * rti, nivel de visibilidad y fecha de ultima edicion.
     * @return array Arreglo con dos elementos [codigo, mensaje].
     */
    public function modificarCGTI() {
        if ($this->id && $this->rti && $this->visibilidad) {
            $consulta = "UPDATE har_hardware SET rti = ?, nivelVisibilidad = ?, "
                    . " fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->rti, &$this->visibilidad, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para modificar el hardware");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM har_hardware WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->tipo = $fila['tipo'];
                $this->nombreCorto = $fila['nombreCorto'];
                $this->nombreLargo = $fila['nombreLargo'];
                $this->dominio = $fila['dominio'];
                $this->swBase = $fila['softwareBase'];
                $this->ambiente = $fila['ambiente'];
                $this->funcion = $fila['funcion'];
                $this->sitio = $fila['idSitio'];
                $this->marca = $fila['marca'];
                $this->modelo = $fila['modelo'];
                $this->arquitectura = $fila['arquitectura'];
                $this->core = $fila['core'];
                $this->procesador = $fila['procesador'];
                $this->mhz = $fila['mhz'];
                $this->memoria = $fila['memoria'];
                $this->disco = $fila['disco'];
                $this->raid = $fila['raid'];
                $this->red = $fila['red'];
                $this->rti = $fila['rti'];
                $this->estado = $fila['estado'];
                $this->descripcion = $fila['descripcion'];
                $this->visibilidad = $fila['nivelVisibilidad'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información del hardware correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al hardware");
    }

    public function obtenerSitio() {
        $sitio = new Sitio($this->sitio);
        $resultado = $sitio->obtener();
        $this->sitio = ($resultado[0] == 2) ? $sitio : NULL;
        return $resultado;
    }

    public function obtenerProveedores() {
        $this->proveedores = NULL;
        $resultado = Proveedores::buscarProveedoresHardware($this->id);
        if ($resultado[0] == 2) {
            $proveedores = $resultado[1];
            while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
                $this->proveedores[] = $proveedor;
            }
            $resultado[1] = ($this->proveedores) ? NULL : $resultado[1];
        }
        return $resultado;
    }

    public function toString() {
        $hardware = ($this->id) ? "{{$this->id}," : "{,";
        $hardware .= ($this->tipo) ? "'{$this->getTipo()}'," : "'',";
        $hardware .= ($this->nombreCorto) ? "'{$this->getNombreCorto()}'," : "'',";
        $hardware .= ($this->nombreLargo) ? "'{$this->getNombreLargo()}'," : "'',";
        $hardware .= ($this->dominio) ? "'{$this->getDominio()}'," : "'',";
        $hardware .= ($this->swBase) ? "'{$this->getSwBase()}'," : "'',";
        $hardware .= ($this->ambiente) ? "'{$this->getAmbiente()}'," : "'',";
        $hardware .= ($this->funcion) ? "'{$this->getFuncion()}'," : "'',";
        $hardware .= ($this->sitio && gettype($this->sitio)) ? "'{$this->getSitio()}'," : "'',";
        $hardware .= ($this->marca) ? "'{$this->getMarca()}'," : "'',";
        $hardware .= ($this->modelo) ? "'{$this->getModelo()}'," : "'',";
        $hardware .= ($this->arquitectura) ? "'{$this->getArquitectura()}'," : "'',";
        $hardware .= ($this->core) ? "'{$this->getCore()}'," : "'',";
        $hardware .= ($this->procesador) ? "'{$this->getProcesador()}'," : "'',";
        $hardware .= ($this->mhz) ? "'{$this->getMhz()}'," : "'',";
        $hardware .= ($this->memoria) ? "'{$this->getMemoria()}'," : "'',";
        $hardware .= ($this->disco) ? "'{$this->getDisco()}'," : "'',";
        $hardware .= ($this->raid) ? "'{$this->getRaid()}'," : "'',";
        $hardware .= ($this->red) ? "'{$this->getRed()}'," : "'',";
        $hardware .= ($this->rti) ? "'{$this->getRti()}'," : "'',";
        $hardware .= ($this->estado) ? "'{$this->getEstado()}'," : "'',";
        $hardware .= ($this->visibilidad) ? "'{$this->getVisibilidad()}'}" : "0}";
        return $hardware;
    }

}
