<?php

namespace app\modelo;

use app\modelo\SQLServer;
use app\modelo\Util;

/**
 * Mapea con la tabla de responsables.
 * 
 * @package app\sitio\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Responsable {

    /** @var int Identificador del responsable [BIGINT] */
    private $id;

    /** @var string Nombre del resposable [NVARCHAR(150) NOT NULL] */
    private $nombre;

    /** @var string Numero de telefono [NVARCHAR(20) NULL] */
    private $telefono;

    /** @var string Numero de telefono [NVARCHAR(50) NULL] */
    private $correo;

    /** @var int Identificador del proveedor [BIGINT NOT NULL] */
    private $proveedor;

    /** @var string Estado [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var string Fecha de creacion [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de ultima edicion [SMALLDATETIME NULL] */
    private $fechaEdicion;

    public function __construct($id = NULL, $nombre = NULL, $telefono = NULL, $correo = NULL, $proveedor = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setTelefono($telefono);
        $this->setCorreo($correo);
        $this->setProveedor($proveedor);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getTelefono() {
        return $this->telefono;
    }

    public function getCorreo() {
        return $this->correo;
    }

    public function getProveedor() {
        return $this->proveedor;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setNombre($nombre) {
        if ($nombre && strlen($nombre) <= 150) {
            $this->nombre = utf8_decode(Util::convertirCamelCase($nombre));
        }
    }

    public function setTelefono($telefono) {
        if ($telefono && strlen($telefono) <= 20) {
            $this->telefono = $telefono;
        }
    }

    public function setCorreo($correo) {
        if ($correo && (strlen($correo) <= 50)) {
            $this->correo = $correo;
        }
    }

    public function setProveedor($proveedor) {
        $this->proveedor = $proveedor;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE pro_responsable SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        return array(1, "No se recibieron los campos obligatorios");
    }

    public function crear() {
        if ($this->nombre && $this->correo && $this->proveedor) {
            $consulta = "INSERT INTO pro_responsable OUTPUT INSERTED.id VALUES (?, ?, ?, ?, 'Activo', GETDATE(), NULL)";
            $datos = array(&$this->nombre, &$this->telefono, &$this->correo, &$this->proveedor);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            $this->id = ($resultado[0] == 2) ? $resultado[2] : NULL;
            return $resultado;
        }
        return array(1, "No se recibieron los campos obligatorios");
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->telefono && $this->correo && $this->proveedor) {
            $consulta = "UPDATE pro_responsable SET nombre = ?, telefono = ?, "
                    . " correo = ?, idProveedor = ?, estado=?, "
                    . " fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->nombre, &$this->telefono, &$this->correo, &$this->proveedor, &$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM pro_responsable WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->telefono = $fila['telefono'];
                $this->correo = $fila['correo'];
                $this->proveedor = $fila['idProveedor'];
                $this->estado = $fila['estado'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información del responsable correctamente");
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios");
    }

    public function obtenerProveedor() {
        $proveedor = new Proveedor($this->proveedor);
        $resultado = $proveedor->obtener();
        $this->proveedor = ($resultado[0] == 2) ? $proveedor : NULL;
        return $resultado;
    }

    public function toString() {
        $responsable = ($this->id) ? "{{$this->getId()}," : "{0,";
        $responsable .= ($this->nombre) ? "'{$this->getNombre()}'," : "'',";
        $responsable .= ($this->telefono) ? "'{$this->getTelefono()}'," : "'',";
        $responsable .= ($this->correo) ? "'{$this->getCorreo()}'," : "'',";
        $responsable .= ($this->proveedor && gettype($this->proveedor) == "integer") ? "{$this->proveedor}," : "0,";
        $responsable .= ($this->estado) ? "'{$this->getEstado()}'}" : "''}";
        return $responsable;
    }

}
