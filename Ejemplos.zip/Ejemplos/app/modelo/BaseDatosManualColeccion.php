<?php

namespace app\modelo;

use app\modelo\SQLServer;

class BaseDatosManualColeccion {

    public static function buscar($nombre, $collation, $estado) {
        $consulta = "SELECT * FROM vwbas_base "
                . "WHERE nombre LIKE ? AND collation LIKE ? AND estado = ?";
        $datos = array("%{$nombre}%", "%{$collation}%", $estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    /**
     * Buscar las bases de datos de una determinada aplicacion. De la consulta se 
     * obtienen todos los datos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $idAplicacion Identificador de la aplicacion (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarBasesDatosAplicacion($idAplicacion) {
        if ($idAplicacion > 0) {
            $consulta = "SELECT base.* FROM bas_base base "
                    . "INNER JOIN apl_aplicacion_base relacion on relacion.idBaseDatos = base.id "
                    . "WHERE relacion.idAplicacion = ?";
            return SQLServer::instancia()->seleccionar($consulta, array(&$idAplicacion));
        }
        return array(0, "No se pudo hacer referencia al firewall para obtener proveedores");
    }

    /**
     * Busca los registros de un determinado informe.
     * @param int idInforme Identificador del informe solicitado.
     * return array Arreglo nulo, vacio o con la informacion del reporte.
     */
    private static function buscarDatosInforme($idInforme) {
        $consulta = "SELECT detalle, total FROM vwbas_informes WHERE id = ? ORDER BY detalle";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$idInforme));
        if ($resultado[0] == 2) {
            $datos = array();
            while ($registro = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $datos[] = array('detalle' => $registro['detalle'], 'total' => $registro['total']);
            }
            return $datos;
        }
        return NULL;
    }

    /**
     * Busca los informes disponibles y agrupa su informacion.
     */
    public static function buscarInformesBaseDatos() {
        $consulta = "SELECT DISTINCT id, informe, COUNT(*) distribucion "
                . " FROM vwbas_informes GROUP BY id, informe ORDER BY id";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        if ($resultado[0] == 2) {
            $informes = array();
            while ($informe = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $datos = BaseDatosManualColeccion::buscarDatosInforme($informe['id']);
                $informes[] = array($informe['id'], $informe['informe'], $informe['distribucion'], $datos);
            }
            return array(2, $informes);
        }
        return $resultado;
    }

    public static function buscarParaSeleccionar($nombre) {
        $consulta = "SELECT id, nombre FROM bas_base "
                . "WHERE nombre LIKE ? AND estado = 'Activa' ORDER BY nombre";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombre}%"));
    }

    public static function buscarUltimasCreadas($top, $estado) {
        $consulta = "SELECT TOP(?) * FROM vwbas_base "
                . " WHERE estado = ? ORDER BY fechaCreacion DESC";
        $datos = array(&$top, &$estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

}
