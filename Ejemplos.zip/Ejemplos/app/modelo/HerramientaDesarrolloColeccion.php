<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla y vista de herramientas.
 * 
 * @package app\plataforma\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class HerramientaDesarrolloColeccion {

    /**
     * Buscar herramientas a partir del nombre, version, fabricante y estado. De la
     * consulta se obtienen todos los campos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre o parte del nombre de la herramienta (LIKE).
     * @param string $version Version de la herramienta (LIKE).
     * @param string $fabricante Nombre del fabricante (LIKE).
     * @param string $estado Estado de la herramienta (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscar($nombre, $version, $fabricante, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM her_herramienta "
                    . "WHERE nombre LIKE ? AND version LIKE ? "
                    . "AND fabricante LIKE ? AND estado = ?";
            $datos = array("%{$nombre}%", "%{$version}%", "%{$fabricante}%", $estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar herramientas");
    }

    /**
     * Buscar herramientas de desarrollo en estado activa a partir de su nombre. 
     * De la consulta se obtiene el id, nombre y version. El objetivo del metodo 
     * es obtener los datos necesarios para seleccionar y relacionar.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre o parte del nombre de la herramienta (LIKE).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarParaSeleccionar($nombre) {
        $consulta = "SELECT id, nombre, version FROM her_herramienta "
                . "WHERE nombre LIKE ? AND estado = 'Activa' "
                . "ORDER BY nombre, version";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombre}%"));
    }

    /**
     * Buscar herramientas ordenadas por fecha de creacion descendente con un tope
     * de registros y un estado. De la consulta se obtienen todos los campos de
     * la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $top Cantidad maxima de registros a seleccionar.
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarUltimasCreadas($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM her_herramienta "
                    . "WHERE estado = ? "
                    . "ORDER BY fechaCreacion DESC";
            $datos = array(&$top, &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar herramientas de desarrollo");
    }

    public static function consultar($nombre, $version, $fabricante) {
        $consulta = "SELECT * FROM her_herramienta WHERE nombre LIKE ? AND version LIKE ? AND fabricante LIKE ? AND estado = 'Activa'";
        $datos = array('%' . $nombre . '%', '%' . $version . '%', '%' . $fabricante . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
