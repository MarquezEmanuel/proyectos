<?php

namespace app\modelo;

use app\modelo\SQLServer;
use app\modelo\Util;

/**
 * Mapea con la tabla de sitios.
 * 
 * @package app\sitio\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Sitio {

    /** @var string Identidicador [NVARCHAR(10) NOT NULL] */
    private $id;

    /** @var string Tipo de sitio entre CPP, URP o SUC [NVARCHAR(10) NOT NULL] */
    private $tipo;

    /** @var string Nombre del sitio [NVARCHAR(50) NOT NULL] */
    private $nombre;

    /** @var string Nombre de la provincia [NVARCHAR(50) NOT NULL] */
    private $provincia;

    /** @var string Nombre de la ciudad [NVARCHAR(50) NOT NULL] */
    private $ciudad;

    /** @var bigint Codigo postal [BIGINT NOT NULL] */
    private $codigoPostal;

    /** @var string Direccion del sitio [NVARCHAR(60) NOT NULL] */
    private $direccion;

    /** @var string Origen entre Tercerizado o Propio [NVARCHAR(10) NOT NULL] */
    private $origen;

    /** @var string Estado del registro [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var string Fecha de creacion del registro [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de ultima edicion del registro [SMALLDATETIME NULL] */
    private $fechaEdicion;

    public function __construct($id = NULL, $tipo = NULL, $nombre = NULL, $provincia = NULL, $ciudad = NULL, $codigoPostal = NULL, $direccion = NULL, $origen = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setTipo($tipo);
        $this->setNombre($nombre);
        $this->setProvincia($provincia);
        $this->setCiudad($ciudad);
        $this->setCodigoPostal($codigoPostal);
        $this->setDireccion($direccion);
        $this->setOrigen($origen);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getProvincia() {
        return utf8_encode($this->provincia);
    }

    public function getCiudad() {
        return utf8_encode($this->ciudad);
    }

    public function getCodigoPostal() {
        return $this->codigoPostal;
    }

    public function getDireccion() {
        return utf8_encode($this->direccion);
    }

    public function getOrigen() {
        return $this->origen;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setTipo($tipo) {
        $this->tipo = ($tipo) ? $tipo : NULL;
    }

    public function setNombre($nombre) {
        if ($nombre && strlen($nombre) <= 50) {
            $this->nombre = utf8_decode(Util::convertirCamelCase($nombre));
        }
    }

    public function setProvincia($provincia) {
        if ($provincia && strlen($provincia) <= 50) {
            $this->provincia = utf8_decode(Util::convertirCamelCase($provincia));
        }
    }

    public function setCiudad($ciudad) {
        if ($ciudad && strlen($ciudad) <= 50) {
            $this->ciudad = utf8_decode(Util::convertirCamelCase($ciudad));
        }
    }

    public function setCodigoPostal($codigoPostal) {
        $this->codigoPostal = ($codigoPostal > 1) ? $codigoPostal : NULL;
    }

    public function setDireccion($direccion) {
        if ($direccion && strlen($direccion) <= 50) {
            $this->direccion = utf8_decode(Util::convertirCamelCase($direccion));
        }
    }

    public function setOrigen($origen) {
        $this->origen = ($origen) ? $origen : NULL;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function crear() {
        if ($this->id && $this->tipo && $this->nombre && $this->provincia && $this->ciudad && $this->codigoPostal) {
            $consulta = "INSERT INTO sit_sitio VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Activo', GETDATE(), NULL)";
            $datos = array($this->id, $this->tipo, $this->nombre, $this->provincia, $this->ciudad, $this->codigoPostal, $this->direccion, $this->origen);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear sitio");
    }

    public function modificar() {
        if ($this->id && $this->tipo && $this->nombre && $this->provincia && $this->ciudad && $this->codigoPostal) {
            $consulta = "UPDATE sit_sitio SET tipo=?, nombre=?, provincia=?, "
                    . "ciudad=?, codigoPostal=?, direccion=?, origen=?, "
                    . "estado=?, fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->tipo, &$this->nombre, &$this->provincia, &$this->ciudad, &$this->codigoPostal, &$this->direccion, &$this->origen, &$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para modificar sitio");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM sit_sitio WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->tipo = $fila['tipo'];
                $this->nombre = $fila['nombre'];
                $this->provincia = $fila['provincia'];
                $this->ciudad = $fila['ciudad'];
                $this->codigoPostal = $fila['codigoPostal'];
                $this->direccion = $fila['direccion'];
                $this->origen = $fila['origen'];
                $this->estado = $fila['estado'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información del sitio correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al sitio");
    }

    public function toString() {
        $sitio = ($this->id) ? "{'{$this->getId()}'," : "{'',";
        $sitio .= ($this->tipo) ? "'{$this->getTipo()}'," : "'',";
        $sitio .= ($this->nombre) ? "'{$this->getNombre()}'," : "'',";
        $sitio .= ($this->provincia) ? "'{$this->getProvincia()}'," : "'',";
        $sitio .= ($this->ciudad) ? "'{$this->getCiudad()}'," : "'',";
        $sitio .= ($this->codigoPostal) ? "{$this->getCodigoPostal()}," : "0,";
        $sitio .= ($this->direccion) ? "'{$this->getDireccion()}'," : "'',";
        $sitio .= ($this->origen) ? "'{$this->getOrigen()}'," : "'',";
        $sitio .= ($this->estado) ? "'{$this->getEstado()}'}" : "''}";
        return $sitio;
    }

}
