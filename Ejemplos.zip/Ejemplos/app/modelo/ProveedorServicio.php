<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla que relaciona proveedores con servicios.
 * 
 * @package app\proveedor\modelo.
 * 
 * @uses pro_proveedor_servicio Tabla relacion de hardware con proveedor.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 * 
 * @version 1.0
 * 
 */
class ProveedorServicio {

    /**
     * Realiza la eliminacion de los servicios asociados al proveedor y luego la
     * creacion de los nuevos servicios asociados.
     * @param int $idProveedor Identificador del activo.
     * @param array $servicios Arreglo con los identificadores de los servicios.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function actualizarServiciosProveedor($idProveedor, $servicios) {
        $resultado = ProveedorServicio::borrar($idProveedor);
        if ($resultado[0] == 2) {
            $resultado = ProveedorServicio::crear($idProveedor, $servicios);
        }
        return $resultado;
    }

    /**
     * Elimina todos los servicios asociados al proveedor.
     * @see SQLServer::$instancia->borrar
     * @param int $idProveedor Identificador del proveedor.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function borrar($idProveedor) {
        if ($idProveedor > 0) {
            $consulta = "DELETE FROM pro_proveedor_servicio WHERE idProveedor = ?";
            return SQLServer::$instancia->borrar($consulta, array(&$idProveedor));
        }
        return array(0, "No se pudo hacer referencia al proveedor de los servicios");
    }

    /**
     * Crea todas las relaciones de un proveedor con sus servicios.
     * @see SQLServer::instancia()->insertar
     * @param int $idProveedor Identificador del proveedor.
     * @param array $servicios Arreglo con los identificadores de los servicios.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function crear($idProveedor, $servicios) {
        if (($idProveedor > 0) && !empty($servicios)) {
            $registros = "";
            for ($index = 0; $index < count($servicios); $index++) {
                $registros .= "({$idProveedor}, ?),";
            }
            $consulta = "INSERT INTO pro_proveedor_servicio VALUES " . substr($registros, 0, -1);
            return SQLServer::instancia()->insertar($consulta, $servicios);
        }
        return array(0, "No se recibieron los campos obligatorios para relacionar servicios");
    }

}
