<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla y vista de firewalls.
 * 
 * @package app\firewall\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class FirewallColeccion {

    /**
     * Buscar firewalls a partir del nombre, marca, sitio y estado. De la
     * consulta se obtienen todos los campos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombreFirewall Nombre o parte del nombre del firewall (LIKE).
     * @param string $marca Marca del fiwarall (LIKE).
     * @param string $nombreSitio Nombre del sitio (LIKE).
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscar($nombreFirewall, $marca, $nombreSitio, $estado) {
        $consulta = "SELECT * FROM vwfir_firewall WHERE nombreFirewall LIKE ? "
                . "AND marcaFirewall LIKE ? AND nombreSitio LIKE ? "
                . "AND estadoFirewall = ?";
        $datos = array("%{$nombreFirewall}%", "%{$marca}%", "%{$nombreSitio}%", $estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    /**
     * Busca los registros de un determinado informe.
     * @param int idInforme Identificador del informe solicitado.
     * return array Arreglo nulo, vacio o con la informacion del reporte.
     */
    private static function buscarDatosInforme($idInforme) {
        $consulta = "SELECT detalle, total FROM vwfir_informes WHERE id = ? ORDER BY detalle";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$idInforme));
        if ($resultado[0] == 2) {
            $datos = array();
            while ($registro = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $datos[] = array('detalle' => $registro['detalle'], 'total' => $registro['total']);
            }
            return $datos;
        }
        return NULL;
    }

    /**
     * Busca los informes disponibles y agrupa su informacion.
     */
    public static function buscarInformesFirewall() {
        $consulta = "SELECT DISTINCT id, informe, COUNT(*) distribucion "
                . " FROM vwfir_informes GROUP BY id, informe ORDER BY id";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        if ($resultado[0] == 2) {
            $informes = array();
            while ($informe = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $datos = FirewallColeccion::buscarDatosInforme($informe['id']);
                $informes[] = array($informe['id'], $informe['informe'], $informe['distribucion'], $datos);
            }
            return array(2, $informes);
        }
        return $resultado;
    }

    /**
     * Buscar firewalls ordenadas por fecha de creacion descendente con un tope
     * de registros y un estado. De la consulta se obtienen todos los campos de
     * la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $top Cantidad maxima de registros a seleccionar.
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarUltimosCreados($top, $estado) {
        $consulta = "SELECT TOP(?) * FROM vwfir_firewall "
                . "WHERE estadoFirewall = ? ORDER BY fechaCreacionFirewall DESC";
        $datos = array(&$top, &$estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

}
