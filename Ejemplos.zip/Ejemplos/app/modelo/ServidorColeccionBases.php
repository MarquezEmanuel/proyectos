<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ServidorColeccionBases {

    /**
     * Buscar bases de datos cargadas automaticamente a partir de su nombre. 
     * De la consulta se obtiene el identificador y nombre. El objetivo del metodo 
     * es obtener los datos necesarios para seleccionar y relacionar.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombreBase Nombre o parte del nombre de la base de datos (LIKE).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public function buscarParaSeleccionar($nombreBase) {
        $consulta = "SELECT id, nombre FROM ser_base_datos ORDER BY nombre ASC";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombreBase}%"));
    }

}
