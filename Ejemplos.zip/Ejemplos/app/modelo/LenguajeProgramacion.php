<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla de lenguajes.
 * 
 * @package app\lenguaje\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class LenguajeProgramacion {

    /** @var int Identificador de la plataforma [BIGINT] */
    private $id;

    /** @var string Nombre [NVARCHAR(50) NOT NULL] */
    private $nombre;

    /** @var string Version [NVARCHAR(20) NOT NULL] */
    private $version;

    /** @var string Descripcion [NVARCHAR(100) NOT NULL] */
    private $descripcion;

    /** @var string Estado [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var string Fecha de creacion [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de edicion [SMALLDATETIME NULL] */
    private $fechaEdicion;

    public function __construct($id = NULL, $nombre = NULL, $version = NULL, $descripcion = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setVersion($version);
        $this->setDescripcion($descripcion);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getVersion() {
        return utf8_encode($this->version);
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = utf8_decode($nombre);
    }

    public function setVersion($version) {
        $this->version = utf8_decode($version);
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = utf8_decode($descripcion);
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function crear() {
        if ($this->nombre && $this->version && $this->descripcion) {
            $consulta = "INSERT INTO len_lenguaje OUTPUT INSERTED.id VALUES (?, ?, ?, 'Activo', GETDATE(), NULL)";
            $datos = array(&$this->nombre, &$this->version, &$this->descripcion);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            $this->id = ($resultado[0] == 2) ? $resultado[2] : NULL;
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear el lenguaje de programación");
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->version) {
            $consulta = "UPDATE len_lenguaje SET nombre=?, version=?, descripcion=?, "
                    . "estado=?, fechaUltimaEdicion=GETDATE() WHERE id=?";
            $datos = array(&$this->nombre, &$this->version, &$this->descripcion, &$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM len_lenguaje WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->version = $fila['version'];
                $this->descripcion = $fila['descripcion'];
                $this->estado = $fila['estado'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al lenguaje de programación");
    }

    public function toString() {
        $lenguaje = ($this->id) ? "{{$this->getId()}," : "{0,";
        $lenguaje .= ($this->nombre) ? "{$this->getNombre()}," : "'',";
        $lenguaje .= ($this->version) ? "{$this->getVersion()}," : "'',";
        $lenguaje .= ($this->estado) ? "{$this->getEstado()}}" : "''}";
        return $lenguaje;
    }

}
