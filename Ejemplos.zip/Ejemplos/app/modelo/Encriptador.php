<?php

namespace app\modelo;

/**
 * Encripta o desencripta cadenas de texto.
 * 
 * @package app\principal\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Encriptador {

    private $iv;

    /**
     * Constructor de clase. 
     */
    public function __construct() {
        $this->iv = NULL;
    }

    /**
     * Encriptar cadena de texto.
     * @param string $datos Cadena de texto a encriptar.
     * @param string $clave Clave de encriptacion/desencriptacion.
     * @return string Cadena de texto encriptada con la clave indicada.
     */
    public function encriptar($datos, $clave) {
        $encryption_key = base64_decode($clave);
        $this->iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
        $encrypted = openssl_encrypt($datos, 'aes-256-cbc', $encryption_key, 0, $this->iv);
        return base64_encode($encrypted . '::' . $this->iv);
    }

    /**
     * Desencriptar cadena de texto.
     * @param string $datos Cadena de texto a desencriptar.
     * @param string $clave Clave de encriptacion/desencriptacion.
     * @return string Cadena de texto desencriptada con la clave indicada.
     */
    public function desencriptar($datos, $clave) {
        $encryption_key = base64_decode($clave);
        list($encrypted_data, $this->iv) = explode('::', base64_decode($datos), 2);
        return openssl_decrypt($encrypted_data, 'aes-256-cbc', $encryption_key, 0, $this->iv);
    }

}
