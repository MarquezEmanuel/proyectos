<?php

namespace app\utilidad\modelo;

use DateTime;
use DateInterval;

/**
 * Convierte el formato de las fechas.
 * 
 * @package app\util\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class FechaRelativa {

    /** @var string Fecha de inicio para el calculo. */
    private $fechaInicio;

    /** @var string Fecha media para el calculo. */
    private $fechaMedia;

    /**
     * Constructor de clase. Inicializa la zona horaria para Buenos Aires y establece
     * la fecha de inicio como 1900-01-01 y la fecha media como 1957-01-01.
     */
    public function __construct() {
        date_default_timezone_set('America/Argentina/Buenos_Aires');
        $this->fechaInicio = new DateTime("1900-01-01");
        $this->fechaMedia = new DateTime("1957-01-01");
    }

    /**
     * Convierte una fecha gregoriana a fecha relativa.
     * @param string $fecha Fecha gregoriana.
     * @return int Fecha convertida en forma relativa.
     */
    public function convertirARelativa($fecha) {
        $date = new DateTime($fecha);
        $diferenciaInicio = $this->fechaInicio->diff($date);
        $diferenciaMedia = $this->fechaInicio->diff($this->fechaMedia);
        return ($diferenciaInicio->days - $diferenciaMedia->days);
    }

    /**
     * Convierte una fecha relativa en fecha gregoriana.
     * @param int $numero Fecha en forma relativa.
     * @return string Fecha convertida en forma gregoriana.
     */
    public function convertirAFecha($numero) {
        $diferenciaMedia = $this->fechaInicio->diff($this->fechaMedia);
        $dias = $diferenciaMedia->days + $numero + 1;
        $this->fechaInicio->add(new DateInterval('P' . $dias . 'D'));
        return $this->fechaInicio->format('Y-m-d');
    }

}
