<?php

namespace app\modelo;

use app\modelo\SQLServer;
use app\modelo\HardwareColeccion as Hardwares;

/**
 * Mapea con la tabla de base de datos manual.
 * 
 * @package app\base\modelo.
 * 
 * @uses SQLServer app\principal\modelo\SQLServer.
 * @uses ColeccionHardwares app\hardware\modelo\ColeccionHardwares.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 * 
 * @version 1.1
 */
class BaseDatosManual {

    /** @var int Identificador del registro [BIGINT] */
    private $id;

    /** @var string Nombre de la base de datos [NVARCHAR(100) NOT NULL] */
    private $nombre;

    /** @var string Collation [NVARCHAR(100) NULL] */
    private $collation;

    /** @var string Estado de la base de datos [NVARCHAR(50) NULL] */
    private $estadoBase;

    /** @var string Riesgo de TI [NVARCHAR(5) NOT NULL] */
    private $rti;

    /** @var string Descripcion del elemento auxiliar [NVARCHAR(500) NOT NULL] */
    private $descripcion;

    /** @var string Estado del activo [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var int Nivel de visibilidad del activo [INT NOT NULL] */
    private $visibilidad;

    /** @var string Fecha de creacion [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de edicion [SMALLDATETIME NULL] */
    private $fechaEdicion;

    /** @var array Servidores asociados */
    private $servidores;

    public function __construct($id = NULL, $nombre = NULL, $collation = NULL, $estadoBase = NULL, $rti = NULL, $descripcion = NULL, $estado = NULL, $visibilidad = NULL, $servidores = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setCollation($collation);
        $this->setEstadoBase($estadoBase);
        $this->setRti($rti);
        $this->setDescripcion($descripcion);
        $this->setEstado($estado);
        $this->setVisibilidad($visibilidad);
        $this->setServidores($servidores);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getCollation() {
        return $this->collation;
    }

    public function getEstadoBase() {
        return $this->estadoBase;
    }

    public function getServidores() {
        return $this->servidores;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getVisibilidad() {
        return $this->visibilidad;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setNombre($nombre) {
        if ($nombre && (strlen($nombre) <= 100)) {
            $this->nombre = utf8_decode($nombre);
        }
    }

    public function setCollation($collation) {
        if ($collation && (strlen($collation) <= 100)) {
            $this->collation = utf8_decode($collation);
        }
    }

    public function setEstadoBase($estadoBase) {
        if ($estadoBase && (strlen($estadoBase) <= 50)) {
            $this->estadoBase = utf8_decode($estadoBase);
        }
    }

    public function setServidores($servidores) {
        $this->servidores = $servidores;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = utf8_decode($descripcion);
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setVisibilidad($visibilidad) {
        $this->visibilidad = ($visibilidad > 0) ? $visibilidad : NULL;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function crear() {
        if ($this->nombre && $this->collation && $this->estadoBase && $this->servidores) {
            $consulta = "INSERT INTO bas_base OUTPUT INSERTED.id "
                    . "VALUES (? ,?, ?, 'Si', ?, 'Activa', 1, GETDATE(), NULL)";
            $datos = array(&$this->nombre, &$this->collation, &$this->estadoBase, &$this->descripcion);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            if ($resultado[0] == 2) {
                $this->id = $resultado[2];
                $rcrear = BaseDatosManualHardware::crear($this->id, $this->servidores);
                $resultado = ($rcrear[0] == 2) ? $resultado : $rcrear;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear la base de datos");
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->servidores) {
            $consulta = "UPDATE bas_base SET nombre=?, collation=?, estadoBase=?, descripcion = ?, "
                    . " estado=?, fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->nombre, &$this->collation, &$this->estadoBase, &$this->descripcion, &$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            if ($resultado[0] == 2) {
                $actualizar = BaseDatosManualHardware::actualizarHardwaresBase($this->id, $this->servidores);
                $resultado = ($actualizar[0] == 2) ? $resultado : $actualizar;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para modificar la base de datos");
    }

    /**
     * Permite modificar los datos del activo que corresponde a Control de Gestion
     * de Tecnologia Informatica (CGTI). Este metodo actualiza los campos
     * rti, nivel de visibilidad y fecha de ultima edicion.
     * @return array Arreglo con dos elementos [codigo, mensaje].
     */
    public function modificarCGTI() {
        if ($this->id && $this->rti && $this->visibilidad) {
            $consulta = "UPDATE bas_base SET rti = ?, nivelVisibilidad = ?, "
                    . "fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->rti, &$this->visibilidad, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para modificar base de datos");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM bas_base WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->collation = $fila['collation'];
                $this->estadoBase = $fila['estadoBase'];
                $this->rti = $fila['rti'];
                $this->descripcion = $fila['descripcion'];
                $this->estado = $fila['estado'];
                $this->visibilidad = $fila['nivelVisibilidad'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información del elemento auxiliar correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la base de datos");
    }

    public function obtenerServidores() {
        $this->servidores = NULL;
        $resultado = Hardwares::buscarHardwaresBaseDatosManual($this->id);
        if ($resultado[0] == 2) {
            $servidores = $resultado[1];
            while ($servidor = sqlsrv_fetch_array($servidores, SQLSRV_FETCH_ASSOC)) {
                $this->servidores[$servidor['orden']] = $servidor;
            }
            $resultado[1] = ($this->servidores) ? NULL : $resultado[1];
        }
        return $resultado;
    }

    public function toString() {
        $base = ($this->id) ? "{{$this->id}," : "{0,";
        $base .= ($this->nombre) ? "'{$this->getNombre()}'," : "'',";
        $base .= ($this->collation) ? "'{$this->getCollation()}'," : "'',";
        $base .= ($this->estadoBase) ? "'{$this->getEstadoBase()}'," : "'',";
        $base .= ($this->estado) ? "'{$this->getEstado()}'," : "'',";
        $base .= ($this->visibilidad) ? "{$this->visibilidad}," : "0,";
        $base .= ($this->servidores) ? count($this->servidores) . "}" : "0}";
        return $base;
    }

}
