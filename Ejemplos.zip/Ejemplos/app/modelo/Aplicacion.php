<?php

namespace app\modelo;

use app\modelo\SQLServer;
use app\modelo\AplicacionBaseDatos;
use app\modelo\AplicacionProveedor;
use app\modelo\AplicacionDespliegue as Despliegue;
use app\modelo\LenguajeProgramacion;
use app\modelo\HerramientaDesarrollo;
use app\modelo\Gerencia;
use app\modelo\Empleado;
use app\modelo\PlataformaSO;
use app\modelo\ModoProcesamiento;
use app\modelo\LugarProcesamiento;
use app\modelo\BaseDatosManualColeccion as Bases;
use app\modelo\ProveedorColeccion as Proveedores;
use app\modelo\HardwareColeccion as Hardwares;

class Aplicacion {

    private $id;
    private $nombreCorto;
    private $nombreLargo;
    private $tipo;
    private $seguridad;
    private $tecnologia;
    private $lenguaje;
    private $herramienta;
    private $modoProcesamiento;
    private $lugarProcesamiento;
    private $plataforma;
    private $gerencia;
    private $empleado;
    private $fechaCaducidad;
    private $codigoSAS;
    private $tipoLog;
    private $confidencialidad;
    private $integridad;
    private $disponibilidad;
    private $criticidad;
    private $rti;
    private $descripcion;
    private $estado;
    private $visibilidad;
    private $fechaCreacion;
    private $fechaEdicion;
    private $basesDatos;
    private $proveedores;
    private $servidores;

    /**
     * @param int $id Identificador del registro [PK BIGINT].
     * @param string $nombreCorto Nombre corto del personal [NVARCHAR(20)].
     * @param string $nombreLargo Nombre largo del personal [NVARCHAR(50)].
     * @param string $tipo Tipo de aplicacion [NVARCHAR(20)].
     * @param string $seguridad Tipo de seguridad [NVARCHAR(50)].
     * @param string $tecnologia Tipo de tecnologia [NVARCHAR(50)].
     * @param string $lenguaje Lenguaje de programacion o identificador de lenguaje [FK BIGINT].
     * @param string $herramienta Herramienta de desarrollo o identificador de herramienta [FK BIGINT].
     * @param string $modo Modo de procesamiento o identificador de modo [FK BIGINT].
     * @param string $lugar Lugar de procesamiento o identificador de lugar [FK BIGINT].
     * @param string $plataforma Plataforma SO o identificador plataforma [FK BIGINT].
     * @param string $gerencia Gerencia o identificador de gerencia [FK BIGINT].
     * @param string $empleado Empleado o identificador empleado [FK NVARCHAR(10)].
     * @param string $fechaCaducidad Fecha de caducidad de la licencia [SMALLDATETIME].
     * @param string $codigoSAS Codigo de aplicacion SAS [NVARCHAR(100)].
     * @param string $tipoLog Tipo de log que maneja la apliacion [NVARCHAR(30)].
     * @param int $confidencialidad Calificacion de confidencialidad [INT].
     * @param int $integridad Calificacion de integridad [INT].
     * @param int $disponibilidad Calificacion de disponibilidad [INT].
     * @param int $criticidad Calificacion de criticidad [INT].
     * @param string $rti Riesgo de TI [NVARCHAR(5)].
     * @param string $descripcion Descripcion adicional [NVARCHAR(500)].
     * @param string $estado Estado activa o inactiva [NVARCHAR(20)].
     * @param int $visibilidad int Nivel de visibilidad [INT].
     * @param array $basesDatos Arreglo de bases de datos asocidadas.
     * @param array $proveedores Arreglo de proveedores asociados.
     */
    public function __construct($id = NULL, $nombreCorto = NULL, $nombreLargo = NULL, $tipo = NULL, $seguridad = NULL, $tecnologia = NULL, $lenguaje = NULL, $herramienta = NULL, $modo = NULL, $lugar = NULL, $plataforma = NULL, $gerencia = NULL, $empleado = NULL, $fechaCaducidad = NULL, $codigoSAS = NULL, $tipoLog = NULL, $confidencialidad = NULL, $integridad = NULL, $disponibilidad = NULL, $criticidad = NULL, $rti = NULL, $descripcion = NULL, $estado = NULL, $visibilidad = NULL, $basesDatos = NULL, $proveedores = NULL) {
        $this->setId($id);
        $this->setNombreCorto($nombreCorto);
        $this->setNombreLargo($nombreLargo);
        $this->setTipo($tipo);
        $this->setSeguridad($seguridad);
        $this->setTecnologia($tecnologia);
        $this->setLenguaje($lenguaje);
        $this->setHerramienta($herramienta);
        $this->setModoProcesamiento($modo);
        $this->setLugarProcesamiento($lugar);
        $this->setPlataforma($plataforma);
        $this->setGerencia($gerencia);
        $this->setEmpleado($empleado);
        $this->setFechaCaducidad($fechaCaducidad);
        $this->setCodigoSAS($codigoSAS);
        $this->setTipoLog($tipoLog);
        $this->setConfidencialidad($confidencialidad);
        $this->setIntegridad($integridad);
        $this->setDisponibilidad($disponibilidad);
        $this->setCriticidad($criticidad);
        $this->setRti($rti);
        $this->setDescripcion($descripcion);
        $this->setEstado($estado);
        $this->setVisibilidad($visibilidad);
        $this->setBasesDatos($basesDatos);
        $this->setProveedores($proveedores);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombreCorto() {
        return utf8_encode($this->nombreCorto);
    }

    public function getNombreLargo() {
        return utf8_encode($this->nombreLargo);
    }

    public function getTipo() {
        return utf8_encode($this->tipo);
    }

    public function getSeguridad() {
        return utf8_encode($this->seguridad);
    }

    public function getTecnologia() {
        return utf8_encode($this->tecnologia);
    }

    public function getLenguaje() {
        return $this->lenguaje;
    }

    public function getHerramienta() {
        return $this->herramienta;
    }

    public function getBasesDatos() {
        return $this->basesDatos;
    }

    public function getModoProcesamiento() {
        return $this->modoProcesamiento;
    }

    public function getLugarProcesamiento() {
        return $this->lugarProcesamiento;
    }

    public function getPlataforma() {
        return $this->plataforma;
    }

    public function getGerencia() {
        return $this->gerencia;
    }

    public function getEmpleado() {
        return $this->empleado;
    }

    public function getFechaCaducidad() {
        return $this->fechaCaducidad;
    }

    public function getCodigoSAS() {
        return utf8_encode($this->codigoSAS);
    }

    public function getTipoLog() {
        return utf8_encode($this->tipoLog);
    }

    public function getConfidencialidad() {
        return $this->confidencialidad;
    }

    public function getIntegridad() {
        return $this->integridad;
    }

    public function getDisponibilidad() {
        return $this->disponibilidad;
    }

    public function getCriticidad() {
        return $this->criticidad;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getVisibilidad() {
        return $this->visibilidad;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function getProveedores() {
        return $this->proveedores;
    }

    public function getServidores() {
        return $this->servidores;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombreCorto($nombreCorto) {
        $this->nombreCorto = utf8_decode($nombreCorto);
    }

    public function setNombreLargo($nombreLargo) {
        $this->nombreLargo = utf8_decode($nombreLargo);
    }

    public function setTipo($tipo) {
        $this->tipo = utf8_decode($tipo);
    }

    public function setSeguridad($seguridad) {
        $this->seguridad = utf8_decode($seguridad);
    }

    public function setTecnologia($tecnologia) {
        $this->tecnologia = utf8_decode($tecnologia);
    }

    public function setLenguaje($lenguaje) {
        $this->lenguaje = $lenguaje;
    }

    public function setHerramienta($herramienta) {
        $this->herramienta = $herramienta;
    }

    public function setBasesDatos($basesDatos) {
        $this->basesDatos = $basesDatos;
    }

    public function setModoProcesamiento($modoProcesamiento) {
        $this->modoProcesamiento = $modoProcesamiento;
    }

    public function setLugarProcesamiento($lugarProcesamiento) {
        $this->lugarProcesamiento = $lugarProcesamiento;
    }

    public function setPlataforma($plataforma) {
        $this->plataforma = $plataforma;
    }

    public function setGerencia($gerencia) {
        $this->gerencia = $gerencia;
    }

    public function setEmpleado($empleado) {
        $this->empleado = $empleado;
    }

    public function setFechaCaducidad($fechaCaducidad) {
        $this->fechaCaducidad = $fechaCaducidad;
    }

    public function setCodigoSAS($codigoSAS) {
        $this->codigoSAS = utf8_decode($codigoSAS);
    }

    public function setTipoLog($tipoLog) {
        $this->tipoLog = utf8_decode($tipoLog);
    }

    public function setConfidencialidad($confidencialidad) {
        $this->confidencialidad = $confidencialidad;
    }

    public function setIntegridad($integridad) {
        $this->integridad = $integridad;
    }

    public function setDisponibilidad($disponibilidad) {
        $this->disponibilidad = $disponibilidad;
    }

    public function setCriticidad($criticidad) {
        $this->criticidad = $criticidad;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = utf8_decode($descripcion);
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setVisibilidad($visibilidad) {
        $this->visibilidad = $visibilidad;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function setProveedores($proveedores) {
        $this->proveedores = $proveedores;
    }

    public function setServidores($servidores) {
        $this->servidores = $servidores;
    }

    public function crear() {
        if ($this->nombreCorto && $this->nombreLargo && $this->tipo && $this->seguridad && $this->tecnologia && $this->modoProcesamiento && $this->lugarProcesamiento && $this->tipoLog) {
            $consulta = "INSERT INTO apl_aplicacion OUTPUT INSERTED.id VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL,NULL,NULL,NULL,'Si',?,'Activa',1,GETDATE(),NULL)";
            $datos = array(&$this->nombreCorto, &$this->nombreLargo, &$this->tipo, &$this->seguridad, &$this->tecnologia, &$this->lenguaje, &$this->herramienta, &$this->modoProcesamiento, &$this->lugarProcesamiento, &$this->plataforma, &$this->gerencia, &$this->empleado, &$this->fechaCaducidad, &$this->codigoSAS, &$this->tipoLog, &$this->descripcion);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            if ($resultado[0] == 2) {
                $this->id = $resultado[2];
                $rbase = AplicacionBaseDatos::crear($this->id, $this->basesDatos);
                $raplicacion = AplicacionProveedor::crear($this->id, $this->proveedores);
                $resultado = ($raplicacion[0] == 2 && $rbase[0] == 2) ? $resultado : array(1, "No se realizó la creación de la aplicación");
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear aplicación");
    }

    /**
     * Permite modificar los datos correspondientes a Sistemas.
     */
    public function modificarSistemas() {
        if ($this->id) {
            $consulta = "UPDATE apl_aplicacion SET nombreCorto=?, nombreLargo=?, "
                    . "tipo=?, seguridad=?, tecnologia=?, idLenguaje=?, idHerramienta=?, "
                    . "idModoProcesamiento=?, idLugarProcesamiento=?, idPlataforma=?, "
                    . "idGerencia=?, idEmpleado=?, fechaCaducidad=?, codigoSAS=?, tipoLog=?, "
                    . "descripcion=?, estado=?, fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->nombreCorto, &$this->nombreLargo, &$this->tipo, &$this->seguridad, &$this->tecnologia, &$this->lenguaje, &$this->herramienta, &$this->modoProcesamiento, &$this->lugarProcesamiento, &$this->plataforma, &$this->gerencia, &$this->empleado, &$this->fechaCaducidad, &$this->codigoSAS, &$this->tipoLog, &$this->descripcion, &$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            if ($resultado[0] == 2) {
                $rbase = AplicacionBaseDatos::actualizarBasesAplicacion($this->id, $this->basesDatos);
                $raplicacion = AplicacionProveedor::actualizarProveedoresAplicacion($this->id, $this->proveedores);
                $resultado = ($raplicacion[0] == 2 && $rbase[0] == 2) ? $resultado : array(1, "No se realizó la modificación de la aplicación");
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para modificar aplicación");
    }

    /**
     * Permite modificar los datos correspondientes a Tecnologia.
     */
    public function modificarTecnologiaInformatica() {
        if ($this->id && $this->servidores) {
            return Despliegue::actualizarHardwaresAplicacion($this->id, $this->servidores);
        }
        return array(0, "No se recibieron los campos obligatorios para modificar aplicación");
    }

    /**
     * Permite modificar los datos correspondientes a Proteccion de Activos de la Informacion.
     */
    public function modificarPAI() {
        if ($this->id && $this->confidencialidad && $this->integridad && $this->disponibilidad && $this->criticidad) {
            $consulta = "UPDATE apl_aplicacion SET confidencialidad = ?, integridad = ?, "
                    . " disponibilidad = ?, criticidad = ?, fechaUltimaEdicion = GETDATE() "
                    . " WHERE id=?";
            $datos = array(&$this->confidencialidad, &$this->integridad, &$this->disponibilidad, &$this->criticidad, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para modificar aplicación");
    }

    /**
     * Permite modificar los datos del activo que corresponde a Control de Gestion
     * de Tecnologia Informatica (CGTI). Este metodo actualiza los campos
     * rti, nivel de visibilidad y fecha de ultima edicion.
     * @return array Arreglo con dos elementos [codigo, mensaje].
     */
    public function modificarCGTI() {
        if ($this->id && $this->rti && $this->visibilidad) {
            $consulta = "UPDATE apl_aplicacion SET rti = ?, nivelVisibilidad = ?, "
                    . "fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->rti, &$this->visibilidad, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para modificar aplicación");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM apl_aplicacion WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombreCorto = $fila['nombreCorto'];
                $this->nombreLargo = $fila['nombreLargo'];
                $this->tipo = $fila['tipo'];
                $this->seguridad = $fila['seguridad'];
                $this->tecnologia = $fila['tecnologia'];
                $this->lenguaje = $fila['idLenguaje'];
                $this->herramienta = $fila['idHerramienta'];
                $this->modoProcesamiento = $fila['idModoProcesamiento'];
                $this->lugarProcesamiento = $fila['idLugarProcesamiento'];
                $this->plataforma = $fila['idPlataforma'];
                $this->gerencia = $fila['idGerencia'];
                $this->empleado = $fila['idEmpleado'];
                $this->fechaCaducidad = $fila['fechaCaducidad'];
                $this->codigoSAS = $fila['codigoSAS'];
                $this->tipoLog = $fila['tipoLog'];
                $this->confidencialidad = $fila['confidencialidad'];
                $this->integridad = $fila['integridad'];
                $this->disponibilidad = $fila['disponibilidad'];
                $this->criticidad = $fila['criticidad'];
                $this->rti = $fila['rti'];
                $this->descripcion = $fila['descripcion'];
                $this->estado = $fila['estado'];
                $this->visibilidad = $fila['nivelVisibilidad'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la aplicación");
    }

    public function obtenerLenguaje() {
        $lenguaje = new LenguajeProgramacion($this->lenguaje);
        $resultado = $lenguaje->obtener();
        $this->lenguaje = ($resultado[0] == 2) ? $lenguaje : NULL;
        return $resultado;
    }

    public function obtenerHerramienta() {
        $herramienta = new HerramientaDesarrollo($this->herramienta);
        $resultado = $herramienta->obtener();
        $this->herramienta = ($resultado[0] == 2) ? $herramienta : NULL;
        return $resultado;
    }

    public function obtenerModo() {
        $modo = new ModoProcesamiento($this->modoProcesamiento);
        $resultado = $modo->obtener();
        $this->modoProcesamiento = ($resultado[0] == 2) ? $modo : NULL;
        return $resultado;
    }

    public function obtenerLugar() {
        $lugar = new LugarProcesamiento($this->lugarProcesamiento);
        $resultado = $lugar->obtener();
        $this->lugarProcesamiento = ($resultado[0] == 2) ? $lugar : NULL;
        return $resultado;
    }

    public function obtenerPlataforma() {
        $plataforma = new PlataformaSO($this->plataforma);
        $resultado = $plataforma->obtener();
        $this->plataforma = ($resultado[0] == 2) ? $plataforma : NULL;
        return $resultado;
    }

    public function obtenerGerencia() {
        $gerencia = new Gerencia($this->gerencia);
        $resultado = $gerencia->obtener();
        $this->gerencia = ($resultado[0] == 2) ? $gerencia : NULL;
        return $resultado;
    }

    public function obtenerEmpleado() {
        $empleado = new Empleado($this->empleado);
        $resultado = $empleado->obtener();
        $this->empleado = ($resultado[0] == 2) ? $empleado : NULL;
        return $resultado;
    }

    public function obtenerBasesDatos() {
        $this->basesDatos = NULL;
        $resultado = Bases::buscarBasesDatosAplicacion($this->id);
        if ($resultado[0] == 2) {
            $bases = $resultado[1];
            while ($base = sqlsrv_fetch_array($bases, SQLSRV_FETCH_ASSOC)) {
                $this->basesDatos[] = $base;
            }
            $resultado[1] = ($this->basesDatos) ? NULL : $resultado[1];
        }
        return $resultado;
    }

    public function obtenerProveedores() {
        $this->proveedores = NULL;
        $resultado = Proveedores::buscarProveedoresAplicacion($this->id);
        if ($resultado[0] == 2) {
            $proveedores = $resultado[1];
            while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
                $this->proveedores[] = $proveedor;
            }
            $resultado[1] = ($this->proveedores) ? NULL : $resultado[1];
        }
        return $resultado;
    }

    public function obtenerServidores() {
        $this->servidores = NULL;
        $resultado = Hardwares::buscarHardwaresAplicacion($this->id);
        if ($resultado[0] == 2) {
            $servidores = $resultado[1];
            while ($servidor = sqlsrv_fetch_array($servidores, SQLSRV_FETCH_ASSOC)) {
                $this->servidores[] = $servidor;
            }
            $resultado[1] = ($this->servidores) ? NULL : $resultado[1];
        }
        return $resultado;
    }

    public function toString() {
        $aplicacion = ($this->id) ? "{{$this->id}," : "{0,";
        $aplicacion .= ($this->nombreCorto) ? "'{$this->getNombreCorto()}'," : "'',";
        $aplicacion .= ($this->nombreLargo) ? "'{$this->getNombreLargo()}'," : "'',";
        $aplicacion .= ($this->tipo) ? "{$this->getTipo()}," : ",";
        $aplicacion .= ($this->seguridad) ? "{$this->getSeguridad()}," : ",";
        $aplicacion .= ($this->tecnologia) ? "{$this->getTecnologia()}," : ",";
        $aplicacion .= ($this->lenguaje && gettype($this->lenguaje) == "integer") ? "{$this->lenguaje}," : ",";
        $aplicacion .= ($this->herramienta && gettype($this->herramienta) == "integer") ? "{$this->herramienta}," : ",";
        $aplicacion .= ($this->modoProcesamiento && gettype($this->modoProcesamiento) == "integer") ? "{$this->modoProcesamiento}," : ",";
        $aplicacion .= ($this->lugarProcesamiento && gettype($this->lugarProcesamiento) == "integer") ? "{$this->lugarProcesamiento}," : ",";
        $aplicacion .= ($this->plataforma && gettype($this->plataforma) == "integer") ? "{$this->plataforma}," : ",";
        $aplicacion .= ($this->gerencia && gettype($this->gerencia) == "integer") ? "{$this->gerencia}," : ",";
        $aplicacion .= ($this->empleado && gettype($this->empleado) == "string") ? "'{$this->empleado}'," : "'',";
        $aplicacion .= ($this->codigoSAS) ? "'{$this->getCodigoSAS()}'," : "'',";
        $aplicacion .= ($this->confidencialidad) ? "'{$this->confidencialidad}'," : "'',";
        $aplicacion .= ($this->integridad) ? "'{$this->integridad}'," : "'',";
        $aplicacion .= ($this->disponibilidad) ? "'{$this->disponibilidad}'," : "'',";
        $aplicacion .= ($this->criticidad) ? "'{$this->criticidad}'," : "'',";
        $aplicacion .= ($this->estado) ? "'{$this->getEstado()}'," : "'',";
        $aplicacion .= ($this->visibilidad) ? "{$this->visibilidad}}" : "0}";
        return $aplicacion;
    }

}
