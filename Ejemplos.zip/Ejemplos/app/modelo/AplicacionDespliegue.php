<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla que relaciona las aplicaciones con los hardwares.
 * 
 * @package app\aplicacion\modelo.
 * 
 * @uses apl_despliegue Tabla relacion de aplicacion con hardware.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 * 
 * @version 1.0
 */
class AplicacionDespliegue {

    /**
     * Realiza la eliminacion de los hardwares asociados a la aplicacion y 
     * luego la creacion de los nuevos hardwares asociados.
     * @param int $idAplicacion Identificador del activo.
     * @param array $hardwares Arreglo con los identificadores de los hardwares.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function actualizarHardwaresAplicacion($idAplicacion, $hardwares) {
        $resultado = AplicacionDespliegue::borrar($idAplicacion);
        if ($resultado[0] == 2) {
            $resultado = AplicacionDespliegue::crear($idAplicacion, $hardwares);
        }
        return $resultado;
    }

    /**
     * Elimina todos los hardwares asociados a un activo aplicacion.
     * @see SQLServer::$instancia->borrar
     * @param int $idAplicacion Identificador del activo.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function borrar($idAplicacion) {
        if ($idAplicacion > 0) {
            $consulta = "DELETE FROM apl_despliegue WHERE idAplicacion = ?";
            $resultado = SQLServer::$instancia->borrar($consulta, array(&$idAplicacion));
            $resultado[0] = ($resultado[0] == 1) ? 2 : $resultado[0];
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la aplicación para quitar relacion con hardware");
    }

    /**
     * Crea todas las relaciones de un activo aplicacion con sus hardwares.
     * @see SQLServer::instancia()->insertar
     * @param int $idAplicacion Identificador del activo.
     * @param array $hardwares Arreglo con los identificadores de los hardwares.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function crear($idAplicacion, $hardwares) {
        if ($idAplicacion > 0 && !empty($hardwares)) {
            $registros = "";
            foreach ($hardwares as $hardware) {
                $idHardware = $hardware[0];
                $orden = $hardware[1];
                $ruta = ($hardware[2]) ? "'{$hardware[2]}'" : "NULL";
                $registros .= "({$idAplicacion}, {$idHardware}, {$orden}, {$ruta}, GETDATE()),";
            }
            $consulta = "INSERT INTO apl_despliegue VALUES " . substr($registros, 0, -1);
            $resultado = SQLServer::instancia()->insertar($consulta, array());
            $resultado[1] = ($resultado[0] == 2) ? "Se realizó la asociación correctamente" : $resultado[1];
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para relacionar hardware");
    }

}
