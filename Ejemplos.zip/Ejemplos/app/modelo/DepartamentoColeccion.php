<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla y vista de departamentos.
 * 
 * @package app\gerencia\modelo.
 * 
 * @uses vwger_departamento Vista de departamentos.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class DepartamentoColeccion {

    /**
     * Buscar departamentos a partir del nombre, nombre gerencia y estado. De la
     * consulta se obtienen todos los campos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombreDepartamento Nombre o parte del nombre del departamento (LIKE).
     * @param string $nombreGerencia Nombre o parte del nombre de la gerencia (LIKE).
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscar($nombreDepartamento, $nombreGerencia, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM vwger_departamento "
                    . "WHERE nombreDepartamento LIKE ? AND "
                    . "nombreGerencia LIKE ? AND estadoDepartamento = ?";
            $datos = array("%{$nombreDepartamento}%", "%{$nombreGerencia}%", &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar departamentos");
    }

    /**
     * Buscar departamento en estado activo a partir de su nombre. De la consulta se 
     * obtiene el id, nombre. El objetivo del metodo es obtener los datos necesarios 
     * para seleccionar y relacionar.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre o parte del nombre del departamento (LIKE).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarParaSeleccionar($nombre) {
        $consulta = "SELECT id, nombre FROM ger_departamento "
                . "WHERE nombre LIKE ? AND estado = 'Activo' "
                . "ORDER BY nombre";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombre}%"));
    }

    /**
     * Buscar departamentos ordenados por fecha de creacion descendente con un tope
     * de registros y un estado. De la consulta se obtienen todos los campos de
     * la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $top Cantidad maxima de registros a seleccionar.
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarUltimosCreados($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM vwger_departamento "
                    . "WHERE estadoDepartamento = ? "
                    . "ORDER BY fechaCreacionDepartamento DESC";
            $datos = array(&$top, &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar departamentos");
    }

}
