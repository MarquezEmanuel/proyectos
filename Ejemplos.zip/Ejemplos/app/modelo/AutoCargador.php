<?php

namespace app\modelo;

/**
 * Realiza la inclusion de los archivos PHP que se utilizan.
 * 
 * @package app\principal\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class AutoCargador {

    /**
     * Incluye los archivos PHP usando SPL_AUTOLOAD_REGISTER. Este metodo requiere
     * que se defina el nombre de espacios desde el ROOT del proyecto.
     * @see Constantes ROOT.
     */
    public static function cargarModulos() {

        spl_autoload_register(function($clase) {
            if (version_compare(phpversion(), '7.1.31', '<')) {
                $ruta = dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "{$clase}.php";
            } else {
                $ruta = dirname(__FILE__, 3) . DIRECTORY_SEPARATOR . "{$clase}.php";
            }
            if (file_exists($ruta)) {
                require_once $ruta;
            }
        });
    }

}
