<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla de lugares de procesamientos.
 * 
 * @package app\procesamiento\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class LugarProcesamientoColeccion {

    /**
     * Buscar lugares de procesamiento a partir del nombre y estado. De la consulta
     * se obtienen todos los campos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre o parte del nombre (LIKE).
     * @param string $estado Estado del lugar (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscar($nombre, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM psa_lugar WHERE nombre LIKE ? AND estado = ?";
            $datos = array("%{$nombre}%", &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar lugares de procesamiento");
    }

    public static function buscarParaSeleccionar($nombre) {
        $consulta = "SELECT id, nombre FROM psa_lugar "
                . "WHERE nombre LIKE ? AND estado = 'Activo'";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombre}%"));
    }

    /**
     * Buscar lugares de procesamiento ordenados por fecha de creacion descendente 
     * con un tope de registros y un estado. De la consulta se obtienen todos los
     * campos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $top Cantidad maxima de registros a seleccionar.
     * @param string $estado Estado del sitio (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarUltimosCreados($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM psa_lugar WHERE estado = ? "
                    . "ORDER BY fechaCreacion DESC";
            $datos = array(&$top, &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar lugares de procesamiento");
    }

}
