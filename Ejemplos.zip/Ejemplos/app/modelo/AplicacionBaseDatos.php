<?php

namespace app\modelo;

use app\modelo\SQLServer;

class AplicacionBaseDatos {

    /**
     * Realiza la eliminacion de las base de datos asociados al activo y luego la
     * creacion de las nuevas bases asociadas.
     * @param int $idAplicacion Identificador del activo.
     * @param array $bases Arreglo con los identificadores de las bases de datos.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function actualizarBasesAplicacion($idAplicacion, $bases) {
        $resultado = AplicacionBaseDatos::borrar($idAplicacion);
        if ($resultado[0] == 2) {
            $resultado = AplicacionBaseDatos::crear($idAplicacion, $bases);
        }
        return $resultado;
    }

    /**
     * Elimina todas las bases de datos asociadas a un activo aplicacion.
     * @see SQLServer::$instancia->borrar
     * @param int $idAplicacion Identificador del activo.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function borrar($idAplicacion) {
        if ($idAplicacion > 0) {
            $consulta = "DELETE FROM apl_aplicacion_base WHERE idAplicacion = ?";
            $eliminacion = SQLServer::$instancia->borrar($consulta, array(&$idAplicacion));
            return $eliminacion;
        }
        return array(0, "No se pudo hacer referencia a la aplicación para asociar bases de datos");
    }

    /**
     * Crea todas las relaciones de un activo aplicacion con sus bases de datos.
     * @see SQLServer::instancia()->insertar
     * @param int $idAplicacion Identificador del activo.
     * @param array $bases Arreglo con los identificadores de las bases de datos.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function crear($idAplicacion, $bases) {
        if ($idAplicacion > 0 && !empty($bases)) {
            $registros = "";
            foreach ($bases as $idBase) {
                $registros .= "({$idAplicacion}, {$idBase}),";
            }
            $consulta = "INSERT INTO apl_aplicacion_base VALUES " . substr($registros, 0, -1);
            $creacion = SQLServer::instancia()->insertar($consulta, array());
            return $creacion;
        }
        if (empty($bases)) {
            return array(2, "Se asociaron las bases de datos correctamente");
        }
        return array(0, "No se recibieron los campos obligatorios para relacionar proveedores");
    }

}
