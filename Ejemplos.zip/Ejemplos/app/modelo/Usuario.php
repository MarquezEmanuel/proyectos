<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla de usuarios.
 * 
 * @package app\seguridad\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Usuario {

    private $id;
    private $nombre;
    private $estado;
    private $perfil;

    public function __construct($id = NULL, $nombre = NULL, $estado = NULL, $perfil = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setEstado($estado);
        $this->setPerfil($perfil);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getPerfil() {
        return $this->perfil;
    }

    public function setId($id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setNombre($nombre) {
        $this->nombre = utf8_decode($nombre);
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setPerfil($perfil) {
        $this->perfil = $perfil;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE seg_usuario SET estado = ? WHERE id = ?";
            $datos = array($this->estado, $this->id);
            $modificacion = SQLServer::instancia()->modificar($consulta, $datos);
            return $modificacion;
        }
        return array(0, "No se pudo hacer referencia al usuario");
    }

    public function crear() {
        if ($this->id && $this->nombre && $this->perfil) {
            $consulta = "INSERT INTO seg_usuario VALUES (?, ?, ?, 'Activo')";
            $datos = array($this->id, $this->nombre, $this->perfil);
            $creacion = SQLServer::instancia()->insertar($consulta, $datos);
            return $creacion;
        }
        return array(0, "No se recibieron los campos obligatorios");
    }

    public function modificar($legajoOriginal) {
        if ($this->id && $this->nombre && $this->perfil) {
            $consulta = "UPDATE seg_usuario SET id = ?, nombre = ?, estado = ?, perfil = ? WHERE id = ?";
            $datos = array($this->id, $this->nombre, &$this->estado, $this->perfil, $legajoOriginal);
            $modificacion = SQLServer::instancia()->modificar($consulta, $datos);
            return $modificacion;
        }
        return array(0, "No se recibieron los campos obligatorios");
    }

    public function login() {
        if ($this->id) {
            $consulta = "SELECT * FROM seg_usuario WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->perfil = $fila['perfil'];
                $this->estado = $fila['estado'];
                return $this->obtenerPerfil();
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al usuario que intenta ingresar");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM seg_usuario WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->perfil = $fila['perfil'];
                $this->estado = $fila['estado'];
                return array(2, "Se obtuvieron los datos del usuario");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al usuario");
    }

    public function obtenerPerfil() {
        $perfil = new Perfil($this->perfil);
        $resultado = $perfil->obtener();
        $this->perfil = ($resultado[0] == 2) ? $perfil : NULL;
        return $resultado;
    }

    public function toString() {
        $usuario = ($this->id) ? "'{$this->id}'; " : "0; ";
        $usuario .= ($this->nombre) ? "'{$this->getNombre()}'; " : "''; ";
        $usuario .= ($this->estado) ? "'{$this->estado}'; " : "''; ";
        return $usuario;
    }

}
