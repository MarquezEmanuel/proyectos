<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla que relaciona herramientas de desarrollo con proveedores.
 * 
 * @package app\herramienta\modelo.
 * 
 * @uses her_herramienta_proveedor Tabla relacion de herramienta con proveedor.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 * 
 * @version 1.0
 * 
 */
class HerramientaDesarrolloProveedor {

    /**
     * Realiza la eliminacion de los proveedores asociados a la herramienta y luego 
     * la creacion de los nuevos proveedores asociados.
     * @param int $idHerramienta Identificador del activo.
     * @param array $proveedores Arreglo con los identificadores de los proveedores.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function actualizarProveedoresHerramienta($idHerramienta, $proveedores) {
        $resultado = HerramientaDesarrolloProveedor::borrar($idHerramienta);
        if ($resultado[0] == 2) {
            $resultado = HerramientaDesarrolloProveedor::crear($idHerramienta, $proveedores);
        }
        return $resultado;
    }

    /**
     * Elimina todos los proveedores asociados a la herramienta.
     * @see SQLServer::$instancia->borrar
     * @param int $idHerramienta Identificador de la herramienta.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function borrar($idHerramienta) {
        if ($idHerramienta > 0) {
            $consulta = "DELETE FROM her_herramienta_proveedor WHERE idHerramienta = ?";
            return SQLServer::$instancia->borrar($consulta, array(&$idHerramienta));
        }
        return array(0, "No se pudo hacer referencia a la herramienta de desarrollo");
    }

    /**
     * Crea todas las relaciones de una herramienta con sus proveedores.
     * @see SQLServer::instancia()->insertar
     * @param int $idHerramienta Identificador de la herramienta.
     * @param array $proveedores Arreglo con los identificadores de los proveedores.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function crear($idHerramienta, $proveedores) {
        if (($idHerramienta > 0) && !empty($proveedores)) {
            $registros = "";
            for ($index = 0; $index < count($proveedores); $index++) {
                $registros .= "({$idHerramienta}, ?),";
            }
            $consulta = "INSERT INTO her_herramienta_proveedor VALUES " . substr($registros, 0, -1);
            return SQLServer::instancia()->insertar($consulta, $proveedores);
        }
        return array(0, "No se recibieron los campos obligatorios para relacionar proveedores");
    }

}
