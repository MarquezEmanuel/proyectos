<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla de sitios.
 * 
 * @package app\sitio\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class SitioColeccion {

    /**
     * Buscar sitios a partir del nombre, provincia, ciudad y estado. De la consulta
     * se obtienen todos los campos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre o parte del nombre (LIKE).
     * @param string $provincia Nombre de provincia o parte del nombre de provincia(LIKE).
     * @param string $ciudad Nombre de ciudad o parte del nombre de ciudad (LIKE).
     * @param string $estado Estado del sitio (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscar($nombre, $provincia, $ciudad, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM sit_sitio WHERE nombre LIKE ? AND provincia LIKE ? AND ciudad LIKE ? AND estado = ?";
            $datos = array("%{$nombre}%", "%{$provincia}%", "%{$ciudad}%", &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar sitios");
    }

    /**
     * Buscar sitios en estado activo a partir de su nombre. De la consulta se 
     * obtiene el id, tipo y nombre. El objetivo del metodo es obtener los datos 
     * necesarios para seleccionar y relacionar.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre o parte del nombre del sitio (LIKE).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarParaSeleccionar($nombre) {
        $consulta = "SELECT id, tipo, nombre FROM sit_sitio WHERE nombre LIKE ? AND estado = 'Activo' ";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombre}%"));
    }

    /**
     * Buscar sitios ordenados por fecha de creacion descendente con un tope
     * de registros y un estado. De la consulta se obtienen todos los campos de
     * la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $top Cantidad maxima de registros a seleccionar.
     * @param string $estado Estado del sitio (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarUltimosCreados($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM sit_sitio WHERE estado = ? "
                    . "ORDER BY fechaCreacion DESC";
            $datos = array(&$top, &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar sitios");
    }

    public static function listarReporte() {
        $consulta = "SELECT snombre, stipo, comunicaciones, firewalls, hardwares, instalaciones, switchs FROM vwsit_sitio WHERE sestado = 'Activo'";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        return $resultado;
    }

}
