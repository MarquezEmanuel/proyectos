<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla de permsisos.
 * 
 * @package app\seguridad\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Permiso {

    private $id;
    private $titulo;
    private $descripcion;
    private $nivel;
    private $padre;
    private $link;

    public function __construct($id = NULL, $titulo = NULL, $descripcion = NULL, $nivel = NULL, $padre = NULL, $link = NULL) {
        $this->id = $id;
        $this->titulo = utf8_decode($titulo);
        $this->descripcion = utf8_decode($descripcion);
        $this->nivel = $nivel;
        $this->padre = $padre;
        $this->link = $link;
    }

    public function getId() {
        return $this->id;
    }

    public function getTitulo() {
        return utf8_encode($this->titulo);
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getNivel() {
        return $this->nivel;
    }

    public function getPadre() {
        return $this->padre;
    }

    public function getLink() {
        return $this->link;
    }

    public function setId($id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setTitulo($titulo) {
        $this->titulo = utf8_decode($titulo);
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = utf8_decode($descripcion);
    }

    public function setNivel($nivel) {
        $this->nivel = $nivel;
    }

    public function setPadre($padre) {
        $this->padre = $padre;
    }

    public function setLink($link) {
        $this->link = $link;
    }

    /**
     * Modifica los datos del permiso en la base de datos. De un submenu pueden 
     * realizarse cambios en el titulo, descripcion o padre a partir de su id. Este 
     * metodo da como resultado un arreglo de dos posiciones.
     * @return array Arreglo con un resultado numerico y un texto descriptivo.
     */
    public function modificar() {
        if ($this->id && $this->titulo && $this->descripcion && $this->padre) {
            $consulta = "UPDATE seg_permiso SET titulo = ?, descripcion = ?, padre = ? WHERE id = ?";
            $datos = array($this->titulo, $this->descripcion, $this->padre, $this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios");
    }

    /**
     * Obtiene los datos propios del permiso. Este metodo solo trae los datos de
     * la tabla permiso y no busca el menu padre perteneciante al submenu. La
     * informacion obtenida se asocia a los atributos de clase. Este metodo da
     * como resultado un arreglo de dos posiciones.
     * @return array Arreglo con un resultado numerico y un texto descriptivo.
     */
    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM seg_permiso WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array($this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->titulo = $fila['titulo'];
                $this->descripcion = $fila['descripcion'];
                $this->nivel = $fila['nivel'];
                $this->padre = $fila['padre'];
                $this->link = $fila['link'];
                return array(2, 'Se obtuvo la información correctamente');
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al permiso");
    }

    public function obtenerPadre() {
        if ($this->nivel > 1) {
            $padre = new Permiso($this->padre);
            $resultado = $padre->obtener();
            $this->padre = ($resultado[0] == 2) ? $padre : NULL;
            $mensaje = ($resultado[0] == 2) ? NULL : "No se pudo obtener el padre del submenu";
            return array($resultado[0], $mensaje);
        }
        return array(2, 'Se obtuvo la información del padre correctamente');
    }

}
