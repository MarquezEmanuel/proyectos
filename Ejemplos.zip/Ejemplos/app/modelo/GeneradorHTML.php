<?php

namespace app\modelo;

/**
 * Generador HTML que contiene metodos estaticos que devuelven tags HTML cargados
 * con la informacion que se pasa por parametro. Sirve para unificar los estilos
 * utilizados en el proyecto.
 * 
 * @package app\principal\controlador.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class GeneradorHTML {

    /**
     * Devuelve un DIV de tipo ALERT con el CLASS definido segun el resultado y
     * conteniendo el mensaje indicado. Para un valor cero se muestra el estilo
     * DANGER, para uno se establece un WARNING y para un dos SUCCESS.
     * @param int $resultado Resultado numerico del 0 al 2.
     * @param string $mensaje Mensaje que se muestra dentro del alerta.
     * @return string DIV generado con el mensaje.
     */
    public static function getAlertaOperacion($resultado, $mensaje) {
        switch ($resultado) {
            case 2:
                $icono = "<i class='far fa-check-circle'></i>";
                $clase = 'class="alert alert-success text-center"';
                break;
            case 1:
                $icono = "<i class='fas fa-exclamation-circle'></i>";
                $clase = 'class="alert alert-warning text-center"';
                break;
            case 0:
                $icono = "<i class='fas fa-exclamation-triangle'></i>";
                $clase = 'class="alert alert-danger text-center"';
                break;
            default:
                $icono = "<i class='fas fa-info-circle'></i>";
                $clase = 'class="alert alert-primary text-center"';
                break;
        }
        return "<div {$clase} role='alert'>{$icono} <strong>{$mensaje}</strong></div>";
    }

    public static function getModalProcesando() {
        return '
            <div class="modal fade bg-dark" style="opacity: 80%" 
                id="ModalCargando" tabindex="0" aria-labelledby="myModalLabel" 
                data-backdrop="static" aria-hidden="false">
                <div class="modal-dialog modal-lg p-4">
                    <div class="container p-4">
                        <div class="container mt-4 mb-4">
                            <div class="row mt-4 mb-4">
                                <div class="col text-center" style="font-size: 1.8rem;">
                                    <i class="fas fa-spinner fa-3x fa-spin text-white"></i>
                                </div>
                            </div>
                            <div class="row mt-4 mb-4">
                                <div class="col text-center text-white" style="font-size: 1.4rem;">
                                    <p> <strong>CARGANDO RESULTADOS</strong></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
    }

    /**
     * Devuelve un CARD GENERICO que se carga con el titulo y cuerpo indicado por 
     * parametro.
     * @param string $cuerpo HTML que rellena el CARD-BODY.
     * @param string $titulo HTML que rellena el CARD-HEADER.
     * @return string CARD generado con el cuerpo y titulo indicado.
     */
    public static function getCard($cuerpo, $titulo) {
        return ' <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white">' . $titulo . '</div>
                    <div class="card-body">' . $cuerpo . '</div>
                </div>';
    }

    /**
     * Devuelve un CARD para el resultado de una busqueda ya que contiene el icono
     * de la tabla en su HEADER.
     * @param string $filtro Texto que rellena el CARD-HEADER junto al icono.
     * @param string $cuerpo HTML que rellena el CARD-BODY.
     * @return string CARD generado con el cuerpo y titulo indicado.
     */
    public static function getCardBusqueda($filtro, $cuerpo) {
        return ' <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white">
                        <i class="fas fa-table"></i> ' . $filtro . '</div>
                    <div class="card-body">' . $cuerpo . '</div>
                </div>';
    }

}
