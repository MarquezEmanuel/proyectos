<?php

namespace app\modelo;

use app\modelo\SQLServer;

class ActividadColeccion {

    public static function buscar($tipo, $modulo, $operacion, $nombreUsuario, $fechaInicio, $fechaFin) {
        $consulta = "SELECT * FROM vwlog_actividad "
                . "WHERE tipo LIKE ? "
                . " AND modulo LIKE ? "
                . " AND operacion LIKE ? "
                . " AND nombreUsuario LIKE ? "
                . " AND CAST(fecha AS DATE) >= CAST(? AS DATE) AND CAST(fecha AS DATE) <= CAST(? AS DATE) "
                . "ORDER BY fecha DESC";
        $datos = array("%{$tipo}%", "%{$modulo}%", "%{$operacion}%", "%{$nombreUsuario}%", &$fechaInicio, &$fechaFin);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    public static function buscarParaSeleccionarOperacion($operacion) {
        $consulta = "SELECT DISTINCT operacion FROM log_actividad "
                . "WHERE operacion LIKE ? ORDER BY operacion";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$operacion}%"));
    }

    public static function buscarParaSeleccionarModulo($modulo) {
        $consulta = "SELECT DISTINCT modulo FROM log_actividad "
                . "WHERE modulo LIKE ? ORDER BY modulo";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$modulo}%"));
    }

    public static function buscarParaSeleccionarTipo($tipo) {
        $consulta = "SELECT DISTINCT tipo FROM log_actividad "
                . "WHERE tipo LIKE ? ORDER BY tipo";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$tipo}%"));
    }

    public static function listarResumenHistoricoUsuario($legajo) {
        $consulta = "SELECT aoperacion, count(*) total FROM vwlog_actividad WHERE ulegajo = ? GROUP BY aoperacion";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$legajo));
        return $resultado;
    }

    public static function listarResumenHoyUsuario($legajo) {
        $consulta = "SELECT aoperacion, count(*) total FROM vwlog_actividad WHERE ulegajo = ? AND CAST(afecha AS DATE) = CAST(GETDATE() AS DATE) GROUP BY aoperacion";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$legajo));
        return $resultado;
    }

    public static function buscarUltimasCreadas($tope) {
        $consulta = "SELECT TOP(?) * FROM vwlog_actividad ORDER BY fecha DESC";
        return SQLServer::instancia()->seleccionar($consulta, array(&$tope));
    }

}
