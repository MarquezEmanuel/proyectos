<?php

namespace app\modelo;

use app\modelo\SQLServer;
use app\modelo\PermisoColeccion as Permisos;

/**
 * Mapea con la tabla de perfiles.
 * 
 * @package app\seguridad\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Perfil {

    /** @var int Identificador del perfil. */
    private $id;

    /** @var string Nombre del perfil. */
    private $nombre;

    /** @var string Descripcion del perfil. */
    private $descripcion;

    /** @var string Nombre de estado del perfil. */
    private $estado;

    /** @var array Listado de permisos asociados. */
    private $permisos;

    /**
     * Constructor de clase.
     * @param int $id Identificador.
     * @param string $nombre Nombre.
     * @param string $descripcion Descripcion.
     * @param string $estado Estado.
     * @param array $permisos Permisos asociados.
     */
    public function __construct($id = NULL, $nombre = NULL, $descripcion = NULL, $estado = NULL, $permisos = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setDescripcion($descripcion);
        $this->setEstado($estado);
        $this->setPermisos($permisos);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getPermisos() {
        return $this->permisos;
    }

    public function setId($id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setNombre($nombre) {
        $this->nombre = utf8_decode($nombre);
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = utf8_decode($descripcion);
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setPermisos($permisos) {
        $this->permisos = $permisos;
    }

    public function crear() {
        if ($this->nombre && $this->descripcion && $this->permisos) {
            $consulta = "INSERT INTO seg_perfil OUTPUT INSERTED.id VALUES (?, ?, 'Activo')";
            $datos = array(&$this->nombre, &$this->descripcion);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            if ($resultado[0] == 2) {
                $this->id = $resultado[2];
                $relacion = PerfilPermiso::crear($this->id, $this->permisos);
                return ($relacion[0] == 2) ? $resultado : $relacion;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear el perfil");
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->descripcion && $this->permisos) {
            $consulta = "UPDATE seg_perfil SET nombre = ?, descripcion = ? WHERE id = ?";
            $datos = array(&$this->nombre, &$this->descripcion, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            if ($resultado[0] == 2) {
                $borra = PerfilPermiso::borrar($this->id);
                $crea = PerfilPermiso::crear($this->id, $this->permisos);
                $resultado = ($borra[0] == 2) ?: $borra;
                $resultado = ($crea[0] == 2) ?: $crea;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para modificar el perfil");
    }

    /**
     * Obtiene los datos propios del perfil y los permisos que posee asociado. 
     * Este metodo consulta la vista de perfiles (seg_perfil) para obtener los datos 
     * del perfil. Cuando se obtiene la informacion, estos se asignan a los atributos
     * de clase.
     * @return array Arreglo con un codigo numerico y un mensaje.
     */
    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM seg_perfil WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->descripcion = $fila['descripcion'];
                $this->permisos = $this->obtenerPermisos();
                return array(2, NULL);
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al perfil");
    }

    /**
     * Obtiene todos los permisos asociados a un determinado perfil. Para el
     * perfil se obtiene cada menu asociado y a su vez cada submenu asociado al
     * menu. Este metodo hace uso de la clase Permisos y los metodos listarMenu
     * y listarSubmenu.
     * @return array Devuelve un arreglo vacio o el arreglo con los menues.
     */
    private function obtenerPermisos() {
        $resultado = Permisos::listarMenu($this->id);
        $arregloMenu = array();
        if ($resultado[0] == 2) {
            while ($menu = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $submenues = $this->obtenerSubmenues($menu["id"]);
                $arregloMenu[] = array($menu['id'], $menu['titulo'], $menu['descripcion'], $submenues);
            }
        }
        return $arregloMenu;
    }

    /**
     * Obtiene todos los permisos de nivel dos para un permiso de nivel uno. Para
     * un menu se obtiene el id, titulo y link de cada submenu asociado.
     * @param integer $idPadre Identificador del permiso nivel 1.
     * @return array Devuelve un arreglo vacio o el arreglo con los submenues.
     */
    private function obtenerSubmenues($idPadre) {
        $resultado = Permisos::listarSubMenu($this->id, $idPadre);
        $submenues = array();
        if ($resultado[0] == 2) {
            $resource = $resultado[1];
            while ($submenu = sqlsrv_fetch_array($resource, SQLSRV_FETCH_ASSOC)) {
                $submenues[] = $submenu;
            }
        }
        return $submenues;
    }

    public function toString() {
        $perfil = ($this->id) ? "'{$this->id}'; " : "0; ";
        $perfil .= ($this->nombre) ? "'{$this->getNombre()}'; " : "''; ";
        $perfil .= ($this->descripcion) ? "'{$this->getDescripcion()}'; " : "''; ";
        $perfil .= ($this->estado) ? "'{$this->estado}'; " : "''; ";
        return $perfil;
    }

}
