<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Trabaja con colecciones de permisos.
 * 
 * @package app\seguridad\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class PermisoColeccion {

    /**
     * Devuelve todos los datos de uno o mas permisos obtenidos a partir de su 
     * nombre y/o nivel. Este metodo consulta la vista de permisos (vwseg_permiso)
     * para obtener los datos.
     * @param string $nombre Nombre o parte del nombre del permiso.
     * @param integer $nivel Nivel del permiso (Menu o Submenu).
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function buscar($nombre, $nivel) {
        $consulta = "SELECT * FROM vwseg_permiso WHERE titulo LIKE ? AND nivel = ?";
        $datos = array('%' . $nombre . '%', &$nivel);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    /**
     * Devuelve todos los datos de todos los permisos cargados en el sistema. Este
     * metodo consulta la visa de permisos (vwseg_permiso) para obtener los datos.
     * El resultado se encuentra ordenado por nivel, padre y titulo.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function listar() {
        $consulta = "SELECT * FROM seg_permiso WHERE nivel = 1 ORDER BY titulo";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        if ($resultado[0] == 2) {
            $menues = $resultado[1];
            $arregloMenu = array();
            while ($menu = sqlsrv_fetch_array($menues, SQLSRV_FETCH_ASSOC)) {
                $submenues = PermisoColeccion::listarSubMenuDeMenu($menu['id']);
                $arregloMenu[] = array($menu['id'], $menu['titulo'], $menu['descripcion'], $submenues);
            }
            return array(2, $arregloMenu);
        }
        return $resultado;
    }

    /**
     * Devuelve el identificador y titulo de un permiso (Menu) asociado a un perfil
     * determinado. Este metodo realiza una consulta que une la tabla de permisos
     * con la relacion entre perfil y permiso.
     * @param integer $idPerfil Identificador del perfil a consultar.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function listarMenu($idPerfil) {
        $consulta = "SELECT id, titulo, descripcion FROM seg_permiso PER INNER JOIN seg_perfil_permiso "
                . "REL ON REL.idPermiso = PER.id AND REL.idPerfil = ? "
                . "WHERE PER.nivel = 1 ORDER BY titulo";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$idPerfil));
        return $resultado;
    }

    /**
     * Devuelve el identificador, titulo y link de los permisos asociados a un menu
     * para un determinado perfil. Este metodo realiza una consulta que une la tabla
     * de permisos con la relacion entre perfil y permiso.
     * @param integer $idPerfil Identificador del perfil a consultar.
     * @param integer $idPadre Identificador del permiso padre (Menu).
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function listarSubMenu($idPerfil, $idPadre) {
        $consulta = "SELECT id, titulo, descripcion, link FROM seg_permiso PER INNER JOIN seg_perfil_permiso "
                . "REL ON REL.idPermiso = PER.id AND REL.idPerfil = ? "
                . "WHERE PER.nivel = 2 AND padre = ? ORDER BY titulo";
        return SQLServer::instancia()->seleccionar($consulta, array(&$idPerfil, &$idPadre));
    }

    private static function listarSubMenuDeMenu($idPadre) {
        $consulta = "SELECT * FROM seg_permiso WHERE nivel = 2 AND padre = ? "
                . " ORDER BY titulo, descripcion";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$idPadre));
        if ($resultado[0] == 2) {
            $resource = $resultado[1];
            $submenues = array();
            while ($submenu = sqlsrv_fetch_array($resource, SQLSRV_FETCH_ASSOC)) {
                $submenues[] = $submenu;
            }
            return $submenues;
        }
        return NULL;
    }

    /**
     * Devuelve un listado de permisos segun la cantidad especificada en el tope.
     * Este metodo consula la vista de permisos (vwseg_permiso) y esta diseñado 
     * para ser utilizado como una vista previa durante una busqueda.
     * @param integer $tope Numero de cantidad maxima a mostrar (TOP SQL).
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function listarConTope($tope) {
        $consulta = "SELECT TOP(?) * FROM vwseg_permiso ORDER BY id DESC";
        return SQLServer::instancia()->seleccionar($consulta, array(&$tope));
    }

    /**
     * Devuelve el identificador y titulo de uno o mas permisos. Este metodo 
     * consulta la vista de permisos y esta diseñado para ser utilizado durante
     * la seleccion de permisos por pantalla.
     * @param string $nombre Nombre o parte del nombre del permiso.
     * @param string $nivel 1 para consultar menues o 2 submenues. 
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function selecccionar($nombre, $nivel) {
        $consulta = "SELECT id, titulo FROM vseg_permiso WHERE titulo LIKE ? AND nivel = ?";
        $datos = array('%' . $nombre . '%', $nivel);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

}
