<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla de proveedores.
 * 
 * @package app\servicio\modelo.
 * 
 * @uses pro_proveedor Vista de proveedores.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ProveedorColeccion {

    /**
     * Buscar proveedores a partir del nombre, provincia, ciudad y  estado. De la
     * consulta se obtienen todos los campos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre corto o parte del nombre (LIKE).
     * @param string $provincia Nombre de la provincia o parte del nombre (LIKE).
     * @param string $ciudad Nombre de la ciudad o parte del nombre (LIKE).
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscar($nombre, $provincia, $ciudad, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM pro_proveedor WHERE nombre LIKE ? "
                    . " AND provincia LIKE ? "
                    . " AND ciudad LIKE ? "
                    . " AND estado = ?";
            $datos = array("%{$nombre}%", "%{$provincia}%", "%{$ciudad}%", &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar proveedores");
    }

    /**
     * Buscar proveedores de desarrollo en estado activo a partir de su nombre. 
     * De la consulta se obtiene el identificador y nombre. El objetivo del metodo 
     * es obtener los datos necesarios para seleccionar y relacionar.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre o parte del nombre del proveedor (LIKE).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarParaSeleccionar($nombre) {
        $consulta = "SELECT id, nombre FROM pro_proveedor "
                . "WHERE nombre LIKE ? AND estado = 'Activo' "
                . "ORDER BY nombre ASC";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombre}%"));
    }

    /**
     * Buscar los proveedores de una determinada aplicacion. De la consulta se 
     * obtienen todos los datos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $idAplicacion Identificador de la aplicacion (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarProveedoresAplicacion($idAplicacion) {
        if ($idAplicacion > 0) {
            $consulta = "SELECT pro.* FROM pro_proveedor pro "
                    . "INNER JOIN apl_aplicacion_proveedor apl on pro.id = apl.idProveedor "
                    . "WHERE apl.idAplicacion = ?";
            return SQLServer::instancia()->seleccionar($consulta, array(&$idAplicacion));
        }
        return array(0, "No se pudo hacer referencia al firewall para obtener proveedores");
    }

    /**
     * Buscar los proveedores de un determinado elemento firewall. De la consulta se 
     * obtienen todos los datos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $idFirewall Identificador del firewall (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarProveedoresFirewall($idFirewall) {
        if ($idFirewall > 0) {
            $consulta = "SELECT pro.* FROM pro_proveedor pro "
                    . "INNER JOIN fir_firewall_proveedor fir on pro.id = fir.idProveedor "
                    . "WHERE fir.idFirewall = ?";
            return SQLServer::instancia()->seleccionar($consulta, array(&$idFirewall));
        }
        return array(0, "No se pudo hacer referencia al firewall para obtener proveedores");
    }

    public static function buscarProveedoresHardware($idHardware) {
        if ($idHardware > 0) {
            $consulta = "SELECT pro.* FROM pro_proveedor pro "
                    . "INNER JOIN har_hardware_proveedor har on pro.id = har.idProveedor "
                    . "WHERE har.idHardware = ?";
            return SQLServer::instancia()->seleccionar($consulta, array(&$idHardware));
        }
        return array(0, "No se pudo hacer referencia al servicio para obtener proveedores");
    }

    /**
     * Buscar los proveedores de una determinada herramienta. De la consulta se 
     * obtienen todos los datos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $idHerramienta Identificador de la herramienta (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarProveedoresHerramienta($idHerramienta) {
        if ($idHerramienta > 0) {
            $consulta = "SELECT pro.* FROM pro_proveedor pro "
                    . "INNER JOIN her_herramienta_proveedor her on pro.id = her.idProveedor "
                    . "WHERE her.idHerramienta = ?";
            return SQLServer::instancia()->seleccionar($consulta, array(&$idHerramienta));
        }
        return array(0, "No se pudo hacer referencia al servicio para obtener proveedores");
    }

    /**
     * Buscar los proveedores de un determinado switch . De la consulta se 
     * obtienen todos los datos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $idSwitch Identificador del switch (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarProveedoresSwitch($idSwitch) {
        if ($idSwitch > 0) {
            $consulta = "SELECT pro.* FROM pro_proveedor pro "
                    . "INNER JOIN swi_switch_proveedor swi on pro.id = swi.idProveedor "
                    . "WHERE swi.idSwitch = ?";
            return SQLServer::instancia()->seleccionar($consulta, array(&$idSwitch));
        }
        return array(0, "No se pudo hacer referencia al switch para obtener proveedores");
    }

    /**
     * Buscar proveedores ordenados por fecha de creacion descendente con un tope
     * de registros y un estado. De la consulta se obtienen todos los campos de
     * la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $top Cantidad maxima de registros a seleccionar.
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarUltimosCreados($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM pro_proveedor WHERE estado = ?"
                    . " ORDER BY fechaCreacion DESC";
            $datos = array(&$top, &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar proveedores");
    }

    public static function consultar($nombre, $provincia) {
        $consulta = "SELECT * FROM pro_proveedor WHERE nombre LIKE ? AND provincia LIKE ? AND estado = 'Activo'";
        $datos = array('%' . $nombre . '%', '%' . $provincia . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        return $resultado;
    }

}
