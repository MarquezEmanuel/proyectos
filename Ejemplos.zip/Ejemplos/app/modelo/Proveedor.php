<?php

namespace app\modelo;

use app\modelo\ServicioColeccion as Servicios;
use app\modelo\SQLServer;
use app\modelo\Util;

/**
 * Mapea con la tabla de proveedores.
 * 
 * @package app\proveedor\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Proveedor {

    /** @var int Identificador del proveedor [BIGINT] */
    private $id;

    /** @var string Nombre del proveedor [NVARCHAR(50) NOT NULL] */
    private $nombre;

    /** @var string Numero de telefono [NVARCHAR(20) NULL] */
    private $telefono;

    /** @var string Correo electronico [NVARCHAR(50) NULL] */
    private $correo;

    /** @var string Nombre de la provincia [NVARCHAR(50) NOT NULL] */
    private $provincia;

    /** @var string Nombre de la ciudad [NVARCHAR(50) NOT NULL] */
    private $ciudad;

    /** @var string Direccion [NVARCHAR(50) NOT NULL] */
    private $direccion;

    /** @var string Tipo de proveedor [NVARCHAR(20) NOT NULL] */
    private $tipo;

    /** @var array Listado de servicios del proveedor */
    private $servicios;

    /** @var string Estado del proveedor [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var int Nivel de visibilidad [INT NOT NULL] */
    private $visibilidad;

    /** @var string Fecha de creacion del registro [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de ultima edicion del registro [SMALLDATETIME NOT NULL] */
    private $fechaEdicion;

    public function __construct($id = NULL, $nombre = NULL, $telefono = NULL, $correo = NULL, $provincia = NULL, $ciudad = NULL, $direccion = NULL, $tipo = NULL, $servicios = NULL, $estado = NULL, $visibilidad = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setTelefono($telefono);
        $this->setCorreo($correo);
        $this->setProvincia($provincia);
        $this->setCiudad($ciudad);
        $this->setDireccion($direccion);
        $this->setTipo($tipo);
        $this->setServicios($servicios);
        $this->setEstado($estado);
        $this->setVisibilidad($visibilidad);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getTelefono() {
        return $this->telefono;
    }

    public function getCorreo() {
        return $this->correo;
    }

    public function getProvincia() {
        return utf8_encode($this->provincia);
    }

    public function getCiudad() {
        return utf8_encode($this->ciudad);
    }

    public function getDireccion() {
        return utf8_encode($this->direccion);
    }

    public function getTipo() {
        return utf8_encode($this->tipo);
    }

    public function getServicios() {
        return $this->servicios;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getVisibilidad() {
        return $this->visibilidad;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setNombre($nombre) {
        if ($nombre && (strlen($nombre) <= 50)) {
            $this->nombre = utf8_decode($nombre);
        }
    }

    public function setTelefono($telefono) {
        if ($telefono && (strlen($telefono) <= 20)) {
            $this->telefono = $telefono;
        }
    }

    public function setCorreo($correo) {
        if ($correo && (strlen($correo) <= 50)) {
            $this->correo = $correo;
        }
    }

    public function setProvincia($provincia) {
        if ($provincia && (strlen($provincia) <= 50)) {
            $this->provincia = utf8_decode(Util::convertirCamelCase($provincia));
        }
    }

    public function setCiudad($ciudad) {
        if ($ciudad && (strlen($ciudad) <= 50)) {
            $this->ciudad = utf8_decode(Util::convertirCamelCase($ciudad));
        }
    }

    public function setDireccion($direccion) {
        if ($direccion && (strlen($direccion) <= 50)) {
            $this->direccion = utf8_decode($direccion);
        }
    }

    public function setTipo($tipo) {
        if ($tipo && (strlen($tipo) <= 20)) {
            $this->tipo = utf8_decode($tipo);
        }
    }

    public function setServicios($servicios) {
        $this->servicios = $servicios;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setVisibilidad($visibilidad) {
        $this->visibilidad = ($visibilidad > 0) ? $visibilidad : NULL;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE pro_proveedor SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para cambiar estado");
    }

    public function crear() {
        if ($this->nombre && $this->provincia && $this->ciudad && $this->direccion && $this->servicios) {
            $consulta = "INSERT INTO pro_proveedor OUTPUT INSERTED.id VALUES (?, ?, ?, ?, ?, ?, ?, 'Activo', 1, GETDATE(), NULL)";
            $datos = array(&$this->nombre, &$this->telefono, &$this->correo, &$this->provincia, &$this->ciudad, &$this->direccion, &$this->tipo);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            if ($resultado[0] == 2) {
                $this->id = $resultado[2];
                $rservicios = ProveedorServicio::crear($this->id, $this->servicios);
                $resultado = ($rservicios[0] == 2) ? $resultado : $rservicios;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear el proveedor");
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->provincia && $this->ciudad && $this->direccion && $this->servicios) {
            $consulta = "UPDATE pro_proveedor SET nombre=?, telefono=?, correo=?, "
                    . " provincia=?, ciudad=?, direccion=?, tipo=?, estado=?, "
                    . " fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->nombre, &$this->telefono, &$this->correo, &$this->provincia, &$this->ciudad, &$this->direccion, &$this->tipo, &$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            if ($resultado[0] == 2) {
                $actualizar = ProveedorServicio::actualizarServiciosProveedor($this->id, $this->servicios);
                $resultado = ($actualizar[0] == 2) ? $resultado : $actualizar;
            }
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para modificar el proveedor");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM pro_proveedor WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->telefono = $fila['telefono'];
                $this->correo = $fila['correo'];
                $this->provincia = $fila['provincia'];
                $this->ciudad = $fila['ciudad'];
                $this->direccion = $fila['direccion'];
                $this->tipo = $fila['tipo'];
                $this->estado = $fila['estado'];
                $this->visibilidad = $fila['nivelVisibilidad'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información del proveedor correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al proveedor");
    }

    public function obtenerServicios() {
        $this->servicios = NULL;
        $resultado = Servicios::buscarServiciosProveedor($this->id);
        if ($resultado[0] == 2) {
            $servicios = $resultado[1];
            while ($servicio = sqlsrv_fetch_array($servicios, SQLSRV_FETCH_ASSOC)) {
                $this->servicios[] = $servicio;
            }
            $resultado[1] = ($this->servicios) ? NULL : $resultado[1];
        }
        return $resultado;
    }

    public function toString() {
        $proveedor = ($this->id) ? "{{$this->getId()}," : "{0,";
        $proveedor .= ($this->nombre) ? "'{$this->getNombre()}'," : "'',";
        $proveedor .= ($this->telefono) ? "'{$this->getTelefono()}'," : "'',";
        $proveedor .= ($this->correo) ? "'{$this->getCorreo()}'," : "'',";
        $proveedor .= ($this->provincia) ? "'{$this->getProvincia()}'," : "'',";
        $proveedor .= ($this->ciudad) ? "'{$this->getCiudad()}'," : "'',";
        $proveedor .= ($this->direccion) ? "'{$this->getDireccion()}'," : "'',";
        $proveedor .= ($this->tipo) ? "'{$this->getTipo()}'," : "'',";
        $proveedor .= ($this->estado) ? "'{$this->getEstado()}'," : "'',";
        $proveedor .= ($this->visibilidad) ? "'{$this->getVisibilidad()}'}" : "''}";
        return $proveedor;
    }

}
