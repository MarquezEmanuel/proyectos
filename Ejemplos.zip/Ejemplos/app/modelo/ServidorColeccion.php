<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ServidorColeccion {

    public function buscar($ip, $nombre, $ambiente) {
        $consulta = "SELECT * FROM ser_servidor WHERE ip LIKE ? "
                . " AND nombre LIKE ? "
                . " AND ambiente LIKE ? ";
        $datos = array("%{$ip}%", "%{$nombre}%", "%{$ambiente}%");
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

}
