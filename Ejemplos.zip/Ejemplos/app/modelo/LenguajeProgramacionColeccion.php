<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Mapea con la tabla y vista de lenguajes.
 * 
 * @package app\lenguaje\modelo.
 * 
 * @uses len_lenguaje Tabla de lenguajes de programacion.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class LenguajeProgramacionColeccion {

    /**
     * Buscar responsables a partir del nombre, nombre proveedor y estado. De la
     * consulta se obtienen todos los campos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre o parte del nombre del lenguaje (LIKE).
     * @param string $version Version del lenguaje (LIKE).
     * @param string $descripcion Descripcion (LIKE).
     * @param string $estado Estado del lenguaje (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscar($nombre, $version, $descripcion, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM len_lenguaje WHERE nombre LIKE ? AND "
                    . "version LIKE ? AND descripcion LIKE ? AND estado = ?";
            $datos = array("%{$nombre}%", "%{$version}%", "%{$descripcion}%", &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar lenguajes");
    }

    /**
     * Buscar lenguajes de programacion en estado activo a partir de su nombre. 
     * De la consulta se obtiene el id, nombre y version. El objetivo del metodo 
     * es obtener los datos necesarios para seleccionar y relacionar.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombre Nombre o parte del nombre del lenguaje (LIKE).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarParaSeleccionar($nombre) {
        $consulta = "SELECT id, nombre, version FROM len_lenguaje "
                . "WHERE nombre LIKE ? AND estado = 'Activo'"
                . "ORDER BY nombre, version";
        return SQLServer::instancia()->seleccionar($consulta, array("%{$nombre}%"));
    }

    /**
     * Buscar lenguajes ordenados por fecha de creacion descendente con un tope
     * de registros y un estado. De la consulta se obtienen todos los campos de
     * la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $top Cantidad maxima de registros a seleccionar.
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarUltimosCreados($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM len_lenguaje WHERE estado = ? "
                    . "ORDER BY fechaCreacion DESC";
            $datos = array(&$top, &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar lenguajes");
    }

    public static function consultar($nombre, $version) {
        $consulta = "SELECT * FROM len_lenguaje WHERE nombre LIKE ? AND version LIKE ? AND estado = 'Activo'";
        $datos = array('%' . $nombre . '%', '%' . $version . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
