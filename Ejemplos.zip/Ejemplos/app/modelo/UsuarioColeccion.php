<?php

namespace app\modelo;

use app\modelo\SQLServer;

/**
 * Trabaja con colecciones de usuarios.
 * 
 * @package app\seguridad\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class UsuarioColeccion {

    /**
     * Devuelve todos los datos de uno o mas usuarios obtenidos a partir de su 
     * nombre y/o estado. Este metodo consulta la vista de usuarios (vwseg_usuario)
     * para obtener los datos.
     * @param string $nombre Nombre o parte del nombre del usuario.
     * @param string $estado Estado actual del usuario a consultar.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM vwseg_usuario WHERE nombreUsuario LIKE ? AND estadoUsuario = ?";
        $datos = array("%{$nombre}%", $estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    /**
     * Devuelve un listado de usuarios segun la cantidad especificada en el tope. 
     * Este metodo consula la vista de usuarios (vwseg_usuario) y esta diseñado 
     * para ser utilizado como una vista previa durante una busqueda.
     * @param integer $tope Numero de cantidad maxima a mostrar (TOP SQL).
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function buscarConTope($top, $estado) {
        $consulta = "SELECT TOP(?) * FROM vwseg_usuario WHERE estadoUsuario = ?";
        return SQLServer::instancia()->seleccionar($consulta, array(&$top, &$estado));
    }

}
