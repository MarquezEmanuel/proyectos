<?php

namespace app\controlador;

use app\modelo\ActividadColeccion as Actividades;

class ControladorActividad {

    public function buscar($tipo, $modulo, $operacion, $nombreUsuario, $fechaInicio, $fechaFin) {
        return Actividades::buscar($tipo, $modulo, $operacion, $nombreUsuario, $fechaInicio, $fechaFin);
    }

    public function buscarParaSeleccionarModulo($modulo) {
        return Actividades::buscarParaSeleccionarModulo($modulo);
    }

    public function buscarParaSeleccionarOperacion($operacion) {
        return Actividades::buscarParaSeleccionarOperacion($operacion);
    }

    public function buscarParaSeleccionarTipo($tipo) {
        return Actividades::buscarParaSeleccionarTipo($tipo);
    }

    public function listarResumenHistoricoUsuario($legajo) {
        $resultado = Actividades::listarResumenHistoricoUsuario($legajo);
        return $resultado;
    }

    public function listarResumenHoyUsuario($legajo) {
        $resultado = Actividades::listarResumenHoyUsuario($legajo);
        return $resultado;
    }

    public function buscarUltimasCreadas($tope) {
        $resultado = Actividades::buscarUltimasCreadas($tope);
        return $resultado;
    }

}
