<?php

namespace app\controlador;

use app\modelo\ActividadColeccion as Actividades;

class ControladorActividad {

    public function buscar($tipo, $modulo, $operacion, $nombreUsuario, $fechaInicio, $fechaFin) {
        $nombreUsuario = utf8_decode($nombreUsuario);
        return Actividades::buscar($tipo, $modulo, $operacion, $nombreUsuario, $fechaInicio, $fechaFin);
    }

    public function buscarParaSeleccionarModulo($modulo) {
        $modulo = utf8_decode($modulo);
        return Actividades::buscarParaSeleccionarModulo($modulo);
    }

    public function buscarParaSeleccionarOperacion($operacion) {
        $operacion = utf8_decode($operacion);
        return Actividades::buscarParaSeleccionarOperacion($operacion);
    }

    public function buscarParaSeleccionarTipo($tipo) {
        $tipo = utf8_decode($tipo);
        return Actividades::buscarParaSeleccionarTipo($tipo);
    }

    public function listarResumenHistoricoUsuario($legajo) {
        return Actividades::listarResumenHistoricoUsuario($legajo);
    }

    public function listarResumenHoyUsuario($legajo) {
        return Actividades::listarResumenHoyUsuario($legajo);
    }

    public function buscarUltimasCreadas($tope) {
        return Actividades::buscarUltimasCreadas($tope);
    }

}
