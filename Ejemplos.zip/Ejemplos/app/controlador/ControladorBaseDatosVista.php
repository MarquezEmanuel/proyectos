<?php

namespace app\base\controlador;

use app\base\modelo\ColeccionVistas as Vistas;

class ControladorVista {

    /**
     * @param string $nombreBase Nombre de la base de datos (LIKE).
     * @param string $nombreVista Nombre de la vista (LIKE).
     * @param string $tipoConsulta Tipo de consulta (LIKE).
     * @param string $descripcion Descripcion de la vista (LIKE).
     */
    public function buscar($nombreBase, $nombreVista, $tipoConsulta, $descripcion) {
        return Vistas::buscar($nombreBase, $nombreVista, $tipoConsulta, $descripcion);
    }

    public function modificar($id, $consulta, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $vista = new Vista($id, NULL, NULL, $consulta, $descripcion);
            $modificacion = $vista->modificar();
            $this->mensaje = $vista->getMensaje();
            $confirmar = ($modificacion == 2) ? true : false;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar con la vista";
        return 1;
    }

    public function listarPorBase($idBase) {
        $resultado = Vistas::listarPorBase($idBase);
        $this->mensaje = Vistas::getMensaje();
        return $resultado;
    }

    public function listarUltimasActualizadas() {
        $resultado = Vistas::listarUltimasActualizadas();
        $this->mensaje = Vistas::getMensaje();
        return $resultado;
    }

}
