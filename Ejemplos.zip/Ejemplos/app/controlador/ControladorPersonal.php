<?php

namespace app\controlador;

use app\modelo\Personal;
use app\modelo\PersonalColeccion as Personales;
use app\modelo\SQLServer;
use app\modelo\Log;

class ControladorPersonal {

    public function buscar($nombrePersonal, $nombreDepartamento, $estado) {
        return Personales::buscar($nombrePersonal, $nombreDepartamento, $estado);
    }

    public function buscarInformesPersonal() {
        return Personales::buscarInformesPersonal();
    }

    public function buscarUltimosCreados($top, $estado) {
        return Personales::buscarUltimosCreados($top, $estado);
    }

    /**
     * @param string $nombreCorto Nombre corto.
     * @param string $nombreLargo Nombre largo.
     * @param int $idDepartamento Identificador del departamento.
     * @param string $descripcion Descripcion adicional.
     */
    public function crear($nombreCorto, $nombreLargo, $idDepartamento, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $personal = new Personal(NULL, $nombreCorto, $nombreLargo, $idDepartamento, NULL, $descripcion);
            $resultado = $personal->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $personal);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificar($id, $nombreCorto, $nombreLargo, $idDepartamento, $estado, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $personal = new Personal($id, $nombreCorto, $nombreLargo, $idDepartamento, NULL, $descripcion);
            $resultado = $personal->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $personal);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $personal = new Personal($id, NULL, NULL, NULL, $rti, NULL, NULL, $visibilidad);
            $resultado = $personal->modificarCGTI();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificarGCTI", $personal);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Personal $personal Plataforma con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $personal) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "PERSONAL";
        $metodo = "ControladorPersonal::$funcion";
        $detalle = substr($personal->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
