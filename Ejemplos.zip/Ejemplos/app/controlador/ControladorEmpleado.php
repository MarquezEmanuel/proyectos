<?php

namespace app\controlador;

use app\modelo\Empleado;
use app\modelo\EmpleadoColeccion as Empleados;
use app\modelo\SQLServer;
use app\modelo\Log;

class ControladorEmpleado {

    public function buscar($legajo, $nombreEmpleado, $nombreDepartamento, $estado) {
        return Empleados::buscar($legajo, $nombreEmpleado, $nombreDepartamento, $estado);
    }

    public function buscarUltimosCreados($top, $estado) {
        return Empleados::buscarUltimosCreados($top, $estado);
    }

    public function buscarParaSeleccionarDelegado($nombre) {
        return Empleados::buscarParaSeleccionarDelegado($nombre);
    }

    public function buscarParaSeleccionarJefe($nombre) {
        return Empleados::buscarParaSeleccionarJefe($nombre);
    }

    public function crear($legajo, $nombre, $idDepartamento) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $empleado = new Empleado($legajo, $nombre, $idDepartamento);
            $resultado = $empleado->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $empleado);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificar($id, $nombre, $departamento, $legajo, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $empleado = new Empleado($id, $nombre, $departamento, $estado);
            $resultado = $empleado->modificar($legajo);
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $empleado);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Empleado $empleado Empleado con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $empleado) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "GERENCIAS";
        $metodo = "ControladorEmpleado::$funcion";
        $detalle = substr($empleado->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
