<?php

namespace app\controlador;

use app\modelo\Gerencia;
use app\modelo\GerenciaColeccion as Gerencias;
use app\modelo\SQLServer;
use app\modelo\Log;

class ControladorGerencia {

    public function buscar($nombreGerencia, $nombreEmpleado, $estado) {
        $nombreGerencia = utf8_decode($nombreGerencia);
        $nombreEmpleado = utf8_decode($nombreEmpleado);
        return Gerencias::buscar($nombreGerencia, $nombreEmpleado, $estado);
    }

    public function buscarParaSeleccionar($nombre) {
        $nombre = utf8_decode($nombre);
        return Gerencias::buscarParaSeleccionar($nombre);
    }

    public function buscarUltimasCreadas($top, $estado) {
        return Gerencias::buscarUltimasCreadas($top, $estado);
    }

    public function crear($nombre, $jefe) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $gerencia = new Gerencia(NULL, $nombre, $jefe);
            $resultado = $gerencia->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $gerencia);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificar($id, $nombre, $jefe, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $gerencia = new Gerencia($id, $nombre, $jefe, $estado);
            $resultado = $gerencia->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $gerencia);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Gerencia $gerencia Departamento con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $gerencia) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "GERENCIAS";
        $metodo = "ControladorGerencia::$funcion";
        $detalle = substr($gerencia->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
