<?php

namespace app\controlador;

use app\modelo\Usuario;
use app\modelo\ActiveDirectory;
use app\modelo\Constantes;
use app\modelo\Log;

/**
 * Controlador principal que se encarga de verificar los usuarios que ingresan al
 * sistema. Realiza la validacion con el Active Directory y tambien con la base
 * de datos.
 * 
 * @package app\principal\controlador.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ControladorPrincipal {

    /**
     * Realiza la verificacion del usuario consultando sus datos en el servidor
     * de Active Directory y en la base de datos del sistema. Se deniega el acceso
     * cuando en alguno de estos puntos no coincide la informacion con la dada.
     * @param string $legajo Legajo del usuario.
     * @param string $clave Clave personal del usuario.
     * @return boolean True para acceder, false en caso contrario.
     */
    public function verificarUsuarioSistema($legajo, $clave) {
        $autorizadoAD = $this->verificarActiveDirectory($legajo, $clave);
        if ($autorizadoAD[0]) {
            $usuario = new Usuario();
            $usuario->setId($legajo);
            $resultado = $usuario->obtenerDatosTerceros();
            if ($resultado[0] == 2) {
                $_SESSION['usuario'] = $usuario;
                $datos = array(true, "Usuario autorizado por CAP");
                $this->registrar($datos, "INGRESO", "verificarUsuarioSistema", $legajo, "Ninguno.");
                return $datos;
            }
            return array(false, "Usuario no autorizado por CAP");
        }
        return $autorizadoAD;
    }

    /**
     * Verifica el usuario en active directory segun su legajo y clave. El acceso
     * se deniega si no se puede establecer la conexion con el servidor a partir de
     * los datos definidos en CONSTANTES o porque no se encontro el usuario.
     * @param string $legajo Numero de legajo del usuario.
     * @param string $clave Clave personal del usuario.
     * @return boolean True para acceder, false en caso contrario.
     */
    private function verificarActiveDirectory($legajo, $clave) {
        $ad = new ActiveDirectory(Constantes::LDAP_HOST, Constantes::LDAP_PORT, Constantes::LDAP_DOMI);
        if ($ad->conectar()) {
            if ($ad->buscar($legajo, $clave)) {
                return array(true, "Usuario autorizado por Active Directory");
            }
            return array(false, "Usuario no autorizado por Active Directory");
        }
        return array(false, "Sin conexión a Active Directory");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param string $referencia Referencia al usuario.
     * @param string $datos Datos adicionales.
     */
    private function registrar($resultado, $operacion, $funcion, $referencia, $datos) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "PRINCIPAL";
        $metodo = "ControladorPrincipal::$funcion";
        $detalle = "$codigo : $datos";
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $referencia, $detalle);
    }

}
