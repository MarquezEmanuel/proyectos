<?php

namespace app\base\controlador;

use app\base\modelo\ColeccionProcedimientos as Procedimientos;

class ControladorProcedimiento {

    /**
     * @param string $nombreBase Nombre de la base de datos (LIKE).
     * @param string $nombreSP Nombre del procedimiento almacenado (LIKE).
     * @param string $fechaCreacion Fecha de creacion del SP (IGUAL).
     * @param string $fechaEdicion Fecha de edicion del SP (IGUAL).
     * @param string $descripcion Descripcion del procedimiento almacenado.
     */
    public function buscar($nombreBase, $nombreSP, $rutina, $fechaCreacion, $fechaEdicion, $descripcion) {
        return Procedimientos::buscar($base, $nombre, $definicion, $descripcion);
    }

    public function modificar($id, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $procedimiento = new Procedimiento($id, NULL, NULL, NULL, NULL, NULL, $descripcion);
            $modificacion = $procedimiento->modificar();
            $this->mensaje = $procedimiento->getMensaje();
            $confirmar = ($modificacion == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $modificacion;
        }
        $this->mensaje = "No se pudo inicializar la transacción para operar con el procedimiento";
        return 1;
    }

    public function listarPorBase($idBase) {
        $resultado = Procedimientos::listarPorBase($idBase);
        return $resultado;
    }

    public function listarUltimosModificados() {
        $resultado = Procedimientos::listarUltimosModificados();
        return $resultado;
    }

}
