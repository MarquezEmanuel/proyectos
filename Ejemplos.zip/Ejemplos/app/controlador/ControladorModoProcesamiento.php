<?php

namespace app\controlador;

use app\modelo\SQLServer;
use app\modelo\Log;
use app\modelo\ModoProcesamiento;
use app\modelo\ModoProcesamientoColeccion as ModosProcesamiento;

class ControladorModoProcesamiento {

    public function buscar($nombre, $estado) {
        return ModosProcesamiento::buscar($nombre, $estado);
    }

    public function buscarParaSeleccionar($nombre) {
        return ModosProcesamiento::buscarParaSeleccionar($nombre);
    }

    public function buscarUltimosCreados($top, $estado) {
        return ModosProcesamiento::buscarUltimosCreados($top, $estado);
    }

    public function crear($nombre) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modo = new ModoProcesamiento(NULL, $nombre);
            $resultado = $modo->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $modo);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    public function modificar($id, $nombre, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $modo = new ModoProcesamiento($id, $nombre, $estado);
            $resultado = $modo->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $modo);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Modo $modo Modo de procesamiento con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $modo) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "PROCESAMIENTOS";
        $metodo = "ControladorModoProcesamiento::$funcion";
        $detalle = substr($modo->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
