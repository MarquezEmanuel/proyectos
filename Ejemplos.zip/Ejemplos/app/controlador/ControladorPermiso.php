<?php

namespace app\controlador;

use app\modelo\Permiso;
use app\modelo\PermisoColeccion as Permisos;
use app\modelo\SQLServer;
use app\modelo\Log;

/**
 * Controla los eventos de los modelos de permisos.
 * 
 * @package app\seguridad\controlador.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ControladorPermiso {

    /**
     * Devuelve todos los datos de uno o mas permisos obtenidos a partir de su 
     * nombre y/o nivel. Este metodo consulta la vista de permisos para obtener
     * los datos.
     * @param string $nombre Nombre o parte del nombre del permiso.
     * @param integer $nivel Nivel del permiso (Menu o Submenu).
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function buscar($nombre, $nivel) {
        $resultado = Permisos::buscar($nombre, $nivel);
        return $resultado;
    }

    /**
     * Devuelve todos los datos de todos los permisos cargados en el sistema. Este
     * metodo consulta la visa de permisos (vwseg_permiso) para obtener los datos.
     * El resultado se encuentra ordenado por nivel, padre y titulo.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function listar() {
        return Permisos::listar();
    }

    /**
     * Devuelve un listado de permisos segun la cantidad especificada en el tope.
     * Este metodo consula la vista de permisos y esta diseñado para ser utilizado
     * como una vista previa durante una busqueda.
     * @param integer $tope Numero de cantidad maxima a mostrar (TOP SQL).
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function listarConTope($tope) {
        $resultado = Permisos::listarConTope($tope);
        return $resultado;
    }

    /**
     * Se realiza la modificacion de un permiso en la base de datos.
     * @param integer $id Identificador del permiso.
     * @param string $titulo Titulo o nombre del permiso.
     * @param string $descripcion Descripcion del permiso.
     * @param integer $padre Identificador del permiso padre.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function modificar($id, $titulo, $descripcion, $padre) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $menu = new Permiso($id, $titulo, $descripcion, NULL, $padre);
            $edicion = $menu->modificar();
            $confirmar = ($edicion[0] == 2) ? TRUE : FALSE;
            $this->registrar($edicion, "modificacion", "modificar", $id, $titulo);
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $edicion;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /*
      public function seleccionar($nombre, $nivel) {
      $permisos = new Permisos();
      $resultado = $permisos->selecccionar($nombre, $nivel);
      $this->mensaje = $permisos->getMensaje();
      return $resultado;
      }

     */

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param string $referencia Referencia al usuario.
     * @param string $datos Datos adicionales.
     */
    private function registrar($resultado, $operacion, $funcion, $referencia, $datos) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "PERMISOS";
        $metodo = "ControladorPermiso::$funcion";
        $detalle = "$codigo : $datos";
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $referencia, $detalle);
    }

}
