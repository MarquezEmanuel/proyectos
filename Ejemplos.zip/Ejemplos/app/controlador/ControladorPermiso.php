<?php

namespace app\controlador;

use app\modelo\Permiso;
use app\modelo\PermisoColeccion as Permisos;
use app\modelo\SQLServer;
use app\modelo\Log;

/**
 * Controla los eventos de los modelos de permisos.
 * 
 * @package app\seguridad\controlador.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ControladorPermiso {

    /**
     * Devuelve todos los datos de uno o mas permisos obtenidos a partir de su 
     * nombre y/o nivel. Este metodo consulta la vista de permisos para obtener
     * los datos.
     * @param string $nombre Nombre o parte del nombre del permiso.
     * @param integer $nivel Nivel del permiso (Menu o Submenu).
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function buscar($nombre, $nivel) {
        $nombre = utf8_decode($nombre);
        return Permisos::buscar($nombre, $nivel);
    }

    /**
     * Devuelve un listado de permisos segun la cantidad especificada en el tope.
     * Este metodo consula la vista de permisos y esta diseñado para ser utilizado
     * como una vista previa durante una busqueda.
     * @param integer $tope Numero de cantidad maxima a mostrar (TOP SQL).
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function buscarConTope($tope) {
        return Permisos::buscarConTope($tope);
    }

    public function buscarParaSeleccionarPadre($nombre) {
        $nombre = utf8_decode($nombre);
        return Permisos::buscarParaSeleccionarPadre($nombre);
    }

    /**
     * Devuelve todos los datos de todos los permisos cargados en el sistema. Este
     * metodo consulta la visa de permisos (vwseg_permiso) para obtener los datos.
     * El resultado se encuentra ordenado por nivel, padre y titulo.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function listar() {
        return Permisos::listar();
    }

    /**
     * Se realiza la modificacion de un permiso en la base de datos.
     * @param integer $id Identificador del permiso.
     * @param string $titulo Titulo o nombre del permiso.
     * @param string $descripcion Descripcion del permiso.
     * @param integer $idPadre Identificador del permiso padre.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function modificar($id, $titulo, $descripcion, $idPadre) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $menu = new Permiso($id, $titulo, $descripcion, NULL, $idPadre);
            $resultado = $menu->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $menu);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Permiso $permiso Perfil con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $permiso) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "SEGURIDAD";
        $metodo = "ControladorPermiso::$funcion";
        $detalle = substr($permiso->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
