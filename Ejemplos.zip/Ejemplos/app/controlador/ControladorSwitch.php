<?php

namespace app\controlador;

use app\modelo\Switchs;
use app\modelo\SwitchColeccion as Switches;
use app\modelo\SQLServer;
use app\modelo\Log;

class ControladorSwitch {

    public function buscar($nombreSwitch, $modelo, $nombreInstalacion, $nombreSitio, $estado) {
        return Switches::buscar($nombreSwitch, $modelo, $nombreInstalacion, $nombreSitio, $estado);
    }

    public function buscarUltimosCreados($top, $estado) {
        return Switches::buscarUltimosCreados($top, $estado);
    }

    /**
     * @param string $nombre Nombre.
     * @param string $modelo Modelo.
     * @param string $version Version.
     * @param int $idInstalacion Identificador de la instalacion.
     * @param string $idSitio Identificador del sitio.
     * @param string $descripcion Descripcion adicional.
     */
    public function crear($nombre, $modelo, $version, $idSitio, $idInstalacion, $descripcion, $proveedores) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $switch = new Switchs(NULL, $nombre, $modelo, $version, $idSitio, $idInstalacion, NULL, $descripcion, NULL, NULL, $proveedores);
            $resultado = $switch->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $switch);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function consultar($nombre, $modelo, $instalacion, $sitio) {
        $resultado = Switches::consultar($nombre, $modelo, $instalacion, $sitio);
        return $resultado;
    }

    public function modificar($id, $nombre, $modelo, $version, $idSitio, $idInstalacion, $descripcion, $estado, $proveedores) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $switch = new Switchs($id, $nombre, $modelo, $version, $idSitio, $idInstalacion, NULL, $descripcion, $estado, NULL, $proveedores);
            $resultado = $switch->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $switch);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $switch = new Switchs($id, NULL, NULL, NULL, NULL, NULL, $rti, NULL, NULL, $visibilidad);
            $resultado = $switch->modificarCGTI();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificarCGTI", $switch);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Switch $switch Switch con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $switch) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "SWITCHS";
        $metodo = "ControladorSwitch::$funcion";
        $detalle = substr($switch->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
