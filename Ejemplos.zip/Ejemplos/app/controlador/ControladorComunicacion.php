<?php

namespace app\controlador;

use app\modelo\Comunicacion;
use app\modelo\ComunicacionColeccion as Comunicaciones;
use app\modelo\SQLServer;
use app\modelo\Log;

class ControladorComunicacion {

    public function buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $nombreProveedor, $estado) {
        $nombreLargo = utf8_decode($nombreLargo);
        $nombreGerencia = utf8_decode($nombreGerencia);
        $nombreEmpleado = utf8_decode($nombreEmpleado);
        $nombreSitio = utf8_decode($nombreSitio);
        $nombreProveedor = utf8_decode($nombreProveedor);
        return Comunicaciones::buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $nombreProveedor, $estado);
    }

    public function buscarInformesComunicacion() {
        return Comunicaciones::buscarInformesComunicacion();
    }

    public function buscarUltimasCreadas($top, $estado) {
        return Comunicaciones::buscarUltimasCreadas($top, $estado);
    }

    /**
     * @param string $nombreCorto Nombre corto del vinculo de comunicacion.
     * @param string $nombreLargo Nombre largo de la comunicacion.
     * @param int $cantidad Cantidad de elementos.
     * @param int $idGerencia Identificador de la gerencia.
     * @param string $idEmpleado Identificador del empleado.
     * @param string $idSitio Identificador del sitio.
     * @param int $idProveedor Identificador del proveedor.
     * @param string $descripcion Descripcion adicional.
     */
    public function crear($nombreCorto, $nombreLargo, $cantidad, $idGerencia, $idEmpleado, $idSitio, $idProveedor, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $comunicacion = new Comunicacion(NULL, $nombreCorto, $nombreLargo, $cantidad, $idGerencia, $idEmpleado, $idSitio, $idProveedor, NULL, NULL, $descripcion);
            $resultado = $comunicacion->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $comunicacion);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function consultar($nombre, $gerencia, $empleado, $sitio, $proveedor) {
        $resultado = Comunicaciones::consultar($nombre, $gerencia, $empleado, $sitio, $proveedor);
        return $resultado;
    }

    public function modificar($id, $nombreCorto, $nombreLargo, $cantidad, $idGerencia, $idEmpleado, $idSitio, $idProveedor, $estado, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $comunicacion = new Comunicacion($id, $nombreCorto, $nombreLargo, $cantidad, $idGerencia, $idEmpleado, $idSitio, $idProveedor, NULL, $estado, $descripcion);
            $resultado = $comunicacion->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $comunicacion);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $comunicacion = new Comunicacion($id);
            $comunicacion->setRti($rti);
            $comunicacion->setVisibilidad($visibilidad);
            $resultado = $comunicacion->modificarCGTI();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $comunicacion);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Comunicacion $comunicacion Vinculo de comunicacion con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $comunicacion) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "COMUNICACIONES";
        $metodo = "ControladorComunicacion::$funcion";
        $detalle = substr($comunicacion->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
