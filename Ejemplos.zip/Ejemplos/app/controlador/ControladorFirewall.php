<?php

namespace app\controlador;

use app\modelo\Firewall;
use app\modelo\FirewallColeccion as Firewalls;
use app\modelo\SQLServer;
use app\modelo\Log;

class ControladorFirewall {

    public function buscar($nombreFirewall, $marca, $nombreSitio, $estado) {
        $nombreFirewall = utf8_decode($nombreFirewall);
        $marca = utf8_decode($marca);
        $nombreSitio = utf8_decode($nombreSitio);
        return Firewalls::buscar($nombreFirewall, $marca, $nombreSitio, $estado);
    }

    public function buscarInformesFirewall() {
        return Firewalls::buscarInformesFirewall();
    }

    public function buscarUltimosCreados($top, $estado) {
        return Firewalls::buscarUltimosCreados($top, $estado);
    }

    /**
     * @param string $nombre Nombre del elemento.
     * @param string $marca Nombre de la marca.
     * @param string $modelo Modelo del firewall.
     * @param string $numeroSerie Numero de serie.
     * @param string $version Version del elemento.
     * @param string $ip Direccion IP.
     * @param string $descripcion Descripcion adicional.
     * @param array $proveedores Arreglo de identificadores de proveedores.
     */
    public function crear($nombre, $marca, $modelo, $numeroSerie, $version, $idSitio, $ip, $descripcion, $proveedores) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $firewall = new Firewall(NULL, $nombre, $marca, $modelo, $numeroSerie, $version, $ip, $idSitio, NULL, $descripcion, NULL, NULL, $proveedores);
            $resultado = $firewall->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $firewall);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificar($id, $nombre, $marca, $modelo, $numeroSerie, $version, $ip, $idSitio, $descripcion, $estado, $proveedores) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $firewall = new Firewall($id, $nombre, $marca, $modelo, $numeroSerie, $version, $ip, $idSitio, NULL, $descripcion, $estado, NULL, $proveedores);
            $resultado = $firewall->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $firewall);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $firewall = new Firewall($id);
            $firewall->setRti($rti);
            $firewall->setVisibilidad($visibilidad);
            $resultado = $firewall->modificarCGTI();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificarGCTI", $firewall);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Firewall $firewall Firewall con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $firewall) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "FIREWALLS";
        $metodo = "ControladorFirewall::$funcion";
        $detalle = substr($firewall->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
