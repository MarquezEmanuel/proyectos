<?php

namespace app\controlador;

use app\modelo\SQLServer;
use app\modelo\Log;
use app\modelo\LenguajeProgramacion;
use app\modelo\LenguajeProgramacionColeccion as Lenguajes;

class ControladorLenguaje {

    public function buscar($nombre, $version, $descripcion, $estado) {
        $nombre = utf8_decode($nombre);
        $version = utf8_decode($version);
        $descripcion = utf8_decode($descripcion);
        return Lenguajes::buscar($nombre, $version, $descripcion, $estado);
    }

    public function buscarParaSeleccionar($nombre) {
        $nombre = utf8_decode($nombre);
        return Lenguajes::buscarParaSeleccionar($nombre);
    }

    public function buscarUltimosCreados($top, $estado) {
        return Lenguajes::buscarUltimosCreados($top, $estado);
    }

    public function crear($nombre, $version, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $lenguaje = new LenguajeProgramacion(NULL, $nombre, $version, $descripcion);
            $resultado = $lenguaje->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $lenguaje);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function consultar($nombre, $version) {
        $resultado = LenguajesProgramacion::consultar($nombre, $version);
        return $resultado;
    }

    public function modificar($id, $nombre, $version, $descripcion, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $lenguaje = new LenguajeProgramacion($id, $nombre, $version, $descripcion, $estado);
            $resultado = $lenguaje->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $lenguaje);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param LenguajeProgramacion $lenguaje Plataforma con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $lenguaje) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "LENGUAJES";
        $metodo = "ControladorLenguaje::$funcion";
        $detalle = substr($lenguaje->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
