<?php

namespace app\controlador;

use app\modelo\Responsable;
use app\modelo\ResponsableColeccion as Responsables;
use app\modelo\SQLServer;
use app\modelo\Log;

/**
 * Description of ControladorResponsable
 *
 * @author Emanuel
 */
class ControladorResponsable {

    public function buscar($nombreResponsable, $nombreProveedor, $estado) {
        return Responsables::buscar($nombreResponsable, $nombreProveedor, $estado);
    }

    public function buscarUltimosCreados($top, $estado) {
        return Responsables::buscarUltimosCreados($top, $estado);
    }

    public function crear($nombre, $telefono, $correo, $idProveedor) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $responsable = new Responsable(NULL, $nombre, $telefono, $correo, $idProveedor);
            $resultado = $responsable->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $responsable);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function consultar($nombre, $proveedor) {
        $resultado = Responsables::consultar($nombre, $proveedor);
        return $resultado;
    }

    public function modificar($id, $nombre, $telefono, $correo, $proveedor, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $responsable = new Responsable($id, $nombre, $telefono, $correo, $proveedor);
            $resultado = $responsable->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "cambiarEstado", $responsable);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Responsable $responsable Responsable con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $responsable) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "PROVEEDORES";
        $metodo = "ControladorResponsable::$funcion";
        $detalle = substr($responsable->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
