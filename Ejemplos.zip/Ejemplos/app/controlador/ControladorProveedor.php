<?php

namespace app\controlador;

use app\modelo\Proveedor;
use app\modelo\ProveedorColeccion as Proveedores;
use app\modelo\SQLServer;
use app\modelo\Log;

class ControladorProveedor {

    public function buscar($nombre, $provincia, $ciudad, $estado) {
        return Proveedores::buscar($nombre, $provincia, $ciudad, $estado);
    }

    public function buscarEstadoActivo() {
        return Proveedores::buscarEstadoActivo();
    }

    public function buscarParaSeleccionar($nombre) {
        return Proveedores::buscarParaSeleccionar($nombre);
    }

    public function buscarUltimosCreados($top, $estado) {
        return Proveedores::buscarUltimosCreados($top, $estado);
    }

    public function crear($nombre, $telefono, $correo, $provincia, $ciudad, $direccion, $tipo, $servicios) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $proveedor = new Proveedor(NULL, $nombre, $telefono, $correo, $provincia, $ciudad, $direccion, $tipo, $servicios);
            $resultado = $proveedor->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $proveedor);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function consultar($nombre, $provincia) {
        $resultado = Proveedores::consultar($nombre, $provincia);
        return $resultado;
    }

    public function modificar($id, $nombre, $telefono, $correo, $provincia, $localidad, $direccion, $tipo, $estado, $servicios) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $proveedor = new Proveedor($id, $nombre, $telefono, $correo, $provincia, $localidad, $direccion, $tipo, $servicios, $estado);
            $resultado = $proveedor->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $proveedor);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function seleccionar($nombre) {
        $resultado = Proveedores::seleccionar($nombre);
        return $resultado;
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Proveedor $proveedor Provedor con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $proveedor) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "PROVEEDORES";
        $metodo = "ControladorProveedor::$funcion";
        $detalle = substr($proveedor->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
