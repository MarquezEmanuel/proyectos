<?php

namespace app\controlador;

use app\modelo\Usuario;
use app\modelo\UsuarioColeccion as Usuarios;
use app\modelo\SQLServer;
use app\modelo\Log;

/**
 * Controla los eventos de los modelos de usuario.
 * 
 * @package app\seguridad\controlador.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ControladorUsuario {

    /**
     * Devuelve todos los datos de uno o mas usuarios obtenidos a partir de su 
     * nombre y/o estado. Este metodo consulta la vista de usuarios (vwseg_usuario)
     * para obtener los datos.
     * @param string $nombre Nombre o parte del nombre del usuario.
     * @param string $estado Estado actual del usuario a consultar.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function buscar($nombre, $estado) {
        $nombreUsuario = utf8_decode($nombre);
        return Usuarios::buscar($nombreUsuario, $estado);
    }

    /**
     * Devuelve un listado de usuarios segun la cantidad especificada en el tope. 
     * Este metodo consula la vista de usuarios (vwseg_usuario) y esta diseñado 
     * para ser utilizado como una vista previa durante una busqueda.
     * @param integer $tope Numero de cantidad maxima a mostrar (TOP SQL).
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function buscarConTope($tope, $estado) {
        return Usuarios::buscarConTope($tope, $estado);
    }

    /**
     * Realiza la creacion de un nuevo usuario. El resultado de esta operacion
     * se guarda en el log de actividades del sistema.
     * @param string $legajo Numero de legajo del nuevo usuario.
     * @param string $nombre Nombre y Apellido del nuevo usuario.
     * @param integer $idPerfil Identificador del perfil.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function crear($legajo, $nombre, $idPerfil) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $usuario = new Usuario($legajo, $nombre, NULL, $idPerfil);
            $resultado = $usuario->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            $this->registrar($resultado, "creacion", "crear", $usuario);
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Realiza la modificacion de un determinado usuario en la base de datos. El
     * resultado de esta operacion se registra en el log de actividades de la base
     * de datos.
     * @param string $legajoOriginal Legajo original cuando este se desea modificar.
     * @param string $legajo Numero de legajo del usuario.
     * @param string $nombre Nombre y Apellido del usuario.
     * @param integer $perfil Identificador del perfil.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function modificar($legajoOriginal, $legajo, $nombre, $estado, $perfil) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $usuario = new Usuario($legajo, $nombre, $estado, $perfil);
            $resultado = $usuario->modificar($legajoOriginal);
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $usuario);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Servicio $usuario Usuario con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $usuario) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "SEGURIDAD";
        $metodo = "ControladorUsuario::$funcion";
        $detalle = substr($usuario->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
