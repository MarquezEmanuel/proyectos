<?php

namespace app\controlador;

use app\modelo\BaseDatosManual;
use app\modelo\BaseDatosManualColeccion as BasesDatosManual;
use app\modelo\SQLServer;
use app\modelo\Log;

class ControladorBaseDatosManual {

    public function buscar($nombre, $collation, $estado) {
        return BasesDatosManual::buscar($nombre, $collation, $estado);
    }

    public function buscarInformesBaseDatos() {
        return BasesDatosManual::buscarInformesBaseDatos();
    }

    public function buscarParaSeleccionar($nombre) {
        return BasesDatosManual::buscarParaSeleccionar($nombre);
    }

    public function buscarUltimasCreadas($top, $estado) {
        return BasesDatosManual::buscarUltimasCreadas($top, $estado);
    }

    /**
     * @param string $nombre Nombre de la base de datos.
     * @param string $collation Collation de la base de datos.
     * @param string $estadoBase Estado de la base de datos.
     * @param array $hardwares Arreglo de hardwares (idHardware, fechaCreacion).
     */
    public function crear($nombre, $collation, $estadoBase, $descripcion, $hardwares) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $base = new BaseDatosManual(NULL, $nombre, $collation, $estadoBase, NULL, $descripcion, NULL, NULL, $hardwares);
            $resultado = $base->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $base);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificar($id, $nombre, $collation, $estadoBase, $descripcion, $estado, $servidores) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $base = new BaseDatosManual($id, $nombre, $collation, $estadoBase, NULL, $descripcion, $estado, NULL, $servidores);
            $resultado = $base->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $base);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param BaseDatosManual $base Base de datos con la que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $base) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "BASES DATOS";
        $metodo = "ControladorBaseDatosManual::$funcion";
        $detalle = substr($base->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
