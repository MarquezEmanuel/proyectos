<?php

namespace app\controlador;

use app\modelo\SQLServer;
use app\modelo\Log;
use app\modelo\PlataformaSO;
use app\modelo\PlataformaSOColeccion as Plataformas;

class ControladorPlataformaSO {

    public function buscar($nombre, $estado) {
        return Plataformas::buscar($nombre, $estado);
    }

    public function buscarUltimasCreadas($top, $estado) {
        return Plataformas::buscarUltimasCreadas($top, $estado);
    }

    public function buscarParaSeleccionar($nombre) {
        return Plataformas::buscarParaSeleccionar($nombre);
    }

    public function crear($nombre) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $plataforma = new PlataformaSO(NULL, $nombre);
            $resultado = $plataforma->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $plataforma);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    public function modificar($id, $nombre, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $plataforma = new PlataformaSO($id, $nombre, $estado);
            $resultado = $plataforma->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $plataforma);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param PlataformaSO $plataforma Plataforma con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $plataforma) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "PLATAFORMAS";
        $metodo = "ControladorPlataformaSO::$funcion";
        $detalle = substr($plataforma->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
