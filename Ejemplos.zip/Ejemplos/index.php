<?php
/* Incluye el archivo con las constantes del sistema y el autocargador */
require_once './config/inc_config.php';
require_once './app/modelo/AutoCargador.php';

use app\modelo\AutoCargador;
use app\modelo\Constantes;
use app\modelo\ConstantesVersion as Version;
use app\modelo\Log;
use app\controlador\ControladorPrincipal;

/* Se cargan los modulos que sean necesarios */
AutoCargador::cargarModulos();

session_start();
$seccionMensaje = "";
if (isset($_POST['btnIngreso'])) {
    $legajo = $_POST['legajo'];
    $clave = $_POST['clave'];
    $controlador = new ControladorPrincipal();
    $autorizado = $controlador->verificarUsuarioSistema($legajo, $clave);
    if ($autorizado[0]) {
        header("Location: app/vista/core_home.php");
    } else {
        Log::escribirLineaError("USUARIO {$legajo} NO AUTORIZADO PARA INGRESAR POR ACTIVE DIRECTORY");
        Log::guardarActividad("ACCESO", "ACCESO", "INGRESO", "verificarUsuarioSistema", "", "{$legajo} --> $autorizado[1]");
        $seccionMensaje = '<div class="alert alert-danger text-center"><strong>' . $autorizado[1] . '</strong></div>';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <title><?= Constantes::APP_NOMBRE_CORTO; ?></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="./lib/cap/cap-admin.min.css">
        <link rel="stylesheet" href="./lib/cap/cap.css">
    </head> 
    <body class="bg-dark">
        <div class="container">
            <div class="card card-login mx-auto mt-5 border-azul-clasico">
                <div class="card-header bg-azul-clasico text-white text-center">
                    <?= Constantes::APP_NOMBRE_CORTO; ?> - FORMULARIO DE INGRESO 
                </div>
                <div class="card-body">
                    <div class="mt-4">
                        <?= $seccionMensaje; ?>
                    </div>
                    <div class="mb-4">
                        <form method="POST">
                            <div class="form-group">
                                <div class="form-label-group">
                                    <input type="text" class="form-control" 
                                           name="legajo" id="legajo" maxlength="10"
                                           title="Número de legajo" required>
                                    <label for="legajo">Legajo</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="form-label-group">
                                    <input type="password" class="form-control" 
                                           name="clave" id="clave"
                                           title="Clave personal" required>
                                    <label for="clave">Clave</label>
                                </div>
                            </div>
                            <input type="submit" name="btnIngreso" id="btnIngreso" 
                                   class="btn btn-outline-success btn-block" 
                                   title="Ingresar a CAP"
                                   value="INGRESAR">
                        </form>
                    </div>
                </div>
                <div class="card-footer bg-azul-clasico text-white">
                    <div class="form-row">
                        <div class="col text-left"><?= Constantes::APP_BANCO_LARGO; ?></div>
                        <div class="col text-right"><?= Version::APP_VERSION; ?></div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>