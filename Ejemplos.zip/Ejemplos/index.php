<?php

header("Location: ./app/vista/core_header.php");
