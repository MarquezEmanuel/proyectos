<?php

namespace app\comunicacion\modelo;

use app\principal\modelo\SQLServer;
use app\gerencia\modelo\Gerencia;
use app\gerencia\modelo\Empleado;
use app\sitio\modelo\Sitio;
use app\proveedor\modelo\Proveedor;

/**
 * 
 * @package app\comunicacion\modelo.
 * 
 * @uses SQLServer app\principal\modelo\SQLServer.
 * @uses Gerencia app\gerencia\modelo\Gerencia.
 * @uses Empleado app\gerencia\modelo\Empleado.
 * @uses Sitio app\sitio\modelo\Sitio.
 * @uses Proveedor app\proveedor\modelo\Proveedor.
 */
class Comunicacion {

    private $id;
    private $nombreCorto;
    private $nombreLargo;
    private $cantidad;
    private $gerencia;
    private $empleado;
    private $sitio;
    private $proveedor;

    /** @var string Riesgo de TI [NVARCHAR(5) NOT NULL] */
    private $rti;

    /** @var string Estado del registro [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var string Descripcion del elemento auxiliar [NVARCHAR(500) NOT NULL] */
    private $descripcion;

    /** @var int Nivel de visibilidad [INT NOT NULL] */
    private $visibilidad;

    /** @var string Fecha de creacion del registro [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de ultima edicion del registro [SMALLDATETIME NOT NULL] */
    private $fechaEdicion;

    /**
     * @param int $id Identificador del registro [PK BIGINT].
     * @param string $nombreCorto Nombre corto del vinculo [NVARCHAR(20)].
     * @param string $nombreLargo Nombre largo del vinculo [NVARCHAR(50)].
     * @param int $cantidad Cantidad de vinculos [INT].
     * @param string $gerencia Gerencia o identificador de gerencia [FK BIGINT].
     * @param string $empleado Empleado o identificador de empleado [FK NVARCHAR(10)].
     * @param string $sitio Sitio o identificador del sitio [FK NVARCHAR(10)].
     * @param string $proveedor Proveedor o identificador proveedor [FK BIGINT].
     * @param string $rti Riesgo de TI [NVARCHAR(5)].
     * @param string $estado Estado del registro [NVARCHAR(20)].
     * @param string $descripcion Descripcion del vinculo [NVARCHAR(500)].
     * @param int $visibilidad Nivel de visibilidad del registro [INT].
     */
    public function __construct($id = NULL, $nombreCorto = NULL, $nombreLargo = NULL, $cantidad = NULL, $gerencia = NULL, $empleado = NULL, $sitio = NULL, $proveedor = NULL, $rti = NULL, $estado = NULL, $descripcion = NULL, $visibilidad = NULL) {
        $this->setId($id);
        $this->setNombreCorto($nombreCorto);
        $this->setNombreLargo($nombreLargo);
        $this->setCantidad($cantidad);
        $this->setGerencia($gerencia);
        $this->setEmpleado($empleado);
        $this->setSitio($sitio);
        $this->setProveedor($proveedor);
        $this->setRti($rti);
        $this->setEstado($estado);
        $this->setDescripcion($descripcion);
        $this->setVisibilidad($visibilidad);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombreCorto() {
        return utf8_encode($this->nombreCorto);
    }

    public function getNombreLargo() {
        return utf8_encode($this->nombreLargo);
    }

    public function getCantidad() {
        return $this->cantidad;
    }

    public function getGerencia() {
        return $this->gerencia;
    }

    public function getEmpleado() {
        return $this->empleado;
    }

    public function getSitio() {
        return $this->sitio;
    }

    public function getProveedor() {
        return $this->proveedor;
    }

    public function getRti() {
        return $this->rti;
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getVisibilidad() {
        return $this->visibilidad;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombreCorto($nombreCorto) {
        $this->nombreCorto = utf8_decode($nombreCorto);
    }

    public function setNombreLargo($nombreLargo) {
        $this->nombreLargo = utf8_decode($nombreLargo);
    }

    public function setCantidad($cantidad) {
        $this->cantidad = $cantidad;
    }

    public function setGerencia($gerencia) {
        $this->gerencia = $gerencia;
    }

    public function setEmpleado($empleado) {
        $this->empleado = $empleado;
    }

    public function setSitio($sitio) {
        $this->sitio = $sitio;
    }

    public function setProveedor($proveedor) {
        $this->proveedor = $proveedor;
    }

    public function setRti($rti) {
        $this->rti = $rti;
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = utf8_decode($descripcion);
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setVisibilidad($visibilidad) {
        $this->visibilidad = $visibilidad;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE com_comunicacion SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para cambiar estado del vinculo de comunicación");
    }

    public function crear() {
        if ($this->nombreCorto && $this->nombreLargo && $this->cantidad && $this->gerencia && $this->empleado && $this->sitio && $this->proveedor && $this->descripcion) {
            $consulta = "INSERT INTO com_comunicacion OUTPUT INSERTED.id VALUES (? ,?, ?, ?, ?, ?, ?, 'Si', ?, 'Activa', 1, GETDATE(), NULL)";
            $datos = array(&$this->nombreCorto, &$this->nombreLargo, &$this->cantidad, &$this->gerencia, &$this->empleado, &$this->sitio, &$this->proveedor, &$this->descripcion);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            $this->id = ($resultado[0] == 2) ? $resultado[2] : NULL;
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear vinculo de comunicación");
    }

    public function modificar() {
        if ($this->nombreCorto && $this->nombreLargo && $this->cantidad && $this->gerencia && $this->empleado && $this->sitio && $this->proveedor && $this->descripcion) {
            $consulta = "UPDATE com_comunicacion SET nombreCorto=?, nombreLargo=?, "
                    . "cantidad=?, idGerencia=?, idEmpleado=?, idSitio=?, idProveedor=?, "
                    . "descripcion=?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->nombreCorto, &$this->nombreLargo, &$this->cantidad, &$this->gerencia, &$this->empleado, &$this->sitio, &$this->proveedor, &$this->descripcion, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para modificar vinculo de comunicación");
    }

    /**
     * Permite modificar los datos del activo que corresponde a Control de Gestion
     * de Tecnologia Informatica (CGTI). Este metodo actualiza los campos
     * rti, nivel de visibilidad y fecha de ultima edicion.
     * @return array Arreglo con dos elementos [codigo, mensaje].
     */
    public function modificarCGTI() {
        if ($this->id && $this->rti && $this->visibilidad) {
            $consulta = "UPDATE com_comunicacion SET rti = ?, nivelVisibilidad = ?, "
                    . "fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->rti, &$this->visibilidad, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para modificar el vinculo de comunicación");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM com_comunicacion WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombreCorto = $fila['nombreCorto'];
                $this->nombreLargo = $fila['nombreLargo'];
                $this->cantidad = $fila['cantidad'];
                $this->gerencia = $fila['idGerencia'];
                $this->empleado = $fila['idEmpleado'];
                $this->sitio = $fila['idSitio'];
                $this->proveedor = $fila['idProveedor'];
                $this->rti = $fila['rti'];
                $this->descripcion = $fila['descripcion'];
                $this->estado = $fila['estado'];
                $this->visibilidad = $fila['nivelVisibilidad'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia a la comunicación");
    }

    public function obtenerGerencia() {
        $gerencia = new Gerencia($this->gerencia);
        $resultado = $gerencia->obtener();
        $this->gerencia = ($resultado[0] == 2) ? $gerencia : NULL;
        return $resultado;
    }

    public function obtenerSitio() {
        $ubicacion = new Sitio($this->sitio);
        $resultado = $ubicacion->obtener();
        $this->sitio = ($resultado[0] == 2) ? $ubicacion : NULL;
        return $resultado;
    }

    public function obtenerEmpleado() {
        $delegado = new Empleado($this->empleado);
        $resultado = $delegado->obtener();
        $this->empleado = ($resultado[0] == 2) ? $delegado : NULL;
        return $resultado;
    }

    public function obtenerProveedor() {
        $proveedor = new Proveedor($this->proveedor);
        $resultado = $proveedor->obtener();
        $this->proveedor = ($resultado[0] == 2) ? $proveedor : NULL;
        return $resultado;
    }

    /**
     * Genera una cadena de texto con los datos del elemento auxiliar. Se omiten
     * los campos descripcion, fecha de creacion y fecha de ultima edicion.
     * @return string Datos del elemento auxiliar.
     */
    public function toString() {
        $comunicacion = ($this->id) ? "{{$this->id}," : "{0,";
        $comunicacion .= ($this->nombreCorto) ? "'{$this->getNombreCorto()}'," : "'',";
        $comunicacion .= ($this->nombreLargo) ? "'{$this->getNombreLargo()}'," : "'',";
        $comunicacion .= ($this->cantidad) ? "{$this->cantidad}," : ",";
        $comunicacion .= ($this->gerencia && gettype($this->gerencia) == "integer") ? "{$this->gerencia}," : ",";
        $comunicacion .= ($this->empleado && gettype($this->empleado) == "string") ? "'{$this->empleado}'," : "'',";
        $comunicacion .= ($this->sitio && gettype($this->sitio) == "string") ? "'{$this->sitio}'," : "'',";
        $comunicacion .= ($this->proveedor && gettype($this->proveedor) == "integer") ? "{$this->proveedor}," : ",";
        $comunicacion .= ($this->rti) ? "'{$this->getRti()}'," : "'',";
        $comunicacion .= ($this->estado) ? "'{$this->getEstado()}'," : "'',";
        $comunicacion .= ($this->visibilidad) ? "{$this->visibilidad}}" : "0}";
        return $comunicacion;
    }

}
