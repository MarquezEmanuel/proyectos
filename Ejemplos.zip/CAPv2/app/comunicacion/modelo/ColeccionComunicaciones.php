<?php

namespace app\comunicacion\modelo;

use app\principal\modelo\SQLServer;

class ColeccionComunicaciones {

    public static function buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $nombreProveedor, $estado) {
        $consulta = "SELECT * FROM vwcom_comunicacion WHERE nombreLargoComunicacion LIKE ? "
                . " AND nombreGerencia LIKE ? AND nombreEmpleado LIKE ? "
                . " AND nombreSitio LIKE ? AND nombreProveedor LIKE ? "
                . " AND estadoComunicacion = ?";
        $datos = array("%{$nombreLargo}%", "%{$nombreGerencia}%", "%{$nombreEmpleado}%", "%{$nombreSitio}%", "%{$nombreProveedor}%", &$estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    /**
     * Busca los registros de un determinado informe.
     * @param int idInforme Identificador del informe solicitado.
     * return array Arreglo nulo, vacio o con la informacion del reporte.
     */
    private static function buscarDatosInforme($idInforme) {
        $consulta = "SELECT detalle, total FROM vwcom_informes WHERE id = ? ORDER BY detalle";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$idInforme));
        if ($resultado[0] == 2) {
            $datos = array();
            while ($registro = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $datos[] = array('detalle' => $registro['detalle'], 'total' => $registro['total']);
            }
            return $datos;
        }
        return NULL;
    }

    /**
     * Busca los informes disponibles y agrupa su informacion.
     */
    public static function buscarInformesComunicacion() {
        $consulta = "SELECT DISTINCT id, informe, COUNT(*) distribucion "
                . " FROM vwcom_informes GROUP BY id, informe ORDER BY id";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        if ($resultado[0] == 2) {
            $informes = array();
            while ($informe = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $datos = ColeccionComunicaciones::buscarDatosInforme($informe['id']);
                $informes[] = array($informe['id'], $informe['informe'], $informe['distribucion'], $datos);
            }
            return array(2, $informes);
        }
        return $resultado;
    }

    public static function buscarUltimasCreadas($top, $estado) {
        $consulta = "SELECT TOP(?) * FROM vwcom_comunicacion "
                . " WHERE estadoComunicacion = ? "
                . " ORDER BY fechaCreacionComunicacion DESC";
        return SQLServer::instancia()->seleccionar($consulta, array(&$top, &$estado));
    }

    public static function consultar($nombre, $gerencia, $empleado, $sitio, $proveedor) {
        $consulta = "SELECT * FROM vwcom_comunicacion WHERE cnombre LIKE ? AND gnombre LIKE ? AND enombre LIKE ? AND snombre LIKE ? AND pnombre LIKE ? AND cestado = 'Activa'";
        $datos = array('%' . utf8_decode($nombre) . '%', '%' . utf8_decode($gerencia) . '%', '%' . utf8_decode($empleado) . '%', '%' . utf8_decode($sitio) . '%', '%' . utf8_decode($proveedor) . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        return $resultado;
    }

}
