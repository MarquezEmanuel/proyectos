<?php
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\comunicacion\modelo\Comunicacion;

AutoCargador::cargarModulos();
session_start();

$boton = "";
if ($_POST['idComunicacion']) {
    $id = $_POST['idComunicacion'];
    $comunicacion = new Comunicacion($id);
    $resultado = $comunicacion->obtener();
    if ($resultado[0] == 2) {

        $nombreCorto = $comunicacion->getNombreCorto();
        $nombreLargo = $comunicacion->getNombreLargo();
        $cantidad = $comunicacion->getCantidad();
        $descripcion = $comunicacion->getDescripcion();
        $getGerencia = $comunicacion->obtenerGerencia();
        $getEmpleado = $comunicacion->obtenerEmpleado();
        $getSitio = $comunicacion->obtenerSitio();
        $getProveedor = $comunicacion->obtenerProveedor();

        $boton = '
            <button type="submit" class="btn btn-success" 
                    id="btnModificarComunicacion" disabled>
                    <i class="far fa-save"></i> GUARDAR
            </button>';

        /* CARGA LOS DATOS DE LA GERENCIA */

        if ($getGerencia[0] == 2) {
            $gerencia = $comunicacion->getGerencia();
            $idGerencia = $gerencia->getId();
            $nombreGerencia = $gerencia->getNombre();
            $opcionGerencia = "
                <select class='form-control mb-2' id='gerencia' name='gerencia' required>
                        <option value='{$idGerencia}'>{$nombreGerencia}</option>
                </select>";
        } else {
            $boton = '';
            $opcionGerencia = GeneradorHTML::getAlertaOperacion($getGerencia[0], $getGerencia[1]);
        }

        /* CARGA LOS DATOS DEL EMPLEADO DELEGADO */

        if ($getEmpleado[0] == 2) {
            $empleado = $comunicacion->getEmpleado();
            $idEmpleado = $empleado->getId();
            $nombreEmpleado = $empleado->getNombre();
            $opcionEmpleado = "
                <select class='form-control mb-2' id='delegado' name='delegado' required>
                        <option value='{$idEmpleado}'>{$nombreEmpleado}</option>
                </select>";
        } else {
            $boton = '';
            $opcionEmpleado = GeneradorHTML::getAlertaOperacion($getEmpleado[0], $getEmpleado[1]);
        }

        /* CARGA LOS DATOS DEL SITIO */

        if ($getSitio[0] == 2) {
            $sitio = $comunicacion->getSitio();
            $idSitio = $sitio->getId();
            $nombreSitio = $sitio->getNombre();
            $opcionSitio = "
                <select class='form-control mb-2' id='sitio' name='sitio' required>
                        <option value='{$idSitio}'>{$nombreSitio}</option>
                </select>";
        } else {
            $boton = '';
            $opcionSitio = GeneradorHTML::getAlertaOperacion($getSitio[0], $getSitio[1]);
        }

        /* CARGA LOS DATOS DEL EMPLEADO DELEGADO */

        if ($getProveedor[0] == 2) {
            $proveedor = $comunicacion->getProveedor();
            $idProveedor = $proveedor->getId();
            $nombreProveedor = $proveedor->getNombre();
            $opcionProveedor = "
                <select class='form-control mb-2' id='proveedor' name='proveedor' required>
                        <option value='{$idProveedor}'>{$nombreProveedor}</option>
                </select>";
        } else {
            $boton = '';
            $opcionProveedor = GeneradorHTML::getAlertaOperacion($getProveedor[0], $getProveedor[1]);
        }

        $cuerpo = '
            <input type="hidden" name="idComunicacion" id="idComunicacion" value="' . $id . '">
            <div class="form-row">
                    <label for="nombreCorto" class="col-sm-2 col-form-label">* Nombre corto:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreCorto" id="nombreCorto" maxlength="20" 
                               value="' . $nombreCorto . '"
                               placeholder="Nombre corto" required>
                    </div>
                    <label for="nombreLargo" class="col-sm-2 col-form-label">* Nombre largo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreLargo" id="nombreLargo" maxlength="50"
                               value="' . $nombreLargo . '"
                               placeholder="Nombre largo" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="gerencia" class="col-sm-2 col-form-label">* Gerencia:</label>
                    <div class="col">' . $opcionGerencia . '</div>
                    <label for="delegado" class="col-sm-2 col-form-label">* Delegado:</label>
                    <div class="col">' . $opcionEmpleado . '</div>
                </div>
                <div class="form-row">
                    <label for="sitio" class="col-sm-2 col-form-label">* Sitio:</label>
                    <div class="col">' . $opcionSitio . '</div>
                    <label for="proveedor" class="col-sm-2 col-form-label">* Proveedor:</label>
                    <div class="col">' . $opcionProveedor . '</div>
                </div>
                <div class="form-row">
                    <label for="cantidad" class="col-sm-2 col-form-label">* Cantidad:</label>
                    <div class="col">
                        <input type="number" class="form-control mb-2" 
                               name="cantidad" id="cantidad" min="1"
                               value="' . $cantidad . '"
                               placeholder="Cantidad" required>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>
                <div class="form-row">
                    <label for="cantidad" class="col-sm-2 col-form-label">* Descripción:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  name="descripcion" id="descripcion"
                                  maxlength="500"
                                  placeholder="Decripción">' . $descripcion . '</textarea>
                    </div>
                </div>';
    } else {
        $cuerpo = ControladorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = ControladorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-broadcast-tower"></i> MODIFICAR COMUNICACIÓN</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarComunicacion" name="formModificarComunicacion" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <a href="FBuscarComunicacion.php">
                    <button type="button" class="btn btn-outline-info">
                        <i class="fas fa-search"></i> BUSCAR
                    </button>
                </a>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="../js/ModificarComunicacion.js"></script>