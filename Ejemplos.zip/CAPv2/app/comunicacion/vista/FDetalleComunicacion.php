<?php
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\comunicacion\modelo\Comunicacion;

AutoCargador::cargarModulos();
session_start();
$boton = "";
if ($_POST['idComunicacion']) {
    $id = $_POST['idComunicacion'];
    $comunicacion = new Comunicacion($id);
    $resultado = $comunicacion->obtener();
    if ($resultado[0] == 2) {

        $nombreCorto = $comunicacion->getNombreCorto();
        $nombreLargo = $comunicacion->getNombreLargo();
        $cantidad = $comunicacion->getCantidad();
        $rti = $comunicacion->getRti();
        $descripcion = $comunicacion->getDescripcion();
        $estado = $comunicacion->getEstado();
        $fechaCreacion = $comunicacion->getFechaCreacion();
        $fechaEdicion = $comunicacion->getFechaEdicion();
        $fechaCreacionFormateada = isset($fechaCreacion) ? date_format($fechaCreacion, 'd/m/Y H:i') : "";
        $fechaEdicionFormateada = isset($fechaEdicion) ? date_format($fechaEdicion, 'd/m/Y H:i') : "";
        $getGerencia = $comunicacion->obtenerGerencia();
        $getEmpleado = $comunicacion->obtenerEmpleado();
        $getSitio = $comunicacion->obtenerSitio();
        $getProveedor = $comunicacion->obtenerProveedor();

        /* CARGA LOS DATOS DE LA GERENCIA ASOCIADA AL ELEMENTO AUXILIAR */

        if ($getGerencia[0] == 2) {
            $gerencia = $comunicacion->getGerencia();
            $idGerencia = $gerencia->getId();
            $nombreGerencia = $gerencia->getNombre();
            $estadoGerencia = $gerencia->getEstado();
            $referenciaGerencia = '#' . str_pad($idGerencia, 6, "0", STR_PAD_LEFT);
            $filaGerencia = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Referencia:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $referenciaGerencia . '"
                               title="Referencia de la gerencia"
                               placeholder="Referencia" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreGerencia . '"
                               title="Nombre de la gerencia"
                               placeholder="Nombre" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoGerencia . '"
                               title="Estado de la gerencia"
                               placeholder="Estado" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>';
        } else {
            $datosGerencia = GeneradorHTML::getAlertaOperacion($getGerencia[0], $getGerencia[1]);
            $filaGerencia = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosGerencia . '</div>
                </div>';
        }

        /* CARGA LOS DATOS DEL EMPLEADO DELEGADO ASOCIADO AL ELEMENTO AUXILIAR */

        if ($getEmpleado[0] == 2) {
            $empleado = $comunicacion->getEmpleado();
            $legajoEmpleado = $empleado->getId();
            $nombreEmpleado = $empleado->getNombre();
            $estadoEmpleado = $empleado->getEstado();
            $filaEmpleado = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Legajo:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $legajoEmpleado . '"
                               title="Número de legajo del empleado delegado"
                               placeholder="Legajo" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreEmpleado . '"
                               title="Nombre del empleado delegado"
                               placeholder="Nombre" readonly>
                    </div>
                    
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoEmpleado . '"
                               title="Estado de empleado delegado"
                               placeholder="Estado" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>';
        } else {
            $datosEmpleado = GeneradorHTML::getAlertaOperacion($getEmpleado[0], $getEmpleado[1]);
            $filaEmpleado = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosEmpleado . '</div>
                </div>';
        }

        /* CARGA LOS DATOS DEL SITIO ASOCIADO AL VINCULO DE COMUNICACION */

        if ($getSitio[0] == 2) {
            $sitio = $comunicacion->getSitio();
            $idSitio = $sitio->getId();
            $tipoSitio = $sitio->getTipo();
            $nombreSitio = $sitio->getNombre();
            $estadoSitio = $sitio->getEstado();
            $filaSucursal = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Código:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $idSitio . '"
                               title="Código del sitio"
                               placeholder="Código" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Tipo:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $tipoSitio . '"
                               title="Tipo de sitio"
                               placeholder="Tipo" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreSitio . '"
                               title="Nombre del sitio"
                               placeholder="Nombre" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoSitio . '"
                               title="Estado del sitio"
                               placeholder="Estado" readonly>
                    </div>
                </div>';
        } else {
            $datosSucursal = GeneradorHTML::getAlertaOperacion($getSitio[0], $getSitio[1]);
            $filaSucursal = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosSucursal . '</div>
                </div>';
        }


        /* CARGA LOS DATOS DEL SITIO ASOCIADO AL VINCULO DE COMUNICACION */

        if ($getProveedor[0] == 2) {
            $proveedor = $comunicacion->getProveedor();
            $idProveedor = $proveedor->getId();
            $nombreProveedor = $proveedor->getNombre();
            $telefonoProveedor = $proveedor->getTelefono();
            $correoProveedor = $proveedor->getCorreo();
            $estadoProveedor = $proveedor->getEstado();
            $referenciaProveedor = '#' . str_pad($idProveedor, 6, "0", STR_PAD_LEFT);
            $filaProveedor = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Referencia:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $referenciaProveedor . '"
                               title="Referencia al proveedor"
                               placeholder="Referencia" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Nombre:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $nombreProveedor . '"
                               title="Nombre del proveedor"
                               placeholder="Nombre" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Telefono:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $telefonoProveedor . '"
                               title="Número telefonico del proveedor"
                               placeholder="Número telefonico" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label">Correo:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $correoProveedor . '"
                               title="Correo electrónico del proveedor"
                               placeholder="Correo electrónico" readonly>
                    </div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label">Estado:</label>
                    <div class="col"> 
                        <input type="text" class="form-control mb-2" 
                               value="' . $estadoProveedor . '"
                               title="Estado del proveedor"
                               placeholder="Estado" readonly>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>';
        } else {
            $datosProveedor = GeneradorHTML::getAlertaOperacion($getProveedor[0], $getProveedor[1]);
            $filaProveedor = '
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">' . $datosProveedor . '</div>
                </div>';
        }

        /* CARGA EL CUERPO DEL FORMULARIO CON LOS DATOS OBTENIDOS */

        $cuerpo = '
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Nombre corto:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombreCorto . '"
                           placeholder="Nombre corto" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Nombre largo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $nombreLargo . '"
                           placeholder="Nombre largo" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Cantidad:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $cantidad . '"
                           placeholder="Cantidad" readonly>
                </div>
                <label class="col-sm-2 col-form-label">RTI:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $rti . '"
                           placeholder="RTI" readonly>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Estado:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value="' . $estado . '"
                           placeholder="Estado" readonly>
                </div>
                <label class="col-sm-2 col-form-label"></label>
                <div class="col"></div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Descripción:</label>
                <div class="col">
                    <textarea class="form-control mb-2"
                              placeholder="Descripción" readonly>' . $descripcion . '</textarea>
                </div>
            </div>
            <div class="form-row">
                <label class="col-sm-2 col-form-label">Fecha de creación:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           value = "' . $fechaCreacionFormateada . '"
                           placeholder="Fecha de creación" readonly>
                </div>
                <label class="col-sm-2 col-form-label">Fecha de edición:</label>
                <div class="col">
                    <input type="input" class="form-control mb-2" 
                           value="' . $fechaEdicionFormateada . '"
                           placeholder="Fecha de ultima edición" readonly>
                </div>
            </div>
            <div class="form-row mt-4 mb-2">
                <div class="col-2">
                    <p class="font-weight-bold">GERENCIA</p>
                </div>
                <div class="col-10"><hr></div>
            </div>
            ' . $filaGerencia . '
            <div class="form-row mt-4 mb-2">
                <div class="col-2">
                    <p class="font-weight-bold">DELEGADO</p>
                </div>
                <div class="col-10"><hr></div>
            </div>
             ' . $filaEmpleado . '
            <div class="form-row mt-4 mb-2">
                <div class="col-2">
                    <p class="font-weight-bold">SITIO</p>
                </div>
                <div class="col-10"><hr></div>
            </div>' . $filaSucursal . '
            <div class="form-row mt-4 mb-2">
                <div class="col-2">
                    <p class="font-weight-bold">PROVEEDOR</p>
                </div>
                <div class="col-10"><hr></div>
            </div>' . $filaProveedor;
    } else {
        $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-broadcast-tower"></i> DETALLE DE COMUNICACIÓN</h4>
        </div>
    </div>
    <div class="card border-azul-clasico mt-3">
        <div class="card-header bg-azul-clasico text-white">Información</div>
        <div class="card-body">
            <?= $cuerpo; ?>
        </div>
    </div>
    <div class="form-row mt-2 mb-4">
        <div class="col text-right">
            <button type="button" class="btn btn-outline-info" 
                    onClick="window.location.reload();" >
                <i class="fas fa-search"></i> REGRESAR
            </button>
        </div>
    </div>
</div>