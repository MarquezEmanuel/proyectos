<?php

namespace app\instalacion\controlador;

use app\instalacion\modelo\Instalacion;
use app\instalacion\modelo\ColeccionInstalaciones as Instalaciones;
use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

class ControladorInstalacion {

    public function buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $estado) {
        return Instalaciones::buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $estado);
    }

    public function buscarInformesInstalacion() {
        return Instalaciones::buscarInformesInstalacion();
    }

    public function buscarParaSeleccionar($nombre) {
        return Instalaciones::buscarParaSeleccionar($nombre);
    }

    public function buscarUltimasCreadas($top, $estado) {
        return Instalaciones::buscarUltimasCreadas($top, $estado);
    }

    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $instalacion = new Instalacion($id, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, $estado);
            $resultado = $instalacion->cambiarEstado();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "cambiarEstado", $instalacion);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * @param string $nombreCorto Nombre corto.
     * @param string $nombreLargo Nombre largo.
     * @param int $idGerencia Identificador de la gerencia.
     * @param string $idEmpleado Identificador del empleado.
     * @param string $idSitio Identificador del sitio.
     * @param int $idPlataforma Identificador de la plataforma.
     * @param string $descripcion Descripcion adicional.
     */
    public function crear($nombreCorto, $nombreLargo, $idGerencia, $idEmpleado, $idSitio, $idPlataforma, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $instalacion = new Instalacion(NULL, $nombreCorto, $nombreLargo, $idGerencia, $idEmpleado, $idSitio, $idPlataforma, NULL, $descripcion);
            $resultado = $instalacion->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $instalacion);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function consultar($nombre, $gerencia, $empleado, $sitio) {
        $resultado = Instalaciones::consultar($nombre, $gerencia, $empleado, $sitio);
        return $resultado;
    }

    public function modificar($id, $nombreCorto, $nombreLargo, $idGerencia, $idEmpleado, $idSitio, $idPlataforma, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $instalacion = new Instalacion($id, $nombreCorto, $nombreLargo, $idGerencia, $idEmpleado, $idSitio, $idPlataforma, NULL, $descripcion);
            $resultado = $instalacion->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $instalacion);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $instalacion = new Instalacion($id);
            $instalacion->setRti($rti);
            $instalacion->setVisibilidad($visibilidad);
            $resultado = $instalacion->modificarCGTI();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificarGCTI", $instalacion);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Instalacion $instalacion Instalacion con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $instalacion) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "INSTALACIONES";
        $metodo = "ControladorInstalacion::$funcion";
        $detalle = substr($instalacion->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
