<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="fas fa-code-branch"></i> CONSULTAR INSTALACIÓN</h4>
                </div>
            </div>
            <div class="mt-3 mb-4">
                <form method="POST" id="formConsultarInstalacion" name="formConsultarInstalacion">
                    <input type="hidden" name="peticion" id="peticion">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="nombreLargo" class="col-2 col-form-label">Nombre largo:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreLargo" id="nombreLargo" 
                                           maxlength="50"
                                           title="Nombre largo de la instalación"
                                           placeholder="Nombre largo">
                                </div>
                                <label for="nombreGerencia" class="col-2 col-form-label">Gerencia:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreGerencia" id="nombreGerencia" 
                                           title="Nombre de la gerencia"
                                           placeholder="Nombre de gerencia">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="nombreEmpleado" class="col-2 col-form-label">Empleado:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreEmpleado" id="nombreEmpleado" 
                                           title="Nombre del empleado"
                                           placeholder="Nombre de empleado">
                                </div>
                                <label for="nombreSitio" class="col-2 col-form-label">Sitio:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreSitio" id="nombreSitio" 
                                           title="Nombre del sitio"
                                           placeholder="Nombre de sitio">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="nombrePlataforma" class="col-2 col-form-label">Plataforma:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombrePlataforma" id="nombrePlataforma" 
                                           title="Nombre de la plataforma"
                                           placeholder="Nombre de plataforma">
                                </div>
                                <label class="col-2 col-form-label"></label>
                                <div class="col"></div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-search"></i>  BUSCAR</button>
                        </div>
                    </div>
                </form>
            </div>
            <div id="seccionInferior" class="mt-4 mb-2"></div>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/ConsultarInstalacion.js"></script>