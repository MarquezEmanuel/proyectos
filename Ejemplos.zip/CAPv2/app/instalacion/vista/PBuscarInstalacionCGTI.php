<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\instalacion\controlador\ControladorInstalacion;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorInstalacion();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreLargo = $_POST['nombreLargo'];
    $nombreGerencia = $_POST['nombreGerencia'];
    $nombreEmpleado = $_POST['nombreEmpleado'];
    $nombreSitio = $_POST['nombreSitio'];
    $estado = 'Activa';
    $datos = ($nombreLargo) ? "'{$nombreLargo}', " : "TODOS, ";
    $datos .= ($nombreGerencia) ? "'{$nombreGerencia}', " : "TODAS, ";
    $datos .= ($nombreEmpleado) ? "'{$nombreEmpleado}', " : "TODOS, ";
    $datos .= ($nombreSitio) ? "'{$nombreSitio}', " : "TODOS, ";
    $datos .= ($estado) ? "'{$estado}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $estado);
    $_SESSION['BINSTALACIONES'] = array($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $estado, $datos);
} else {
    if (isset($_SESSION['BINSTALACIONES'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BINSTALACIONES'];
        $nombreLargo = $parametros[0];
        $nombreGerencia = $parametros[1];
        $nombreEmpleado = $parametros[2];
        $nombreSitio = $parametros[3];
        $estado = $parametros[4];
        $filtro = "Ultima búsqueda realizada: " . $parametros[5];
        $resultado = $controlador->buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $estado);
        $_SESSION['BINSTALACIONES'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activa';
        $resultado = $controlador->buscarUltimasCreadas($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['BINSTALACIONES'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $filas = "";
    $instalaciones = $resultado[1];
    while ($instalacion = sqlsrv_fetch_array($instalaciones, SQLSRV_FETCH_ASSOC)) {

        $idInstalacion = $instalacion['idInstalacion'];
        $nombreCortoInstalacion = utf8_encode($instalacion['nombreCortoInstalacion']);
        $nombreLargoInstalacion = utf8_encode($instalacion['nombreLargoInstalacion']);
        $idGerencia = $instalacion['idGerencia'];
        $nombreGerencia = utf8_encode($instalacion['nombreGerencia']);
        $estadoGerencia = $instalacion['estadoGerencia'];
        $idEmpleado = $instalacion['idEmpleado'];
        $nombreEmpleado = utf8_encode($instalacion['nombreEmpleado']);
        $estadoEmpleado = $instalacion['estadoEmpleado'];
        $idSitio = $instalacion['idSitio'];
        $tipoSitio = $instalacion['tipoSitio'];
        $nombreSitio = utf8_encode($instalacion['nombreSitio']);
        $estadoSitio = $instalacion['estadoSitio'];
        $idPlataforma = $instalacion['idPlataforma'];
        $nombrePlataforma = utf8_encode($instalacion['nombrePlataforma']);
        $estadoPlataforma = $instalacion['estadoPlataforma'];
        $rtiInstalacion = $instalacion['rtiInstalacion'];
        $descripcionInstalacion = utf8_encode($instalacion['descripcionInstalacion']);
        $estadoInstalacion = $instalacion['estadoInstalacion'];
        $fechaCreacion = isset($instalacion['fechaCreacionInstalacion']) ? date_format($instalacion['fechaCreacionInstalacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($instalacion['fechaUltimaEdicionInstalacion']) ? date_format($instalacion['fechaUltimaEdicionInstalacion'], 'd/m/Y H:i') : "";

        $filas .= "
            <tr>
                <td>{$nombreCortoInstalacion}</td>
                <td>{$nombreLargoInstalacion}</td>
                <td title='Gerencia: {$estadoGerencia}'>{$nombreGerencia}</td>
                <td style='display: none;'>{$estadoGerencia}</td> 
                <td style='display: none;'>{$idEmpleado}</td>
                <td title='Responsable: {$idEmpleado} {$estadoEmpleado}'>{$nombreEmpleado}</td>
                <td style='display: none;'>{$estadoEmpleado}</td>
                <td style='display: none;'>{$idSitio}</td>
                <td style='display: none;'>{$tipoSitio}</td>
                <td title='Sitio: {$idSitio} {$tipoSitio} {$estadoSitio}'>{$nombreSitio}</td>
                <td style='display: none;'>{$estadoSitio}</td>
                <td title='Plataforma: {$estadoPlataforma}'>{$nombrePlataforma}</td>
                <td style='display: none;'>{$estadoPlataforma}</td>
                <td>{$rtiInstalacion}</td>
                <td style='display: none;'>{$descripcionInstalacion}</td>
                <td style='display: none;'>{$estadoInstalacion}</td>
                <td style='display: none;'>{$fechaCreacion}</td> 
                <td style='display: none;'>{$fechaEdicion}</td> 
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$idInstalacion}' title='Detalle: {$nombreLargoInstalacion}'>
                                <i class='fas fa-info-circle'></i>
                        </button>
                        <button class='btn btn-outline-warning editar' 
                                name='{$idInstalacion}' title='Editar: {$nombreLargoInstalacion}'>
                            <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbInstalaciones" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre corto</th>
                        <th>Nombre largo</th>
                        <th>Nombre gerencia</th>
                        <th style="display: none;">Estado gerencia</th>
                        <th style="display: none;">Legajo responsable</th>
                        <th>Nombre responsable</th>
                        <th style="display: none;">Estado responsable</th>
                        <th style="display: none;">Código sitio</th>
                        <th style="display: none;">Tipo sitio</th>
                        <th>Nombre sitio</th>
                        <th style="display: none;">Estado sitio</th>
                        <th>Nombre plataforma</th>
                        <th style="display: none;">Estado plataforma</th>
                        <th>RTI</th>
                        <th style="display: none;">Descripcion</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">Fecha de creación</th>
                        <th style="display: none;">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
