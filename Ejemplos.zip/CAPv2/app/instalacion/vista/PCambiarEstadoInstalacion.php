<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\instalacion\controlador\ControladorInstalacion;

AutoCargador::cargarModulos();
session_start();

if (isset($_POST['mceiEstado'])) {
    $controlador = new ControladorInstalacion();
    $id = $_POST['mceiIdInstalacion'];
    $nombre = $_POST['mceiNombre'];
    $estado = $_POST['mceiEstado'];
    $modificacion = $controlador->cambiarEstado($id, $estado);
    $mensaje = "{$nombre}: {$modificacion[1]}";
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

echo $resultado;
