<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\instalacion\controlador\ControladorInstalacion;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['idInstalacion'])) {
    $controlador = new ControladorInstalacion();
    $id = $_POST['idInstalacion'];
    $nombreCorto = $_POST['nombreCorto'];
    $nombreLargo = $_POST['nombreLargo'];
    $gerencia = $_POST['gerencia'];
    $empleado = $_POST['empleado'];
    $sitio = $_POST['sitio'];
    $plataforma = $_POST['plataforma'];
    $descripcion = $_POST['descripcion'];
    $modificacion = $controlador->modificar($id, $nombreCorto, $nombreLargo, $gerencia, $empleado, $sitio, $plataforma, $descripcion);
    $mensaje = "{$nombreLargo}: {$modificacion[1]}";
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);

