<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\instalacion\controlador\ControladorInstalacion;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorInstalacion();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $instalaciones = $resultado[1];
        while ($instalacion = sqlsrv_fetch_array($instalaciones, SQLSRV_FETCH_ASSOC)) {
            $id = $instalacion['id'];
            $nombreInstalacion = utf8_encode($instalacion["nombreLargo"]);
            $arreglo[] = array('id' => $id, 'text' => $nombreInstalacion);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar instalacion";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'INSTALACION', 'busqueda', 'PSeleccionarInstalacion', '', $detalle);
}

echo json_encode($arreglo);
