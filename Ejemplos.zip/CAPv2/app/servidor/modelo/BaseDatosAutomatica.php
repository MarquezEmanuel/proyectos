<?php

class BaseDatos {

    private $id;
    private $nombre;
    private $motor;
    private $collation;
    private $servidor;
    private $fechaCreacion;
    private $fechaProceso;

    public function __construct($id = NULL, $nombre = NULL, $motor = NULL, $collation = NULL, $servidor = NULL, $fechaCreacion = NULL, $fechaProceso = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setMotor($motor);
        $this->setCollation($collation);
        $this->setServidor($servidor);
        $this->setFechaCreacion($fechaCreacion);
        $this->setFechaProceso($fechaProceso);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getMotor() {
        return $this->motor;
    }

    public function getCollation() {
        return $this->collation;
    }

    public function getServidor() {
        return $this->servidor;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaProceso() {
        return $this->fechaProceso;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function setMotor($motor) {
        $this->motor = $motor;
    }

    public function setCollation($collation) {
        $this->collation = $collation;
    }

    public function setServidor($servidor) {
        $this->servidor = $servidor;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaProceso($fechaProceso) {
        $this->fechaProceso = $fechaProceso;
    }

    public function modificar() {
        if ($this->id && $this->rti && $this->test && $this->desarrollo) {
            $consulta = "UPDATE bas_base SET rti = ?, test = ?, desarrollo = ? WHERE id = ?";
            $datos = array(&$this->rti, &$this->test, &$this->desarrollo, &$this->id);
            $modificacion = SQLServer::instancia()->modificar($consulta, $datos);
            $this->mensaje = SQLServer::instancia()->getMensaje();
            return ($modificacion == 2) ? $this->registrarActividad("MODIFICACION", $this->id) : $modificacion;
        }
        $this->mensaje = "No se recibieron los campos obligatorios";
        return 0;
    }

    private function registrarActividad($operacion, $id) {
        $creacion = Log::guardarActividad("bas_base", $operacion, $id);
        $this->mensaje = ($creacion == 2) ? $this->mensaje : "No se pudo registrar actividad";
        return $creacion;
    }

}
