<?php

namespace app\base\modelo;

use app\principal\modelo\SQLServer;


class ColeccionColumnas {

    public static function buscar($base, $tabla, $nombre, $descripcion) {
        $top = (!$base && !$tabla && (!$nombre || strlen($nombre) <= 2) && !$descripcion) ? "TOP(5000)" : "";
        $consulta = "SELECT {$top} * FROM vwbas_columna WHERE bnombre LIKE ? AND tnombre LIKE ? AND cnombre LIKE ? AND cdescripcion LIKE ?";
        $datos = array('%' . $base . '%', '%' . $tabla . '%', '%' . $nombre . '%', '%' . $descripcion . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        return $resultado;
    }

    public static function listarPorTabla($idTabla) {
        $consulta = "SELECT * FROM vwbas_columna WHERE tid = ? ORDER BY cnombre";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$idTabla));
        return $resultado;
    }

    public static function listarConTope($tope) {
        $consulta = "SELECT TOP(?) * FROM vwbas_columna ORDER BY cid DESC";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array($tope));
        return $resultado;
    }

}
