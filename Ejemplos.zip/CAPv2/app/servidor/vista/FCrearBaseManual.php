<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-database"></i> CREAR BASE DE DATOS</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formCrearBase" name="formCrearBase" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="nombre" class="col-sm-2 col-form-label">* Nombre:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombre" id="nombre" 
                               placeholder="Nombre" required>
                    </div>
                    <label for="collation" class="col-sm-2 col-form-label">* Collation:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="collation" id="collation"
                               placeholder="Collation" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="estadoBase" class="col-sm-2 col-form-label">* Estado:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="estadoBase" name="estadoBase">
                            <option value="ONLINE">ONLINE</option>
                            <option value="OFFLINE">OFFLINE</option>
                        </select>
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label">* Descripcion:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  id="descripcion" name="descripcion"
                                  maxlength="500"
                                  placeholder="Descripcion" required></textarea>
                    </div>
                </div>
                <div class="form-row mt-4 mb-3">
                    <div class="col-2"><p class="font-weight-bold">DATOS DE HARDWARE</p></div>
                    <div class="col-10"><hr></div>
                </div>
                <div class="form-row">
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col">
                        <label class="col-form-label mb-2">Hardware</label>
                    </div>
                    <div class="col">
                        <label class="col-form-label mb-2">Ruta</label>
                    </div>
                </div>
                <div class="form-row">
                    <label for="servidor1" class="col-sm-2 col-form-label">* N° 1:</label>
                    <div class="col">
                        <select class="form-control mb-2 hardware" name="servidor1" id="servidor1" required></select>
                    </div>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCreacion1" id="fechaCreacion1"
                               placeholder="Fecha de creación">
                    </div>
                </div>
                <div class="form-row">
                    <label for="servidor2" class="col-sm-2 col-form-label">N° 2:</label>
                    <div class="col">
                        <select class="form-control mb-2 hardware" name="servidor2" id="servidor2"></select>
                    </div>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCreacion2" id="fechaCreacion2"
                               placeholder="Fecha de creación">
                    </div>
                </div>
                <div class="form-row">
                    <label for="servidor3" class="col-sm-2 col-form-label">N° 3:</label>
                    <div class="col">
                        <select class="form-control mb-2 hardware" name="servidor3" id="servidor3"></select>
                    </div>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCreacion3" id="fechaCreacion3"
                               placeholder="Fecha de creación">
                    </div>
                </div>
                <div class="form-row">
                    <label for="servidor4" class="col-sm-2 col-form-label">N° 4:</label>
                    <div class="col">
                        <select class="form-control mb-2 hardware" name="servidor4" id="servidor4"></select>
                    </div>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCreacion4" id="fechaCreacion4"
                               placeholder="Fecha de creación">
                    </div>
                </div>
                <div class="form-row">
                    <label for="servidor5" class="col-sm-2 col-form-label">N° 5:</label>
                    <div class="col">
                        <select class="form-control mb-2 hardware" name="servidor5" id="servidor5"></select>
                    </div>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCreacion5" id="fechaCreacion5"
                               title="Fecha de creación"
                               placeholder="Fecha de creación">
                    </div>
                </div>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-success">
                    <i class="far fa-save"></i> GUARDAR
                </button>
                <button type="button" class="btn btn-outline-info" onclick="window.location.reload()">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="../js/CrearBaseDatosManual.js"></script>