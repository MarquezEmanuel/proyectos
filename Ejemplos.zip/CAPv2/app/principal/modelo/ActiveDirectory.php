<?php

namespace app\principal\modelo;

/**
 * Realiza la conexion con el HOST de Active Directory.
 * 
 * @package app\principal\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ActiveDirectory {

    /** @var recurso Conexion al servidor de AD. */
    private $conexion;

    /** @var string Nombre o IP del host a conectar. */
    private $host;

    /** @var int Numero de puerto del host. */
    private $puerto;

    /** @var string Dominio del AD. */
    private $dominio;

    /**
     * Constructor de la clase.
     * @param string $host Direccion IP del host active directory.
     * @param int $puerto Puerto de conexion al servidor.
     * @param string $dominio Dominio de conexion (Desarrollo, test o produccion).
     */
    public function __construct($host = NULL, $puerto = NULL, $dominio = NULL) {
        $this->host = $host;
        $this->puerto = $puerto;
        $this->dominio = $dominio;
    }

    /**
     * Retorna el nombre del host de conexion.
     * @return string host de conexion.
     */
    public function getHost() {
        return $this->host;
    }

    /**
     * Retorna el numero de puerto de conexion.
     * @return int Puerto de conexion.
     */
    public function getPuerto() {
        return $this->puerto;
    }

    /**
     * Retorna el nombre del dominio.
     * @return Nombre del dominio.
     */
    public function getDominio() {
        return $this->dominio;
    }

    /**
     * Modificar el host de conexion.
     * @param string $host Direccion IP del host.
     */
    public function setHost($host) {
        $this->host = $host;
    }

    /**
     * Modifica el numero de puerto.
     * @param int $puerto Numero de puerto.
     */
    public function setPuerto($puerto) {
        $this->puerto = $puerto;
    }

    /**
     * Retorna el nombre del dominio.
     * @param string Dominio.
     */
    public function setDominio($dominio) {
        $this->dominio = $dominio;
    }

    /**
     * Conectar con servidor de active directory.
     * @return array Arreglo de dos posiciones (boolean, mensaje).
     */
    public function conectar() {
        $this->conexion = ldap_connect($this->host, $this->puerto);
        if ($this->conexion) {
            ldap_set_option($this->conexion, LDAP_OPT_PROTOCOL_VERSION, 3);
            return array(true, "Conexión exitosa");
        }
        Log::escribirLineaError("Error al realizar la conexion con LDAP (HOST: {$this->host}, PORT: {$this->puerto})");
        return array(false, "No se pudo establecer la conexion con LDAP (verifique la configuración)");
    }

    /**
     * Buscar usuario dentro del dominio.
     * @param string $usuario Legajo del usuario.
     * @param string $clave Clave personal del usuario.
     * @return array Arreglo de dos posiciones (boolean, mensaje).
     */
    public function buscar($usuario, $clave) {
        $user = $this->dominio . $usuario;
        if (@ldap_bind($this->conexion, $user, $clave)) {
            return array(true, "Busqueda exitosa");
        }
        Log::escribirLineaError("Usuario no autenticado en LDAP (USUARIO: {$user})");
        return array(false, "Usuario no autenticado (verifique los datos)");
    }

}
