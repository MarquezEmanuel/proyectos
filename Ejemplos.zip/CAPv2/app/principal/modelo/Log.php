<?php

namespace app\principal\modelo;

/**
 * Encripta o desencripta cadenas de texto.
 * 
 * @package app\principal\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Log {

    /**
     * Escirbir linea de texto en un archivo de error. Si el archivo existe, escribe
     * una linea nueva al final. Si el archivo no existe, se crea y se agrega la
     * linea de texto.
     * @param string $texto Texto a incorporar al archivo.
     */
    public static function escribirLineaError($texto) {
        $date = date("H:i:s");
        $url = Constantes::LOG . "\\" . date("Ymd") . ".txt";
        $file = file_exists($url) ? fopen($url, 'a') : fopen($url, 'w');
        $ip = ($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : "DESC";
        $script_name = ($_SERVER["SCRIPT_NAME"]) ? explode("/", $_SERVER["SCRIPT_NAME"]) : array("DESC");
        $script = $script_name[count($script_name) - 1];
        $user = (isset($_SESSION['usuario'])) ? $_SESSION['usuario']->getId() : "";
        $data = "[HORA: {$date}][USUARIO: {$user}][IP: {$ip}][SCRIPT: {$script}][{$texto}]" . PHP_EOL;
        fwrite($file, $data);
    }

    /**
     * Almacena un registro en el log de actividades de la base de datos.
     * @param string $tipo Tipo de registro.
     * @param string $modulo Nombre del modulo.
     * @param string $operacion Nombre de la operacion.
     * @param string $metodo Nombre del metodo.
     * @param string $referencia Referencia al registro con el que se opera.
     * @param string $detalle Detalle adicional.
     */
    public static function guardarActividad($tipo, $modulo, $operacion, $metodo, $referencia, $detalle) {
        if ($tipo && $modulo && $operacion && $metodo && $detalle) {
            $usuario = (isset($_SESSION['usuario'])) ? $_SESSION['usuario']->getId() : "DESC";
            $consulta = "INSERT INTO log_actividad VALUES (?, ?, ?, ?, ?, ?, ?, GETDATE())";
            $detalle = utf8_decode(substr($detalle, 0, 500));
            $datos = array(strtoupper($tipo), &$usuario, strtolower($modulo), strtolower($operacion), $metodo, $referencia, $detalle);
            $creacion = SQLServer::instancia()->insertar($consulta, $datos);
            if ($creacion[0] != 2) {
                $mensaje = "$tipo - $modulo - $operacion - $metodo - $detalle";
                Log::escribirLineaError("$creacion[1] - $mensaje");
                return;
            }
        } else {
            Log::escribirLineaError("No se pudo guardar actividad por falta de datos");
        }
    }

}
