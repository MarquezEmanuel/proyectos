<?php

namespace app\lenguaje\controlador;

use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;
use app\lenguaje\modelo\LenguajeProgramacion;
use app\lenguaje\modelo\ColeccionLenguajesProgramacion as Lenguajes;

class ControladorLenguaje {

    public function buscar($nombre, $version, $descripcion, $estado) {
        return Lenguajes::buscar($nombre, $version, $descripcion, $estado);
    }

    public function buscarParaSeleccionar($nombre) {
        return Lenguajes::buscarParaSeleccionar($nombre);
    }

    public function buscarUltimosCreados($top, $estado) {
        return Lenguajes::buscarUltimosCreados($top, $estado);
    }

    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $lenguaje = new LenguajeProgramacion($id, NULL, NULL, NULL, $estado);
            $resultado = $lenguaje->cambiarEstado();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "cambiarEstado", $lenguaje);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function crear($nombre, $version, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $lenguaje = new LenguajeProgramacion(NULL, $nombre, $version, $descripcion);
            $resultado = $lenguaje->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $lenguaje);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function consultar($nombre, $version) {
        $resultado = LenguajesProgramacion::consultar($nombre, $version);
        return $resultado;
    }

    public function modificar($id, $nombre, $version, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $lenguaje = new LenguajeProgramacion($id, $nombre, $version, $descripcion);
            $resultado = $lenguaje->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $lenguaje);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param LenguajeProgramacion $lenguaje Plataforma con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $lenguaje) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "LENGUAJES";
        $metodo = "ControladorLenguaje::$funcion";
        $detalle = substr($lenguaje->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
