<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\procesamiento\controlador\ControladorLugarProcesamiento;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorLugarProcesamiento();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $lugares = $resultado[1];
        while ($lugar = sqlsrv_fetch_array($lugares, SQLSRV_FETCH_ASSOC)) {
            $idLugar = $lugar["id"];
            $nombreLugar = utf8_encode($lugar["nombre"]);
            $arreglo[] = array('id' => $idLugar, 'text' => $nombreLugar);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar lugar de procesamiento";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'PROCESAMIENTOS', 'busqueda', 'PSeleccionarLugarProcesamiento', '', $detalle);
}

echo json_encode($arreglo);

