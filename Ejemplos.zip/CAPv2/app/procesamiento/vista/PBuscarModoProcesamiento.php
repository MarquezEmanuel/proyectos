<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\procesamiento\controlador\ControladorModoProcesamiento;
use app\utilidad\modelo\GeneradorHTML;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorModoProcesamiento();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $$datos = ($nombre) ? "'{$nombre}', '{$estado}'" : "'$estado'";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombre, $estado);
    $_SESSION['BMODOS'] = array($nombre, $estado, $datos);
} else {
    if (isset($_SESSION['BMODOS'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BMODOS'];
        $nombre = $parametros[0];
        $estado = $parametros[1];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $resultado = $controlador->buscar($nombre, $estado);
        $_SESSION['BMODOS'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['BMODOS'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $modos = $resultado[1];
    $filas = "";
    while ($modo = sqlsrv_fetch_array($modos, SQLSRV_FETCH_ASSOC)) {
        $id = $modo['id'];
        $nombre = utf8_encode($modo['nombre']);
        $estado = $modo['estado'];
        $fechaCreacion = isset($modo['fechaCreacion']) ? date_format($modo['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($modo['fechaUltimaEdicion']) ? date_format($modo['fechaUltimaEdicion'], 'd/m/Y H:i') : "";
        if ($estado == 'Activo') {
            $operaciones = "
                <button class='btn btn-outline-warning editar' 
                        name='{$id}' title='Editar: $nombre'>
                    <i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger baja' 
                        name='{$id}' title='Dar de baja: $nombre'>
                    <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-success alta' 
                    name='{$id}' title='Dar de alta: $nombre'>
                        <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td>{$nombre}</td>
                <td style='display: none;'>{$estado}</td>
                <td class='align-middle'>{$fechaCreacion}</td>
                <td class='align-middle'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>{$operaciones}</div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbModos" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th style="display: none;">Estado</th>
                        <th>Fecha de creación</th>
                        <th>Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
