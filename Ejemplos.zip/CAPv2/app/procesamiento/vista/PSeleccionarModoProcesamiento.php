<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\procesamiento\controlador\ControladorModoProcesamiento;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorModoProcesamiento();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $modos = $resultado[1];
        while ($modo = sqlsrv_fetch_array($modos, SQLSRV_FETCH_ASSOC)) {
            $idModo = $modo["id"];
            $nombreModo = utf8_encode($modo["nombre"]);
            $arreglo[] = array('id' => $idModo, 'text' => $nombreModo);
        }
    }
} else {
    $arreglo[] = array('id' => "NO", 'text' => "Sin parametros");
}

echo json_encode($arreglo);
