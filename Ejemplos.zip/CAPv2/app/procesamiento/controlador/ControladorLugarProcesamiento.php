<?php

namespace app\procesamiento\controlador;

use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;
use app\procesamiento\modelo\LugarProcesamiento;
use app\procesamiento\modelo\ColeccionLugaresProcesamiento as LugaresProcesamiento;

class ControladorLugarProcesamiento {

    public function buscar($nombre, $estado) {
        return LugaresProcesamiento::buscar($nombre, $estado);
    }

    public function buscarParaSeleccionar($nombre) {
        return LugaresProcesamiento::buscarParaSeleccionar($nombre);
    }

    public function buscarUltimosCreados($top, $estado) {
        return LugaresProcesamiento::buscarUltimosCreados($top, $estado);
    }

    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $lugar = new LugarProcesamiento($id, NULL, $estado);
            $resultado = $lugar->cambiarEstado();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "cambiarEstado", $lugar);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    public function crear($nombre) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $lugar = new LugarProcesamiento(NULL, $nombre);
            $resultado = $lugar->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $lugar);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    public function modificar($id, $nombre) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $lugar = new LugarProcesamiento($id, $nombre);
            $resultado = $lugar->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $lugar);
            return $resultado;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Lugar $lugar Lugar de procesamiento con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $lugar) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "PROCESAMIENTOS";
        $metodo = "ControladorLugarProcesamiento::$funcion";
        $detalle = substr($lugar->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
