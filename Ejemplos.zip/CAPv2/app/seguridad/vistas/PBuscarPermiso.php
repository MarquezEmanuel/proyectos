<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\seguridad\controlador\ControladorPermiso;
use app\utilidad\modelo\GeneradorHTML;
use app\principal\modelo\AutoCargador;

AutoCargador::cargarModulos();

$controlador = new ControladorPermiso();

if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $nivel = $_POST['nivel'];
    $resultado = $controlador->buscar($nombre, $nivel);
    $filtro = "Resultado de la búsqueda: ";
    $filtro .= ($nombre) ? $nombre . ", " . $nivel : "TODOS, " . $nivel;
    $_SESSION['BPERMISOS'] = array($nombre, $nivel);
} else {
    if (isset($_SESSION['BPERMISOS'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BPERMISOS'];
        $nombre = $parametros[0];
        $nivel = $parametros[1];
        $resultado = $controlador->buscar($nombre, $nivel);
        $filtro = "Ultima búsqueda realizada: ";
        $filtro .= ($nombre) ? $nombre . ", " . $nivel : $nivel;
        $_SESSION['BPERMISOS'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $resultado = $controlador->listarConTope(20);
        $filtro = "Resumen inicial de permisos";
        $_SESSION['BPERMISOS'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $filas = "";
    $permisos = $resultado[1];
    while ($permiso = sqlsrv_fetch_array($permisos, SQLSRV_FETCH_ASSOC)) {

        $idPermiso = $permiso['id'];
        $titulo = utf8_encode($permiso['titulo']);
        $padre = utf8_encode($permiso['padre']);
        $descripcion = utf8_encode($permiso['descripcion']);
        $perfiles = $permiso['perfiles'];
        $hijos = $permiso['hijos'];
        $operaciones = "";
        if (($perfiles == 0) && ($hijos == 0)) {
            $operaciones = "
                <button class='btn btn-outline-danger baja'
                    name='{$idPermiso}' title='Dar de baja: {$titulo}'>
                    <i class='fas fa-trash'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td>{$titulo}</td>
                <td>{$padre}</td>
                <td>{$descripcion}</td>
                <td>{$perfiles}</td>
                <td>{$hijos}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-warning editar' 
                                name='{$idPermiso}' title='Editar: {$titulo}'>
                                <i class='far fa-edit'></i>
                        </button>
                        {$operaciones}
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive">
            <table id="tbPermisos" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Titulo</th>
                        <th>Padre</th>
                        <th>Descripción</th>
                        <th title="Cantidad de roles asociados">Roles</th>
                        <th title="Cantidad de permisos asociados">Permisos</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
