<?php

namespace app\seguridad\controlador;

use app\seguridad\modelo\Usuario;
use app\seguridad\modelo\ConjuntoUsuarios as Usuarios;
use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

/**
 * Controla los eventos de los modelos de usuario.
 * 
 * @package app\seguridad\controlador.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ControladorUsuario {

    /**
     * Devuelve todos los datos de uno o mas usuarios obtenidos a partir de su 
     * nombre y/o estado. Este metodo consulta la vista de usuarios (vwseg_usuario)
     * para obtener los datos.
     * @param string $nombre Nombre o parte del nombre del usuario.
     * @param string $estado Estado actual del usuario a consultar.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function buscar($nombre, $estado) {
        $resultado = Usuarios::buscar($nombre, $estado);
        return $resultado;
    }

    /**
     * Realiza el cambio de estado de un determinado usuario. El resultado de esta
     * operacion se registra en el log de actividades del sistema.
     * @param integer $id Legajo del usuario.
     * @param string $estado Nombre de estado.
     * @return array Arreglo con un resultado numerico y un texto descriptivo.
     */
    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $usuario = new Usuario($id, NULL, $estado);
            $edicion = $usuario->cambiarEstado();
            $confirmar = ($edicion[0] == 2) ? TRUE : FALSE;
            $this->registrar($edicion, "modificacion", "cambiarEstado", $id, $estado);
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $edicion;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Realiza la creacion de un nuevo usuario. El resultado de esta operacion
     * se guarda en el log de actividades del sistema.
     * @param string $legajo Numero de legajo del nuevo usuario.
     * @param string $nombre Nombre y Apellido del nuevo usuario.
     * @param integer $perfil Identificador del perfil.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function crear($legajo, $nombre, $perfil) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $usuario = new Usuario($legajo, $nombre, NULL, $perfil);
            $creacion = $usuario->crear();
            $confirmar = ($creacion[0] == 2) ? TRUE : FALSE;
            $this->registrar($creacion, "creacion", "crear", $legajo, $nombre);
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $creacion;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Devuelve un listado de usuarios segun la cantidad especificada en el tope. 
     * Este metodo consula la vista de usuarios (vwseg_usuario) y esta diseñado 
     * para ser utilizado como una vista previa durante una busqueda.
     * @param integer $tope Numero de cantidad maxima a mostrar (TOP SQL).
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function listarConTope($tope) {
        $resultado = Usuarios::listarConTope($tope);
        return $resultado;
    }

    /**
     * Realiza la modificacion de un determinado usuario en la base de datos. El
     * resultado de esta operacion se registra en el log de actividades de la base
     * de datos.
     * @param string $legajoOriginal Legajo original cuando este se desea modificar.
     * @param string $legajo Numero de legajo del usuario.
     * @param string $nombre Nombre y Apellido del usuario.
     * @param integer $perfil Identificador del perfil.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public function modificar($legajoOriginal, $legajo, $nombre, $perfil) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $usuario = new Usuario($legajo, $nombre, NULL, $perfil);
            $edicion = $usuario->modificar($legajoOriginal);
            $confirmar = ($edicion[0] == 2) ? TRUE : FALSE;
            $this->registrar($edicion, "modificacion", "modificar", $legajo, $nombre);
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $edicion;
        }
        return array(1, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param string $referencia Referencia al usuario.
     * @param string $datos Datos adicionales.
     */
    private function registrar($resultado, $operacion, $funcion, $referencia, $datos) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "USUARIOS";
        $metodo = "ControladorUsuario::$funcion";
        $detalle = "$codigo : $datos";
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $referencia, $detalle);
    }

}
