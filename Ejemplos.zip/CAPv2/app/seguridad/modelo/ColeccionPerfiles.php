<?php

namespace app\seguridad\modelo;

use app\principal\modelo\SQLServer;

/**
 * Trabaja con colecciones de perfiles.
 * 
 * @package app\seguridad\modelo.
 * 
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ColeccionPerfiles {

    /**
     * Devuelve todos los datos de uno o mas perfiles obtenidos a partir de su 
     * nombre y/o estado. Este metodo consulta la vista de perfiles (vwseg_perfil)
     * para obtener los datos.
     * @param string $nombre Nombre o parte del nombre del permiso.
     * @param string $estado Estado actual del perfil a consultar.
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function buscar($nombre, $estado) {
        $consulta = "SELECT * FROM vwseg_perfil WHERE nombre LIKE ? AND estado = ?";
        $datos = array('%' . $nombre . '%', $estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    /**
     * Devuelve un listado de perfiles segun la cantidad especificada en el tope
     * y ordernados por identificador en forma descendente. Este metodo consula la 
     * vista de perfiles (vwseg_perfil) y esta diseñado para ser utilizado como 
     * una vista previa durante una busqueda.
     * @param integer $tope Numero de cantidad maxima a mostrar (TOP SQL).
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function listarConTope($tope) {
        $consulta = "SELECT TOP(?) * FROM vwseg_perfil WHERE estado = 'Activo' ORDER BY id DESC";
        return SQLServer::instancia()->seleccionar($consulta, array(&$tope));
    }

    /**
     * Devuelve el identificador y nombre de uno o mas perfiles. Este metodo 
     * consulta la vista de perfiles (vwseg_perfil) y esta diseñado para ser 
     * utilizado durante la seleccion de perfiles por pantalla.
     * @param string $nombre Nombre o parte del nombre del perfil.
     * @param string $estado Nombre del estado del perfil (Activo o Inactivo). 
     * @return array Arreglo con un resultado numerico y un texto descriptivo. 
     */
    public static function seleccionar($nombre, $estado = 'Activo') {
        $consulta = "SELECT * FROM vwseg_perfil WHERE nombre LIKE ? AND estado = ?";
        $datos = array('%' . $nombre . '%', $estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

}
