<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\principal\modelo\Log;
use app\base\controlador\ControladorBaseDatosManual;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorBaseDatosManual();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $basesDatos = $resultado[1];
        while ($base = sqlsrv_fetch_array($basesDatos, SQLSRV_FETCH_ASSOC)) {
            $idBase = $base["id"];
            $nombreBase = utf8_encode($base["nombre"]);
            $arreglo[] = array('id' => $idBase, 'text' => $nombreBase);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar base de datos";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'BASES', 'busqueda', 'PSeleccionarBaseManual', '', $detalle);
}

echo json_encode($arreglo);
