<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\auxiliar\controlador\ControladorAuxiliar;

AutoCargador::cargarModulos();
session_start();

if (isset($_POST['mceaEstado'])) {
    $controlador = new ControladorAuxiliar();
    $id = $_POST['mceaIdAuxiliar'];
    $estado = $_POST['mceaEstado'];
    $nombre = $_POST['mceaNombre'];
    $modificacion = $controlador->cambiarEstado($id, $estado);
    $mensaje = "{$nombre}: $modificacion[1]";
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

echo $resultado;
