<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\auxiliar\controlador\ControladorAuxiliar;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['idAuxiliar'])) {
    $controlador = new ControladorAuxiliar();
    $id = $_POST['idAuxiliar'];
    $nombreLargo = $_POST['nombreLargo'];
    $rti = $_POST['rti'];
    $visibilidad = $_POST['visibilidad'];
    $modificacion = $controlador->modificarGCTI($id, $rti, $visibilidad);
    $mensaje = "{$nombreLargo}: {$modificacion[1]}";
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
