<?php

namespace app\auxiliar\controlador;

use app\auxiliar\modelo\ElementoAuxiliar;
use app\auxiliar\modelo\ColeccionElementosAuxiliares as Elementos;
use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

class ControladorAuxiliar {

    public function buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $estado) {
        return Elementos::buscar($nombreLargo, $nombreGerencia, $nombreEmpleado, $nombreSitio, $estado);
    }

    public function buscarInformesElementoAuxiliar() {
        return Elementos::buscarInformesElementoAuxiliar();
    }

    public function buscarUltimosCreados($top, $estado) {
        return Elementos::buscarUltimosCreados($top, $estado);
    }

    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $auxiliar = new ElementoAuxiliar($id);
            $auxiliar->setEstado($estado);
            $resultado = $auxiliar->cambiarEstado();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "cambiarEstado", $auxiliar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function crear($nombreCorto, $nombreLargo, $cantidad, $idGerencia, $idEmpleado, $idSitio, $descripcion) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $auxiliar = new ElementoAuxiliar(NULL, $nombreCorto, $nombreLargo, $cantidad, $idGerencia, $idEmpleado, $idSitio, NULL, $descripcion);
            $resultado = $auxiliar->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $auxiliar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function consultar($nombre, $gerencia, $empleado, $sitio) {
        $resultado = ElementosAuxiliares::consultar($nombre, $gerencia, $empleado, $sitio);
        return $resultado;
    }

    public function modificar($id, $nombreCorto, $nombreLargo, $cantidad, $gerencia, $empleado, $sitio, $descripcion, $rti, $estado, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $auxiliar = new ElementoAuxiliar($id, $nombreCorto, $nombreLargo, $cantidad, $gerencia, $empleado, $sitio, $descripcion, $rti, $estado, $visibilidad);
            $resultado = $auxiliar->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $auxiliar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $auxiliar = new ElementoAuxiliar($id);
            $auxiliar->setRti($rti);
            $auxiliar->setVisibilidad($visibilidad);
            $resultado = $auxiliar->modificarCGTI();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $auxiliar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Auxiliar $auxiliar Provedor con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $auxiliar) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "AUXILIARES";
        $metodo = "ControladorAuxiliar::$funcion";
        $detalle = substr($auxiliar->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
