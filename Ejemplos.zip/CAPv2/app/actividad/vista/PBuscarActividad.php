<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\actividad\controlador\ControladorActividad;
use app\utilidad\modelo\GeneradorHTML;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorActividad();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $tipo = isset($_POST['tipo']) ? $_POST['tipo'] : NULL;
    $modulo = isset($_POST['modulo']) ? $_POST['modulo'] : NULL;
    $operacion = isset($_POST['operacion']) ? $_POST['operacion'] : NULL;
    $nombreUsuario = $_POST['nombreUsuario'];
    $fechaInicio = $_POST['fechaInicio'];
    $fechaFin = $_POST['fechaFin'];
    $datos = ($tipo) ? "'{$tipo}', " : "TODOS, ";
    $datos .= ($modulo) ? "'{$modulo}', " : "TODOS, ";
    $datos .= ($operacion) ? "'{$operacion}', " : "TODAS, ";
    $datos .= ($nombreUsuario) ? "'{$nombreUsuario}', " : "TODOS, ";
    $datos .= ($fechaInicio) ? "'{$fechaInicio}', " : "TODAS, ";
    $datos .= ($fechaFin) ? "'{$fechaFin}'" : "TODAS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($tipo, $modulo, $operacion, $nombreUsuario, $fechaInicio, $fechaFin);
    $_SESSION['BACTIVIDADES'] = array($tipo, $modulo, $operacion, $nombreUsuario, $fechaInicio, $fechaFin, $datos);
} else {
    if (isset($_SESSION['BACTIVIDADES'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BACTIVIDADES'];
        $tipo = $parametros[0];
        $modulo = $parametros[1];
        $operacion = $parametros[2];
        $nombreUsuario = $parametros[3];
        $fechaInicio = $parametros[4];
        $fechaFin = $parametros[5];
        $filtro = "Ultima búsqueda realizada: " . $parametros[6];
        $resultado = $controlador->buscar($tipo, $modulo, $operacion, $nombreUsuario, $fechaInicio, $fechaFin);
        $_SESSION['BACTIVIDADES'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $resultado = $controlador->buscarUltimasCreadas($cantidad);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros";
        $_SESSION['BACTIVIDADES'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $filas = "";
    $actividades = $resultado[1];
    while ($actividad = sqlsrv_fetch_array($actividades, SQLSRV_FETCH_ASSOC)) {
        $id = $actividad['id'];
        $tipo = $actividad['tipo'];
        $idUsuario = $actividad['idUsuario'];
        $nombreUsuario = $actividad['nombreUsuario'];
        $modulo = $actividad['modulo'];
        $operacion = $actividad['operacion'];
        $metodo = $actividad['metodo'];
        $referencia = $actividad['referencia'];
        $fecha = date_format($actividad['fecha'], 'd/m/Y H:m:s');
        $filas .= "
            <tr>
                <td>{$tipo}</td>
                <td style='display: none;'>{$idUsuario}</td>
                <td>{$nombreUsuario}</td>
                <td>{$modulo}</td>
                <td>{$operacion}</td>
                <td>{$metodo}</td>
                <td>{$referencia}</td>
                <td>{$fecha}</td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbActividades" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Tipo</th>
                        <th style="display:none;">Legajo usuario</th>
                        <th>Nombre usuario</th>
                        <th>Módulo</th>
                        <th>Operación</th>
                        <th>Método</th>
                        <th>Referencia</th>
                        <th>Fecha</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
