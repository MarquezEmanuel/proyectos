<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\proveedor\controlador\ControladorProveedor;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorProveedor();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $provincia = $_POST['provincia'];
    $ciudad = $_POST['ciudad'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " : "TODAS, ";
    $datos .= ($provincia) ? "'{$provincia}', " : "TODAS, ";
    $datos .= ($ciudad) ? "'{$ciudad}', " : "TODAS, ";
    $datos .= ($estado) ? "'{$estado}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombre, $provincia, $ciudad, $estado);
    $_SESSION['BPROVEEDORES'] = array($nombre, $provincia, $ciudad, $estado, $datos);
} else {
    if (isset($_SESSION['BPROVEEDORES'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BPROVEEDORES'];
        $nombre = $parametros[0];
        $provincia = $parametros[1];
        $ciudad = $parametros[2];
        $estado = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[4];
        $resultado = $controlador->buscar($nombre, $provincia, $ciudad, $estado);
        $_SESSION['BPROVEEDORES'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['BPROVEEDORES'] = NULL;
    }
}

if ($resultado[0] == 2) {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $proveedores = $resultado[1];
    $filas = "";
    while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
        $id = $proveedor['id'];
        $nombre = utf8_encode($proveedor['nombre']);
        $tipo = utf8_encode($proveedor['tipo']);
        $telefono = $proveedor['telefono'];
        $correo = $proveedor['correo'];
        $provincia = utf8_encode($proveedor['provincia']);
        $ciudad = utf8_encode($proveedor['ciudad']);
        $direccion = utf8_encode($proveedor['direccion']);
        $estado = $proveedor['estado'];
        $fechaCreacion = isset($proveedor['fechaCreacion']) ? date_format($proveedor['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($proveedor['fechaUltimaEdicion']) ? date_format($proveedor['fechaUltimaEdicion'], 'd/m/Y H:i') : "";

        if ($estado == 'Activo') {
            $operaciones = "
                <button class='btn btn-outline-warning editar' 
                        name='{$id}' title='Editar: $nombre'>
                        <i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger baja' 
                        name='{$id}' title='Dar de baja: $nombre'>
                        <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-success alta' 
                        name='{$id}' title='Dar de alta: $nombre'>
                        <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td>{$nombre}</td>
                <td>{$tipo}</td>
                <td>{$telefono}</td>
                <td>{$correo}</td>
                <td>{$provincia}</td>
                <td style='display: none;'>{$ciudad}</td>
                <td style='display: none;'>{$direccion}</td>
                <td style='display: none;'>{$estado}</td>
                <td style='display: none;'>{$fechaCreacion}</td>
                <td style='display: none;'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$id}' title='Detalle: $nombre'>
                                <i class='fas fa-info-circle'></i>
                        </button>
                        {$operaciones}
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbProveedores" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Tipo</th>
                        <th>Telefono</th>
                        <th>Correo</th>
                        <th>Provincia</th>
                        <th style="display: none;">Ciudad</th>
                        <th style="display: none;">Dirección</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">Fecha de creación</th>
                        <th style="display: none;">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
