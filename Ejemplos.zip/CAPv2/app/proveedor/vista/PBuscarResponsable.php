<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\proveedor\controlador\ControladorResponsable;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorResponsable();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreResponsable = $_POST['nombreResponsable'];
    $nombreProveedor = $_POST['nombreProveedor'];
    $estado = $_POST['estado'];
    $datos = ($nombreResponsable) ? "'{$nombreResponsable}', " : "";
    $datos .= ($nombreProveedor) ? "'{$nombreProveedor}', " : "";
    $datos .= ($estado) ? "'{$estado}'" : "";
    $filtro = "Resultado de la búsqueda: $datos";
    $resultado = $controlador->buscar($nombreResponsable, $nombreProveedor, $estado);
    $_SESSION['BRESPONSABLES'] = array($nombreResponsable, $nombreProveedor, $estado, $datos);
} else {
    if (isset($_SESSION['BRESPONSABLES'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUS*-QUEDA ALMACENADA */
        $parametros = $_SESSION['BRESPONSABLES'];
        $nombreResponsable = $parametros[0];
        $nombreProveedor = $parametros[1];
        $estado = $parametros[2];
        $filtro = "Ultima búsqueda realizada: $parametros[3]";
        $resultado = $controlador->buscar($nombreResponsable, $nombreProveedor, $estado);
        $_SESSION['BRESPONSABLES'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['BRESPONSABLES'] = NULL;
    }
}

if ($resultado[0] == 2) {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $responsables = $resultado[1];
    $filas = "";
    while ($responsable = sqlsrv_fetch_array($responsables, SQLSRV_FETCH_ASSOC)) {
        $id = $responsable['idResponsable'];
        $nombreResponsable = utf8_encode($responsable['nombreResponsable']);
        $telefono = $responsable['telefonoResponsable'];
        $correo = $responsable['correoResponsable'];
        $nombreProveedor = $responsable['nombreProveedor'];
        $estadoProveedor = $responsable['estadoProveedor'];
        $estadoResponsable = $responsable['estadoResponsable'];
        $fechaCreacion = isset($servicio['fechaCreacionResponsable']) ? date_format($servicio['fechaCreacionResponsable'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($servicio['fechaUltimaEdicionResponsable']) ? date_format($servicio['fechaUltimaEdicionResponsable'], 'd/m/Y H:i') : "";

        if ($estadoResponsable == 'Activo') {
            $operaciones = "
                <button class='btn btn-outline-warning editar' 
                        name='{$id}' title='Editar: $nombreResponsable'>
                        <i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger baja' 
                        name='{$id}' title='Dar de baja: $nombreResponsable'>
                        <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-success alta' 
                        name='{$id}' title='Dar de alta: $nombreResponsable'>
                        <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td title='Estado del proveedor: $estadoProveedor'>{$nombreProveedor}</td>
                <td>{$nombreResponsable}</td>
                <td>{$telefono}</td>
                <td>{$correo}</td>
                <td style='display: none;'>{$estadoResponsable}</td>
                <td style='display: none;'>{$fechaCreacion}</td>
                <td style='display: none;'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>{$operaciones}</div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbResponsables" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Proveedor</th>
                        <th>Nombre</th>
                        <th>Telefono</th>
                        <th>Correo</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">Fecha de creación</th>
                        <th style="display: none;">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
