<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\proveedor\controlador\ControladorResponsable;

AutoCargador::cargarModulos();
session_start();

if (isset($_POST['mcerEstado'])) {
    $controlador = new ControladorResponsable();
    $id = $_POST['mcerIdResponsable'];
    $nombre = $_POST['mcerNombre'];
    $estado = $_POST['mcerEstado'];
    $modificacion = $controlador->cambiarEstado($id, $estado);
    $mensaje = "{$nombre}: $modificacion[1]";
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

echo $resultado;
