<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\principal\modelo\Log;
use app\proveedor\controlador\ControladorProveedor;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorProveedor();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $proveedores = $resultado[1];
        while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
            $idProveedor = $proveedor["id"];
            $nombre = utf8_encode($proveedor["nombre"]);
            $arreglo[] = array('id' => $idProveedor, 'text' => $nombre);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar proveedor";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'PROVEEDORES', 'busqueda', 'PSeleccionarProveedor', '', $detalle);
}

echo json_encode($arreglo);
