<?php

namespace app\proveedor\modelo;

use app\principal\modelo\SQLServer;

/**
 * Mapea con la tabla de responsables y la vista de responsables.
 * 
 * @package app\proveedor\modelo.
 * 
 * @uses vwpro_responsable Vista de responsables.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class ColeccionResponsables {

    /**
     * Buscar responsables a partir del nombre, nombre proveedor y estado. De la
     * consulta se obtienen todos los campos de la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param string $nombreResponsable Nombre o parte del nombre del responsable (LIKE).
     * @param string $nombreProveedor Nombre o parte del nombre del proveedor (LIKE).
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscar($nombreResponsable, $nombreProveedor, $estado) {
        if ($estado) {
            $consulta = "SELECT * FROM vwpro_responsable "
                    . "WHERE nombreResponsable LIKE ? AND nombreProveedor LIKE ? "
                    . "AND estadoResponsable = ?";
            $datos = array("%{$nombreResponsable}%", "%{$nombreProveedor}%", &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar responsables");
    }

    /**
     * Buscar responsables ordenados por fecha de creacion descendente con un tope
     * de registros y un estado. De la consulta se obtienen todos los campos de
     * la tabla.
     * @see SQLServer::instancia()->seleccionar
     * @param int $top Cantidad maxima de registros a seleccionar.
     * @param string $estado Estado del registro (IGUAL).
     * @return array Arreglo de dos posiciones (codigo o datos, mensaje).
     */
    public static function buscarUltimosCreados($top, $estado) {
        if (($top > 0) && $estado) {
            $consulta = "SELECT TOP(?) * FROM vwpro_responsable WHERE estadoResponsable = ? "
                    . "ORDER BY fechaCreacionResponsable DESC";
            $datos = array(&$top, &$estado);
            return SQLServer::instancia()->seleccionar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para consultar proveedores");
    }

    public static function consultar($nombre, $proveedor) {
        $consulta = "SELECT * FROM vwpro_responsable WHERE rnombre LIKE ? AND pnombre LIKE ? AND restado = 'Activo'";
        $datos = array('%' . $nombre . '%', '%' . $proveedor . '%');
        $resultado = SQLServer::instancia()->seleccionar($consulta, $datos);
        self::$mensaje = SQLServer::instancia()->getMensaje();
        return $resultado;
    }

}
