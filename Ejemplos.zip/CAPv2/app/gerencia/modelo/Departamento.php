<?php

namespace app\gerencia\modelo;

use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;
use app\utilidad\modelo\Util;

/**
 * Mapea con la tabla de departamentos.
 * 
 * @package app\gerencia\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Departamento {

    /** @var int Identificador del empleado [BIGINT] */
    private $id;

    /** @var string Nombre [NVARCHAR(100) NOT NULL] */
    private $nombre;

    /** @var int Identificador de la gerencia [BIGINT NOT NULL] */
    private $gerencia;

    /** @var string Estado [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var string Fecha de creacion [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de edicion [SMALLDATETIME NULL] */
    private $fechaEdicion;

    public function __construct($id = NULL, $nombre = NULL, $gerencia = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setGerencia($gerencia);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombre() {
        return utf8_encode($this->nombre);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getGerencia() {
        return $this->gerencia;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = ($id > 0) ? $id : NULL;
    }

    public function setNombre($nombre) {
        if ($nombre && (strlen($nombre) <= 100)) {
            $this->nombre = utf8_decode(Util::convertirCamelCase($nombre));
        }
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setGerencia($gerencia) {
        $this->gerencia = $gerencia;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE ger_departamento SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        Log::guardarActividad("WARNING", "GERENCIAS", "modificacion", "Departamento::cambiarEstado", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para cambiar el estado del departamento");
    }

    public function crear() {
        if ($this->nombre && $this->gerencia) {
            $consulta = "INSERT INTO ger_departamento OUTPUT INSERTED.id VALUES (?, ?, 'Activo', GETDATE(), NULL)";
            $datos = array(&$this->nombre, &$this->gerencia);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            $this->id = ($resultado[0] == 2) ? $resultado[2] : NULL;
            return $resultado;
        }
        Log::guardarActividad("WARNING", "GERENCIAS", "creacion", "Departamento::crear", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para crear el departamento");
    }

    public function modificar() {
        if ($this->id && $this->nombre && $this->gerencia) {
            $consulta = "UPDATE ger_departamento SET nombre=?, idGerencia=?, "
                    . "fechaUltimaEdicion = GETDATE() WHERE id=?";
            $datos = array(&$this->nombre, &$this->gerencia, &$this->id);
            $resultado = SQLServer::instancia()->modificar($consulta, $datos);
            return $resultado;
        }
        Log::guardarActividad("WARNING", "GERENCIAS", "modificacion", "Departamento::modificar", 1, $this->toString());
        return array(0, "No se recibieron los campos obligatorios para modificar el departamento");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM ger_departamento WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombre = $fila['nombre'];
                $this->estado = $fila['estado'];
                $this->gerencia = $fila['idGerencia'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información del departamento correctamente");
            }
            return $resultado;
        }
        Log::guardarActividad("WARNING", "GERENCIAS", "busqueda", "Departamento::obtener", 1, $this->toString());
        return array(0, "No se pudo hacer referencia al departamento");
    }

    public function obtenerGerencia() {
        $gerencia = new Gerencia($this->gerencia);
        $resultado = $gerencia->obtener();
        $this->gerencia = ($resultado[0] == 2) ? $gerencia : NULL;
        return $resultado;
    }

    public function toString() {
        $departamento = ($this->id) ? "{{$this->getId()}," : "{0,";
        $departamento .= ($this->nombre) ? "'{$this->getNombre()}'," : "'',";
        $departamento .= ($this->gerencia && (gettype($this->gerencia) == "integer")) ? "{$this->getGerencia()}," : "0,";
        $departamento .= ($this->estado) ? "'{$this->getEstado()}'}" : "''}";
        return $departamento;
    }

}
