<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\principal\modelo\Log;
use app\gerencia\controlador\ControladorEmpleado;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if ($_POST['nombre']) {
    $controlador = new ControladorEmpleado();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionarDelegado($nombre);
    if ($resultado[0] == 2) {
        $empleados = $resultado[1];
        while ($empleado = sqlsrv_fetch_array($empleados, SQLSRV_FETCH_ASSOC)) {
            $idEmpleado = $empleado["id"];
            $nombreEmpleado = utf8_encode($empleado["nombre"]);
            $arreglo[] = array('id' => $idEmpleado, 'text' => $nombreEmpleado);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar delegado";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'GERENCIAS', 'busqueda', 'PSeleccionarEmpleadoDelegado', '', $detalle);
}

echo json_encode($arreglo);
