<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\principal\modelo\Log;
use app\gerencia\controlador\ControladorGerencia;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorGerencia();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $gerencias = $resultado[1];
        while ($gerencia = sqlsrv_fetch_array($gerencias, SQLSRV_FETCH_ASSOC)) {
            $idGerencia = $gerencia["id"];
            $nombreGerencia = utf8_encode($gerencia["nombre"]);
            $arreglo[] = array('id' => $idGerencia, 'text' => $nombreGerencia);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar gerencia";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'GERENCIAS', 'busqueda', 'PSeleccionarGerencia', '', $detalle);
}

echo json_encode($arreglo);
