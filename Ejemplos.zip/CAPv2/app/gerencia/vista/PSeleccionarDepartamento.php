<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\principal\modelo\Log;
use app\gerencia\controlador\ControladorDepartamento;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorDepartamento();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $departamentos = $resultado[1];
        while ($deparamento = sqlsrv_fetch_array($departamentos, SQLSRV_FETCH_ASSOC)) {
            $idDepartamento = $deparamento["id"];
            $nombreDepartamento = utf8_encode($deparamento["nombre"]);
            $arreglo[] = array('id' => $idDepartamento, 'text' => $nombreDepartamento);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar departamento";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'GERENCIAS', 'busqueda', 'PSeleccionarDepartamento', '', $detalle);
}

echo json_encode($arreglo);
