<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\principal\modelo\Log;
use app\gerencia\controlador\ControladorEmpleado;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorEmpleado();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionarJefe($nombre);
    if ($resultado[0] == 2) {
        $trabajadores = $resultado[1];
        while ($empleado = sqlsrv_fetch_array($trabajadores, SQLSRV_FETCH_ASSOC)) {
            $idEmpleado = $empleado["idEmpleado"];
            $nombreEmpleado = utf8_encode($empleado["nombreEmplado"]);
            $arreglo[] = array('id' => $idEmpleado, 'text' => $nombreEmpleado);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar gerente";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'GERENCIAS', 'busqueda', 'PSeleccionarEmpleadoJefe', '', $detalle);
}

echo json_encode($arreglo);
