<?php
require_once '../../principal/modelos/Constantes.php';
require_once '../../principal/modelos/AutoCargador.php';
require_once '../../principal/vistas/header.php';

AutoCargador::cargarModulos();

$controlador = new ControladorGerencia();
$gerencias = $controlador->listarReporte();
if (gettype($gerencias) == "resource") {
    $filas = "";
    while ($gerencia = sqlsrv_fetch_array($gerencias, SQLSRV_FETCH_ASSOC)) {
        $filas .= "
            <tr>
                <td>" . utf8_encode($gerencia['gnombre']) . "</td>
                <td class='text-center'>{$gerencia['aplicaciones']}</td>
                <td class='text-center'>{$gerencia['auxiliares']}</td>
                <td class='text-center'>{$gerencia['comunicaciones']}</td>
                <td class='text-center'>{$gerencia['departamentos']}</td>
                <td class='text-center'>{$gerencia['instalaciones']}</td>
            </tr>";
    }

    $cuerpo = '
        <div class="form-row">
            <div class="col-5">
                <div class="input-group">
                    <select class="custom-select" id="minimo" name="minimo" title="Cantidad minima de elementos">
                        <option value="1">1 elemento</option>
                        <option value="2">2 elementos</option>
                        <option value="3">3 elementos</option>
                        <option value="4">4 elementos</option>
                        <option value="5">5 elementos</option>
                        <option value="6">6 elementos</option>
                        <option value="7">7 elementos</option>
                        <option value="8">8 elementos</option>
                        <option value="9">9 elementos</option>
                        <option value="10">10 elementos</option>
                    </select>
                    <select class="custom-select" id="elemento" name="elemento">
                        <option value="1">Aplicaciones</option>
                        <option value="2">Elementos auxiliares</option>
                        <option value="3">Comunicaciones</option>
                        <option value="4">Departamentos</option>
                        <option value="5">Instalaciones</option>
                    </select>
                    <div class="input-group-append">
                      <button class="btn btn-outline-success" id="btnGraficar" name="btnGraficar"
                              title="Graficar" type="button"><i class="fas fa-chart-pie"></i></button>
                    </div>
                </div>
            </div>
            <div class="col"></div>
        </div>
        <div class="row  mt-4">
            <div class="col">
                <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white"><i class="fas fa-table"></i> Información resumida</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="tbReporteGerencias" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Nombre</th>
                                        <th>Aplicaciones</th>
                                        <th>Auxiliares</th>
                                        <th>Comunicaciones</th>
                                        <th>Departamentos</th>
                                        <th>Instalaciones</th>
                                    </tr>
                                </thead>
                                <tbody>' . $filas . '</tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4" id="seccionImagen" style="display: none;">
            <div class="col">
                <div class="card border-azul-clasico">
                    <div class="card-header bg-azul-clasico text-white"><i class="fas fa-chart-pie"></i> Gráfico</div>
                    <div class="card-body">
                        <div class="mt-4 mb-4 text-center" id="imagen"></div>
                    </div>
                </div>
            </div>
        </div>';
} else {
    $filtro = "Información resumida";
    $mensaje = $controlador->getMensaje();
    $alerta = ControladorHTML::getAlertaOperacion($gerencias, $mensaje);
    $cuerpo = ControladorHTML::getCardBusqueda($filtro, $alerta);
}
?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="far fa-building"></i> REPORTE DE GERENCIAS</h4>
                </div>
            </div>
            <div class="mt-3 mb-4"><?= $cuerpo; ?></div>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/ReporteGerencia.js"></script>
