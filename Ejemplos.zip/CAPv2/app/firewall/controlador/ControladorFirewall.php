<?php

namespace app\firewall\controlador;

use app\firewall\modelo\Firewall;
use app\firewall\modelo\ColeccionFirewalls as Firewalls;
use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

class ControladorFirewall {

    public function buscar($nombreFirewall, $marca, $nombreSitio, $estado) {
        return Firewalls::buscar($nombreFirewall, $marca, $nombreSitio, $estado);
    }

    public function buscarInformesFirewall() {
        return Firewalls::buscarInformesFirewall();
    }

    public function buscarUltimosCreados($top, $estado) {
        return Firewalls::buscarUltimosCreados($top, $estado);
    }

    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $firewall = new Firewall($id);
            $firewall->setEstado($estado);
            $resultado = $firewall->cambiarEstado();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "cambiarEstado", $firewall);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * @param string $nombre Nombre del elemento.
     * @param string $marca Nombre de la marca.
     * @param string $modelo Modelo del firewall.
     * @param string $numeroSerie Numero de serie.
     * @param string $version Version del elemento.
     * @param string $ip Direccion IP.
     * @param string $descripcion Descripcion adicional.
     * @param array $proveedores Arreglo de identificadores de proveedores.
     */
    public function crear($nombre, $marca, $modelo, $numeroSerie, $version, $sitio, $ip, $descripcion, $proveedores) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $firewall = new Firewall(NULL, $nombre, $marca, $modelo, $numeroSerie, $version, $sitio, $ip, $proveedores, NULL, $descripcion);
            $resultado = $firewall->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $firewall);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function consultar($nombre, $marca, $ip, $sitio) {
        $resultado = Firewalls::consultar($nombre, $marca, $ip, $sitio);
        return $resultado;
    }

    public function modificar($id, $nombre, $marca, $modelo, $numeroSerie, $version, $sitio, $ip, $descripcion, $proveedores) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $firewall = new Firewall($id, $nombre, $marca, $modelo, $numeroSerie, $version, $sitio, $ip, $proveedores, NULL, $descripcion);
            $resultado = $firewall->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $firewall);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $firewall = new Firewall($id);
            $firewall->setRti($rti);
            $firewall->setVisibilidad($visibilidad);
            $resultado = $firewall->modificarCGTI();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificarGCTI", $firewall);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Firewall $firewall Firewall con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $firewall) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "FIREWALLS";
        $metodo = "ControladorFirewall::$funcion";
        $detalle = substr($firewall->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
