<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\personal\controlador\ControladorPersonal;

AutoCargador::cargarModulos();
session_start();

if (isset($_POST['mcepEstado'])) {
    $controlador = new ControladorPersonal();
    $id = $_POST['mcepIdPersonal'];
    $nombre = $_POST['mcepNombre'];
    $estado = $_POST['mcepEstado'];
    $modificacion = $controlador->cambiarEstado($id, $estado);
    $mensaje = "{$nombre}: $modificacion[1]";
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

echo $resultado;
