<?php

namespace app\aplicacion\modelo;

use app\principal\modelo\SQLServer;

class ColeccionAplicaciones {

    public static function buscar($nombreLargo, $tipo, $tecnologia, $seguridad, $tipoLog, $nombreLenguaje, $nombreGerencia, $nombreEmpleado, $estado) {
        $consulta = "SELECT * FROM vwapl_aplicacion "
                . " WHERE nombreLargoAplicacion LIKE ? "
                . " AND tipoAplicacion LIKE ? "
                . " AND tecnologiaAplicacion LIKE ? "
                . " AND seguridadAplicacion LIKE ? "
                . " AND tipoLogAplicacion LIKE ? "
                . " AND nombreLenguaje LIKE ? "
                . " AND nombreGerencia LIKE ? "
                . " AND nombreEmpleado LIKE ? "
                . " AND estadoAplicacion = ?";
        $datos = array("%{$nombreLargo}%", "%{$tipo}%", "%{$tecnologia}%", "%{$seguridad}%", "%{$tipoLog}%", "%{$nombreLenguaje}%", "%{$nombreGerencia}%", "%{$nombreEmpleado}%", $estado);
        return SQLServer::instancia()->seleccionar($consulta, $datos);
    }

    /**
     * Busca los registros de un determinado informe.
     * @param int idInforme Identificador del informe solicitado.
     * return array Arreglo nulo, vacio o con la informacion del reporte.
     */
    private static function buscarDatosInforme($idInforme) {
        $consulta = "SELECT detalle, total FROM vwapl_informes WHERE id = ? ORDER BY detalle";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array(&$idInforme));
        if ($resultado[0] == 2) {
            $datos = array();
            while ($registro = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $datos[] = array('detalle' => $registro['detalle'], 'total' => $registro['total']);
            }
            return $datos;
        }
        return NULL;
    }

    /**
     * Busca los informes disponibles y agrupa su informacion.
     */
    public static function buscarInformesAplicacion() {
        $consulta = "SELECT DISTINCT id, informe, COUNT(*) distribucion "
                . " FROM vwapl_informes GROUP BY id, informe ORDER BY id";
        $resultado = SQLServer::instancia()->seleccionar($consulta, array());
        if ($resultado[0] == 2) {
            $informes = array();
            while ($informe = sqlsrv_fetch_array($resultado[1], SQLSRV_FETCH_ASSOC)) {
                $datos = ColeccionAplicaciones::buscarDatosInforme($informe['id']);
                $informes[] = array($informe['id'], $informe['informe'], $informe['distribucion'], $datos);
            }
            return array(2, $informes);
        }
        return $resultado;
    }

    public static function buscarUltimasCreadas($top, $estado) {
        $consulta = "SELECT TOP(?) * FROM vwapl_aplicacion "
                . " WHERE estadoAplicacion = ? "
                . " ORDER BY fechaCreacionAplicacion DESC";
        return SQLServer::instancia()->seleccionar($consulta, array(&$top, &$estado));
    }

}
