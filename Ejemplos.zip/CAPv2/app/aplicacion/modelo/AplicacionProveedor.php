<?php

namespace app\aplicacion\modelo;

use app\principal\modelo\SQLServer;

/**
 * Mapea con la tabla que relaciona las aplicaciones con los proveedores.
 * 
 * @package app\aplicacion\modelo.
 * 
 * @uses apl_aplicacion_proveedor Tabla relacion de aplicacion con proveedor.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 * 
 * @version 1.0
 */
class AplicacionProveedor {

    /**
     * Realiza la eliminacion de los proveedores asociados al activo y luego la
     * creacion de los nuevos proveedores asociados.
     * @param int $idAplicacion Identificador del activo.
     * @param array $proveedores Arreglo con los identificadores de los proveedores.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function actualizarProveedoresAplicacion($idAplicacion, $proveedores) {
        $resultado = AplicacionProveedor::borrar($idAplicacion);
        if ($resultado[0] == 2) {
            $resultado = AplicacionProveedor::crear($idAplicacion, $proveedores);
        }
        return $resultado;
    }

    /**
     * Elimina todos los proveedores asociados a un activo aplicacion.
     * @see SQLServer::$instancia->borrar
     * @param int $idAplicacion Identificador del activo.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function borrar($idAplicacion) {
        if ($idAplicacion > 0) {
            $consulta = "DELETE FROM apl_aplicacion_proveedor WHERE idAplicacion = ?";
            $eliminacion = SQLServer::$instancia->borrar($consulta, array(&$idAplicacion));
            return $eliminacion;
        }
        return array(0, "No se pudo hacer referencia a la aplicación para asociar proveedores");
    }

    /**
     * Crea todas las relaciones de un activo aplicacion con sus proveedores.
     * @see SQLServer::instancia()->insertar
     * @param int $idAplicacion Identificador del activo.
     * @param array $proveedores Arreglo con los identificadores de los proveedores.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function crear($idAplicacion, $proveedores) {
        if ($idAplicacion > 0 && !empty($proveedores)) {
            $registros = "";
            for ($index = 0; $index < count($proveedores); $index++) {
                $registros .= "({$idAplicacion}, ?),";
            }
            $consulta = "INSERT INTO apl_aplicacion_proveedor VALUES " . substr($registros, 0, -1);
            $creacion = SQLServer::instancia()->insertar($consulta, $proveedores);
            return $creacion;
        }
        return array(0, "No se recibieron los campos obligatorios para relacionar proveedores");
    }

}
