<?php
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\aplicacion\modelo\Aplicacion;
use app\proveedor\controlador\ControladorProveedor;

AutoCargador::cargarModulos();
session_start();

$boton = "";
if ($_POST['idAplicacion']) {
    $id = $_POST['idAplicacion'];
    $aplicacion = new Aplicacion($id);
    $controladorProveedor = new ControladorProveedor();
    $resultado = $aplicacion->obtener();
    $datosProveedores = $controladorProveedor->buscarEstadoActivo();
    if (($resultado[0] == 2) && ($datosProveedores[0] == 2)) {

        $nombreCorto = $aplicacion->getNombreCorto();
        $nombreLargo = $aplicacion->getNombreLargo();
        $tipo = $aplicacion->getTipo();
        $tecnologia = $aplicacion->getTecnologia();
        $seguridad = $aplicacion->getSeguridad();
        $baseDatos = $aplicacion->getBaseDatos(); // PARA COMPARAR SI ES NULO
        $herramientaDesarrollo = $aplicacion->getHerramienta(); // PARA COMPARAR SI ES NULO
        $lenguajeProgramacion = $aplicacion->getLenguaje(); // PARA COMPARAR SI ES NULO
        $responsableTecnico = $aplicacion->getEmpleado(); // PARA COMPARAR SI ES NULO
        $fechaCaducidad = $aplicacion->getFechaCaducidad();
        $codigoSAS = $aplicacion->getCodigoSAS();
        $tipoLog = $aplicacion->getTipoLog();
        $descripcion = $aplicacion->getDescripcion();
        $fechaCaducidadFormateada = isset($fechaCaducidad) ? date_format($fechaCaducidad, 'Y-m-d') : "";
        $getLenguaje = $aplicacion->obtenerLenguaje();
        $getHerramienta = $aplicacion->obtenerHerramienta();
        $getBase = $aplicacion->obtenerBase();
        $getGerencia = $aplicacion->obtenerGerencia();
        $getEmpleado = $aplicacion->obtenerEmpleado();
        $getModo = $aplicacion->obtenerModo();
        $getLugar = $aplicacion->obtenerLugar();
        $getPlataforma = $aplicacion->obtenerPlataforma();
        $getProveedores = $aplicacion->obtenerProveedores();

        //CARGA LAS OPCIONES PARA TIPO DE SOFTWARE 

        if ($tipo == "Aplicación") {
            $opcionesTipo = '<option value="Aplicación" selected>Aplicación</option>';
            $opcionesTipo .= '<option value="Técnico">Técnico</option>';
        } else {
            $opcionesTipo .= '<option value="Aplicación">Aplicación</option>';
            $opcionesTipo .= '<option value="Técnico" selected>Técnico</option>';
        }

        //CARGA LAS OPCIONES PARA TECNOLOGIA

        $opcionesTecnologia = ($tecnologia == "No aplica") ? '<option value="No aplica" selected>No aplica</option>' : '<option value="No aplica">No aplica</option>';
        $opcionesTecnologia .= ($tecnologia == "Cliente-Servidor") ? '<option value="Cliente-Servidor" selected>Cliente-Servidor</option>' : '<option value="Cliente-Servidor">Cliente-Servidor</option>';
        $opcionesTecnologia .= ($tecnologia == "Stand Alone") ? '<option value="Stand Alone" selected>Stand Alone</option>' : '<option value="Stand Alone">Stand Alone</option>';
        $opcionesTecnologia .= ($tecnologia == "Web") ? '<option value="Web" selected>Web</option>' : '<option value="Web">Web</option>';
        $opcionesTecnologia .= ($tecnologia == "Web Service") ? '<option value="Web Service" selected>Web Service</option>' : '<option value="Web Service">Web Service</option>';

        //CARGA LAS OPCIONES PARA SEGURIDAD

        $opcionesSeguridad = ($seguridad == 'Active Directory') ? '<option value="Active Directory" selected>Active Directory</option>' : '<option value="Active Directory">Active Directory</option>';
        $opcionesSeguridad .= ($seguridad == 'Integrada') ? '<option value="Integrada" selected>Integrada</option>' : '<option value="Integrada">Integrada</option>';
        $opcionesSeguridad .= ($seguridad == 'Propia') ? '<option value="Propia" selected>Propia</option>' : '<option value="Propia">Propia</option>';

        // CARGA LAS OPCIONES DE TIPO DE LOG

        $opcionesLog = ($tipoLog == 'Archivo') ? '<option value="Archivo" selected>Archivo</option>' : '<option value="Archivo">Archivo</option>';
        $opcionesLog .= ($tipoLog == 'Base de datos') ? '<option value="Base de datos" selected>Base de datos</option>' : '<option value="Base de datos">Base de datos</option>';
        $opcionesLog .= ($tipoLog == 'Integrado') ? '<option value="Integrado" selected>Integrado</option>' : '<option value="Integrado">Integrado</option>';
        $opcionesLog .= ($tipoLog == 'No aplica') ? '<option value="No aplica" selected>No aplica</option>' : '<option value="No aplica">No aplica</option>';

        $boton = '<button type="submit" class="btn btn-success" 
                          id="btnModificarAplicacion" disabled>
                          <i class="far fa-save"></i> GUARDAR
                  </button>';

        /* CARGA LOS DATOS DE LA GERENCIA */

        if ($getGerencia[0] == 2) {
            $gerencia = $aplicacion->getGerencia();
            $idGerencia = $gerencia->getId();
            $nombreGerencia = $gerencia->getNombre();
            $opcionGerencia = "
                <select class='form-control mb-2' id='gerencia' name='gerencia' required>
                        <option value='{$idGerencia}'>{$nombreGerencia}</option>
                </select>";
        } else {
            $boton = '';
            $opcionGerencia = GeneradorHTML::getAlertaOperacion($getGerencia[0], $getGerencia[1]);
        }

        /* CARGA LOS DATOS DEL EMPLEADO DELEGADO (CAMPO NO  OBLIGATORIO) */

        if ($getEmpleado[0] == 2) {
            $empleado = $aplicacion->getEmpleado();
            $idEmpleado = $empleado->getId();
            $nombreEmpleado = $empleado->getNombre();
            $opcionEmpleado = "
                <select class='form-control mb-2' id='delegado' name='delegado' required>
                        <option value='{$idEmpleado}'>{$nombreEmpleado}</option>
                </select>";
        } else {
            if ($responsableTecnico) {
                $boton = '';
                $opcionEmpleado = GeneradorHTML::getAlertaOperacion($getEmpleado[0], $getEmpleado[1]);
            } else {
                $opcionEmpleado = "
                    <select class='form-control mb-2' 
                            id='delegado' name='delegado' required>
                    </select>";
            }
        }

        /* CARGA LOS DATOS DE LA HERRAMIENTA (CAMPO NO  OBLIGATORIO) */

        if ($getHerramienta[0] == 2) {
            $herramienta = $aplicacion->getHerramienta();
            $idHerramienta = $herramienta->getId();
            $nombreHerramienta = $herramienta->getNombre();
            $opcionHerramienta = "
                <select class='form-control mb-2' id='herramienta' name='herramienta' required>
                        <option value='{$idHerramienta}'>{$nombreHerramienta}</option>
                </select>";
        } else {
            if ($herramientaDesarrollo) {
                $boton = '';
                $opcionHerramienta = GeneradorHTML::getAlertaOperacion($getHerramienta[0], $getHerramienta[1]);
            } else {
                $opcionHerramienta = "
                    <select class='form-control mb-2' 
                            id='herramienta' name='herramienta' required>
                    </select>";
            }
        }

        /* CARGA LOS DATOS DEL LENGUAJE DE PROGRAMACION (CAMPO NO  OBLIGATORIO) */

        if ($getLenguaje[0] == 2) {
            $lenguaje = $aplicacion->getLenguaje();
            $idLenguaje = $lenguaje->getId();
            $nombreLenguaje = $lenguaje->getNombre();
            $opcionLenguaje = "
                <select class='form-control mb-2' id='lenguaje' name='lenguaje' required>
                        <option value='{$idLenguaje}'>{$nombreLenguaje}</option>
                </select>";
        } else {
            if ($lenguajeProgramacion) {
                $boton = '';
                $opcionLenguaje = GeneradorHTML::getAlertaOperacion($getLenguaje[0], $getLenguaje[1]);
            } else {
                $opcionLenguaje = "
                    <select class='form-control mb-2' 
                            id='lenguaje' name='lenguaje' required>
                    </select>";
            }
        }

        /* CARGA LOS DATOS DE LA BASE DE DATOS (CAMPO NO OBLIGATORIO) */

        if ($getBase[0] == 2) {
            $base = $aplicacion->getBaseDatos();
            $idBase = $base->getId();
            $nombreBase = $base->getNombre();
            $opcionBase = "
                <select class='form-control mb-2' id='base' name='base' required>
                        <option value='{$idBase}'>{$nombreBase}</option>
                </select>";
        } else {
            if ($baseDatos) {
                $boton = '';
                $opcionBase = GeneradorHTML::getAlertaOperacion($getBase[0], $getBase[1]);
            } else {
                $opcionBase = "<select class='form-control mb-2' id='base' name='base' required></select>";
            }
        }

        /* CARGA LOS DATOS DE LA BASE DE DATOS */

        if ($getPlataforma[0] == 2) {
            $plataforma = $aplicacion->getPlataforma();
            $idPlataforma = $plataforma->getId();
            $nombrePlataforma = $plataforma->getNombre();
            $opcionPlataforma = "
                <select class='form-control mb-2' id='plataforma' name='plataforma' required>
                        <option value='{$idPlataforma}'>{$nombrePlataforma}</option>
                </select>";
        } else {
            $boton = '';
            $opcionPlataforma = GeneradorHTML::getAlertaOperacion($getPlataforma[0], $getPlataforma[1]);
        }

        /* CARGA LOS DATOS DEL MODO DE PROCESAMIENTO */

        if ($getModo[0] == 2) {
            $modo = $aplicacion->getModoProcesamiento();
            $idModo = $modo->getId();
            $nombreModo = $modo->getNombre();
            $opcionModo = "
                <select class='form-control mb-2' id='modo' name='modo' required>
                        <option value='{$idModo}'>{$nombreModo}</option>
                </select>";
        } else {
            $boton = '';
            $opcionModo = GeneradorHTML::getAlertaOperacion($getModo[0], $getModo[1]);
        }

        /* CARGA LOS DATOS DEL LUGAR DE PROCESAMIENTO */

        if ($getLugar[0] == 2) {
            $lugar = $aplicacion->getLugarProcesamiento();
            $idLugar = $lugar->getId();
            $nombreLugar = $lugar->getNombre();
            $opcionLugar = "
                <select class='form-control mb-2' id='lugar' name='lugar' required>
                        <option value='{$idLugar}'>{$nombreLugar}</option>
                </select>";
        } else {
            $boton = '';
            $opcionLugar = GeneradorHTML::getAlertaOperacion($getLugar[0], $getLugar[1]);
        }

        /* CARGA LOS PROVEEDORES ACTIVOS QUE ESTAN EN LA BASE DE DATOS */

        $filas = "";
        $proveedoresAplicacion = $aplicacion->getProveedores();
        $idsProveedores = isset($proveedoresAplicacion) ? array_column($proveedoresAplicacion, "id") : array();
        $proveedores = $datosProveedores[1];
        while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
            $check = (in_array($proveedor['id'], $idsProveedores)) ? "checked" : "";
            $filas .= "
            <tr>
                <td class='text-center'>
                    <input type='checkbox' 
                           id='proveedores' name='proveedores[]' $check value='{$proveedor['id']}'>
                </td>
                <td class='align-middle'>" . utf8_encode($proveedor['nombre']) . "</td>
            </tr>";
        }
        $tablaProveedores = '
            <div class="table-responsive">
                <table id="tbProveedores" class="table table-bordered table-hover" 
                       cellspacing="0" style="width:100%">
                    <thead>
                        <tr>
                            <th class="text-center">
                                <input type="checkbox" id="cbTodosProveedores" name="cbTodosProveedores">
                            </th>
                            <th>Nombre</th>
                        </tr>
                    </thead>
                    <tbody>' . $filas . '</tbody>
                </table>
            </div>';

        $cuerpo = '
            <input type="hidden" name="idAplicacion" id="idAplicacion" value="' . $aplicacion->getId() . '"/>
            <div class="form-row">
                    <label for="nombreCorto" class="col-sm-2 col-form-label"
                           title="Nombre corto: campo obligatorio">* Nombre corto:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreCorto" id="nombreCorto"
                               minlength="3" maxlength="20"
                               value="' . $nombreCorto . '"
                               placeholder="Nombre corto" required>
                    </div>
                    <label for="nombreLargo" class="col-sm-2 col-form-label"
                           title="Nombre largo: campo obligatorio">* Nombre largo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreLargo" id="nombreLargo"
                               minlength="3" maxlength="50"
                               value="' . $nombreLargo . '"
                               placeholder="Nombre largo" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="tipo" class="col-sm-2 col-form-label"
                           title="Tipo de software: campo obligatorio">* Tipo de software:</label>
                    <div class="col">
                        <select class="form-control mb-2" 
                                id="tipo" name="tipo">' . $opcionesTipo . '</select>
                    </div>
                    <label for="tecnologia" class="col-sm-2 col-form-label"
                           title="Teconologia: campo obligatorio">* Técnologia:</label>
                    <div class="col">
                        <select class="form-control mb-2" 
                                id="tecnologia" name="tecnologia">' . $opcionesTecnologia . '</select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="seguridad" class="col-sm-2 col-form-label"
                           title="Seguridad: campo obligatorio">* Seguridad:</label>
                    <div class="col">
                        <select class="form-control mb-2" 
                                id="seguridad" name="seguridad">' . $opcionesSeguridad . '</select>
                    </div>
                    <label for="tipoLog" class="col-sm-2 col-form-label"
                           title="Tipo de log: campo obligatorio">* Tipo de log:</label>
                    <div class="col">
                        <select class="form-control mb-2" 
                                id="tipoLog" name="tipoLog">' . $opcionesLog . '</select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="fechaCaducidad" class="col-sm-2 col-form-label"
                           title="Fecha de caducidad de licencia: campo no obligatorio">Fecha caducidad:</label>
                    <div class="col">
                        <input type="date" class="form-control mb-2" 
                               name="fechaCaducidad" id="fechaCaducidad"
                               minlength="3" maxlength="50"
                               value="' . $fechaCaducidadFormateada . '"
                               placeholder="Fecha de caducidad">
                    </div>
                    <label for="codigoSAS" class="col-sm-2 col-form-label"
                           title="Código SAS: campo no obligatorio">Código SAS:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="codigoSAS" id="codigoSAS"
                               minlength="3" maxlength="50"
                               value="' . $codigoSAS . '"
                               placeholder="Código SAS">
                    </div>
                </div>
                <div class="form-row">
                    <label for="gerencia" class="col-sm-2 col-form-label"
                           title="Gerencia: campo obligatorio">* Gerencia:</label>
                    <div class="col">' . $opcionGerencia . '</div>
                    <label for="delegado" class="col-sm-2 col-form-label"
                           title="Delegado: campo no obligatorio">Responsable técnico:</label>
                    <div class="col">' . $opcionEmpleado . '</div>
                </div>
                <div class="form-row">
                    <label for="herramienta" class="col-sm-2 col-form-label"
                           title="Herramienta de desarrollo: campo no obligatorio">Herramienta:</label>
                    <div class="col">' . $opcionHerramienta . '</div>
                    <label for="lenguaje" class="col-sm-2 col-form-label"
                           title="Lenguaje de programación: campo no obligatorio">Lenguaje:</label>
                    <div class="col">' . $opcionLenguaje . '</div>
                </div>
                <div class="form-row">
                    <label for="base" class="col-sm-2 col-form-label"
                           title="Base de datos: campo no obligatorio">Base de datos:</label>
                    <div class="col">' . $opcionBase . '</div>
                    <label for="plataforma" class="col-sm-2 col-form-label"
                           title="Plataforma de sistema operativo: campo obligatorio">* Plataforma SO:</label>
                    <div class="col">' . $opcionPlataforma . '</div>
                </div>
                <div class="form-row">
                    <label for="modo" class="col-sm-2 col-form-label"
                           title="Modo de procesamiento: campo obligatorio">* Modo:</label>
                    <div class="col">' . $opcionModo . '</div>
                    <label for="lugar" class="col-sm-2 col-form-label"
                           title="Lugar de procesamiento: campo obligatorio">* Lugar:</label>
                    <div class="col">' . $opcionLugar . '</div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label"
                           title="Descripción: campo obligatorio">* Descripción:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  name="descripcion" id="descripcion"
                                  rows="5" minlength="10" maxlength="500"
                                  placeholder="Descripción de la aplicación" required>' . $descripcion . '</textarea>
                    </div>
                </div>
                <div class="form-row">
                    <label for="proveedor" class="col-sm-2 col-form-label">Proveedores:</label>
                    <div class="col">' . $tablaProveedores . '</div>
                </div>';
    } else {
        $codigo = ($resultado[0] == 2) ? $datosProveedores[0] : $resultado[0];
        $mensaje = ($resultado[0] == 2) ? $datosProveedores[1] : $resultado[1];
        $cuerpo = GeneradorHTML::getAlertaOperacion($codigo, $mensaje);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-desktop"></i> MODIFICAR APLICACIÓN</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formModificarAplicacion" name="formModificarAplicacion" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <?= $cuerpo; ?>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <?= $boton; ?>
                <button type="button" class="btn btn-outline-info" 
                        onclick="window.location.reload()">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="../js/ModificarAplicacionSIS.js"></script>


