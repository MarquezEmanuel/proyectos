<?php

namespace app\aplicacion\controlador;

use app\aplicacion\modelo\Aplicacion;
use app\aplicacion\modelo\ColeccionAplicaciones as Aplicaciones;
use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

class ControladorAplicacion {

    public function buscar($nombreLargo, $tipo, $tecnologia, $seguridad, $tipoLog, $nombreLenguaje, $nombreGerencia, $nombreEmpleado, $estado) {
        return Aplicaciones::buscar($nombreLargo, $tipo, $tecnologia, $seguridad, $tipoLog, $nombreLenguaje, $nombreGerencia, $nombreEmpleado, $estado);
    }

    public function buscarInformesAplicacion() {
        return Aplicaciones::buscarInformesAplicacion();
    }

    public function buscarUltimasCreadas($top, $estado) {
        return Aplicaciones::buscarUltimasCreadas($top, $estado);
    }

    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $aplicacion = new Aplicacion($id);
            $aplicacion->setEstado($estado);
            $resultado = $aplicacion->cambiarEstado();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * @param string $nombreCorto Nombre corto de la aplicacion.
     * @param string $nombreLargo Nombre largo de la aplicacion.
     * @param string $tipo Tipo de aplicacion.
     * @param string $seguridad Tipo de seguridad.
     * @param string $tecnologia Tipo de tecnologia.
     * @param int $idLenguaje Identificador del lenguaje de progracion.
     * @param int $idHerramienta Identificador de la herramienta de desarrollo.
     * @param int $idBaseDatos Identificador de la base de datos manual.
     * @param int $idModo Identificador modo de procesamiento.
     * @param int $idLugar Identificador del lugar de procesamiento.
     * @param int $idPlataforma Identificador de la plataforma SO.
     * @param int $idGerencia Identificador de la gerencia.
     * @param string $idEmpleado Identificador del empleado delegado.
     * @param string $fechaCaducidad Fecha de caducidad de la licencia.
     * @param string $codigoSAS Codigo de aplicacion SAS.
     * @param string $tipoLog Tipo de log que guarda la aplicacion.
     * @param string $descripcion Descripcion de la aplicacion.
     * @param array $proveedores Arreglo de proveedores.
     */
    public function crear($nombreCorto, $nombreLargo, $tipo, $seguridad, $tecnologia, $idLenguaje, $idHerramienta, $idBaseDatos, $idModo, $idLugar, $idPlataforma, $idGerencia, $idEmpleado, $fechaCaducidad, $codigoSAS, $tipoLog, $descripcion, $proveedores) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $aplicacion = new Aplicacion(NULL, $nombreCorto, $nombreLargo, $tipo, $seguridad, $tecnologia, $idLenguaje, $idHerramienta, $idBaseDatos, $idModo, $idLugar, $idPlataforma, $idGerencia, $idEmpleado, $fechaCaducidad, $codigoSAS, $tipoLog, NULL, NULL, NULL, NULL, NULL, $descripcion, NULL, NULL, $proveedores);
            $resultado = $aplicacion->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarSistemas($id, $nombreCorto, $nombreLargo, $tipo, $seguridad, $tecnologia, $idLenguaje, $idHerramienta, $idBaseDatos, $idModo, $idLugar, $idPlataforma, $idGerencia, $idEmpleado, $fechaCaducidad, $codigoSAS, $tipoLog, $descripcion, $proveedores) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $aplicacion = new Aplicacion($id, $nombreCorto, $nombreLargo, $tipo, $seguridad, $tecnologia, $idLenguaje, $idHerramienta, $idBaseDatos, $idModo, $idLugar, $idPlataforma, $idGerencia, $idEmpleado, $fechaCaducidad, $codigoSAS, $tipoLog, NULL, NULL, NULL, NULL, NULL, $descripcion, NULL, NULL, $proveedores);
            $resultado = $aplicacion->modificarSistemas();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarTecnologiaInformatica($id, $hardwares) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $aplicacion = new Aplicacion($id);
            $aplicacion->setServidores($hardwares);
            $resultado = $aplicacion->modificarTecnologiaInformatica();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarPAI($id, $confidencialidad, $integridad, $disponibilidad, $criticidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $aplicacion = new Aplicacion($id);
            $aplicacion->setConfidencialidad($confidencialidad);
            $aplicacion->setIntegridad($integridad);
            $aplicacion->setDisponibilidad($disponibilidad);
            $aplicacion->setCriticidad($criticidad);
            $resultado = $aplicacion->modificarPAI();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $aplicacion = new Aplicacion($id);
            $aplicacion->setRti($rti);
            $aplicacion->setVisibilidad($visibilidad);
            $resultado = $aplicacion->modificarCGTI();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Aplicacion $aplicacion Aplicacion con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $aplicacion) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "APLICACIONES";
        $metodo = "ControladorAplicacion::$funcion";
        $detalle = substr($aplicacion->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
