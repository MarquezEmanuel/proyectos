/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    /* EJECUTA LA FUNCION QUE REALIZA LA BUSQUEDA */

    realizarBusqueda();

    /* ENVIA EL FORMULARIO DE BUSQUEDA INDICANDO QUE SE PETICIONO POR EL USUARIO */

    $('#formBuscarAplicacion').submit(function (event) {
        event.preventDefault();
        $("#peticion").val("true");
        realizarBusqueda();
    });

    /* CARGA EL FORMULARIO DE CREACION CUANDO SE PRESIONA EL BOTON EN PANTALLA */

    $('#btnCrearAplicacion').click(function () {
        $.ajax({
            type: "POST",
            url: "./FCrearAplicacion.php",
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html, body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });

    /* CARGA EL FORMULARIO DE MODIFICACION CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('#seccionInferior').on('click', '.editar', function () {
        var idAplicacion = $(this).attr("name");
        event.preventDefault();
        $.ajax({
            type: "POST",
            url: "./FModificarAplicacionSIS.php",
            data: "idAplicacion=" + idAplicacion,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });

    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('#seccionInferior').on('click', '.datos', function () {
        var idAplicacion = $(this).attr("name");
        event.preventDefault();
        $.ajax({
            type: "POST",
            url: "./FDetalleAplicacion.php",
            data: "idAplicacion=" + idAplicacion,
            success: function (data) {
                $('#contenido').html(data);
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#contenido").offset().top}, '1250');
            }
        });
    });

    /* ABRE EL MODAL PARA CONFIRMAR LA BAJA */

    $('#seccionInferior').on('click', '.baja', function () {
        var nombre = $(this).parents("tr").find("td").eq(0).html();
        $("#mceaTitulo").html("<i class='fas fa-trash'></i> CONFIRME LA BAJA DE LA APLICACIÓN");
        $("#mceaEstado").val("Inactiva");
        $("#mceaIdAplicacion").val($(this).attr("name"));
        $("#mceaNombre").val(nombre);
        $("#mceaTituloNombre").text(nombre + ": ");
        $("#ModalCambioEstadoAplicacion").modal({backdrop: 'static', keyboard: false});
    });

    /* ABRE EL MODAL PARA CONFIRMAR EL ALTA */

    $('#seccionInferior').on('click', '.alta', function () {
        var nombre = $(this).parents("tr").find("td").eq(0).html();
        $("#mceaTitulo").html("<i class='fas fa-plus-circle'></i> CONFIRME EL ALTA DE LA APLICACIÓN");
        $("#mceaEstado").val("Activa");
        $("#mceaIdAplicacion").val($(this).attr("name"));
        $("#mceaNombre").val(nombre);
        $("#mceaTituloNombre").text(nombre + ": ");
        $("#ModalCambioEstadoAplicacion").modal({backdrop: 'static', keyboard: false});
    });

    /* ENVIA LA OPERACION Y MUESTRA EL RESULTADO EN EL MODAL */

    $("#btnCambiarEstadoAplicacion").click(function () {
        $.ajax({
            type: "POST",
            url: "./PCambiarEstadoAplicacion.php",
            data: $("#formCambiarEstadoAplicacion").serialize(),
            success: function (data) {
                $('#mceaCuerpo').html(data);
                $('#btnCambiarEstadoAplicacion').hide();
                $('#btnCancelarCambiarEstado').hide();
                $('#btnRefrescarPantalla').show();
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#mceaCuerpo").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#seccionInferior").offset().top}, '1250');
            }
        });
    });



});

/* ENVIA LA PETICION AJAX PARA CARGAR EL RESULTADO PREVIO DE UNA BUSQUEDA */

function realizarBusqueda() {
    $.ajax({
        type: "POST",
        url: "./PBuscarAplicacionSIS.php",
        data: $("#formBuscarAplicacion").serialize(),
        beforeSend: function () {
            $('#ModalCargando').modal({show: true, backdrop: 'static'});
        },
        success: function (data) {
            $('#seccionInferior').html(data);
            $('#tbAplicaciones').dataTable({
                dom: 'Bfrtip',
                lengthChange: false,
                language: {url: "../../../lib/JQuery/Spanish.json"}
            });
        },
        error: function (data) {
            console.log(data);
            var men = '<b>No se procesó la petición (Informe al administrador)</b>';
            var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
            $("#seccionInferior").html(div);
        },
        complete: function () {
            setTimeout(function () {
                $('#ModalCargando').modal('hide');
            }, 1000);
            $('html,body').animate({scrollTop: $("#seccionInferior").offset().top}, '1250');
        }
    });
}


