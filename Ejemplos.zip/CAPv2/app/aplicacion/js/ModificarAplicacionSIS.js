/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {

    var formOriginal = $("#formModificarAplicacion").serialize();

    /* DETECTA LOS CAMBIOS EN LOS CAMPOS DEL FORMULARIO PARA ACTIVAR/DESACTIVAR EL BOTON DE GUARDADO */

    $("#formModificarAplicacion").change(function () {
        var formModificado = $("#formModificarAplicacion").serialize();
        var habilitar = (formOriginal !== formModificado) ? false : true;
        $("#btnModificarAplicacion").prop("disabled", habilitar);
    });

    /* ENVIA EL FORMULARIO PARA REALIZAR LA MODIFICACION */

    $('#formModificarAplicacion').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: "./PModificarAplicacionSIS.php",
            data: $("#formModificarAplicacion").serialize(),
            success: function (data) {
                $('#seccionResultado').html(data[0]['resultado']);
                if (data[0]['exito'] === true) {
                    $('#formModificarAplicacion').find('input, textarea, select').prop('disabled', true);
                    $("#btnModificarAplicacion").prop("disabled", true);
                }
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionResultado").html(div);
            },
            complete: function () {
                $('html,body').animate({scrollTop: $("#seccionResultado").offset().top}, '1250');
            }
        });
    });

    $('select#herramienta').select2({
        placeholder: 'Selecione una herramienta',
        theme: "bootstrap",
        minimumInputLength: 1,
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "../../herramienta/vista/PSeleccionarHerramienta.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#lenguaje').select2({
        placeholder: 'Seleccione un lenguaje',
        theme: "bootstrap",
        minimumInputLength: 1,
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "../../lenguaje/vista/PSeleccionarLenguaje.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#base').select2({
        placeholder: 'Seleccione una base',
        theme: "bootstrap",
        minimumInputLength: 1,
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "../../base/vista/PSeleccionarBaseManual.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#plataforma').select2({
        placeholder: 'Seleccione una plataforma',
        theme: "bootstrap",
        minimumInputLength: 1,
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "../../plataforma/vista/PSeleccionarPlataformaSO.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#modo').select2({
        placeholder: 'Seleccione un modo',
        theme: "bootstrap",
        minimumInputLength: 1,
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "../../procesamiento/vista/PSeleccionarModoProcesamiento.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#lugar').select2({
        placeholder: 'Seleccione un lugar',
        theme: "bootstrap",
        minimumInputLength: 1,
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "../../procesamiento/vista/PSeleccionarLugarProcesamiento.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#gerencia').select2({
        placeholder: 'Seleccione una gerencia',
        theme: "bootstrap",
        minimumInputLength: 1,
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "../../gerencia/vista/PSeleccionarGerencia.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('select#delegado').select2({
        placeholder: 'Seleccione un delegado',
        theme: "bootstrap",
        minimumInputLength: 1,
        maximumInputLength: 30,
        allowClear: true,
        ajax: {
            url: "../../gerencia/vista/PSeleccionarEmpleadoDelegado.php",
            dataType: 'json',
            type: "POST",
            delay: 250,
            data: function (params) {
                return {nombre: params.term};
            },
            processResults: function (data) {
                return {results: data};
            },
            cache: true
        }
    });

    $('#cbTodosProveedores').change(function () {
        var habilitar = ($(this).is(':checked')) ? true : false;
        $("input[name='proveedores[]']").each(function () {
            $(this).prop('checked', habilitar);
        });
    });

});
