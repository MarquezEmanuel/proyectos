<?php

namespace app\hardware\modelo;

use app\principal\modelo\SQLServer;

/**
 * Mapea con la tabla que relaciona elementos de hardware con los proveedores.
 * 
 * @package app\proveedor\modelo.
 * 
 * @uses har_hardware_proveedor Tabla relacion de hardware con proveedor.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 * 
 * @version 1.0
 */
class HardwareProveedor {

    /**
     * Realiza la eliminacion de los proveedores asociados al activo y luego la
     * creacion de los nuevos proveedores asociados.
     * @param int $idHardware Identificador del activo.
     * @param array $proveedores Arreglo con los identificadores de los proveedores.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function actualizarProveedoresHardware($idHardware, $proveedores) {
        $resultado = HardwareProveedor::borrar($idHardware);
        if ($resultado[0] == 2) {
            $resultado = HardwareProveedor::crear($idHardware, $proveedores);
        }
        return $resultado;
    }

    /**
     * Elimina todos los proveedores asociados a un activo hardware.
     * @see SQLServer::$instancia->borrar
     * @param int $idHardware Identificador del activo.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function borrar($idHardware) {
        if ($idHardware > 0) {
            $consulta = "DELETE FROM har_hardware_proveedor WHERE idHardware = ?";
            return SQLServer::$instancia->borrar($consulta, array(&$idHardware));
        }
        return array(0, "No se pudo hacer referencia al hardware para asociar proveedores");
    }

    /**
     * Crea todas las relaciones de un activo hardware con sus proveedores.
     * @see SQLServer::instancia()->insertar
     * @param int $idHardware Identificador del activo.
     * @param array $proveedores Arreglo con los identificadores de los proveedores.
     * @return array Arreglo de dos elementos (codigo, mensaje).
     */
    public static function crear($idHardware, $proveedores) {
        if ($idHardware && !empty($proveedores)) {
            $registros = "";
            for ($index = 0; $index < count($proveedores); $index++) {
                $registros .= "({$idHardware}, ?),";
            }
            $consulta = "INSERT INTO har_hardware_proveedor VALUES " . substr($registros, 0, -1);
            return SQLServer::instancia()->insertar($consulta, $proveedores);
        }
        return array(0, "No se recibieron los campos obligatorios para relacionar proveedores");
    }

}
