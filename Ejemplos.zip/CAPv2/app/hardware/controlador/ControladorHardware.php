<?php

namespace app\hardware\controlador;

use app\hardware\modelo\Hardware;
use app\hardware\modelo\ColeccionHardwares as Hardwares;
use app\principal\modelo\SQLServer;
use app\principal\modelo\Log;

class ControladorHardware {

    public function buscar($tipo, $nombreLargo, $ambiente, $nombreSitio, $dominio, $estado) {
        return Hardwares::buscar($tipo, $nombreLargo, $ambiente, $nombreSitio, $dominio, $estado);
    }

    public function buscarInformesHardware() {
        return Hardwares::buscarInformesHardware();
    }

    public function buscarParaSeleccionar($nombreLargo) {
        return Hardwares::buscarParaSeleccionar($nombreLargo);
    }

    public function buscarUltimosCreados($top, $estado) {
        return Hardwares::buscarUltimosCreados($top, $estado);
    }

    /**
     * Cambiar estado del activo hardware.
     * @see SQLServer::instancia()->iniciarTransaccion
     * @see SQLServer::instancia()->finalizarTransaccion
     * @see Hardware::cambiarEstado
     * @param int $id Identificador del activo.
     * @param string $estado Nuevo estado del activo.
     * @return array Arreglo con dos elementos (codigo, mensaje).
     */
    public function cambiarEstado($id, $estado) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $hardware = new Hardware($id);
            $hardware->setEstado($estado);
            $resultado = $hardware->cambiarEstado();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            $this->registrar($resultado, "modificacion", "cambiarEstado", $hardware);
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * @param string $tipo Tipo de hardware.
     * @param string $nombreCorto Nombre corto.
     * @param string $nombreLargo Nombre largo.
     * @param string $dominio Nombre del dominio.
     * @param string $swBase Software de base.
     * @param string $ambiente Ambiente desarrollo, test o produccion.
     * @param string $funcion Funcion que cumple.
     * @param string $idSitio Identificador del sitio.
     * @param string $marca Nombre de la marca.
     * @param string $modelo Modelo.
     * @param string $arquitectura Arquitectura.
     * @param string $core Informacion del core.
     * @param string $procesador Informacion del procesador.
     * @param string $mhz Informacion de mhz.
     * @param string $memoria Memoria.
     * @param string $disco Informacion del disco.
     * @param string $raid Informacion del raid.
     * @param int $red Numero de red.
     * @param string $descripcion Descripcion adicional.
     * @param array $proveedores Arreglo con identificadores de proveedores.
     */
    public function crear($tipo, $nombreCorto, $nombreLargo, $dominio, $swBase, $ambiente, $funcion, $idSitio, $marca, $modelo, $arquitectura, $core, $procesador, $mhz, $memoria, $disco, $raid, $red, $descripcion, $proveedores) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $hardware = new Hardware(NULL, $tipo, $nombreCorto, $nombreLargo, $dominio, $swBase, $ambiente, $funcion, $idSitio, $marca, $modelo, $arquitectura, $core, $procesador, $mhz, $memoria, $disco, $raid, $red, NULL, NULL, $descripcion, NULL, $proveedores);
            $resultado = $hardware->crear();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "creacion", "crear", $hardware);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function consultar($nombre, $tipo, $ambiente, $dominio, $sitio) {
        $resultado = Hardwares::consultar($nombre, $tipo, $ambiente, $dominio, $sitio);
        return $resultado;
    }

    public function modificar($id, $tipo, $nombreCorto, $nombreLargo, $dominio, $swBase, $ambiente, $funcion, $idSitio, $marca, $modelo, $arquitectura, $core, $procesador, $mhz, $memoria, $disco, $raid, $red, $descripcion, $proveedores) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $hardware = new Hardware($id, $tipo, $nombreCorto, $nombreLargo, $dominio, $swBase, $ambiente, $funcion, $idSitio, $marca, $modelo, $arquitectura, $core, $procesador, $mhz, $memoria, $disco, $raid, $red, NULL, NULL, $descripcion, NULL, $proveedores);
            $resultado = $hardware->modificar();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificar", $hardware);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    public function modificarGCTI($id, $rti, $visibilidad) {
        if (SQLServer::instancia()->iniciarTransaccion()) {
            $hardware = new Hardware($id);
            $hardware->setRti($rti);
            $hardware->setVisibilidad($visibilidad);
            $resultado = $hardware->modificarCGTI();
            $confirmar = ($resultado[0] == 2) ? TRUE : FALSE;
            SQLServer::instancia()->finalizarTransaccion($confirmar);
            $this->registrar($resultado, "modificacion", "modificarGCTI", $hardware);
            return $resultado;
        }
        return array(0, "No se pudo inicializar la transacción para operar");
    }

    /**
     * Registra la actividad o el error en el log de actividades de la base de
     * datos. Recibe el resultado de una operacion, el tipo de operacion y el
     * nombre del metodo ejecutado.
     * @param array $resultado Arreglo con el codigo y mensaje.
     * @param string $operacion Tipo de operacion que se realizo.
     * @param string $funcion Nombre del metodo que se ejecuto.
     * @param Hardware $hardware Hardware con el que se opera.
     */
    private function registrar($resultado, $operacion, $funcion, $hardware) {
        $codigo = $resultado[0];
        $tipo = ($codigo == 0) ? "ERROR" : "ACTIVIDAD";
        $modulo = "HARDWARES";
        $metodo = "ControladorHardware::$funcion";
        $detalle = substr($hardware->toString(), 0, 500);
        Log::guardarActividad($tipo, $modulo, $operacion, $metodo, $codigo, $detalle);
    }

}
