<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\hardware\controlador\ControladorHardware;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['idHardware'])) {
    $id = $_POST['idHardware'];
    $nombreLargo = $_POST['nombreLargo'];
    $visibilidad = $_POST['visibilidad'];
    $rti = $_POST['rti'];
    $controlador = new ControladorHardware();
    $modificacion = $controlador->modificarGCTI($id, $rti, $visibilidad);
    $exito = ($modificacion[0] == 2) ? true : false;
    $mensaje = "{$nombreLargo}: $modificacion[1]";
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
