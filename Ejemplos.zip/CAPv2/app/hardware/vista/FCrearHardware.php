<?php
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\proveedor\controlador\ControladorProveedor;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorProveedor();
$resultado = $controlador->buscarEstadoActivo();
$estadoBoton = "disabled";
if ($resultado[0] == 2) {
    $proveedores = $resultado[1];
    $filas = $estadoBoton = "";
    while ($proveedor = sqlsrv_fetch_array($proveedores, SQLSRV_FETCH_ASSOC)) {
        $idProveedor = $proveedor['id'];
        $nombreProveedor = $proveedor['nombre'];
        $filas .= "
            <tr>
                <td class='text-center'>
                    <input type='checkbox' 
                           id='proveedores' name='proveedores[]' 
                           title='Seleccionar: {$nombreProveedor}'
                           value='{$idProveedor}'>
                </td>
                <td class='align-middle'>{$nombreProveedor}</td>
            </tr>";
    }
    $tablaProveedores = '
        <div class="table-responsive">
            <table id="tbProveedores" class="table table-bordered table-hover" 
                   cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th class="text-center">
                            <input type="checkbox" 
                                   id="cbTodosProveedores" name="cbTodosProveedores"
                                   title="Seleccionar todos los proveedores">
                        </th>
                        <th>Nombre</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $tablaProveedores = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fas fa-microchip"></i> CREAR HARDWARE</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <form id="formCrearHardware" name="formCrearHardware" method="POST">
        <div class="card border-azul-clasico mt-3">
            <div class="card-header bg-azul-clasico text-white">Complete el formulario</div>
            <div class="card-body">
                <div class="form-row">
                    <label for="tipo" class="col-sm-2 col-form-label">* Tipo:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="tipo" name="tipo">
                            <option value="Host virtual">Host virtual</option>
                            <option value="Maquina virtual">Máquina virtual</option>
                            <option value="Hardware fisico">Hardware físico</option>
                            <option value="Otro">Otro</option>
                        </select>
                    </div>
                    <label for="ambiente" class="col-sm-2 col-form-label">* Ambiente:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="ambiente" name="ambiente">
                            <option value="Produccion">Producción</option>
                            <option value="Test">Test</option>
                            <option value="Desarrollo">Desarrollo</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="nombreCorto" class="col-sm-2 col-form-label">* Nombre corto:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreCorto" id="nombreCorto" 
                               maxlength="20"
                               placeholder="Sigla" required>
                    </div>
                    <label for="nombre" class="col-sm-2 col-form-label">* Nombre largo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="nombreLargo" id="nombreLargo" 
                               maxlength="50"
                               placeholder="Nombre" required>
                    </div>
                </div>
                <div class="form-row">
                    <label for="sitio" class="col-sm-2 col-form-label">* Sitio:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="sitio" name="sitio"></select>
                    </div>
                    <label for="dominio" class="col-sm-2 col-form-label">* Dominio:</label>
                    <div class="col">
                        <select class="form-control mb-2" id="dominio" name="dominio">
                            <option value="CORP">CORP</option>
                            <option value="DMZ">DMZ</option>
                            <option value="SANTACRUZ">SANTA CRUZ</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <label for="swbase" class="col-sm-2 col-form-label">Software base:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="swbase" id="swbase" maxlength="50"
                               placeholder="Software base">
                    </div>
                    <label for="marca" class="col-sm-2 col-form-label">Marca:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="marca" id="marca" maxlength="50"
                               placeholder="Marca">
                    </div>
                </div>
                <div class="form-row">
                    <label for="modelo" class="col-sm-2 col-form-label">Modelo:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="modelo" id="modelo" maxlength="50"
                               placeholder="Modelo">
                    </div>
                    <label for="arquitectura" class="col-sm-2 col-form-label">Arquitectura:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="arquitectura" id="arquitectura" maxlength="50"
                               placeholder="Arquitectura">
                    </div>
                </div>
                <div class="form-row">
                    <label for="core" class="col-sm-2 col-form-label">Core:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="core" id="core" maxlength="50"
                               placeholder="Core">
                    </div>
                    <label for="procesador" class="col-sm-2 col-form-label">Procesador:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="procesador" id="procesador" maxlength="50"
                               placeholder="Procesador">
                    </div>
                </div>
                <div class="form-row">
                    <label for="mhz" class="col-sm-2 col-form-label">Mhz:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="mhz" id="mhz" maxlength="50"
                               placeholder="Mhz">
                    </div>
                    <label for="memoria" class="col-sm-2 col-form-label">Memoria:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="memoria" id="memoria" maxlength="50" 
                               placeholder="Memoria">
                    </div>
                </div>
                <div class="form-row">
                    <label for="disco" class="col-sm-2 col-form-label">Disco:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="disco" id="disco" maxlength="50"
                               placeholder="Disco">
                    </div>
                    <label for="raid" class="col-sm-2 col-form-label">Raid:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="raid" id="raid" maxlength="50"
                               placeholder="Raid">
                    </div>
                </div>
                <div class="form-row">
                    <label for="disco" class="col-sm-2 col-form-label">Red:</label>
                    <div class="col">
                        <input type="text" class="form-control mb-2" 
                               name="red" id="red" maxlength="50"
                               placeholder="Red">
                    </div>
                    <label class="col-sm-2 col-form-label"></label>
                    <div class="col"></div>
                </div>
                <div class="form-row">
                    <label for="funcion" class="col-sm-2 col-form-label">* Función: </label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  name="funcion" id="funcion" maxlength="300" 
                                  placeholder="Función" required></textarea>
                    </div>
                </div>
                <div class="form-row">
                    <label for="descripcion" class="col-sm-2 col-form-label">* Descripcion:</label>
                    <div class="col">
                        <textarea class="form-control mb-2" 
                                  id="descripcion" name="descripcion"
                                  maxlength="500"
                                  placeholder="Descripcion" required></textarea>
                    </div>
                </div>
                <div class="form-row">
                    <label for="proveedores" class="col-sm-2 col-form-label">* Proveedores:</label>
                    <div class="col"><?= $tablaProveedores; ?></div>
                </div>
            </div>
        </div>
        <div class="form-row mt-2 mb-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-success">
                    <i class="far fa-save"></i> GUARDAR
                </button>
                <button type="button" class="btn btn-outline-info" onclick="window.location.reload()">
                    <i class="fas fa-search"></i> BUSCAR
                </button>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript" src="../js/CrearHardware.js"></script>


