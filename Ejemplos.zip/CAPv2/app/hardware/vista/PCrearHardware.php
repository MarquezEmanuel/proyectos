<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\hardware\controlador\ControladorHardware;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if (isset($_POST['tipo'])) {
    $tipo = $_POST['tipo'];
    $nombreCorto = $_POST['nombreCorto'];
    $nombreLargo = $_POST['nombreLargo'];
    $dominio = $_POST['dominio'];
    $swBase = $_POST['swbase'];
    $ambiente = $_POST['ambiente'];
    $funcion = $_POST['funcion'];
    $sitio = $_POST['sitio'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $arquitectura = $_POST['arquitectura'];
    $core = $_POST['core'];
    $procesador = $_POST['procesador'];
    $mhz = $_POST['mhz'];
    $memoria = $_POST['memoria'];
    $disco = $_POST['disco'];
    $raid = $_POST['raid'];
    $red = $_POST['red'];
    $descripcion = $_POST['descripcion'];
    $proveedores = $_POST['proveedores'];
    $controlador = new ControladorHardware();
    $creacion = $controlador->crear($tipo, $nombreCorto, $nombreLargo, $dominio, $swBase, $ambiente, $funcion, $sitio, $marca, $modelo, $arquitectura, $core, $procesador, $mhz, $memoria, $disco, $raid, $red, $descripcion, $proveedores);
    $mensaje = "{$nombreLargo}: {$creacion[1]}";
    $exito = ($creacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($creacion[0], $mensaje);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);

