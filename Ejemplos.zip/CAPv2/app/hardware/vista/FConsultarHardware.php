<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="fas fa-microchip"></i> CONSULTAR HARDWARE</h4>
                </div>
            </div>
            <div class="mt-3 mb-4">
                <form method="POST" id="formConsultarHardware" name="formConsultarHardware">
                    <input type="hidden" name="peticion" id="peticion">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="tipo" class="col-sm-2 col-form-label">* Tipo:</label>
                                <div class="col">
                                    <select class="form-control mb-2" id="tipo" name="tipo">
                                        <option value="">Todos</option>
                                        <option value="Host virtual">Host virtual</option>
                                        <option value="Maquina virtual">Máquina virtual</option>
                                        <option value="Hardware fisico">Hardware físico</option>
                                        <option value="Otro">Otro</option>
                                    </select>
                                </div>
                                <label for="nombreLargo" class="col-2 col-form-label">Nombre largo:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombreLargo" id="nombreLargo" 
                                           maxlength="50"
                                           title="Nombre del hardware"
                                           placeholder="Nombre del hardware">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="ambiente" class="col-sm-2 col-form-label">Ambiente:</label>
                                <div class="col">
                                    <select class="form-control mb-2" id="ambiente" name="ambiente">
                                        <option value="">Todos</option>
                                        <option value="Produccion">Producción</option>
                                        <option value="DMZ">DMZ</option>
                                    </select>
                                </div>
                                <label for="sitio" class="col-2 col-form-label">Sitio:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="sitio" id="sitio" 
                                           maxlength="50"
                                           title="Nombre del sitio"
                                           placeholder="Nombre del sitio">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="estado" class="col-2 col-form-label">* Dominio:</label>
                                <div class="col">
                                    <select class="form-control mb-2" id="dominio" name="dominio">
                                        <option value="">Todos</option>
                                        <option value="CORP">CORP</option>
                                        <option value="DMZ">DMZ</option>
                                        <option value="SANTACRUZ">SANTA CRUZ</option>
                                    </select>
                                </div>
                                <label class="col-2 col-form-label"></label>
                                <div class="col"></div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-search"></i>  BUSCAR</button>  
                        </div>
                    </div>
                </form>
            </div>
            <br>
            <div id="seccionInferior" class="mt-4 mb-2"></div>
        </div>
        <div class="modal fade bg-dark" style="opacity: 80%" id="ModalCargando" tabindex="0" aria-labelledby="myModalLabel" data-backdrop="static" aria-hidden="false">
            <div class="modal-dialog modal-lg p-4">
                <div class="container p-4">
                    <div class="container mt-4 mb-4">
                        <div class="row mt-4 mb-4">
                            <div class="col text-center" style="font-size: 1.8rem;">
                                <i class="fas fa-spinner fa-3x fa-spin text-white"></i>
                            </div>
                        </div>
                        <div class="row mt-4 mb-4">
                            <div class="col text-center text-white" style="font-size: 1.4rem;">
                                <p> <strong>CARGANDO RESULTADOS</strong></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/ConsultarHardware.js"></script>