<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\hardware\controlador\ControladorHardware;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorHardware();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $tipo = $_POST['tipo'];
    $nombreLargo = $_POST['nombreLargo'];
    $ambiente = $_POST['ambiente'];
    $nombreSitio = $_POST['sitio'];
    $dominio = $_POST['dominio'];
    $estado = 'Activo';
    $datos = ($tipo) ? "'{$tipo}', " : "TODOS, ";
    $datos .= ($nombreLargo) ? "'{$nombreLargo}', " : "TODOS, ";
    $datos .= ($ambiente) ? "'{$ambiente}', " : "TODOS, ";
    $datos .= ($nombreSitio) ? "'{$nombreSitio}', " : "TODOS, ";
    $datos .= ($dominio) ? "'{$dominio}', " : "TODOS, ";
    $datos .= ($estado) ? "'{$estado}'" : "TODOS";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($tipo, $nombreLargo, $ambiente, $nombreSitio, $dominio, $estado);
    $_SESSION['BHARDWARES'] = array($tipo, $nombreLargo, $ambiente, $nombreSitio, $dominio, $estado, $datos);
} else {
    if (isset($_SESSION['BHARDWARES'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BHARDWARES'];
        $tipo = $parametros[0];
        $nombreLargo = $parametros[1];
        $ambiente = $parametros[2];
        $nombreSitio = $parametros[3];
        $dominio = $parametros[4];
        $estado = $parametros[5];
        $filtro = "Ultima búsqueda realizada: " . $parametros[6];
        $resultado = $controlador->buscar($tipo, $nombreLargo, $ambiente, $nombreSitio, $dominio, $estado);
        $_SESSION['BHARDWARES'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['BHARDWARES'] = NULL;
    }
}

if ($resultado[0] == 2) {
    /* SE OBTUVO UN RESULTADO DESDE LA BASE DE DATOS */
    $hardwares = $resultado[1];
    $filas = "";
    while ($hardware = sqlsrv_fetch_array($hardwares, SQLSRV_FETCH_ASSOC)) {
        $idHardware = $hardware['idHardware'];
        $tipoHardware = utf8_encode($hardware['tipoHardware']);
        $nombreCortoHardware = utf8_encode($hardware['nombreCortoHardware']);
        $nombreLargoHardware = utf8_encode($hardware['nombreLargoHardware']);
        $dominioHardware = utf8_encode($hardware['dominioHardware']);
        $softwareBaseHardware = utf8_encode($hardware['softwareBaseHardware']);
        $ambienteHardware = utf8_encode($hardware['ambienteHardware']);
        $funcionHardware = utf8_encode($hardware['funcionHardware']);
        $idSitio = $hardware['idSitio'];
        $tipoSitio = utf8_encode($hardware['tipoSitio']);
        $nombreSitio = utf8_encode($hardware['nombreSitio']);
        $estadoSitio = $hardware['estadoSitio'];
        $marcaHardware = utf8_encode($hardware['marcaHardware']);
        $modeloHardware = utf8_encode($hardware['modeloHardware']);
        $arquitecturaHardware = utf8_encode($hardware['arquitecturaHardware']);
        $coreHardware = utf8_encode($hardware['coreHardware']);
        $procesadorHardware = utf8_encode($hardware['procesadorHardware']);
        $mhzHardware = utf8_encode($hardware['mhzHardware']);
        $memoriaHardware = utf8_encode($hardware['memoriaHardware']);
        $discoHardware = utf8_encode($hardware['discoHardware']);
        $raidHardware = utf8_encode($hardware['raidHardware']);
        $redHardware = $hardware['redHardware'];
        $rtiHardware = $hardware['rtiHardware'];
        $estadoHardware = $hardware['estadoHardware'];
        $descripcionHardware = utf8_encode($hardware['descripcionHardware']);
        $fechaCreacionHardware = isset($hardware['fechaCreacionHardware']) ? date_format($hardware['fechaCreacionHardware'], 'd/m/Y H:i') : "";
        $fechaEdicionHardware = isset($hardware['fechaUltimaEdicionHardware']) ? date_format($hardware['fechaUltimaEdicionHardware'], 'd/m/Y H:i') : "";
        $cantidadProveedores = $hardware['cantidadProveedores'];

        $filas .= "
            <tr>
                <td>{$tipoHardware}</td>
                <td>{$nombreCortoHardware}</td>
                <td>{$nombreLargoHardware}</td>
                <td>{$dominioHardware}</td>
                <td style='display: none;'>{$softwareBaseHardware}</td>
                <td>{$ambienteHardware}</td>
                <td style='display: none;'>{$funcionHardware}</td>
                <td style='display: none;'>{$idSitio}</td>
                <td style='display: none;'>{$tipoSitio}</td>
                <td title='{$idSitio}, {$tipoSitio}: {$estadoSitio}'>{$nombreSitio}</td>
                <td style='display: none;'>{$estadoSitio}</td>
                <td>{$marcaHardware}</td>
                <td>{$modeloHardware}</td>
                <td style='display: none;'>{$arquitecturaHardware}</td>
                <td style='display: none;'>{$coreHardware}</td>
                <td style='display: none;'>{$procesadorHardware}</td>
                <td style='display: none;'>{$mhzHardware}</td>
                <td style='display: none;'>{$memoriaHardware}</td>
                <td style='display: none;'>{$discoHardware}</td>
                <td style='display: none;'>{$raidHardware}</td>
                <td style='display: none;'>{$redHardware}</td>
                <td>{$rtiHardware}</td>
                <td style='display: none;'>{$estadoHardware}</td>
                <td style='display: none;'>{$descripcionHardware}</td>
                <td style='display: none;'>{$cantidadProveedores}</td>
                <td style='display: none;'>{$fechaCreacionHardware}</td> 
                <td style='display: none;'>{$fechaEdicionHardware}</td> 
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$idHardware}' title='Ver detalle'>
                                <i class='fas fa-info-circle'></i>
                        </button>
                        <button class='btn btn-outline-warning editar' 
                                name='{$idHardware}' title='Editar: {$nombreLargoHardware}'>
                                <i class='far fa-edit'></i>
                        </button>
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbHardwares" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Tipo</th>
                        <th>Nombre corto</th>
                        <th>Nombre largo</th>
                        <th>Dominio</th>
                        <th style="display: none;">Software base</th>
                        <th>Ambiente</th>
                        <th style="display: none;">Función</th>
                        <th style="display: none;">Código sitio</th>
                        <th style="display: none;">Tipo sitio</th>
                        <th>Nombre sitio</th>
                        <th style="display: none;">Estado sitio</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th style="display: none;">Arquitectura</th>
                        <th style="display: none;">Core</th>
                        <th style="display: none;">Procesador</th>
                        <th style="display: none;">Mhz</th>
                        <th style="display: none;">Memoria</th>
                        <th style="display: none;">Disco</th>
                        <th style="display: none;">Raid</th>
                        <th style="display: none;">Red</th>
                        <th>RTI</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">Descripción</th>
                        <th style="display: none;">Cantidad de proveedores</th>
                        <th style="display: none;">Fecha de creación</th>
                        <th style="display: none;">Fecga de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
