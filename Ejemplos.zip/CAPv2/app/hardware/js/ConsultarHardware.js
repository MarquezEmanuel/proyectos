/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {

    /* CARGA LA FECHA DEL DIA ACTUAL PARA USAR EN LOS NOMBRES DE ARCHIVOS */

    var hoy = new Date();
    var fecha = hoy.getDate() + "_" + (hoy.getMonth() + 1) + "_" + hoy.getFullYear();

    /* EJECUTA LA FUNCION QUE REALIZA LA BUSQUEDA */

    realizarBusqueda();

    /* ENVIA EL FORMULARIO DE BUSQUEDA INDICANDO QUE SE PETICIONO POR EL USUARIO */

    $('#formConsultarHardware').submit(function (event) {
        event.preventDefault();
        $("#peticion").val("true");
        realizarBusqueda();
    });

    /* ABRE EL MODAL CON LOS DATOS BASICOS CUANDO SE PRESIONA EL BOTON EN LA TABLA */

    $('#seccionInferior').on('dblclick', '.fila', function () {
        $("#mdhTipo").val($(this).find('td:eq(0)').text());
        $("#mdhSigla").val($(this).find('td:eq(1)').text());
        $("#mdhNombre").val($(this).find('td:eq(2)').text());
        $("#mdhDominio").val($(this).find('td:eq(3)').text());
        $("#mdhAmbiente").val($(this).find('td:eq(4)').text());
        $("#mdhSwBase").val($(this).find('td:eq(5)').text());
        $("#mdhUbicacion").val($(this).find('td:eq(6)').text());
        $("#mdhMarca").val($(this).find('td:eq(7)').text());
        $("#mdhModelo").val($(this).find('td:eq(8)').text());
        $("#mdhArquitectura").val($(this).find('td:eq(9)').text());
        $("#mdhCore").val($(this).find('td:eq(10)').text());
        $("#mdhProcesador").val($(this).find('td:eq(11)').text());
        $("#mdhMhz").val($(this).find('td:eq(12)').text());
        $("#mdhMemoria").val($(this).find('td:eq(13)').text());
        $("#mdhDisco").val($(this).find('td:eq(14)').text());
        $("#mdhRaid").val($(this).find('td:eq(15)').text());
        $("#mdhRed").val($(this).find('td:eq(16)').text());
        $("#mdhRTI").val($(this).find('td:eq(17)').text());
        $("#mdhFuncion").val($(this).find('td:eq(18)').text());
        $("#ModalDatosHardware").modal({});
    });

    function realizarBusqueda() {
        $.ajax({
            type: "POST",
            url: "./PConsultarHardware.php",
            data: $("#formConsultarHardware").serialize(),
            beforeSend: function () {
                $('#ModalCargando').modal({show: true, backdrop: 'static'});
            },
            success: function (data) {
                $('#seccionInferior').html(data);
                $('#tbHardwares').dataTable({
                    dom: 'Bfrtip',
                    lengthChange: false,
                    buttons: [{
                            extend: 'excelHtml5',
                            title: fecha + '_HARDWARES'
                        }
                    ],
                    language: {url: "../../../lib/JQuery/Spanish.json"}
                });
            },
            error: function (data) {
                console.log(data);
                var men = '<b>No se procesó la petición (Informe al administrador)</b>';
                var div = '<div class="alert alert-danger text-center" role="alert">' + men + '</div>';
                $("#seccionInferior").html(div);
            },
            complete: function () {
                setTimeout(function () {
                    $('#ModalCargando').modal('hide');
                }, 1000);
                $('html,body').animate({scrollTop: $("#seccionInferior").offset().top}, '1250');
            }
        });
    }

});
