<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\herramienta\controlador\ControladorHerramientaDesarrollo;

AutoCargador::cargarModulos();
session_start();

$exito = FALSE;
if ($_POST['idHerramienta']) {
    $id = $_POST['idHerramienta'];
    $nombre = $_POST['nombre'];
    $version = $_POST['version'];
    $fabricante = $_POST['fabricante'];
    $fechaCaducidad = $_POST['fechaCaducidad'];
    $descripcion = $_POST['descripcion'];
    $proveedores = $_POST['proveedores'];
    $controlador = new ControladorHerramientaDesarrollo();
    $modificacion = $controlador->modificar($id, $nombre, $version, $fabricante, $fechaCaducidad, $descripcion, $proveedores);
    $exito = ($modificacion[0] == 2) ? true : false;
    $resultado = GeneradorHTML::getAlertaOperacion($modificacion[0], $modificacion[1]);
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $resultado = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}

/* RETORNA EL ARREGLO JSON PARA MOSTRAR LA INFORMACION SEGUN CORRESPONDA */

$json[] = array('exito' => $exito, 'resultado' => $resultado);
echo json_encode($json);
