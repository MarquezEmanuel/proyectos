<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\principal\modelo\Log;
use app\herramienta\controlador\ControladorHerramientaDesarrollo;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorHerramientaDesarrollo();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $herramientas = $resultado[1];
        while ($herramienta = sqlsrv_fetch_array($herramientas, SQLSRV_FETCH_ASSOC)) {
            $idHerramienta = $herramienta["id"];
            $nombreHerramienta = utf8_encode($herramienta["nombre"]) . " (" . utf8_encode($herramienta["version"]) . ')';
            $arreglo[] = array('id' => $idHerramienta, 'text' => $nombreHerramienta);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar herramienta de desarrollo";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'HERRAMIENTAS', 'busqueda', 'PSeleccionarHerramienta', '', $detalle);
}

echo json_encode($arreglo);
