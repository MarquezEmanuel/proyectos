<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\utilidad\modelo\GeneradorHTML;
use app\herramienta\controlador\ControladorHerramientaDesarrollo;

AutoCargador::cargarModulos();
session_start();

$controlador = new ControladorHerramientaDesarrollo();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombre = $_POST['nombre'];
    $version = $_POST['version'];
    $fabricante = $_POST['fabricante'];
    $estado = $_POST['estado'];
    $datos = ($nombre) ? "'{$nombre}', " : "Sin nombre, ";
    $datos .= ($version) ? "'{$version}', " : "Sin version, ";
    $datos .= ($fabricante) ? "'{$fabricante}', " : "Sin fabricante, ";
    $datos .= ($estado) ? "'{$estado}'" : "Sin estado";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $resultado = $controlador->buscar($nombre, $version, $fabricante, $estado);
    $_SESSION['BHERRAMIENTAS'] = array($nombre, $version, $fabricante, $estado, $datos);
} else {
    if (isset($_SESSION['BHERRAMIENTAS'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BHERRAMIENTAS'];
        $nombre = $parametros[0];
        $version = $parametros[1];
        $fabricante = $parametros[2];
        $estado = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[4];
        $resultado = $controlador->buscar($nombre, $version, $fabricante, $estado);
        $_SESSION['BHERRAMIENTAS'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activa';
        $resultado = $controlador->buscarUltimasCreadas($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['BHERRAMIENTAS'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $herramientas = $resultado[1];
    $filas = "";
    while ($herramienta = sqlsrv_fetch_array($herramientas, SQLSRV_FETCH_ASSOC)) {
        $id = $herramienta['id'];
        $nombre = utf8_encode($herramienta['nombre']);
        $version = utf8_encode($herramienta['version']);
        $fabricante = utf8_encode($herramienta['fabricante']);
        $fechaCaducidad = isset($herramienta['fechaCaducidad']) ? date_format($herramienta['fechaCaducidad'], 'd/m/Y') : "";
        $descripcion = utf8_encode($herramienta['descripcion']);
        $estado = $herramienta['estado'];
        $fechaCreacion = isset($herramienta['fechaCreacion']) ? date_format($herramienta['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($herramienta['fechaUltimaEdicion']) ? date_format($herramienta['fechaUltimaEdicion'], 'd/m/Y H:i') : "";

        if ($estado == 'Activa') {
            $operaciones = "
                <button class='btn btn-outline-warning editar' 
                        name='{$id}' title='Editar: $nombre'>
                        <i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger baja' 
                        name='{$id}' title='Dar de baja: $nombre'>
                        <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-success alta' 
                        name='{$id}' title='Dar de alta: $nombre'>
                        <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td>{$nombre}</td>
                <td>{$version}</td>
                <td>{$fabricante}</td>
                <td>{$fechaCaducidad}</td>
                <td style='display: none;'>{$descripcion}</td>
                <td style='display: none;'>{$estado}</td>
                <td style='display: none;'>{$fechaCreacion}</td>
                <td style='display: none;'>{$fechaEdicion}</td>
                <td class='text-center'>
                    <div class='btn-group btn-group-sm'>
                        <button class='btn btn-outline-info datos' 
                                name='{$id}' title='Datos básicos: $nombre'>
                                <i class='fas fa-info-circle'></i>
                        </button>
                        {$operaciones}
                    </div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbHerramientas" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Versión</th>
                        <th>Fabricante</th>
                        <th>Fecha caducidad</th>
                        <th style="display: none;">Descripción</th>
                        <th style="display: none;">Estado</th>
                        <th style="display: none;">Fecha de creación</th>
                        <th style="display: none;">Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
