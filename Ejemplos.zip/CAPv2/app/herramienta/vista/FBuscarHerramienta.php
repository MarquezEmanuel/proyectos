<?php require_once '../../principal/vistas/header.php'; ?>
<div id="content-wrapper">
    <div id="contenido">
        <div class="container-fluid">
            <div id="seccionSuperior" class="form-row mt-3">
                <div class="col text-left">
                    <h4><i class="fas fa-laptop-code"></i> BUSCAR HERRAMIENTA</h4>
                </div>
            </div>
            <div class="mt-3 mb-4">
                <form method="POST" id="formBuscarHerramienta" name="formBuscarHerramienta">
                    <input type="hidden" name="peticion" id="peticion">
                    <div class="card border-azul-clasico">
                        <div class="card-header bg-azul-clasico text-white">Formulario de búsqueda</div>
                        <div class="card-body">
                            <div class="form-row">
                                <label for="nombre" class="col-2 col-form-label">Nombre:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="nombre" id="nombre" 
                                           maxlength="50" pattern="[A-Za-z0-9]{1,9}"
                                           title="Nombre de la herramienta"
                                           placeholder="Nombre de la herramienta">
                                </div>
                                <label for="version" class="col-2 col-form-label">Version:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="version" id="version" 
                                           maxlength="20"
                                           title="Versión de la herramienta"
                                           placeholder="Versión">
                                </div>
                            </div>
                            <div class="form-row">
                                <label for="fabricante" class="col-2 col-form-label">Fabricante:</label>
                                <div class="col">
                                    <input type="text" class="form-control mb-2" 
                                           name="fabricante" id="fabricante" 
                                           title="Nombre del fabricante"
                                           maxlength="50"
                                           placeholder="Nombre del fabricante">
                                </div>
                                <label for="estado" class="col-2 col-form-label">* Estado:</label>
                                <div class="col">
                                    <select id="estado" name="estado" class="form-control mb-2" required>
                                        <option value="Activa">Activa</option>
                                        <option value="Inactiva">Inactiva</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row mt-2">
                        <div class="col text-right">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-search"></i>  BUSCAR
                            </button>
                            <button type="button" class="btn btn-outline-info" 
                                    id="btnCrearHerramienta" name="btnCrearHerramienta">
                                <i class="fas fa-plus"></i> CREAR
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <br>
            <div id="seccionInferior" class="mt-4 mb-2"></div>
        </div>
        <div class="modal fade bg-dark" style="opacity: 80%" id="ModalCargando" tabindex="0" aria-labelledby="myModalLabel" data-backdrop="static" aria-hidden="false">
            <div class="modal-dialog modal-lg p-4">
                <div class="container p-4">
                    <div class="container mt-4 mb-4">
                        <div class="row mt-4 mb-4">
                            <div class="col text-center" style="font-size: 1.8rem;">
                                <i class="fas fa-spinner fa-3x fa-spin text-white"></i>
                            </div>
                        </div>
                        <div class="row mt-4 mb-4">
                            <div class="col text-center text-white" style="font-size: 1.4rem;">
                                <p> <strong>CARGANDO RESULTADOS</strong></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="ModalCambioEstadoHerramienta" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg border-azul-clasico">
                <div class="modal-content">
                    <div class="modal-header bg-azul-clasico text-white">
                        <h4 class="modal-title text-center" id="mcehTitulo"></h4>
                    </div>
                    <div class="modal-body" id="mcehCuerpo">
                        <form id="formCambiarEstadoHerramienta" name="formCambiarEstadoHerramienta" method="POST">
                            <input type="hidden" name="mcehAccion" id="mcehAccion">
                            <input type="hidden" name="mcehIdHerramienta" id="mcehIdHerramienta">
                            <div class="form-row">
                                <b><p id="mcehNombre" name="mcehNombre"></p></b>
                                <p>&nbsp;Presione <b>GUARDAR</b> para efectuar la operación.</p>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success"
                                name="btnCambiarEstadoHerramienta" id="btnCambiarEstadoHerramienta">
                            <i class="far fa-save"></i> GUARDAR</button>
                        <button type="button" class="btn btn-outline-secondary" 
                                name="btnCancelarCambiarEstado" id="btnCancelarCambiarEstado"
                                data-dismiss="modal">Cancelar</button>
                        <input type='submit' class='btn btn-outline-secondary' 
                               style="display: none;"
                               name="btnRefrescarPantalla" id="btnRefrescarPantalla" value='Aceptar'>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/BuscarHerramientaDesarrollo.js"></script>