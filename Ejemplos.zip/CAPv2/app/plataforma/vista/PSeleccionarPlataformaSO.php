<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\plataforma\controlador\ControladorPlataformaSO;

AutoCargador::cargarModulos();
session_start();

$arreglo = array();
if (isset($_POST['nombre'])) {
    $controlador = new ControladorPlataformaSO();
    $nombre = $_POST['nombre'];
    $resultado = $controlador->buscarParaSeleccionar($nombre);
    if ($resultado[0] == 2) {
        $plataformas = $resultado[1];
        while ($plataforma = sqlsrv_fetch_array($plataformas, SQLSRV_FETCH_ASSOC)) {
            $id = $plataforma["id"];
            $nombrePlataforma = utf8_encode($plataforma["nombre"]);
            $arreglo[] = array('id' => $id, 'text' => $nombrePlataforma);
        }
    }
} else {
    $detalle = "No se recibio nombre para seleccionar plataforma";
    Log::escribirLineaError($detalle);
    Log::guardarActividad('ERROR', 'PLATAFORMAS', 'busqueda', 'PSeleccionarPlataformaSO', '', $detalle);
}

echo json_encode($arreglo);
