<?php
require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\servicio\modelo\Servicio;
use app\utilidad\modelo\GeneradorHTML;

AutoCargador::cargarModulos();

$cuerpo = $boton = "";
if (isset($_POST['idServicio'])) {
    $id = $_POST['idServicio'];
    $servicio = new Servicio($id);
    $resultado = $servicio->obtener();
    if ($resultado[0] == 2) {
        $nombreCorto = $servicio->getNombreCorto();
        $nombreLargo = $servicio->getNombreLargo();
        $descripcion = $servicio->getDescripcion();
        $cuerpo = '
            <input type="hidden" name="idServicio" id="idServicio" value="' . $id . '">
            <div class="form-row">
                <label for="nombreCorto" class="col-sm-2 col-form-label">* Nombre corto:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombreCorto" id="nombreCorto" 
                           maxlength="20"
                           value="' . $nombreCorto . '"
                           placeholder="Nombre corto para el servicio">
                </div>
                <label for="nombre" class="col-sm-2 col-form-label">* Nombre largo:</label>
                <div class="col">
                    <input type="text" class="form-control mb-2" 
                           name="nombreLargo" id="nombreLargo" 
                           maxlength="50"
                           value="' . $nombreLargo . '"
                           placeholder="Nombre del servicio">
                </div>
            </div>
            <div class="form-row">
                <label for="nombre" class="col-sm-2 col-form-label">* Descripción:</label>
                <div class="col">
                    <textarea class="form-control" name="descripcion" id="descripcion" maxlength="500">' . $servicio->getDescripcion() . '</textarea>
                </div>
            </div>';
        $boton = '
            <button type="submit" class="btn btn-success" 
                    id="btnModificarServicio" disabled>
                    <i class="far fa-save"></i> GUARDAR</button>';
    } else {
        $codigo = $resultado[0];
        $mensaje = $resultado[1];
        $cuerpo = GeneradorHTML::getAlertaOperacion($codigo, $mensaje);
    }
} else {
    $mensaje = "No se obtuvo la información desde el formulario";
    $cuerpo = GeneradorHTML::getAlertaOperacion(0, $mensaje);
}
?>
<div class="container-fluid">
    <div id="seccionSuperior" class="form-row mt-3 mb-3">
        <div class="col text-left">
            <h4><i class="fab fa-connectdevelop"></i> MODIFICAR SERVICIO</h4>
        </div>
    </div>
    <div id="seccionResultado"></div>
    <div id="seccionCentral">
        <form id="formModificarServicio" name="formModificarServicio" method="POST">
            <div class="card border-azul-clasico">
                <div class="card-header text-left bg-azul-clasico text-white">Formulario de modificación</div>
                <div class="card-body">
                    <?= $cuerpo; ?>
                </div>
            </div>
            <div class="form-row mt-2 mb-4">
                <div class="col text-right">
                    <?= $boton; ?>
                    <a href="FBuscarServicio.php">
                        <button type="button" class="btn btn-outline-info">
                            <i class="fas fa-search"></i> BUSCAR
                        </button>
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="../js/ModificarServicio.js"></script>