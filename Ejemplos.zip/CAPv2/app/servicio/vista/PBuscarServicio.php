<?php

require_once '../../principal/modelo/Constantes.php';
require_once '../../principal/modelo/AutoCargador.php';

use app\principal\modelo\AutoCargador;
use app\servicio\controlador\ControladorServicio;
use app\utilidad\modelo\GeneradorHTML;

AutoCargador::cargarModulos();

session_start();

$controlador = new ControladorServicio();
if ($_POST['peticion']) {
    /* SE COMPLETO EL FORMULARIO Y SE PRESIONO EL BOTON */
    $nombreCorto = $_POST['nombreCorto'];
    $nombreLargo = $_POST['nombreLargo'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];
    $resultado = $controlador->buscar($nombreCorto, $nombreLargo, $descripcion, $estado);
    $datos = ($nombreCorto) ? "'{$nombreCorto}', " : "";
    $datos .= ($nombreLargo) ? "'{$nombreLargo}', " : "";
    $datos .= ($descripcion) ? "'{$descripcion}', " : "";
    $datos .= ($estado) ? "'{$estado}'" : "";
    $filtro = "Resultado de la búsqueda: " . $datos;
    $_SESSION['BSERVICIOS'] = array($nombreCorto, $nombreLargo, $descripcion, $estado, $datos);
} else {
    if (isset($_SESSION['BSERVICIOS'])) {
        /* SE INGRESO AL FORMULARIO Y HAY UNA BUSQUEDA ALMACENADA */
        $parametros = $_SESSION['BSERVICIOS'];
        $nombreCorto = $parametros[0];
        $nombreLargo = $parametros[1];
        $descripcion = $parametros[2];
        $estado = $parametros[3];
        $filtro = "Ultima búsqueda realizada: " . $parametros[2];
        $resultado = $controlador->buscar($nombreCorto, $nombreLargo, $descripcion, $estado);
        $_SESSION['BSERVICIOS'] = NULL;
    } else {
        /* SE INGRESA POR PRIMERA VEZ */
        $cantidad = 20;
        $estado = 'Activo';
        $resultado = $controlador->buscarUltimosCreados($cantidad, $estado);
        $filtro = "Resumen inicial: Hasta {$cantidad} registros en estado '{$estado}'";
        $_SESSION['BSERVICIOS'] = NULL;
    }
}

if ($resultado[0] == 2) {
    $servicios = $resultado[1];
    $filas = $operaciones = "";
    while ($servicio = sqlsrv_fetch_array($servicios, SQLSRV_FETCH_ASSOC)) {
        $id = $servicio['id'];
        $nombreCorto = utf8_encode($servicio['nombreCorto']);
        $nombreLargo = utf8_encode($servicio['nombreLargo']);
        $descripcion = utf8_encode($servicio['descripcion']);
        $fechaCreacion = isset($servicio['fechaCreacion']) ? date_format($servicio['fechaCreacion'], 'd/m/Y H:i') : "";
        $fechaEdicion = isset($servicio['fechaUltimaEdicion']) ? date_format($servicio['fechaUltimaEdicion'], 'd/m/Y H:i') : "";
        $estado = $servicio['estado'];
        if ($estado == 'Activo') {
            $operaciones = "
                <button class='btn btn-outline-info datos' 
                    name='{$id}' title='Datos básicos: $nombreCorto'>
                    <i class='fas fa-info-circle'></i>
                </button>
                <button class='btn btn-outline-warning editar' 
                    name='{$id}' title='Editar: $nombreCorto'>
                    <i class='far fa-edit'></i>
                </button>
                <button class='btn btn-outline-danger baja' 
                    name='{$id}' title='Dar de baja: $nombreCorto'>
                    <i class='fas fa-trash'></i>
                </button>";
        } else {
            $operaciones = "
                <button class='btn btn-outline-info datos' 
                    name='{$id}' title='Datos básicos: $nombreCorto'>
                    <i class='fas fa-info-circle'></i>
                </button>
                <button class='btn btn-outline-success alta' 
                    name='{$id}' title='Dar de alta: $nombreCorto'>
                        <i class='fas fa-plus-circle'></i>
                </button>";
        }
        $filas .= "
            <tr>
                <td class='align-middle'>{$nombreCorto}</td>
                <td class='align-middle'>{$nombreLargo}</td>
                <td style='display: none;' class='align-middle'>{$descripcion}</td>
                <td style='display: none;'>{$estado}</td>
                <td class='align-middle'>{$fechaCreacion}</td>
                <td class='align-middle'>{$fechaEdicion}</td>
                <td class='text-center align-middle'>
                    <div class='btn-group btn-group-sm'>{$operaciones}</div>
                </td>
            </tr>";
    }
    $cuerpo = '
        <div class="table-responsive mt-4 mb-4">
            <table id="tbServicios" class="table table-bordered table-hover" cellspacing="0" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre corto</th>
                        <th>Nombre largo</th>
                        <th style="display: none;">Descripción</th>
                        <th style="display: none;">Estado</th>
                        <th>Fecha de creación</th>
                        <th>Fecha de edición</th>
                        <th>Operaciones</th>
                    </tr>
                </thead>
                <tbody>' . $filas . '</tbody>
            </table>
        </div>';
} else {
    $cuerpo = GeneradorHTML::getAlertaOperacion($resultado[0], $resultado[1]);
}

echo GeneradorHTML::getCardBusqueda($filtro, $cuerpo);
