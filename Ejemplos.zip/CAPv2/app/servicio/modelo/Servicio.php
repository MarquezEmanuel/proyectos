<?php

namespace app\servicio\modelo;

use app\principal\modelo\SQLServer;
use app\utilidad\modelo\Util;

/**
 * Mapea con la tabla de servicios.
 * 
 * @package app\sitio\modelo.
 * 
 * @author Farinola Santiago <07501@santacruz.net>
 * @author Marquez Emanuel <07489@santacruz.net>
 */
class Servicio {

    /** @var int Identificador del servicio [BIGINT] */
    private $id;

    /** @var string Nombre corto [NVARCHAR(20) NOT NULL] */
    private $nombreCorto;

    /** @var string Nombre largo [NVARCHAR(50) NOT NULL] */
    private $nombreLargo;

    /** @var string Descripcion [NVARCHAR(500) NOT NULL] */
    private $descripcion;

    /** @var string Estado del registro [NVARCHAR(20) NOT NULL] */
    private $estado;

    /** @var string Fecha de creacion del registro [SMALLDATETIME NOT NULL] */
    private $fechaCreacion;

    /** @var string Fecha de ultima edicion del registro [SMALLDATETIME NULL] */
    private $fechaEdicion;

    public function __construct($id = NULL, $nombreCorto = NULL, $nombreLargo = NULL, $descripcion = NULL, $estado = NULL) {
        $this->setId($id);
        $this->setNombreCorto($nombreCorto);
        $this->setNombreLargo($nombreLargo);
        $this->setDescripcion($descripcion);
        $this->setEstado($estado);
    }

    public function getId() {
        return $this->id;
    }

    public function getNombreCorto() {
        return utf8_encode($this->nombreCorto);
    }

    public function getNombreLargo() {
        return utf8_encode($this->nombreLargo);
    }

    public function getDescripcion() {
        return utf8_encode($this->descripcion);
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getFechaCreacion() {
        return $this->fechaCreacion;
    }

    public function getFechaEdicion() {
        return $this->fechaEdicion;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setNombreCorto($nombreCorto) {
        if ($nombreCorto && strlen($nombreCorto) <= 20) {
            $this->nombreCorto = utf8_decode(strtoupper($nombreCorto));
        }
    }

    public function setNombreLargo($nombreLargo) {
        if ($nombreLargo && strlen($nombreLargo) <= 50) {
            $this->nombreLargo = utf8_decode(Util::convertirCamelCase($nombreLargo));
        }
    }

    public function setDescripcion($descripcion) {
        if ($descripcion && strlen($descripcion) <= 500) {
            $this->descripcion = utf8_decode($descripcion);
        }
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setFechaCreacion($fechaCreacion) {
        $this->fechaCreacion = $fechaCreacion;
    }

    public function setFechaEdicion($fechaEdicion) {
        $this->fechaEdicion = $fechaEdicion;
    }

    public function cambiarEstado() {
        if ($this->id && $this->estado) {
            $consulta = "UPDATE srv_servicio SET estado = ?, fechaUltimaEdicion = GETDATE() WHERE id = ?";
            $datos = array(&$this->estado, &$this->id);
            return SQLServer::instancia()->modificar($consulta, $datos);
        }
        return array(0, "No se recibieron los campos obligatorios para cambiar estado del servicio");
    }

    public function crear() {
        if ($this->nombreCorto && $this->nombreLargo && $this->descripcion) {
            $consulta = "INSERT INTO srv_servicio OUTPUT INSERTED.id VALUES (?, ?, ?, 'Activo', GETDATE(), NULL)";
            $datos = array(&$this->nombreCorto, &$this->nombreLargo, &$this->descripcion);
            $resultado = SQLServer::instancia()->insertar($consulta, $datos);
            $this->id = ($resultado[0] == 2) ? $resultado[2] : NULL;
            return $resultado;
        }
        return array(0, "No se recibieron los campos obligatorios para crear el servicio");
    }

    public function modificar() {
        if ($this->id && $this->nombreCorto && $this->nombreLargo && $this->descripcion) {
            $consulta = "UPDATE srv_servicio SET nombreCorto=?, nombreLargo=?, "
                    . "descripcion=?, fechaUltimaEdicion = GETDATE() "
                    . "WHERE id=?";
            $datos = array(&$this->nombreCorto, &$this->nombreLargo, &$this->descripcion, &$this->id);
            $modificacion = SQLServer::instancia()->modificar($consulta, $datos);
            return $modificacion;
        }
        return array(0, "No se recibieron los campos obligatorios para modificar el servicio");
    }

    public function obtener() {
        if ($this->id) {
            $consulta = "SELECT * FROM srv_servicio WHERE id = ?";
            $resultado = SQLServer::instancia()->obtener($consulta, array(&$this->id));
            if ($resultado[0] == 2) {
                $fila = $resultado[1];
                $this->nombreCorto = $fila['nombreCorto'];
                $this->nombreLargo = $fila['nombreLargo'];
                $this->descripcion = $fila['descripcion'];
                $this->estado = $fila['estado'];
                $this->fechaCreacion = $fila['fechaCreacion'];
                $this->fechaEdicion = $fila['fechaUltimaEdicion'];
                return array(2, "Se obtuvo la información del servicio correctamente");
            }
            return $resultado;
        }
        return array(0, "No se pudo hacer referencia al servicio");
    }

    public function toString() {
        $servicio = ($this->id) ? "{{$this->getId()}," : "{0,";
        $servicio .= ($this->nombreCorto) ? "'{$this->getNombreCorto()}'," : "'',";
        $servicio .= ($this->nombreLargo) ? "'{$this->getNombreLargo()}'," : "'',";
        $servicio .= ($this->estado) ? "'{$this->getEstado()}'}" : "''}";
        return $servicio;
    }

}
